/* 

                          Firewall Builder

                 Copyright (C) 2002 NetCitadel, LLC

  Author:  Vadim Kurland     vadim@vk.crocodile.org

  $Id: PolicyCompiler_ipfw.cpp,v 1.1 2004/05/11 06:06:29 vkurland Exp $

  This program is free software which we release under the GNU General Public
  License. You may redistribute and/or modify this program under the terms
  of that license as published by the Free Software Foundation; either
  version 2 of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
 
  To get a copy of the GNU General Public License, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#include "config.h"

#include "PolicyCompiler_ipfw.h"

#include "fwbuilder/FWObjectDatabase.h"
#include "fwbuilder/RuleElement.h"
#include "fwbuilder/IPService.h"
#include "fwbuilder/ICMPService.h"
#include "fwbuilder/TCPService.h"
#include "fwbuilder/UDPService.h"
#include "fwbuilder/Policy.h"
#include "fwbuilder/Interface.h"
#include "fwbuilder/Firewall.h"

#include <iostream>

#include <assert.h>

using namespace libfwbuilder;
using namespace fwcompiler;
using namespace std;

string PolicyCompiler_ipfw::myPlatformName() { return "ipfw"; }

int PolicyCompiler_ipfw::prolog()
{
    int n= PolicyCompiler_pf::prolog();

    FWObject    *grp;
    anytcp=TCPService::cast(dbcopy->create(TCPService::TYPENAME,false) );
    anytcp->setId(ANY_TCP_OBJ_ID);
    dbcopy->add(anytcp,false);
    cacheObj(anytcp); // to keep cache consistent

    anyudp=UDPService::cast(dbcopy->create(UDPService::TYPENAME,false) );
    anyudp->setId(ANY_UDP_OBJ_ID);
    dbcopy->add(anyudp,false);
    cacheObj(anyudp); // to keep cache consistent

    anyicmp=ICMPService::cast(dbcopy->create(ICMPService::TYPENAME,false) );
    anyicmp->setId(ANY_ICMP_OBJ_ID);
    dbcopy->add(anyicmp,false);
    cacheObj(anyicmp); // to keep cache consistent


    return n;
}

/*
 *  (this is a virtual method). We do not want to expand a firewall
 *  object that own the policy we are processing, because we can use
 *  address 'me' in ipfw rules.
 */
void PolicyCompiler_ipfw::_expandAddr(Rule *rule,FWObject *s) 
{
    RuleElement *re=RuleElement::cast(s);

    if (re!=NULL && re->size()==1 )
    {
        FWObject *o=re->front();
        if (FWReference::cast(o)!=NULL) o=getCachedObj(o->getStr("ref"));

        if (o->getId()==fw->getId()) return;
    }
    Compiler::_expandAddr(rule,s);
}

bool PolicyCompiler_ipfw::expandAnyService::processNext()
{
    PolicyRule *rule=getNext(); if (rule==NULL) return false;

    RuleElementSrv *srv=rule->getSrv();
    FWOptions *ruleopt =rule->getOptionsObject();

    if (srv->isAny() && ! ruleopt->getBool("stateless") && rule->getAction()==PolicyRule::Accept) 
    {
	PolicyRule *r= PolicyRule::cast(
	    compiler->dbcopy->create(PolicyRule::TYPENAME,false) );
	compiler->temp_ruleset->add(r);
	r->duplicate(rule);
	RuleElementSrv *nsrv=r->getSrv();
	nsrv->clearChildren();
	nsrv->addRef(compiler->getCachedObj(ANY_ICMP_OBJ_ID));
	tmp_queue.push_back(r);

	r= PolicyRule::cast(
	    compiler->dbcopy->create(PolicyRule::TYPENAME,false) );
	compiler->temp_ruleset->add(r);
	r->duplicate(rule);
	nsrv=r->getSrv();
	nsrv->clearChildren();
	nsrv->addRef(compiler->getCachedObj(ANY_TCP_OBJ_ID));
	tmp_queue.push_back(r);

	r= PolicyRule::cast(
	    compiler->dbcopy->create(PolicyRule::TYPENAME,false) );
	compiler->temp_ruleset->add(r);
	r->duplicate(rule);
	nsrv=r->getSrv();
	nsrv->clearChildren();
	nsrv->addRef(compiler->getCachedObj(ANY_UDP_OBJ_ID));
	tmp_queue.push_back(r);

	r= PolicyRule::cast(
	    compiler->dbcopy->create(PolicyRule::TYPENAME,true) );
	compiler->temp_ruleset->add(r);
	r->duplicate(rule);
	FWOptions *ruleopt =r->getOptionsObject();
	ruleopt->setBool("stateless",true);
	tmp_queue.push_back(r);

    } else
	tmp_queue.push_back(rule);

    return true;
}

bool PolicyCompiler_ipfw::doSrcNegation::processNext()
{
    PolicyRule *rule=getNext(); if (rule==NULL) return false;

    RuleElementSrc *src=rule->getSrc();

    if (src->getNeg()) {
        RuleElementSrc *nsrc;
	PolicyRule     *r;

	r= PolicyRule::cast(compiler->dbcopy->create(PolicyRule::TYPENAME,false) );
	compiler->temp_ruleset->add(r);
	r->duplicate(rule);
	r->setAction(PolicyRule::Continue);
	r->setLogging(false);
        nsrc=r->getSrc();
        nsrc->setNeg(false);
	r->setBool("quick",false);
        r->setBool("skip_check_for_duplicates",true);
	tmp_queue.push_back(r);

	r= PolicyRule::cast(compiler->dbcopy->create(PolicyRule::TYPENAME,false) );
	compiler->temp_ruleset->add(r);
	r->duplicate(rule);
        nsrc=r->getSrc();
        nsrc->setNeg(false);
	nsrc->clearChildren();
	nsrc->setAnyElement();
	r->setBool("quick",true);
        r->setBool("skip_check_for_duplicates",true);
	tmp_queue.push_back(r);

	return true;
    }
    tmp_queue.push_back(rule);
    return true;
}

bool PolicyCompiler_ipfw::doDstNegation::processNext()
{
    PolicyRule *rule=getNext(); if (rule==NULL) return false;

    RuleElementDst *dst=rule->getDst();

    if (dst->getNeg()) {
        RuleElementDst *ndst;
	PolicyRule     *r;

	r= PolicyRule::cast(compiler->dbcopy->create(PolicyRule::TYPENAME,false) );
	compiler->temp_ruleset->add(r);
	r->duplicate(rule);
	r->setAction(PolicyRule::Continue);
	r->setLogging(false);
        ndst=r->getDst();
        ndst->setNeg(false);
	r->setBool("quick",false);
        r->setBool("skip_check_for_duplicates",true);
	tmp_queue.push_back(r);

	r= PolicyRule::cast(compiler->dbcopy->create(PolicyRule::TYPENAME,false) );
	compiler->temp_ruleset->add(r);
	r->duplicate(rule);
        ndst=r->getDst();
        ndst->setNeg(false);
	ndst->clearChildren();
	ndst->setAnyElement();
	r->setBool("quick",true);
        r->setBool("skip_check_for_duplicates",true);
	tmp_queue.push_back(r);

	return true;
    }
    tmp_queue.push_back(rule);
    return true;
}

bool PolicyCompiler_ipfw::doSrvNegation::processNext()
{
    PolicyRule *rule=getNext(); if (rule==NULL) return false;

    RuleElementSrv *srv=rule->getSrv();

    if (srv->getNeg()) {
	throw FWException(_("Negation in Srv is not implemented. Rule: ")+rule->getLabel());
	return false;
    }
    tmp_queue.push_back(rule);
    return true;
}

void PolicyCompiler_ipfw::specialCaseWithDynInterface::dropDynamicInterface(RuleElement *re)
{
    list<FWObject*> cl;
    for (list<FWObject*>::iterator i1=re->begin(); i1!=re->end(); ++i1) 
    {
        FWObject *o   = *i1;
        FWObject *obj = o;
        if (FWReference::cast(o)!=NULL) obj=compiler->getCachedObj(o->getStr("ref"));
        Interface  *ifs   =Interface::cast( obj );

        if (ifs!=NULL && (ifs->isDyn() || ifs->isUnnumbered())) continue;
        cl.push_back(obj);
    }
    if (!cl.empty()) 
    {
        re->clearChildren();
        for (list<FWObject*>::iterator i1=cl.begin(); i1!=cl.end(); ++i1)  
            re->addRef( (*i1) );
    }
}

bool PolicyCompiler_ipfw::specialCaseWithDynInterface::processNext()
{
    PolicyRule *rule=getNext(); if (rule==NULL) return false;

    dropDynamicInterface( rule->getDst() );
    dropDynamicInterface( rule->getSrc() );
    tmp_queue.push_back(rule);
    return true;
}


PolicyCompiler_ipfw::calculateNum::calculateNum(const std::string &n) : PolicyRuleProcessor(n)
{
    ipfw_num=0;
}

bool PolicyCompiler_ipfw::calculateNum::processNext()
{
    PolicyRule *rule;

    slurp();
    if (tmp_queue.size()==0) return false;

    for (deque<Rule*>::iterator k=tmp_queue.begin(); k!=tmp_queue.end(); ++k) 
    {
        PolicyRule *r = PolicyRule::cast( *k );

        ipfw_num += 10;
        r->setInt("ipfw_num", ipfw_num );
    }


    for (deque<Rule*>::iterator k=tmp_queue.begin(); k!=tmp_queue.end(); ++k) 
    {
        PolicyRule *r = PolicyRule::cast( *k );
        int    current_position=r->getPosition();
        if (r->getAction()==PolicyRule::Continue) 
        {
            r->setAction(PolicyRule::Skip);
            
            deque<Rule*>::iterator j=k;
            ++j;
            PolicyRule *r2;
            for ( ; j!=tmp_queue.end(); ++j) 
            {
                r2 = PolicyRule::cast( *j );

                if (r2->getPosition()!=current_position)
                {
                    r->setInt("skip_to", r2->getInt("ipfw_num") );
                    break;
                }
            }
        }
    }

    return true;
}


bool PolicyCompiler_ipfw::checkForKeepState::processNext()
{
    PolicyRule *rule=getNext(); if (rule==NULL) return false;
    tmp_queue.push_back(rule);

    Service   *srv=compiler->getFirstSrv(rule);    assert(srv);
    FWOptions *ruleopt =rule->getOptionsObject();

    if (! ICMPService::isA(srv) && 
        ! UDPService::isA(srv)  &&
        ! TCPService::isA(srv) )    ruleopt->setBool("stateless",true);

    return true;
}

bool PolicyCompiler_ipfw::eliminateDuplicateRules::processNext()
{
    PolicyCompiler *pcomp=dynamic_cast<PolicyCompiler*>(compiler);
    PolicyRule *rule=getNext(); if (rule==NULL) return false;

    if ( ! rule->getBool("skip_check_for_duplicates"))
    {
        for (deque<PolicyRule*>::iterator i=rules_seen_so_far.begin(); i!=rules_seen_so_far.end(); ++i)
        {
            PolicyRule *r=(*i);
            if ( r->getBool("skip_check_for_duplicates") ) continue;
            if (r->getInterfaceId()==rule->getInterfaceId() &&
                r->getAction()==rule->getAction()   &&
                r->getLogging()==rule->getLogging() &&
                pcomp->cmpRules(*r,*rule) ) 
            {
//                cout << "---------------------------------------" << endl;
//                cout << pcomp->debugPrintRule(r) << endl;
//                cout << pcomp->debugPrintRule(rule) <<  endl;
                return true;
            }
        }
    }
    tmp_queue.push_back(rule);
    rules_seen_so_far.push_back(rule);

    return true;
}


void PolicyCompiler_ipfw::compile()
{
    cout << " Compiling policy for " << fw->getName() << " ..." <<  endl << flush;

    try {

	Compiler::compile();

	addDefaultPolicyRule();
        bool check_for_recursive_groups=true;

        if ( fw->getOptionsObject()->getBool ("check_shading") ) 
        {
            add( new Begin                       (" Detecting rule shadowing"                ) );
            add( new printTotalNumberOfRules     (                                         ) );

            add( new recursiveGroupsInSrc(       "check for recursive groups in SRC"     ) );
            add( new recursiveGroupsInDst(       "check for recursive groups in DST"     ) );
            add( new recursiveGroupsInSrv(       "check for recursive groups in SRV"     ) );
            check_for_recursive_groups=false;

            add( new ExpandGroups                ("expand groups"                          ) );
            add( new eliminateDuplicatesInSRC    ("eliminate duplicates in SRC"            ) );
            add( new eliminateDuplicatesInDST    ("eliminate duplicates in DST"            ) );
            add( new eliminateDuplicatesInSRV    ("eliminate duplicates in SRV"            ) );
            add( new ExpandMultipleAddressesInSRC("expand objects with multiple addresses in SRC" ) );
            add( new ExpandMultipleAddressesInDST("expand objects with multiple addresses in DST" ) );
            add( new ConvertToAtomic             ("convert to atomic rules"                ) );
            add( new DetectShadowing             ("Detect shadowing"                         ) );
            add( new simplePrintProgress         (                                         ) );

            runRuleProcessors();
            deleteRuleProcessors();
        }


        add( new Begin(                       "Begin processing"                                ) );
        add( new printTotalNumberOfRules() );

        if (check_for_recursive_groups)
        {
            add( new recursiveGroupsInSrc(   "check for recursive groups in SRC"     ) );
            add( new recursiveGroupsInDst(   "check for recursive groups in DST"     ) );
            add( new recursiveGroupsInSrv(   "check for recursive groups in SRV"     ) );
        }

        add( new emptyGroupsInSrc(           "check for empty groups in SRC"         ) );
        add( new emptyGroupsInDst(           "check for empty groups in DST"         ) );
        add( new emptyGroupsInSrv(           "check for empty groups in SRV"         ) );

        add( new doSrcNegation(               "process negation in Src"                         ) );
        add( new doDstNegation(               "process negation in Dst"                         ) );
        add( new doSrvNegation(               "process negation in Srv"                         ) );
        add( new ExpandGroups(                "expand groups"                                   ) );
        add( new eliminateDuplicatesInSRC(    "eliminate duplicates in SRC"                     ) );
        add( new eliminateDuplicatesInDST(    "eliminate duplicates in DST"                     ) );
        add( new eliminateDuplicatesInSRV(    "eliminate duplicates in SRV"                     ) );

        add( new splitIfFirewallInSrc(        "split rule if firewall is in Src"                ) );
        add( new splitIfFirewallInDst(        "split rule if firewall is in Dst"                ) );
        add( new fillDirection(               "determine directions"                            ) );
        add( new ExpandMultipleAddresses(     "expand objects with multiple addresses"          ) );
        add( new checkForDynamicInterfacesOfOtherObjects( "check for dynamic interfaces of other hosts and firewalls" ) );
        add( new MACFiltering(                "verify for MAC address filtering"                ) );
        add( new checkForUnnumbered(          "check for unnumbered interfaces"                 ) );
        add( new specialCaseWithDynInterface( "check for a special cases with dynamic interface") );
        add( new addressRanges(               "expand address range objects"                    ) );
        add( new splitServices(               "split rules with different protocols"            ) );
        add( new separateTCPWithFlags(        "separate TCP services with flags"                ) );
        add( new verifyCustomServices(        "verify custom services for this platform"        ) );
        add( new SpecialServices(             "check for special services"                      ) );
//        add( new expandAnyService(            "expand ANY service for stateful rules"           ) );
        add( new ConvertToAtomicForAddresses( "convert to atomic rules in SRC and DST"          ) );
        add( new checkForZeroAddr(            "check for zero addresses"                        ) );

	add( new calculateNum(                "calculate rule numbers "                         ) );
        add( new convertInterfaceIdToStr(    "prepare interface assignments"         ) );
        add( new PrintRule(                   "generate ipf code"                               ) );
        add( new simplePrintProgress() );

        runRuleProcessors();


    } catch (FWException &ex) {
	error(ex.toString());
	exit(1);
    }
}

string PolicyCompiler_ipfw::debugPrintRule(Rule *r)
{
    PolicyRule *rule=PolicyRule::cast(r);
    FWOptions  *ruleopt =rule->getOptionsObject();

    string  iface = rule->getInterfaceId();
    if (iface!="") {
	Interface *rule_iface = getCachedFwInterface( iface );
        iface=" intf: "+rule_iface->getName();
    }
    string s= PolicyCompiler::debugPrintRule(rule)+" "+iface;

    return s;
}


void PolicyCompiler_ipfw::epilog()
{
    cout << _(" Policy compiled successfully \n") << flush;
}
