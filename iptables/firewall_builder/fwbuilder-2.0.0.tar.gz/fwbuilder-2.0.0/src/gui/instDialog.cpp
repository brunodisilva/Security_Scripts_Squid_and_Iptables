/* 

                          Firewall Builder

                 Copyright (C) 2004 NetCitadel, LLC

  Author:  Vadim Kurland     vadim@fwbuilder.org

  $Id: instDialog.cpp,v 1.36 2004/07/25 05:51:55 vkurland Exp $

  This program is free software which we release under the GNU General Public
  License. You may redistribute and/or modify this program under the terms
  of that license as published by the Free Software Foundation; either
  version 2 of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
 
  To get a copy of the GNU General Public License, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#include "../../config.h"
#include "global.h"
#include "utils.h"

#include "instDialog.h"
#include "instConf.h"
#include "FWBSettings.h"

#include <qcheckbox.h>
#include <qlineedit.h>
#include <qtextbrowser.h>
#include <qtextedit.h>
#include <qtimer.h>
#include <qfiledialog.h>
#include <qpushbutton.h>
#include <qlabel.h>
#include <qprogressbar.h>
#include <qprocess.h>
#include <qapplication.h>
#include <qeventloop.h>
#include <qfile.h>
#include <qmessagebox.h>

#include "fwbuilder/Resources.h"
#include "fwbuilder/FWObjectDatabase.h"
#include "fwbuilder/Firewall.h"
#include "fwbuilder/XMLTools.h"
#include "fwbuilder/Policy.h"
#include "fwbuilder/InterfacePolicy.h"
#include "fwbuilder/NAT.h"
#include "fwbuilder/Interface.h"

#ifndef _WIN32
#  include <unistd.h>     // for access(2) and getdomainname
#endif

#include <errno.h>
#include <iostream>

using namespace std;
using namespace libfwbuilder;

class UpgradePredicate: public XMLTools::UpgradePredicate
{
    QTextBrowser *t;
    public:
    UpgradePredicate(QTextBrowser *_t) { t=_t; }
    virtual bool operator()(const string &msg) const 
    { 
	t->append( QObject::tr("Data file has been created in the old version of Firewall Builder. Use fwbuilder GUI to convert it.\n") );
	return false;
    }
};


char   *instDialog::normal_prompt="> ";
char   *instDialog::fwb_prompt="--**--**--";
char   *instDialog::enable_prompt="# ";
char   *instDialog::pwd_prompt="'s password: ";
char   *instDialog::epwd_prompt="Password: ";
char   *instDialog::scp_pwd_prompt="Password: ";
char   *instDialog::ssh_pwd_prompt="'s password: ";
char   *instDialog::ssoft_prompt1="]# ";
char   *instDialog::ssoft_prompt2=" # ";
char   *instDialog::ssoft_config_prompt="> ";
char   *instDialog::sudo_pwd_prompt="Password:";
char   *instDialog::putty_pwd_prompt="Password: ";
char   *instDialog::passphrase_prompt="Enter passphrase for key ";

char   *instDialog::OSSHerrors1[]={   // errors valid on the login phase
    "Permission denied"    ,
    "Invalid password"     ,
    "Sorry, try again"     ,
    "Too many authentication failures",
    NULL
};

char   *instDialog::OSSHerrors2[]={   // errors valid on the login phase
    "No such file or directory",
    "Cannot allocate memory",
    NULL
};

char   *instDialog::PIXerrors1[]={   // errors valid on the login phase
    "Permission denied"    ,
    "Invalid password"     ,
    "Access denied"        ,
    NULL
};

char   *instDialog::PIXerrors2[]={   // errors valid after login before 'enable'
    "Invalid password"     ,
    "ERROR: "              ,
//    "Type help"            ,
    "Not enough arguments" ,
    "cannot find"          ,
    NULL
};

char   *instDialog::PIXerrors3[]={   // errors valid in 'enable' mode
    "ERROR: "              ,
    "Type help"            ,
    "Not enough arguments" ,
    "Invalid"              ,
    "invalid"              ,
    "cannot find"          ,
    "An object-group with the same id but different type" ,
    NULL
};

char  *instDialog::newKeyOpenSSH  ="Are you sure you want to continue connecting (yes/no)?";
char  *instDialog::newKeyPlink    ="Store key in cache? (y/n)";
char  *instDialog::newKeyVsh      ="Accept and save? (y/n)";
char  *instDialog::fingerprintPrompt="key fingerprint is";




instDialog::instDialog(instConf *_c)
{
    ready=false;
    cnf=_c;

    proc=NULL;
    eloop=NULL;
    config_file=NULL;
    confScript="";

/* read manifest from the conf file */

    QFile cf(  cnf->wdir+"/"+cnf->conffile );
    if (cf.open( IO_ReadOnly ) )
    {
        QTextStream stream(&cf);
        QString line;
        while (!stream.eof())
        {
            line    = stream.readLine();
            int pos = -1;
            if ( (pos=line.find(MANIFEST_MARKER))!=-1 )
            {
                int n = pos + QString(MANIFEST_MARKER).length();
                if (line[n]=='*')  confScript=line.mid(n+2);
                else               confFiles.push_back( line.mid(n+2) );
            }
            line = "";
        }
        cf.close();
    } else
    {
        QMessageBox::critical(this, "Firewall Builder",
                 tr("File %1 not found.").arg(cnf->wdir+"/"+cnf->conffile),
                 tr("&Continue") );
        return;
    }

    if (confScript.isEmpty()) confScript=cnf->conffile;


    newKeyMsg = tr("You are connecting to the firewall <b>'%1'</b> for the first time. It has provided you its identification in a form of its host public key. The fingerprint of the host public key is: \"%2\" You can save the host key to the local database by pressing YES, or you can cancel connection by pressing NO. You should press YES only if you are sure you are really connected to the firewall <b>'%3'</b>.");


    pwd->setEchoMode( QLineEdit::Password );
    epwd->setEchoMode( QLineEdit::Password );

    setHelpEnabled( page(0), false );
    setHelpEnabled( page(1), false );

    if (cnf->fwobj!=NULL)
    {
        QString fwobjname=cnf->fwobj->getName().c_str();
        setTitle( page(0), title( page(0) ).arg(fwobjname) );
        setTitle( page(1), title( page(1) ).arg(fwobjname) );
    }

    cnf->incremental=st->readBoolEntry("/FirewallBuilder2/Installer/incr"    );
    cnf->save_diff  =st->readBoolEntry("/FirewallBuilder2/Installer/savediff");
    cnf->dry_run    =st->readBoolEntry("/FirewallBuilder2/Installer/dryrun"  );
    cnf->quiet      =st->readBoolEntry("/FirewallBuilder2/Installer/quiet"   );
    cnf->verbose    =st->readBoolEntry("/FirewallBuilder2/Installer/verbose" );
    cnf->stripComments=st->readBoolEntry("/FirewallBuilder2/Installer/stripComments" );

/* TODO: set cnf->pgm to ssh path here */

    QString platform=cnf->fwobj->getStr("platform").c_str();

    if (platform!="pix")
    {
        incr->hide();
        test->hide();
        saveDiff->hide();
        backupConfigFile->hide();
        backupConfigFileLbl->hide();
        epwd->hide();
        epwdLbl->hide();
    } else
    {
        incr->show();
        test->show();
        saveDiff->show();
        backupConfigFile->show();
        backupConfigFileLbl->show();
        epwd->show();
        epwdLbl->show();
    }

    if (cnf->fwobj->getStr("host_OS")=="linksys" || platform=="pix")
    {
        progressBar->show();
        stripComments->show();
    } else
    {
        progressBar->hide();
        stripComments->hide();
    }
#ifdef _WIN32
/* TODO: work on diff on windows
 *
 * I am having difficulties with running diff on windows so this
 * feature is disabled there. The diff executable that I have is a
 * console exec so it opens black MsDOS window when executed, even as
 * a background application. This is ugly. I guess I am going to have
 * to recompile it, possibly including its code into my code
 * tree. Will figure this out later.
 
    incr->setChecked( false );
    incr->hide();
    saveDiff->setChecked( false );
    saveDiff->hide();
 */
#endif

    uname->setFocus();
    uname->setText( cnf->user );
    incr->setChecked( cnf->incremental );
    test->setChecked( cnf->dry_run );
    backupConfigFile->setText( cnf->backup_file );
    saveDiff->setChecked( cnf->save_diff );
    altAddress->setText( cnf->maddr );
    quiet->setChecked( cnf->quiet );
    verbose->setChecked( cnf->verbose );
    stripComments->setChecked( cnf->stripComments );

/* we initialize these in FWBSettings constructor on Unix, but do not
 * do it on Windows since there is no standard ssh package there. User
 * is supposed to fill these in in the Preferences dialog, otherwise
 * they can't use installer
 */

    ssh=st->getSSHPath();
    scp=st->getSCPPath();

    if ( access(cnf->diff_pgm.latin1(), F_OK|X_OK)!=0 )
    {
        cerr << "could not access " << cnf->diff_pgm << endl;

        incr->setChecked(false);
        incr->setEnabled(false);
        saveDiff->setChecked(false);
        saveDiff->setEnabled(false);
    }


    try
    {
        if (cnf->fwobj!=NULL && ! cnf->fwbfile.isEmpty())
        {
            cnf->maddr = cnf->fwobj->getManagementAddress().toString().c_str();
//            altAddress->setText( cnf->maddr );
        }

        

        setReady(true);

    } catch(FWException &ex)
    {
        setReady(false);
        showPage( page(1) );
        progressDisplay->append( ex.toString().c_str() );
    } catch (std::string s) {
        setReady(false);
        showPage( page(1) );
        progressDisplay->append( s.c_str() );
    } catch (std::exception ex) {
        setReady(false);
        showPage( page(1) );
        progressDisplay->append( ex.what() );
    } catch (...) {
        setReady(false);
        showPage( page(1) );
        progressDisplay->append( QObject::tr("Unsupported exception") );
    }
}

instDialog::~instDialog()
{

    st->writeEntry("/FirewallBuilder2/Installer/incr",    cnf->incremental);
    st->writeEntry("/FirewallBuilder2/Installer/savediff",cnf->save_diff  );
    st->writeEntry("/FirewallBuilder2/Installer/dryrun"  ,cnf->dry_run    );
    st->writeEntry("/FirewallBuilder2/Installer/quiet",   cnf->quiet      );
    st->writeEntry("/FirewallBuilder2/Installer/verbose", cnf->verbose    );
    st->writeEntry("/FirewallBuilder2/Installer/stripComments", cnf->stripComments    );
}

void instDialog::append(const QString &s)
{
    progressDisplay->append(s);
}

void instDialog::append(const char *s)
{
    progressDisplay->append(s);
}

QString instDialog::getUName() { return uname->text(); }
QString instDialog::getPWD()   { return pwd->text();   }
QString instDialog::getEPWD()  { return epwd->text();  }

void instDialog::summary()
{
    append( "<hr>" + QObject::tr("<b>Summary:</b>") );
    append( QObject::tr("* firewall name : %1")
            .arg(cnf->fwobj->getName().c_str()) );
    append( QObject::tr("* user name : %1")
            .arg(cnf->user) );
    append( QObject::tr("* management address : %1")
            .arg(cnf->maddr) );
    append( QObject::tr("* platform : %1")
            .arg(cnf->fwobj->getStr("platform").c_str())  );
    append( QObject::tr("* host OS : %1")
            .arg(cnf->fwobj->getStr("host_OS").c_str()) );
    append( QObject::tr("* Loading configuration from file %1")
            .arg(cnf->fwbfile));

    if (cnf->incremental)
    {
        append( QObject::tr("* Incremental install"));
    }
    if (cnf->save_diff && cnf->incremental)
    {
        append(
QObject::tr("* Configuration diff will be saved in file %1").arg(cnf->diff_file));
    }
    if (cnf->dry_run)
    {
        append(
QObject::tr("* Test run, commands will not be executed on the firewall"));
    }
    append("<hr>\n");
}

/*
 * do not call this method from state machine functions, always
 * schedule it using timer with 0 interval
 */
QString instDialog::cmd(QProcess *proc,const QString &cmd)
{
    cmdBuffer="";
    stdoutBuffer="";

    proc->writeToStdin( cmd  );
    proc->writeToStdin( "\n" );

    state=EXECUTING_COMMAND;
    QApplication::eventLoop()->enterLoop();

    return stdoutBuffer;
}



void instDialog::selected(const QString &title)
{
    int p = indexOf( currentPage() );

    if (p==0 && proc!=NULL)
    {
        disconnect(proc,SIGNAL(readyReadStdout()),this,SLOT(readFromStdout() ) );
        disconnect(proc,SIGNAL(readyReadStderr()),this,SLOT(readFromStderr() ) );
        disconnect(proc,SIGNAL(processExited()),  this,SLOT(processExited() ) );

        proc->tryTerminate();
        QTimer::singleShot( 2000, proc, SLOT(kill()) );
        proc=NULL;

        if (config_file!=NULL)
        {
            config_file->close();
            delete config_file;
            config_file=NULL;
        }
        return;
    }

    if (p==1 && ready)
    {
/* change of the page when flag ready is 'true' means we should start
 * operation */

        cnf->incremental = incr->isChecked();
        cnf->dry_run     = test->isChecked();
        cnf->backup_file = backupConfigFile->text();
        cnf->backup      = !cnf->backup_file.isEmpty();
        cnf->save_diff   = saveDiff->isChecked();
	QString aaddr    = altAddress->text();
	if (!aaddr.isEmpty())
	{
/* alternative address can also be putty session name. In any case,
 * leave it up to ssh to resolve it and signal an error if it can't be
 * resolved ( Putty session name does not have to be in DNS at all ).
 */
            cnf->maddr = aaddr;
	} else
            cnf->maddr = cnf->fwobj->getManagementAddress().toString().c_str();

//        cnf->maddr         = altAddress->text();
        cnf->user          = uname->text();
        cnf->pwd           = pwd->text();
        cnf->epwd          = epwd->text();
        cnf->quiet         = quiet->isChecked();
        cnf->verbose       = verbose->isChecked();
        cnf->stripComments = stripComments->isChecked();

/* check for a common error when multiple interfaces are marked as 'management' */

        int nmi = 0;
        list<FWObject*> ll = cnf->fwobj->getByType(Interface::TYPENAME);
        for (FWObject::iterator i=ll.begin(); i!=ll.end(); i++)
        {
            Interface *intf = Interface::cast( *i );
            if (intf->isManagement()) nmi++;
        }
        if (nmi>1)
        {
	   append(
		QObject::tr("Only one interface of the firewall '%1' must be marked as management interface.")
		.arg(cnf->fwobj->getName().c_str()).latin1() );
	    return;
        }
        if (nmi==0)
        {
	   append(
		QObject::tr("One of the interfaces of the firewall '%1' must be marked as management interface.")
		.arg(cnf->fwobj->getName().c_str()).latin1() );
	    return;
        }
        if ((cnf->maddr == "" || cnf->maddr == "0.0.0.0") &&
            altAddress->text().isEmpty())
	{
	   append(
               QObject::tr("Management interface does not have IP address, can not communicate with the firewall.") );
	    return;
	}

	progressDisplay->setText("");
        progressBar->setProgress(0);

        summary();

        QStringList  args;

        if (cnf->fwobj->getStr("platform")=="pix" ||
            cnf->fwobj->getStr("host_OS")=="linksys")
        {
#ifdef _WIN32
            args.push_back(ssh);

            if (ssh.find("plink.exe")!=-1) args.push_back("-ssh");
            args.push_back("-pw");
            args.push_back(cnf->pwd);
#else
            args.push_back(argv0.c_str());
            args.push_back("-X");   // fwbuilder works as ssh wrapper
            args.push_back("-t");
            args.push_back("-t");
#endif
            args.push_back("-v");
            if (!cnf->user.isEmpty())
                args.push_back(cnf->user + "@" + cnf->maddr);
            else
                args.push_back(cnf->maddr);

            phase=1;
            lineCounter=0;
            runSSH( args );

        } else
        {
            initiateCopy( confScript );
        }
    }
}

void instDialog::initiateCopy(const QString &file)
{
    QStringList args;
#ifdef _WIN32
    args.push_back(scp);
    args.push_back("-pw");
    args.push_back(cnf->pwd);
#else
    args.push_back(argv0.c_str());
    args.push_back("-Y");   // fwbuilder works as scp wrapper
#endif
    if (cnf->verbose) args.push_back("-v");
    args.push_back("-q");

/* do not change destination, we do chmod on it later */
    args.push_back( cnf->wdir+"/"+file);

    if (!cnf->user.isEmpty())
        args.push_back(cnf->user + "@" + cnf->maddr + ":" + cnf->fwdir);
    else
        args.push_back(cnf->maddr + ":" + cnf->fwdir);

    phase=1;
    lineCounter=0;
    runSSH( args );
}

void instDialog::runSSH(const QStringList &args)
{
#ifdef _WIN32
    if (cnf->verbose)
    {
        QStringList a1 = args;

        for (QStringList::iterator i=a1.begin(); i!=a1.end(); i++)
        {
            if ( (*i)=="-pw" )
            {
                i++;
                *i = "XXXXXX";
                break;
            }
        }
        QString s=a1.join(" ");
        progressDisplay->append( tr("Running command '%1'\n\n").arg(s) );
    }
#endif

    proc = new QProcess();
    proc->setCommunication(
        QProcess::Stdin|QProcess::Stdout|QProcess::Stderr|QProcess::DupStderr);

    connect(proc,SIGNAL(readyReadStdout()), this,  SLOT(readFromStdout() ) );
    connect(proc,SIGNAL(readyReadStderr()), this,  SLOT(readFromStderr() ) );
    connect(proc,SIGNAL(processExited()),   this,  SLOT(processExited() ) );

    QString cmd;

    for (QStringList::const_iterator i=args.begin(); i!=args.end(); ++i)
    {
        proc->addArgument( *i );
        cmd += *i;
    }

#ifdef _WIN32
    env.push_back( QString("APPDATA=")+getenv("APPDATA") );
    env.push_back( QString("HOMEPATH=")+getenv("HOMEPATH") );
    env.push_back( QString("HOMEDRIVE=")+getenv("HOMEDRIVE") );
    env.push_back( QString("ProgramFiles=")+getenv("ProgramFiles") );
/* NB: putty absolutely needs SystemRoot env. var. */
    env.push_back( QString("SystemRoot=")+getenv("SystemRoot") );
    env.push_back( QString("TEMP=")+getenv("TEMP") );
    env.push_back( QString("USERNAME=")+getenv("USERNAME") );
    env.push_back( QString("USERPROFILE=")+getenv("USERPROFILE") );

    env.push_back( QString("HOME=")+getenv("HOMEPATH") );
    env.push_back( QString("USER=")+getenv("USERNAME") );
#else
    env.push_back( QString("HOME=")+getenv("HOME") );
    env.push_back( QString("USER=")+getenv("USER") );
#endif

    env.push_back( QString("TMP=")+getenv("TMP") );
    env.push_back( QString("PATH=")+getenv("PATH") );
    env.push_back( QString("SSH_AUTH_SOCK=")+getenv("SSH_AUTH_SOCK") );

//    progressDisplay->moveCursor( QTextEdit::MoveEnd , false );
//    progressDisplay->insert( tr("Running command %1\n").arg(cmd) );

    if ( ! proc->start(&env))
    {
        progressDisplay->append( tr("Failed to start ssh") );
        return;
    }

    logged_in = false;
    enable    = false;
    configure = false;
    state     = NONE;
}

void instDialog::readFromStdout()
{
    QString s=QString(proc->readStdout());
    stdoutBuffer=stdoutBuffer + s;

    if (cnf->verbose)
    {
        s.replace('\r',"");    
        progressDisplay->moveCursor( QTextEdit::MoveEnd , false );
        progressDisplay->insert( s );
    }

/* state machine operates on stdoutBuffer directly */
    stateMachine();
}

void instDialog::readFromStderr()
{
    QString s=QString(proc->readStderr());
    progressDisplay->append( s );
    stderrBuffer=stderrBuffer + QString(s);
}

void instDialog::processExited()
{
    int retcode=proc->exitStatus();
    progressDisplay->append( tr("SSH terminated, exit status: %1").arg(retcode) );

    if (state==EXECUTING_COMMAND)
        QApplication::eventLoop()->exitLoop();
    
    state=FINISH;
    stateMachine();
}

/* user clicked 'Cancel' */
void instDialog::rejected()
{
    if (proc!=NULL)
    {
        disconnect(proc,SIGNAL(readyReadStdout()),this,SLOT(readFromStdout() ) );
        disconnect(proc,SIGNAL(readyReadStderr()),this,SLOT(readFromStderr() ) );
        disconnect(proc,SIGNAL(processExited()),  this,SLOT(processExited()  ) );

        proc->tryTerminate();
        QTimer::singleShot( 2000, proc, SLOT(kill()) );
        proc=NULL;
    }
}

void instDialog::stateMachine()
{
    if (cnf->fwobj->getStr("platform")=="pix")  stateMachinePIX();
    else
    {
        if (cnf->fwobj->getStr("host_OS")=="linksys")  stateMachineLinksys();
        else
            stateMachineSSHSUDO();
    }
}

bool instDialog::cmpPrompt(const QString &str,char *prompt)
{
    if (str.isEmpty()) return false;

    bool res=false;
    if (str.length()>=strlen(prompt))
    {
        res=(unsigned(str.findRev(prompt,-1))==str.length()-strlen(prompt));
        if (!res)
        {
            QString s=str.stripWhiteSpace();
            res=(unsigned(s.findRev(prompt,-1))==s.length()-strlen(prompt));
        }
    }
    return res;
}

void instDialog::showEvent( QShowEvent *ev)
{
    st->restoreGeometry(this, QRect(200,100,480,500) );
    QDialog::showEvent(ev);
}

void instDialog::hideEvent( QHideEvent *ev)
{
    st->saveGeometry(this);
    QDialog::hideEvent(ev);
}
    
