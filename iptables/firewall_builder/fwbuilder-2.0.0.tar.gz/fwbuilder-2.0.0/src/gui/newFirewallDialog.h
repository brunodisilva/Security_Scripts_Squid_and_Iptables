/*

                          Firewall Builder

                 Copyright (C) 2004 NetCitadel, LLC

  Author:  Vadim Kurland     vadim@fwbuilder.org

  $Id: newFirewallDialog.h,v 1.5 2004/06/13 22:15:35 vkurland Exp $

  This program is free software which we release under the GNU General Public
  License. You may redistribute and/or modify this program under the terms
  of that license as published by the Free Software Foundation; either
  version 2 of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
 
  To get a copy of the GNU General Public License, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/


#ifndef __NEWFIREWALLDIALOG_H_
#define __NEWFIREWALLDIALOG_H_

#include "../../config.h"
#include <newfirewalldialog_q.h>

#include "InterfaceData.h"

#include <map>

namespace libfwbuilder {
    class FWObject;
    class Firewall;
    class Interface;
    class Logger;
    class SNMP_interface_query;
};

class QListViewItem;
class QListBoxItem;
class QTimer;
class QTextEdit;

class newFirewallDialog : public newFirewallDialog_q
{
    Q_OBJECT

    libfwbuilder::Firewall             *nfw;
    bool                                snmpPollCompleted;
    libfwbuilder::Logger               *logger;
    libfwbuilder::SNMP_interface_query *q;
    QTimer                             *timer;
    std::map<QListBoxItem*, libfwbuilder::FWObject*> templates;


    void adjustSL(QListViewItem *itm1);
    void fillInterfaceData(libfwbuilder::Interface *intf, QTextBrowser *qte);
    void fillInterfaceSLList();

 public:
    newFirewallDialog();
    virtual ~newFirewallDialog();

    libfwbuilder::Firewall* getNewFirewall() { return nfw; };

    virtual bool appropriate(QWidget *page) const;

public slots:
    virtual void addInterface();
    virtual void updateInterface();
    virtual void deleteInterface();
    virtual void upInterface();
    virtual void downInterface();
    virtual void changed();
    virtual void selectedInterface(QListViewItem *itm);
    virtual void getInterfacesViaSNMP();    
    virtual void monitor();
    virtual void templateSelected(QListBoxItem *itm);
    
 protected slots:
    void selected(const QString &title);
    virtual void accept();
 
};

#endif // __NEWFIREWALLDIALOG_H
