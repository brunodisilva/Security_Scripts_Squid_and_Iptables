#!/bin/sh

for f in *.png; do

  pgm=`basename $f .png`.pgm
  ppm=`basename $f .png`.ppm
  xpm=`basename $f .png`.xpm

  pngtopnm -alpha $f > $pgm
  pngtopnm        $f > $ppm

  ppmtoxpm -alphamask=$pgm $ppm > $xpm

  rm -f $pgm $ppm

done

