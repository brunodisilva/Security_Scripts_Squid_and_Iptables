/* 

                          Firewall Builder

                 Copyright (C) 2004 NetCitadel, LLC

  Author:  Vadim Kurland     vadim@fwbuilder.org

  $Id: StartWizard.cpp,v 1.9 2004/06/25 06:04:38 vkurland Exp $

  This program is free software which we release under the GNU General Public
  License. You may redistribute and/or modify this program under the terms
  of that license as published by the Free Software Foundation; either
  version 2 of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
 
  To get a copy of the GNU General Public License, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#include "../../config.h"
#include "global.h"

#include "StartWizard.h"
#include "RCSFileDialog.h"
#include "FWWindow.h"
#include "FWBSettings.h"

#include <qmessagebox.h>
#include <qlabel.h>
#include <qcheckbox.h>
#include <qpushbutton.h>

#ifndef _WIN32
#  include <unistd.h>     // for access(2)
#else
#  include <io.h>
#endif

#include <errno.h>
#include <iostream>

using namespace std;
using namespace libfwbuilder;


StartWizard::StartWizard()
{
    wantRCS=false;
    oldfile=false;
    newfile=false;

    cancelButton()->hide();

    setNextEnabled(   QWizard::page(0), false );
    setHelpEnabled(   QWizard::page(0), false );
    setHelpEnabled(   QWizard::page(1), false );
}

void StartWizard::openFile()
{
    RCSFileDialog   fd(this, 0, true);

    if ( fd.exec()== QDialog::Accepted )
    {
        RCS *rcs = fd.getSelectedRev();

        if (rcs==NULL) return;

        try
        {
            rcs->co();

        } catch (FWException &ex)
        {
/* if there was an exception, abort operation. */
            return;
        }
/***********************************************************************/

        mw->load( this, rcs );
        mw->showFirewalls();

        if (rcs->isTemp()) unlink(rcs->getFileName().latin1());

        setFinishEnabled( QWizard::page(0), true );
        oldfile=true;

        accept();
    }
}

void StartWizard::newFile()
{
    fname = QFileDialog::getSaveFileName( st->getWDir(), 
                             "Firewall Builder 2 files (*.fwb)",
                              this, 0,
                              tr("Choose name and folder for the new file") );

    if (fname.isEmpty()) return;
    if (fname.findRev(".fwb",-1)==-1) fname=fname+".fwb";

    if (
        QFile::exists( fname ) &&
        QMessageBox::warning(
            this,"Firewall Builder", 
            tr("The file %1 already exists.\nDo you want to overwrite it ?")
            .arg(fname.latin1()),
            "&Yes", "&No", QString::null,
            0, 1 )!=0
    ) return;


    if (
#ifdef _WIN32
	_access( fname.latin1(), W_OK)!=0
#else
	access( fname.latin1(), W_OK)!=0
#endif
	 && errno==EACCES)
    {
        QMessageBox::warning(
            this,"Firewall Builder", 
            tr("File %1 is read-only, you can not save changes to it.")
            .arg(fname),
            "&Continue", QString::null, QString::null,
            0, 1 );
        return;
    }

    mw->load(this);

// set file name in the main window but do not check if the file is
// present, we just checked it

    mw->setFileName(fname,false);

// save blank data into the new file ("initialize" it)
    mw->save();
    mw->fileClose();

    setNextEnabled( QWizard::page(0), true );
    newfile=true;
}

void StartWizard::selected(const QString &title)
{
    int p = indexOf( currentPage() );

    if (p==1 && newfile && !fname.isEmpty())
    {
        fileLbl->setText( fileLbl->text().arg(fname) );
        setFinishEnabled( QWizard::page(1), true );
    }
}

void StartWizard::accept()
{
    if (newfile && !fname.isEmpty())
    {
        if (autoopenBtn->isChecked())
        {
            st->setStartupAction(1);
            st->setLastEdited(fname);
        }

        RCS *rcs=new RCS(fname);
        if (rcsBtn->isChecked())
        {
            try
            {
                rcs->add();
            }
            catch (FWException &ex)
            {
                QMessageBox::warning(
                    this,"Firewall Builder", 
                    tr("Error adding file to RCS:\n%1").arg(ex.toString().c_str()),
                    "&Continue", QString::null,QString::null,
                    0, 1 );
            }
        } 
        try
        {
            rcs->co();
            mw->load( this, rcs );
        }
        catch (FWException &ex)
        {
            QMessageBox::warning(
                this,"Firewall Builder", 
                tr("Error opening file:\n%1").arg(ex.toString().c_str()),
                "&Continue", QString::null,QString::null,
                0, 1 );
        }
    }
    QWizard::accept();
}



