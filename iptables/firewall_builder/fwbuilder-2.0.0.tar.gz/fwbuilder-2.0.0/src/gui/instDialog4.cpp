/* 

                          Firewall Builder

                 Copyright (C) 2004 NetCitadel, LLC

  Author:  Vadim Kurland     vadim@fwbuilder.org

  $Id: instDialog4.cpp,v 1.3 2004/07/09 05:29:37 vkurland Exp $

  This program is free software which we release under the GNU General Public
  License. You may redistribute and/or modify this program under the terms
  of that license as published by the Free Software Foundation; either
  version 2 of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
 
  To get a copy of the GNU General Public License, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#include "../../config.h"
#include "global.h"

#include "instDialog.h"
#include "instConf.h"

#include <qprogressbar.h>
#include <qmessagebox.h>
#include <qregexp.h>
#include <qprocess.h>
#include <qtimer.h>
#include <qtextbrowser.h>
#include <qlineedit.h>

#include "fwbuilder/Resources.h"
#include "fwbuilder/FWObjectDatabase.h"
#include "fwbuilder/Firewall.h"

#ifndef _WIN32
#  include <unistd.h>
#else
#  include <direct.h>
#endif

#include <errno.h>
#include <iostream>

using namespace std;
using namespace libfwbuilder;


void instDialog::stateMachineLinksys()
{
    char     **cptr;

//    QString s=stdoutBuffer;
//    s.replace('\r',"");    
//
//    progressDisplay->moveCursor( QTextEdit::MoveEnd , false );
//    if (!cnf->quiet && cnf->verbose)
//        progressDisplay->insert( QString("\nS='%1'\n").arg(stdoutBuffer) );

    switch (state)
    {
    case LOGGEDIN:  cptr=OSSHerrors2; break;
    default:        cptr=OSSHerrors1; break;
    }

    for( ; *cptr!=NULL; cptr++)
    {
        if ( stdoutBuffer.findRev(*cptr,-1)!=-1 )
        {
            progressDisplay->append( tr("*** Fatal error :") );
            progressDisplay->append( stdoutBuffer+"\n" );
            stdoutBuffer="";
            proc->tryTerminate();
            QTimer::singleShot( 2000, proc, SLOT(kill()) );
            return;
        }
    }

 entry:
    switch (state)
    {
    case NONE:
    {
        if ( cmpPrompt(stdoutBuffer,ssh_pwd_prompt) ||
             cmpPrompt(stdoutBuffer,putty_pwd_prompt) ||
             stdoutBuffer.findRev(passphrase_prompt,-1)!=-1 )
        {
            stdoutBuffer="";
            proc->writeToStdin( cnf->pwd );
            proc->writeToStdin( "\n" );
            break;
        }
/* we may get to LOGGEDIN state directly from NONE, for example when
 * password is supplied on command line to plink.exe or ssh-agent is used
 */
        if (cmpPrompt(stdoutBuffer,ssoft_prompt1) ||
            cmpPrompt(stdoutBuffer,ssoft_prompt2) )
        {
// **** this is just a hack to make sure user sees what fw script has to say
//            cnf->verbose=true;
            progressDisplay->moveCursor( QTextEdit::MoveEnd , false );
            if (!cnf->quiet) progressDisplay->insert( tr("Logged in\n") );
            stdoutBuffer="";
            proc->writeToStdin( "\n" );
            state=CLEAR_CONFIG;
            break;
        }

        QString fingerprint;
        int n1,n2;
        if (stdoutBuffer.find(newKeyOpenSSH)!=-1 ||
            stdoutBuffer.find(newKeyPlink)!=-1   ||
            stdoutBuffer.find(newKeyVsh)!=-1)
        {
/* new key */

            n1=stdoutBuffer.find(fingerprintPrompt) + strlen(fingerprintPrompt);
            n2=stdoutBuffer.find(QRegExp("[^ 0-9a-f:]"), n1+4);
            fingerprint=stdoutBuffer.mid(n1,n2-n1);

            QString fwobjname=cnf->fwobj->getName().c_str();
            QString msg=newKeyMsg.arg(fwobjname).arg(fingerprint).arg(fwobjname);

            int res =QMessageBox::warning( this, tr("New RSA key"), msg,
                                           tr("Yes"), tr("No"), 0,
                                           0, -1 );

            stdoutBuffer="";
            if (res==0)
            {
                if (ssh.find("vsh.exe")!=-1)
                    proc->writeToStdin( "y\n" );
                else
                    proc->writeToStdin( "yes\n" );
                break;
            } else
            {
                state=EXIT;
                goto entry;
            }
        }
    }
    break;

    case CLEAR_CONFIG:
    {
        if (cmpPrompt(stdoutBuffer,ssoft_prompt1) ||
            cmpPrompt(stdoutBuffer,ssoft_prompt2) )
        {
            progressDisplay->moveCursor( QTextEdit::MoveEnd , false );
            if (!cnf->quiet)
                progressDisplay->insert( tr("Clear firewall script\n") );
            stdoutBuffer="";
            proc->writeToStdin( "nvram unset rc_firewall\n" );
            state=PUSHING_CONFIG;
        }
    }
    break;

    case PUSHING_CONFIG:
    {
// if verbose is ON, the text has already been printed
//        if (!cnf->quiet && !cnf->verbose) 
//        {
//            progressDisplay->moveCursor( QTextEdit::MoveEnd , false );
//            progressDisplay->insert( stdoutBuffer );
//        }

        if (cmpPrompt(stdoutBuffer,ssoft_prompt1) ||
            cmpPrompt(stdoutBuffer,ssoft_prompt2) )
        {
            stdoutBuffer="";

/* install full policy */
            QString ff = cnf->wdir+"/"+cnf->conffile;
            config_file = new ifstream(ff.latin1());
            if ( ! *config_file)
            {
                progressDisplay->append(
                    QObject::tr("Can not open file %1").arg(ff)
                );
                state=FINISH;
                break;
            }
            proc->writeToStdin( "nvram set rc_firewall=\"" );
            proc->writeToStdin( "\n" );
            state=WAITING_FOR_CONFIG_PROMPT;

/* read the whole file */
            string s0;
            nLines=0;
            allConfig.clear();
            while ( !config_file->eof() )
            {
                getline( *config_file, s0);
                    
                QString s(s0.c_str());
                s.stripWhiteSpace();
                allConfig.push_back(s);
                nLines++;
            }
            config_file->close();
            delete config_file;
            config_file=NULL;
            
            progressBar->setTotalSteps(nLines);

            if (!cnf->dry_run)
                progressDisplay->insert(tr("Pushing firewall configuration"));
            progressDisplay->insert( "\n");
            ncmd=0;
        }
    }
    break;

    case WAITING_FOR_CONFIG_PROMPT:
    {
        if ( cmpPrompt(stdoutBuffer,ssoft_config_prompt) )
        {
            if (allConfig.size()!=0)
            {
                QString s;

                do {
                    s = allConfig.front();
                    allConfig.pop_front();
                } while (cnf->stripComments && s[0]=='#');

                progressBar->setProgress(progressBar->totalSteps()-allConfig.size());
                if (!cnf->dry_run)
                {
                    if ( !s.isEmpty())  ncmd++;
                    stdoutBuffer="";
                    proc->writeToStdin( s+"\n"); // send even if s is empty
                } else
                {
                    progressDisplay->insert( s+"\n" );
                }
            } else
            {
                state=EXIT_FROM_CONFIG;
                proc->writeToStdin( "\"" );
                proc->writeToStdin( "\n" );
            }
        }
    }
    break;


    case EXIT_FROM_CONFIG:
        if ( cmpPrompt(stdoutBuffer,ssoft_prompt1) ||
             cmpPrompt(stdoutBuffer,ssoft_prompt2) )
        {
            if (!cnf->dry_run && ncmd!=0)
            {
                state=SAVE_CONFIG;
                proc->writeToStdin( "nvram commit");
                proc->writeToStdin( "\n");
            } else
            {
                state=EXIT;
                proc->writeToStdin( "exit\n");
            }
        }
        break;

    case SAVE_CONFIG:
        if ( cmpPrompt(stdoutBuffer,ssoft_prompt1) ||
             cmpPrompt(stdoutBuffer,ssoft_prompt2) )
        {
            state=RUN_SCRIPT;
            progressDisplay->insert( "Activating policy\n" );
            proc->writeToStdin( "nvram get rc_firewall | /bin/sh\n");
            proc->writeToStdin( "\n");
            stdoutBuffer="";
        }
        break;

    case RUN_SCRIPT:
        if (!cnf->quiet && !cnf->verbose)
        {
            stdoutBuffer.replace('\r',"");    
            progressDisplay->moveCursor( QTextEdit::MoveEnd , false );
            progressDisplay->insert( stdoutBuffer );
        }

        if ( cmpPrompt(stdoutBuffer,ssoft_prompt1) ||
             cmpPrompt(stdoutBuffer,ssoft_prompt2) )
        {
            state=EXIT;
            progressDisplay->insert( "Done" );
            proc->writeToStdin( "\n");
        }

        stdoutBuffer="";
        break;

    case EXIT:
        proc->tryTerminate();
        QTimer::singleShot( 2000, proc, SLOT(kill()) );
        state=FINISH;
        break;

    case FINISH:
        setFinishEnabled( page(1), true );
        break;

    default:    break;
    }
}

