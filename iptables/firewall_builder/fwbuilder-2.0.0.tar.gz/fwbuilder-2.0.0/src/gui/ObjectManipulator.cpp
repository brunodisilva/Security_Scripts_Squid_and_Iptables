/* 

                          Firewall Builder

                 Copyright (C) 2003 NetCitadel, LLC

  Author:  Vadim Kurland     vadim@fwbuilder.org

  $Id: ObjectManipulator.cpp,v 1.77 2004/07/14 19:30:28 vkurland Exp $

  This program is free software which we release under the GNU General Public
  License. You may redistribute and/or modify this program under the terms
  of that license as published by the Free Software Foundation; either
  version 2 of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
 
  To get a copy of the GNU General Public License, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/



#include "config.h"
#include "global.h"
#include "utils.h"

#include "ObjectManipulator.h"
#include "ObjectEditor.h"
#include "ObjectTreeViewItem.h"
#include "ObjectTreeView.h"
#include "FWObjectClipboard.h"
#include "FWObjectPropertiesFactory.h"
#include "FWBSettings.h"
#include "newFirewallDialog.h"
#include "newHostDialog.h"
#include "listOfLibraries.h"
#include "findDialog.h"
#include "newGroupDialog.h"

#include <qobject.h>
#include <qobjectlist.h>
#include <qlistview.h>
#include <qimage.h>
#include <qpixmap.h>
#include <qheader.h>
#include <qwidgetstack.h>
#include <qpushbutton.h>
#include <qtabwidget.h>
//#include <qtoolbar.h>
#include <qaction.h>
#include <qlabel.h>
#include <qcombobox.h>
#include <qsplitter.h>
#include <qtoolbutton.h>
#include <qlayout.h>
#include <qmessagebox.h>
#include <qpopupmenu.h>
#include <qtextbrowser.h>
#include <qapplication.h>
#include <qcursor.h>
#include <qtooltip.h>
#include <qlineedit.h>
#include <qcombobox.h>


#include "DialogFactory.h"
#include "FWBTree.h"
#include "FWWindow.h"

#include "fwbuilder/Library.h"
#include "fwbuilder/Firewall.h"
#include "fwbuilder/Host.h"
#include "fwbuilder/Network.h"
#include "fwbuilder/IPv4.h"
#include "fwbuilder/AddressRange.h"
#include "fwbuilder/ObjectGroup.h"

#include "fwbuilder/Resources.h"
#include "fwbuilder/FWReference.h"
#include "fwbuilder/Interface.h"
#include "fwbuilder/RuleSet.h"
#include "fwbuilder/InterfacePolicy.h"

#include "fwbuilder/CustomService.h"
#include "fwbuilder/IPService.h"
#include "fwbuilder/ICMPService.h"
#include "fwbuilder/TCPService.h"
#include "fwbuilder/UDPService.h"
#include "fwbuilder/ServiceGroup.h"

#include "fwbuilder/Interval.h"
#include "fwbuilder/IntervalGroup.h"

#include <iostream>

using namespace std;
using namespace libfwbuilder;

#define OBJTREEVIEW_WIDGET_NAME  "ObjTreeView"


HistoryItem::~HistoryItem() {}

ObjToolTip::ObjToolTip(ObjectTreeView *w) : QToolTip(w->viewport(),0)
{
    otv=w;
}

void ObjToolTip::maybeTip(const QPoint &p)
{
    if (st->getObjTooltips())
    {
        QListViewItem *itm = otv->itemAt( p );
        if (itm==NULL) return;
        ObjectTreeViewItem *otvi=dynamic_cast<ObjectTreeViewItem*>(itm);
        assert(otvi);

        FWObject *obj=otvi->getFWObject();
        QRect     cr =otv->itemRect(itm);

        tip(cr,
          FWObjectPropertiesFactory::getObjectPropertiesDetailed(obj,true,true));
    }
}

ObjectManipulator::ObjectManipulator( QWidget *parent ) :
    ObjectManipulator_q( parent, tr("Object Manipulator") )
{
    treeWidth    = -1;
    treeHeight   = -1;
    currentObj   = NULL;
    active       = false;
    currentTreeView=NULL;

//    setFocusPolicy( QWidget::StrongFocus  );

/* Adding pop-down menu to the button "New" */

    QString icon_path="/FWBuilderResources/Type/";

    QPopupMenu* newObjectPopup = new QPopupMenu( this );

    addPopupMenuItem( this, newObjectPopup, icon_path+Group::TYPENAME+"/icon-tree",         tr( "New &Library" ),        SLOT( newLibrary()        ) );
    newObjectPopup->insertSeparator();                                                     

    addPopupMenuItem( this, newObjectPopup, icon_path+Firewall::TYPENAME+"/icon-tree",      tr( "New &Firewall" ),       SLOT( newFirewall()       ) );
    addPopupMenuItem( this, newObjectPopup, icon_path+Host::TYPENAME+"/icon-tree",          tr( "New &Host" ),           SLOT( newHost()           ) );
    addPopupMenuItem( this, newObjectPopup, icon_path+Interface::TYPENAME+"/icon-tree",     tr( "New &Interface" ),      SLOT( newInterface()      ) );

    addPopupMenuItem( this, newObjectPopup, icon_path+Network::TYPENAME+"/icon-tree",       tr( "New &Network" ),        SLOT( newNetwork()        ) );
    addPopupMenuItem( this, newObjectPopup, icon_path+IPv4::TYPENAME+"/icon-tree",          tr( "New &Address" ),        SLOT( newAddress()        ) );
    addPopupMenuItem( this, newObjectPopup, icon_path+AddressRange::TYPENAME+"/icon-tree",  tr( "New Address &Range" ),  SLOT( newAddressRange()   ) );
    addPopupMenuItem( this, newObjectPopup, icon_path+ObjectGroup::TYPENAME+"/icon-tree",   tr( "New &Object Group" ),   SLOT( newObjectGroup()    ) );
    newObjectPopup->insertSeparator();                                                     
    addPopupMenuItem( this, newObjectPopup, icon_path+CustomService::TYPENAME+"/icon-tree", tr( "New &Custom Service" ), SLOT( newCustom()         ) );
    addPopupMenuItem( this, newObjectPopup, icon_path+IPService::TYPENAME+"/icon-tree",     tr( "New &IP Service" ),     SLOT( newIP()             ) );
    addPopupMenuItem( this, newObjectPopup, icon_path+ICMPService::TYPENAME+"/icon-tree",   tr( "New IC&MP Service" ),   SLOT( newICMP()           ) );
    addPopupMenuItem( this, newObjectPopup, icon_path+TCPService::TYPENAME+"/icon-tree",    tr( "New &TCP Service" ),    SLOT( newTCP()            ) );
    addPopupMenuItem( this, newObjectPopup, icon_path+UDPService::TYPENAME+"/icon-tree",    tr( "New &UDP Service" ),    SLOT( newUDP()            ) );
    addPopupMenuItem( this, newObjectPopup, icon_path+ServiceGroup::TYPENAME+"/icon-tree",  tr( "New &Service Group" ),  SLOT( newServiceGroup()   ) );
    newObjectPopup->insertSeparator();                                                     
    addPopupMenuItem( this, newObjectPopup, icon_path+Interval::TYPENAME+"/icon-tree",      tr( "New Ti&me Interval" ),  SLOT( newInterval()       ) );

//    QToolButton *btn = (QToolButton*)toolBar->child("newObjectAction_action_button");

    newButton->setPopup( newObjectPopup );
    newButton->setPopupDelay( 0 );


#if defined(Q_WS_X11)
/* do something that makes sense only on X11 */

#elif defined(Q_OS_WIN32) || defined(Q_OS_CYGWIN)
/* do something that only works on windows */

#elif defined(Q_OS_MAC)

#endif

//    backwardAction->setEnabled( false );

//    setMinimumSize( QSize( 0, 174 ) );
//    splitter3->setMinimumSize( QSize( 0, 118 ) );
//    treeFrame->setMinimumSize( QSize( 200, 0 ) );
//    splitter3->setResizeMode( treeFrame, QSplitter::KeepSize );
}


QString ObjectManipulator::getTreeLabel( FWObject *obj )
{
    QString name;

    if (Interface::isA(obj))
    {
        name=Interface::constcast(obj)->getLabel().c_str();
        if (name=="")  name=QString::fromUtf8(obj->getName().c_str());
        QString q;
        if (Interface::constcast(obj)->isDyn())        q=" dyn";
        if (Interface::constcast(obj)->isUnnumbered()) q=" unnum";
        if (Interface::constcast(obj)->isExt())        q=q+" ext";
        if (q!="") name=name+" ("+q+")";
    }
    else
    {       
        name=QString::fromUtf8(obj->getName().c_str());
        if (Library::isA(obj) && obj->isReadOnly())
	    name=name+QObject::tr(" ( read only )");
    }

    if (name=="")
    {  // no name, use type description string instead
        name= Resources::global_res->getObjResourceStr(obj,"description").c_str();
    }
    return name;
}

ObjectTreeViewItem* ObjectManipulator::insertObject( ObjectTreeViewItem *itm,
                                                  FWObject *obj )
{
    if (FWReference::cast(obj)!=NULL) return NULL;
    if (Resources::global_res->getObjResourceBool(obj,"hidden") ) return NULL;
    if (RuleSet::cast(obj)!=NULL) return NULL;

    ObjectTreeViewItem *nitm=NULL;

    QString icn_filename;

    if (FWBTree::isSystem(obj))
        icn_filename="folder1.png";
    else
        icn_filename=Resources::global_res->getObjResourceStr(obj, "icon-tree").c_str();

    if (Resources::global_res->getResourceBool(
            string("/FWBuilderResources/Type/") +
            obj->getTypeName() + "/hidden") ) return NULL;

    nitm=new ObjectTreeViewItem( itm );
    nitm->setLib("");
    nitm->setText( 0, getTreeLabel(obj) );
    nitm->setPixmap( 0, QPixmap::fromMimeSource( icn_filename ) );
    nitm->setDragEnabled(true);

    nitm->setProperty("id",   obj->getId().c_str()   );
    nitm->setProperty("type", obj->getTypeName().c_str() );
    nitm->setFWObject( obj );

    allItems[obj] = nitm;

    return nitm;
}

void ObjectManipulator::insertSubtree( ObjectTreeViewItem *itm,
                                       FWObject *obj )
{
    if (fwbdebug)
        qDebug("ObjectManipulator::insertSubtree itm=%p  obj: %s",
               itm, obj->getName().c_str() );

    ObjectTreeViewItem *nitm = insertObject(itm, obj);

    if (fwbdebug)
        qDebug("ObjectManipulator::insertSubtree nitm=%p", nitm);

    if (nitm==NULL) return;
    if ( FWBTree::isSystem(obj) ) nitm->setOpen( st->getExpandTree() );

    for (list<FWObject*>::iterator m=obj->begin(); m!=obj->end(); m++) 
    {
        FWObject *o1=*m;
        if (FWReference::cast(o1)!=NULL) continue;
        insertSubtree( nitm, o1 );
    }
}

void ObjectManipulator::showDeletedObjects(bool f)
{
    FWObject *dobj = mw->db()->getById( FWObjectDatabase::getDeletedObjectsId());

    if (fwbdebug)
        qDebug("ObjectManipulator::showDeletedObjects f=%d  dobj=%p",f, dobj);

    if (dobj==NULL)
    {
        dobj=mw->db()->create(Library::TYPENAME);
        dobj->setId(mw->db()->getDeletedObjectsId());
        dobj->setName("Deleted Objects");
        dobj->setReadOnly(false);
        mw->db()->add(dobj);
    }

    int idx = getIdxForLib(dobj);

    if (fwbdebug)
        qDebug("ObjectManipulator::showDeletedObjects idx=%d",idx);

    if (f)
    {
        if (idx>=0) return;
        addTreePage( dobj );
        openLib( dobj );
    } else
    {
        if (idx<0) return;

        QListView *otv = idxToTrees[idx];

        if (fwbdebug)
            qDebug("ObjectManipulator::showDeletedObjects otv=%p",otv);

        assert(otv!=NULL);
        widgetStack->removeWidget( otv );
        removeLib(idx);
    }
}

void ObjectManipulator::removeObjectFromTreeView(FWObject *obj )
{
    ObjectTreeViewItem *itm = allItems[obj];
    allItems.erase(obj);
    delete itm;
}

void ObjectManipulator::updateLibColor(FWObject *lib)
{
    QListView *objTreeView = idxToTrees[ getIdxForLib(lib) ];

    QString clr=lib->getStr("color").c_str();
    if (clr=="" || clr=="#000000" || clr=="black") clr="#FFFFFF";
    objTreeView->setPaletteBackgroundColor( QColor( clr ) );
}

int ObjectManipulator::getIdxForLib(FWObject* lib)
{
    for (int i=0; i<libs->count(); i++)
        if ( idxToLibs[i]->getId() == lib->getId() ) return i;

    return -1;
}

void ObjectManipulator::updateLibName(FWObject *lib)
{
    int              oldidx = getIdxForLib(lib);
    QListView  *objTreeView = idxToTrees[oldidx];    
    QString      newlibname = QString::fromUtf8(lib->getName().c_str());

    if (libs->text(oldidx)!=newlibname)
    {
        removeLib(oldidx);
//        libs->removeItem( oldidx );
//        idxToLibs.erase(oldidx);
//        idxToTrees.erase(oldidx);

        addLib(lib,objTreeView);
    
    }
//        libs->changeItem( QPixmap::fromMimeSource( "books1.png" ),
//                          lib->getName().c_str(),  getIdxForLib(lib) );
}


/*
 * TODO: make this signal/slot. Dialogs just emit signal
 * 'updateObject_sign', which objectManipulator should have connected
 * to its slot which would do what updateObjName does now, and more.
 */
void ObjectManipulator::updateObjName(FWObject *obj,
                                      const QString &oldName,
                                      bool  askForAutorename)
{
    if (obj!=currentObj) openObject(obj);

    QListViewItem *itm = allItems[obj];
    assert(itm!=NULL);

    if (fwbdebug)
    {
        qDebug("ObjectManipulator::updateObjName  changing name %s -> %s",
               oldName.latin1(), QString::fromUtf8(obj->getName().c_str()).latin1());
    }

    if ((QString::fromUtf8(obj->getName().c_str())!=oldName) &&
         (Host::isA(obj) || Firewall::isA(obj) || Interface::isA(obj)))
        autorename(obj,askForAutorename);

    itm->setText(0, getTreeLabel( obj ) );

    if (!Library::isA(obj)) itm->parent()->sort();

/* need to update name of the firewall in the drop-down list */
    if (Firewall::isA(obj))
        mw->updateFirewallName(obj,oldName);

    if (QString::fromUtf8(obj->getName().c_str())!=oldName)  mw->reopenFirewall();

    info();  // need to update info in case user edited comments and other attributes.
}

/* 
 * variant specifically used for interfaces that have name and a label
 */ 
void ObjectManipulator::updateObjName(FWObject *obj,
                                      const QString &oldName,
                                      const QString &oldLabel,
                                      bool  askForAutorename)
{
    if (obj!=currentObj) openObject(obj);

    QListViewItem *itm = allItems[obj];
    assert(itm!=NULL);

    if (fwbdebug)
    {
        qDebug("ObjectManipulator::updateObjName  changing name %s -> %s",
               oldName.latin1(), QString::fromUtf8(obj->getName().c_str()).latin1());
    }

    if ((QString::fromUtf8(obj->getName().c_str())!=oldName) && Interface::isA(obj))
        autorename(obj,askForAutorename);

    itm->setText(0, getTreeLabel( obj ) );
    itm->parent()->sort();

    Interface *i = Interface::cast(obj);
    if  ((i!=NULL && i->getLabel()!=oldLabel.latin1()) ||
         (QString::fromUtf8(obj->getName().c_str())!=oldName))  mw->reopenFirewall();

    info();  // need to update info in case user edited comments and other attributes.
}

void ObjectManipulator::autorename(FWObject *obj,bool ask)
{
    if (Host::isA(obj) || Firewall::isA(obj))
    {
        if (!ask || QMessageBox::warning(
                this,"Firewall Builder", 
                tr(
"The name of the object '%1' has changed. The program can also\n"
"rename IP address objects that belong to this object,\n"
"using standard naming scheme 'host_name:interface_name:ip'.\n"
"This makes it easier to distinguish what host or a firewall\n"
"given IP address object belongs to when it is used in \n"
"the policy or NAT rule. The program also renames MAC address\n"
"objects using scheme 'host_name:interface_name:mac'.\n"
"Do you want to rename child IP and MAC address objects now?\n"
"(If you click 'No', names of all address objects that belong to\n"
"%1 will stay the same.)")
                .arg(QString::fromUtf8(obj->getName().c_str()))
                .arg(QString::fromUtf8(obj->getName().c_str())),
                "&Yes", "&No", QString::null,
                0, 1 )==0 )
        {
            list<FWObject*> il = obj->getByType(Interface::TYPENAME);
            for (list<FWObject*>::iterator i=il.begin(); i!=il.end(); ++i)
            {
                autorename(*i,IPv4::TYPENAME,"ip");
                autorename(*i,physAddress::TYPENAME,"mac");
            }
        }
    }

    if (Interface::isA(obj))
    {
        if (!ask || QMessageBox::warning(
                this,"Firewall Builder", 
                tr(
"The name of the interface '%1' has changed. The program can also\n"
"rename IP address objects that belong to this interface,\n"
"using standard naming scheme 'host_name:interface_name:ip'.\n"
"This makes it easier to distinguish what host or a firewall\n"
"given IP address object belongs to when it is used in \n"
"the policy or NAT rule. The program also renames MAC address\n"
"objects using scheme 'host_name:interface_name:mac'.\n"
"Do you want to rename child IP and MAC address objects now?\n"
"(If you click 'No', names of all address objects that belong to\n"
"%1 will stay the same.)")
                .arg(QString::fromUtf8(obj->getName().c_str()))
                .arg(QString::fromUtf8(obj->getName().c_str())),
                "&Yes", "&No", QString::null,
                0, 1 )==0 )
        {
            autorename(obj,IPv4::TYPENAME,"ip");
            autorename(obj,physAddress::TYPENAME,"mac");
        }
    }
}

void ObjectManipulator::autorename(FWObject *obj,
                                   const string &objtype,
                                   const string &namesuffix)
{
    FWObject      *hst = obj->getParent();
    list<FWObject*> ol = obj->getByType(objtype);
    int           sfxn = 1;

    for (list<FWObject*>::iterator j=ol.begin(); j!=ol.end(); ++j,sfxn++)
    {
        QString sfx;
        if (ol.size()==1) sfx="";
        else              sfx.setNum(sfxn);
        QString nn = QString("%1:%2:%3%4")
            .arg(QString::fromUtf8(hst->getName().c_str()))
            .arg(QString::fromUtf8(obj->getName().c_str()))
            .arg(namesuffix.c_str())
            .arg(sfx);

        (*j)->setName(string(nn.utf8()));
        QListViewItem *itm1 = allItems[ *j ];
        assert(itm1!=NULL);
        itm1->setText(0, getTreeLabel( *j ) );
        itm1->parent()->sort();
    }
    ol.clear();
}

void ObjectManipulator::clearObjects()
{
    if (fwbdebug) qDebug("ObjectManipulator::clearObjects  start");

    invalidateDialog();
    while (history.size()!=0) history.pop();

    if (fwbdebug) qDebug("ObjectManipulator::clearObjects  history size: %d",
                         history.size());

    int N=libs->count();

    if (fwbdebug) qDebug("ObjectManipulator::clearObjects  %d libs", N);

    for (int i=N-1; i>=0; i--)
    {
        QListView *otv = idxToTrees[i];
        assert(otv!=NULL);
        widgetStack->removeWidget( otv );
        removeLib(i);
    }

    if (fwbdebug) qDebug("ObjectManipulator::clearObjects  idxToLibs size: %d",
                         idxToLibs.size());
    if (fwbdebug) qDebug("ObjectManipulator::clearObjects  idxToTrees size: %d",
                         idxToTrees.size());

    idxToLibs.clear();
    idxToTrees.clear();

    if (fwbdebug) qDebug("ObjectManipulator::clearObjects  done");
}

void ObjectManipulator::loadObjects()
{
    loadObjects( mw->db() );
}

void ObjectManipulator::loadObjects(FWObjectDatabase *db)
{
    if (fwbdebug) qDebug("ObjectManipulator::loadObjects  start");

    if (libs->count()!=0) clearObjects();

    FWObject *firstUserLib=NULL;
    list<FWObject*> ll = mw->db()->getByType( Library::TYPENAME );

//    ll.sort(FWObjectNameCmpPredicate());

    for (FWObject::iterator i=ll.begin(); i!=ll.end(); i++)
    {
        FWObject *lib = (*i);

        if ( lib->getId()==DELETED_LIB &&
             ! st->getBool("UI/ShowDeletedObjects")) continue;

        if ( lib->getId()!=STANDARD_LIB &&
             lib->getId()!=TEMPLATE_LIB &&
             firstUserLib==NULL) firstUserLib=*i;

        addTreePage( lib );

        if (fwbdebug) qDebug("ObjectManipulator::loadObjects  added lib %s",
                             lib->getName().c_str());
    }

    if (firstUserLib==NULL) firstUserLib=ll.front();
    openLib( firstUserLib );
}

void ObjectManipulator::addLib( FWObject *lib,QListView* otv)
{
    QString newlibname = QString::fromUtf8(lib->getName().c_str());
    int              N = libs->count();
    int            idx = 0;
    vector<FWObject*>::iterator  i1=idxToLibs.begin();
    vector<QListView*>::iterator i2=idxToTrees.begin();
    for ( ; idx<N; ++idx,++i1,++i2)
        if ( libs->text(idx) > newlibname ) break;

    string icn=Resources::global_res->getObjResourceStr(lib,"icon-tree").c_str();
    libs->insertItem( QPixmap::fromMimeSource( icn.c_str() ),
                      newlibname, idx);
//    idx=libs->count()-1;

    libs->setCurrentItem(idx);

    idxToLibs.insert(i1,lib);
    if (otv!=NULL) idxToTrees.insert(i2,otv);
}

void ObjectManipulator::addTreePage( FWObject *lib)
{
    ObjectTreeView *objTreeView = new ObjectTreeView( widgetStack,
                                                      OBJTREEVIEW_WIDGET_NAME );
    new ObjToolTip(objTreeView);

    addLib(lib,objTreeView);

    objTreeView->setSizePolicy(
        QSizePolicy( QSizePolicy::Preferred,
                     (QSizePolicy::SizeType)7,
                     0,
                     0,
                     objTreeView->sizePolicy().hasHeightForWidth() )
    );

    widgetStack->addWidget( objTreeView );

//    objTreeView->setSelectionMode( QListView::Extended );
    
    updateLibColor( lib );
//    updateLibName( lib );

    connect(objTreeView,SIGNAL(openObjectEditor_sign(libfwbuilder::FWObject*) ),
             this,        SLOT( edit(libfwbuilder::FWObject*) ) );

    connect( objTreeView, SIGNAL( deleteObject_sign(libfwbuilder::FWObject*) ),
             this,        SLOT( deleteObj() ) );

    connect( objTreeView, SIGNAL( objectDropped_sign(libfwbuilder::FWObject*) ),
             this,        SLOT( openObject(libfwbuilder::FWObject*) ) );

    connect( objTreeView, SIGNAL( contextMenuRequested(QListViewItem*,const QPoint&,int) ),
             this,        SLOT( contextMenu(QListViewItem*,const QPoint&,int) ) );

//    connect( objTreeView, SIGNAL( currentChanged(QListViewItem*) ),
//             this,        SLOT( selectionChanged() ) );

    connect( objTreeView, SIGNAL( selectionChanged() ),
             this,        SLOT( selectionChanged() ) );


    ObjectTreeViewItem *itm1=new ObjectTreeViewItem( objTreeView );

    itm1->setLib("");
    itm1->setOpen(TRUE);

/* need to enable dragging in order to avoid object highlighting in
 * the tree when user drags mouse cursor */

    itm1->setDragEnabled(true);

    itm1->setText( 0 , getTreeLabel( lib ) );
    if (lib->isReadOnly())
        itm1->setPixmap(0, QPixmap::fromMimeSource( "lock.png" ) );
    else
    {   
        string icn=Resources::global_res->getObjResourceStr(lib,"icon-tree").c_str();
        itm1->setPixmap( 0, QPixmap::fromMimeSource( icn.c_str() ));
    }

    itm1->setProperty("id",   lib->getId().c_str()   );
    itm1->setProperty("type", lib->getTypeName().c_str() );
    itm1->setFWObject( lib );
    allItems[lib] = itm1;

//    objTreeView->setSelected( itm1, true );

    for (list<FWObject*>::iterator m=lib->begin(); m!=lib->end(); m++) 
        insertSubtree( itm1, (*m) );

}

void ObjectManipulator::removeLib(FWObject* lib)
{
    removeLib( getIdxForLib(lib) );
}

void ObjectManipulator::removeLib(int id)
{
    int              N = libs->count();
    int            idx = 0;
    vector<FWObject*>::iterator  i1=idxToLibs.begin();
    vector<QListView*>::iterator i2=idxToTrees.begin();
    for ( ; idx<N; ++idx,++i1,++i2)
        if ( idx==id ) break;

    libs->removeItem( idx );
    idxToLibs.erase(i1);
    idxToTrees.erase(i2);

#if 0
    libs->removeItem( idx );

//    int N=idxToLibs.size();
    int N=libs->count();

    idxToLibs.erase(idx);
    idxToTrees.erase(idx);

    int i=idx;
    while (i<N)
    {
        idxToLibs[i]  = idxToLibs[i+1];
        idxToTrees[i] = idxToTrees[i+1];
        i++;
    }
    idxToLibs[N]  = NULL;
    idxToTrees[N] = NULL;
#endif
}

void ObjectManipulator::makeNameUnique(FWObject* parent,FWObject* obj)
{
    int      suffix=1;
    QString  basename=QString::fromUtf8(obj->getName().c_str());
    QString  newname=basename;

/* check if there is another object with the same name */
    while (parent->findObjectByName(obj->getTypeName(),newname.latin1())!=NULL)
    {
/* there is a duplicate */
        newname=QString("%1-%2").arg(basename).arg(suffix);
        suffix++;
    }
    obj->setName(string(newname.utf8()));
}

void ObjectManipulator::contextMenu(QListViewItem *item,
                                    const QPoint &pos, int col)
{
/* in extended selection mode there may be several selected items */

    if (fwbdebug)
        qDebug("ObjectManipulator::contextMenu  selectedObjects.size=%d",
               getCurrentObjectTree()->getNumSelected());

    ObjectTreeViewItem *otvi=dynamic_cast<ObjectTreeViewItem*>(item);
    if (otvi==NULL)  return;  // happens when user clicks outside an item

    if (!getCurrentObjectTree()->isSelected(otvi->getFWObject()))
        openObject( otvi , true );

    if (currentObj==NULL)  currentObj=otvi->getFWObject();

    QPopupMenu *popup=new QPopupMenu(this);

    int edtID =popup->insertItem( tr("Edit") ,      this , SLOT( editObj() ) );

    QPopupMenu *duptargets  = new QPopupMenu(popup);
    QPopupMenu *movetargets = new QPopupMenu(popup);

    int libid = 0;

    FWObject *cl=getCurrentLib();
    int moveTargets=0;
    vector<FWObject*>::iterator i;
    for (i=idxToLibs.begin(); i!=idxToLibs.end(); ++i,++libid)
    {
        FWObject *lib   = *i;

        if ( lib->getId()==STANDARD_LIB ||
             lib->getId()==TEMPLATE_LIB ||
             lib->getId()==DELETED_LIB  ||
             lib->isReadOnly())
            continue;
        int did=duptargets->insertItem(
            tr("place in library %1").arg(QString::fromUtf8(lib->getName().c_str()))
        );

        duptargets->connectItem( did, this, SLOT( duplicateObj(int)) );
        duptargets->setItemParameter(did, libid );

        if (lib==cl) continue;   // can't move to the same library

        int mid=movetargets->insertItem(
            tr("to library %1").arg(QString::fromUtf8(lib->getName().c_str()))
        );

        movetargets->connectItem( mid, this, SLOT( moveObj(int)) );
        movetargets->setItemParameter(mid, libid );

        moveTargets++;
    }

    int dupID =popup->insertItem( tr("Duplicate ...") , duptargets );
    int movID =popup->insertItem( tr("Move ...") ,      movetargets );

    popup->insertSeparator();

    int copyID=popup->insertItem( tr("Copy") ,      this ,
                                  SLOT( copyObj() ) );
    int cutID =popup->insertItem( tr("Cut") ,       this ,
                                  SLOT( cutObj() ) );
    popup->insertItem( tr("Paste") ,     this ,
                       SLOT( pasteObj() ) );

    popup->insertSeparator();

    int delID =popup->insertItem( tr("Delete") ,    this ,
                                  SLOT( deleteObj() ) );

    int newID1=-1;
    int newID2=-1;

    if (getCurrentObjectTree()->getNumSelected()==1)
    {
        popup->insertSeparator();

        if ( (Firewall::isA(currentObj) || Host::isA(currentObj)) && 
             ! currentObj->isReadOnly() )
            newID1=popup->insertItem( tr("Add Interface"),     this ,
                               SLOT( newInterface() ) );

        if (Interface::isA(currentObj) && ! currentObj->isReadOnly())
        {
            newID1=popup->insertItem( tr("Add IP Address"),    this ,
                               SLOT( newAddress() ) );
            newID2=popup->insertItem( tr("Add MAC Address"),   this ,
                               SLOT( newPhysicalAddress() ) );
        }

        if (currentObj->getPath(true)=="Firewalls")
            newID1=popup->insertItem( tr("New Firewall"),      this ,
                               SLOT( newFirewall() ) );

        if (currentObj->getPath(true)=="Objects/Addresses")
            newID1=popup->insertItem( tr("New Address"),       this ,
                               SLOT( newAddress() ) );

        if (currentObj->getPath(true)=="Objects/Address Ranges")
            newID1=popup->insertItem( tr("New Address Range"), this ,
                               SLOT( newAddressRange() ) );

        if (currentObj->getPath(true)=="Objects/Hosts")
            newID1=popup->insertItem( tr("New Host"),          this ,
                               SLOT( newHost() ) );

        if (currentObj->getPath(true)=="Objects/Networks")
            newID1=popup->insertItem( tr("New Network"),       this ,
                               SLOT( newNetwork() ) );

        if (currentObj->getPath(true)=="Objects/Groups")
            newID1=popup->insertItem( tr("New Group"),         this ,
                               SLOT( newObjectGroup() ) );

        if (currentObj->getPath(true)=="Services/Custom")
            newID1=popup->insertItem( tr("New Custom Service"),this ,
                               SLOT( newCustom() ) );

        if (currentObj->getPath(true)=="Services/IP")
            newID1=popup->insertItem( tr("New IP Service"),    this ,
                               SLOT( newIP() ) );

        if (currentObj->getPath(true)=="Services/ICMP")
            newID1=popup->insertItem( tr("New ICMP Service"),  this ,
                               SLOT( newICMP() ) );

        if (currentObj->getPath(true)=="Services/TCP")
            newID1=popup->insertItem( tr("New TCP Service"),   this ,
                               SLOT( newTCP() ) );

        if (currentObj->getPath(true)=="Services/UDP")
            newID1=popup->insertItem( tr("New UDP Service"),   this ,
                               SLOT( newUDP() ) );

        if (currentObj->getPath(true)=="Services/Groups")
            newID1=popup->insertItem( tr("New Group"),         this ,
                               SLOT( newServiceGroup() ) );

        if (currentObj->getPath(true)=="Time")
            newID1=popup->insertItem( tr("New Time Interval"), this ,
                               SLOT( newInterval() ) );

        popup->insertSeparator();
        popup->insertItem( tr("Find") , this , SLOT( find()));

        if (Firewall::cast(currentObj)!=NULL)
        {
            popup->insertSeparator();
            popup->insertItem( tr("Compile") , this , SLOT( compile()));
            popup->insertItem( tr("Install") , this , SLOT( install()));
        }
    } else
    {

        popup->insertItem( tr("Group"), this ,
                           SLOT( groupObjects() ) );

    }

#if 0
/* keep this for debugging  */
    popup->insertSeparator();
    popup->insertItem( tr("dump") , this , SLOT( dumpObj()));
#endif

    if (getCurrentObjectTree()->getNumSelected()==1)
    {
        popup->setItemEnabled(edtID,  ! FWBTree::isSystem(currentObj) );
    } else
        popup->setItemEnabled(edtID,  false);

/* TODO: should really scan all selected objects to make sure conditions
 * are met for all of them, not only for currentObj
 */

    bool f1=true;
    bool f2=true;
    bool f3=true;
    bool f4=true;
    bool f5=true;

    bool inDeletedObjects = false;

    vector<FWObject*> so = getCurrentObjectTree()->getSelectedObjects();
    for (vector<FWObject*>::iterator i=so.begin();  i!=so.end(); ++i)
    {
        FWObject *obj= *i;
        f1= (f1 && ! FWBTree::isSystem(obj) && ! Interface::isA(obj) &&
             ! Library::isA(obj) );

        inDeletedObjects = (obj->getLibrary()->getId()==FWObjectDatabase::getDeletedObjectsId());
        f1 = f1 && !inDeletedObjects;

        f2= (f2 && ! FWBTree::isSystem(obj) && ! Interface::isA(obj) &&
             ! obj->isReadOnly() && ! Library::isA(obj) && moveTargets!=0);

        f3= (f3 && ! FWBTree::isSystem(currentObj) && ! Library::isA(currentObj));
        f4= (f4 && ! FWBTree::isSystem(currentObj));

        f5= (f5 && ! obj->isReadOnly() );
    }

    popup->setItemEnabled(dupID, f1); 
    popup->setItemEnabled(movID, f2);
    popup->setItemEnabled(copyID,f3);
    
    popup->setItemEnabled(cutID, f3);
    popup->setItemEnabled(delID, f4);

    popup->setItemEnabled(newID1,f5);
    popup->setItemEnabled(newID2,f5);

    if (inDeletedObjects) popup->changeItem(movID, tr("Undelete...") );

    popup->exec( pos );
}

void ObjectManipulator::find()
{
    if (getCurrentObjectTree()->getNumSelected()==0) return;

    FWObject *obj=getCurrentObjectTree()->getSelectedObjects().front();
    if (obj==NULL) return;
    fd->setObject( obj );
    fd->show();
}

void ObjectManipulator::dumpObj()
{
    if (getCurrentObjectTree()->getNumSelected()==0) return;

    FWObject *obj=getCurrentObjectTree()->getSelectedObjects().front();
    if (obj==NULL) return;
    obj->dump(true,true);
}

void ObjectManipulator::compile()
{
    if (getCurrentObjectTree()->getNumSelected()==0) return;

    FWObject *obj=getCurrentObjectTree()->getSelectedObjects().front();
    if (obj==NULL) return;
    mw->showFirewall(obj);
    mw->compile();
}

void ObjectManipulator::install()
{
    if (getCurrentObjectTree()->getNumSelected()==0) return;

    FWObject *obj=getCurrentObjectTree()->getSelectedObjects().front();
    if (obj==NULL) return;
    mw->showFirewall(obj);
    mw->install();
}

void ObjectManipulator::editObj()
{
    if (getCurrentObjectTree()->getNumSelected()==0) return;

    FWObject *obj=getCurrentObjectTree()->getSelectedObjects().front();
    if (obj==NULL) return;
    edit(obj);
}

FWObject* ObjectManipulator::duplicateObject(FWObject *targetLib,
                                             FWObject *obj,
                                             const QString &name,
                                             bool  askForAutorename)
{
    if (!isTreeReadWrite(this, targetLib)) return NULL;

    openLib(targetLib);

    FWObject *o=NULL;

    QString n;
    if (!name.isEmpty()) n=name;
    else                 n=QString::fromUtf8(obj->getName().c_str());

    openObject(o=createObject(obj->getTypeName().c_str(), n, obj));

    if (Host::isA(o) || Firewall::isA(o) || Interface::isA(o))
        autorename(o,askForAutorename);

    return o;
}

void ObjectManipulator::duplicateObj(int libid)
{
    if (getCurrentObjectTree()->getNumSelected()==0) return;

    ObjectTreeView* ot=getCurrentObjectTree();
    ot->freezeSelection(true);
    FWObject *obj;
    vector<FWObject*> so = getCurrentObjectTree()->getSelectedObjects();
    for (vector<FWObject*>::iterator i=so.begin();  i!=so.end(); ++i)
    {
        obj= *i;

        if ( FWBTree::isSystem(obj) ||
             Interface::isA(obj)    ||
             Interface::isA(obj->getParent())) continue;

        FWObject *cl   = idxToLibs[libid];

        FWObject *nobj = duplicateObject(cl,obj,"",false);

        if (nobj->getTypeName()==Firewall::TYPENAME)
        {
            mw->addFirewall(nobj);
            mw->showFirewall(nobj);
        }
    }
    ot->freezeSelection(false);
}

void ObjectManipulator::moveObject(FWObject *targetLib, FWObject *obj)
{
    FWObject *cl=getCurrentLib();
    if (cl==targetLib) return;

    bool inDeletedObjects = (obj->getParent()->getId()==FWObjectDatabase::getDeletedObjectsId());

    QString parentType;
    QString parentName;

    if (inDeletedObjects)
    {
        QString objType = obj->getTypeName().c_str();
        FWBTree::getStandardSlotForObject(objType, parentType, parentName);
    } else
    {
        parentType = obj->getParent()->getTypeName().c_str();
        parentName = obj->getParent()->getName().c_str();
    }

    if (fwbdebug)
    {
        qDebug("ObjectManipulator::moveObject  parentType= %s",
               parentType.latin1());
        qDebug("ObjectManipulator::moveObject  parentName= %s",
               parentName.latin1());
    }

    FWObject *grp  = targetLib->findObjectByName(parentType.latin1(),
                                                 parentName.latin1());

    if (fwbdebug)
        qDebug("ObjectManipulator::moveObject  grp= %p", grp);

    if (grp==NULL) grp=targetLib;

    if (fwbdebug)
        qDebug("ObjectManipulator::moveObject  grp= %s",
               grp->getName().c_str());

    if (!grp->isReadOnly())
    {
        obj->ref();
        obj->ref();

        if (fwbdebug)
            qDebug("ObjectManipulator::moveObject  removing from the widget");

        ObjectTreeViewItem *itm = allItems[obj];
        if (itm->parent()==NULL) return;

        itm->parent()->takeItem(itm);

        if (fwbdebug)
            qDebug("ObjectManipulator::moveObject  removing from the tree");

        obj->getParent()->remove(obj);

        if (fwbdebug)
            qDebug("ObjectManipulator::moveObject  adding to the tree");

        grp->add(obj);
        obj->unref();

        if (fwbdebug)
            qDebug("ObjectManipulator::moveObject  adding to the widget");

        allItems[grp]->insertItem(itm);
    }

//    if (fwbdebug)
//        qDebug("ObjectManipulator::moveObject  open lib cl %s",
//               cl->getName().c_str());
//    openLib(cl);

    if (fwbdebug)
        qDebug("ObjectManipulator::moveObject  all done");
}

/*
 *  targetLibName is the name of the target library in Unicode
 */
void ObjectManipulator::moveObject(const QString &targetLibName,
                                   FWObject *obj)
{
    list<FWObject*> ll = mw->db()->getByType( Library::TYPENAME );
    for (FWObject::iterator i=ll.begin(); i!=ll.end(); i++)
    {
        FWObject *lib=*i;
        if (targetLibName==QString::fromUtf8(lib->getName().c_str()))
        {
            if (fwbdebug)
                qDebug("ObjectManipulator::moveObject  found lib %s",
                       lib->getName().c_str() );

            moveObject(lib,obj);
        }
    }
}

void ObjectManipulator::moveObj(int libid)
{
    if (getCurrentObjectTree()->getNumSelected()==0) return;

    ObjectTreeView* ot=getCurrentObjectTree();
    ot->freezeSelection(true);
    FWObject *obj;

    vector<FWObject*> so = getCurrentObjectTree()->getSelectedObjects();
    for (vector<FWObject*>::iterator i=so.begin();  i!=so.end(); ++i)
    {
        obj= *i;

        if (fwbdebug)
        {
            qDebug("ObjectManipulator::moveObj  #");
            qDebug("ObjectManipulator::moveObj  obj=%p  obj: %s",
                   obj, obj->getName().c_str() );
        }

        if ( FWBTree::isSystem(obj) ||
             Interface::isA(obj)    ||
             Interface::isA(obj->getParent())) continue;

        FWObject *cl   = idxToLibs[libid];

        moveObject(cl,obj);
    }
    ot->freezeSelection(false);
}

void ObjectManipulator::copyObj()
{
    if (getCurrentObjectTree()->getNumSelected()==0) return;
    FWObject *obj;
    FWObjectClipboard::obj_clipboard->clear();

    vector<FWObject*> so = getCurrentObjectTree()->getSelectedObjects();
    for (vector<FWObject*>::iterator i=so.begin();  i!=so.end(); ++i)
    {
        obj= *i;
        if ( ! FWBTree::isSystem(obj) )
            FWObjectClipboard::obj_clipboard->add( obj );
    }
}

void ObjectManipulator::cutObj()
{
    copyObj();
    deleteObj();   // works with the list getCurrentObjectTree()->getSelectedObjects()
}

void ObjectManipulator::pasteObj()
{
    if (getCurrentObjectTree()->getNumSelected()==0) return;
    FWObject *obj=getCurrentObjectTree()->getSelectedObjects().front();
    if (obj==NULL) return;

    vector<FWObject*>::iterator i;
    for (i= FWObjectClipboard::obj_clipboard->begin();
         i!=FWObjectClipboard::obj_clipboard->end(); ++i)
    {
        FWObject *co= *i;
        FWObject *nobj=pasteTo( obj , co );
        if (nobj!=NULL)
        {
            if (Firewall::isA(nobj)) mw->addFirewall(nobj);
            if (Firewall::isA(obj))  mw->showFirewall(obj);
        }
    }
}

FWObject*  ObjectManipulator::pasteTo(FWObject *target,FWObject *obj,bool openobj)
{
    FWObject *ta=target;
    try
    {
/* clipboard holds a copy of the object */
//        if (ta->getTypeName()==obj->getTypeName()) ta=ta->getParent();

        Host *hst=Host::cast(ta);   // works for firewall, too

        if (
            (FWBTree::isSystem(ta) && FWBTree::validateForInsertion(ta,obj)) ||
            (hst!=NULL && hst->validateChild(obj))
        )
        {
/* add a copy of the object to system group */

            FWObject *nobj=
                mw->db()->create(obj->getTypeName(),true);
            assert (nobj!=NULL);
            nobj->ref();
            nobj->duplicate(obj,true);   // creates new object ID

            makeNameUnique(ta,nobj);
            ta->add( nobj );
            insertSubtree( allItems[ta], nobj);

            if (openobj) openObject(nobj);

            return nobj;
        }

        Group *grp=Group::cast(ta);

        if (grp!=NULL && grp->validateChild(obj))
        {
/* check for duplicates. We just won't add an object if it is already there */
            string cp_id=obj->getId();
            list<FWObject*>::iterator j;
            for(j=grp->begin(); j!=grp->end(); ++j)     
            {
                FWObject *o1=*j;
                if(cp_id==o1->getId()) return o1;

                FWReference *ref;
                if( (ref=FWReference::cast(o1))!=NULL &&
                    cp_id==ref->getPointerId()) return o1;
            }

            grp->addRef(obj);
            if (openobj) openObject(grp);
        }
    }
    catch(FWException &ex)
    {
        QMessageBox::warning(
            this,"Firewall Builder", 
            ex.toString().c_str(),
            "&Continue", QString::null,QString::null,
            0, 1 );

    }

    return obj;
}


void ObjectManipulator::deleteObj()
{
    if (getCurrentObjectTree()->getNumSelected()==0) return;

    FWObject *obj;
    bool emptyingTrash      = false;
    bool emptyingTrashInLib = false;

    vector<FWObject*> so = getCurrentObjectTree()->getSelectedObjects();
    for (vector<FWObject*>::iterator i=so.begin();  i!=so.end(); ++i)
    {
        obj= *i;
        emptyingTrash |= 
            obj->getParent()->getId()==FWObjectDatabase::getDeletedObjectsId();
    }

    emptyingTrashInLib = emptyingTrash && mw->editingLibrary();

    QString msg;

    if (emptyingTrashInLib)
msg = tr(
    "Emptying of the 'Deleted Objects' in a library file is not recommended.\n"
    "When you remove deleted objects from a library file, Firewall Builder\n"
    "loses ability to track them. If a group or a policy rule in some\n"
    "data file still uses removed object from this library, you may encounter\n"
    "unusual and unexpected behavior of the program.\n"
    "Do you want to delete selected objects anyway ?"
);
    else
msg = tr(
    "When you delete an object, it is removed from the tree and\n"
    "all groups and firewall policy rules that reference it.\n"
    "Do you want to delete selected objects ?"
);

    if ( (!emptyingTrash || emptyingTrashInLib) &&
         QMessageBox::warning(
             this,"Firewall Builder", msg,
             "&Yes", "&No", QString::null,
             0, 1 )!=0) return;

/* need to work with a copy of the list of selected objects because
 * some of the methods we call below clear list getCurrentObjectTree()->getSelectedObjects()
 */

    for (vector<FWObject*>::iterator i=so.begin();  i!=so.end(); ++i)
    {
        obj= *i;
        openObject(obj);

//        if ( obj->isReadOnly() ) continue;

        if ( ! FWBTree::isSystem(obj) )
        {
            if (Library::isA(obj))
            {
                list<FWObject*> ll=mw->db()->getByType(Library::TYPENAME);
                if (ll.size()==1)  return;

                if (QMessageBox::warning(
                        this,"Firewall Builder", 
                        tr("When you delete a library, all objects that belong to it\ndisappear from the tree and all groups and rules that reference them.\nYou won't be able to reverse this operation later.\nDo you still want to delete library %1?")
                        .arg(QString::fromUtf8(obj->getName().c_str())),
                        "&Yes", "&No", QString::null,
                        0, 1 )!=0 ) continue;
            }

            if (oe->isVisible() && oe->getOpened()==obj) oe->hide();

            delObj(obj);
//        currentObj=NULL;

        }
    }
}

void ObjectManipulator::delObj(FWObject *obj,bool openobj)
{
    if (obj->getId()==STANDARD_LIB || obj->getId()==DELETED_LIB) return;

    try
    {
        FWObject *parent=obj->getParent();
        bool islib  = (Library::isA(obj));
//        bool isintf = (Interface::isA(obj) && Firewall::isA(parent));
        bool isfw   = (Firewall::isA(obj));
        bool isDelObj = (obj->getLibrary()->getId()==FWObjectDatabase::getDeletedObjectsId()
);

/*
 * TODO: we have to remove not only the object, but also all its child
 * objects from the database, as well as all references to them. This
 * logic should really be in FWObject::removeAllInstances(FWObject*);
 */

/* remove from our internal tables before it is removed from the
 * object tree so we could use obj->getId()
 */
        if (islib)
        {
            int idx = getIdxForLib(obj);
            QListView *otv = idxToTrees[idx];
            assert(otv!=NULL);
            widgetStack->removeWidget( otv );
            removeLib(idx);
        }
        removeObjectFromTreeView(obj);

        if (islib)
        {
            QApplication::setOverrideCursor( QCursor( Qt::WaitCursor) );
            if (obj->isReadOnly()) obj->setReadOnly(false);
            mw->db()->recursivelyRemoveObjFromTree(obj);
            QApplication::restoreOverrideCursor();

            parent=mw->db()->getFirstByType(Library::TYPENAME);

        } else
        {
            QApplication::setOverrideCursor( QCursor( Qt::WaitCursor) );
//            if (obj->isReadOnly()) obj->setReadOnly(false);
            mw->db()->recursivelyRemoveObjFromTree(obj);
            QApplication::restoreOverrideCursor();
        }

        if (isfw) mw->deleteFirewall(obj);

        if (!isDelObj)
        {
            FWObject *dobj = mw->db()->getById( FWObjectDatabase::getDeletedObjectsId());
            if (allItems[dobj]!=NULL) insertSubtree( allItems[dobj], obj );
        }

        mw->reopenFirewall();

        if (openobj) openObject(parent);

    }
    catch(FWException &ex)
    {
        QMessageBox::warning(
            this,"Firewall Builder", 
            ex.toString().c_str(),
            "&Continue", QString::null,QString::null,
            0, 1 );

    }
}

void ObjectManipulator::groupObjects()
{
    if (getCurrentObjectTree()->getNumSelected()==0) return;

    FWObject *co = getCurrentObjectTree()->getSelectedObjects().front();

    newGroupDialog ngd( this );

    if (ngd.exec()==QDialog::Accepted)
    {
        QString objName = ngd.obj_name->text();
        QString libName = ngd.libs->currentText();

        QString parentType;
        QString parentName;

        QString type = ObjectGroup::TYPENAME;
        if (Service::cast(co)!=NULL)  type=ServiceGroup::TYPENAME;
        if (Interval::cast(co)!=NULL) type=IntervalGroup::TYPENAME;

        FWBTree::getStandardSlotForObject(type,parentType, parentName);

        FWObject *newgrp=NULL;

        list<FWObject*> ll = mw->db()->getByType( Library::TYPENAME );
        for (FWObject::iterator i=ll.begin(); i!=ll.end(); i++)
        {
            FWObject *lib=*i;
            if (libName==QString::fromUtf8(lib->getName().c_str()))
            {
/* TODO: need to show a dialog and say that chosen library is read-only.
 * this is not critical though since newGroupDialog fills the pull-down
 * only with names of read-write libraries
 */
                if (lib->isReadOnly()) return;

                newgrp=createObject(lib->findObjectByName(parentType.latin1(),
                                                          parentName.latin1()),
                                      type,objName);
                break;
            }
        }
        if (newgrp==NULL) return;

        FWObject *obj;

        ObjectTreeView* ot=getCurrentObjectTree();
        ot->freezeSelection(true);

        vector<FWObject*> so = getCurrentObjectTree()->getSelectedObjects();
        for (vector<FWObject*>::iterator i=so.begin();  i!=so.end(); ++i)
        {
            obj= *i;
            newgrp->addRef(obj);
        }
        ot->freezeSelection(false);
    
        openObject(newgrp);
        edit(newgrp);
    }
}

void ObjectManipulator::info()
{
    mw->info(currentObj);
    active=true;
}


void ObjectManipulator::edit(FWObject *obj)
{
// need to check here because ObjectTree class does not check for this
// condition but emits signal connected to this method

//    if ( FWBTree::isSystem(obj) ) return;

    if (validateDialog())
    {
        oe->open(obj);
        if (!oe->isVisible())
        {
//            st->restoreGeometry(oe, QRect(960,200,180,600) );
            oe->show();
        }

        currentObj=obj;
        active=true;
    }
}


void ObjectManipulator::openObject(ObjectTreeViewItem *otvi,
                                   bool register_in_history)
{
    openObject(otvi->getFWObject(),register_in_history);
}

/* This method is called from the GroupObjectDialog when user double
 * clicks on the object in a group, so first we should check if this
 * object is shown in the tree and if not, find and open it.
 */
void ObjectManipulator::openObject(FWObject *obj, bool register_in_history)
{
    if (obj==NULL) return;

    raise();
    FWObject *o=obj;
    if (FWReference::cast(o)!=NULL) o=FWReference::cast(o)->getPointer();

    ObjectTreeViewItem *otvi=allItems[o];
// this changes selection and thus calls slot slectionChanged
    showObjectInTree(otvi);

    libs->setCurrentItem( getIdxForLib( obj->getLibrary() ) );
    updateCreateObjectMenu( obj->getLibrary() );
}

void ObjectManipulator::selectionChanged()
{
    if (fwbdebug)
        qDebug("ObjectManipulator::selectionChanged");

    QListView *qlv= getCurrentObjectTree();
    if (qlv==NULL) return;

    ObjectTreeViewItem* otvi=
        dynamic_cast<ObjectTreeViewItem*>(qlv->currentItem());
    if (otvi==NULL) return;

    FWObject *obj=otvi->getFWObject();
    if (obj==NULL) return;

    FWObject *o=obj;
//    if (FWReference::cast(o)!=NULL) o=FWReference::cast(o)->getPointer();

    if (history.empty() || otvi!=history.top().item() )
    {
        mw->backAction->setEnabled( true );
        history.push( HistoryItem(otvi,o->getId().c_str()) );
    }

    currentObj = obj;

    active=true;
    mw->unselectRules();
    info();
}

/*
 * I could use default value for the parameter register_in_history,
 * but that caused problems when this method was used as a slot
 */
void ObjectManipulator::openObject(QListViewItem *item)
{
    ObjectTreeViewItem *otvi=dynamic_cast<ObjectTreeViewItem*>(item);
    openObject(otvi,true);
}

void ObjectManipulator::openObject(FWObject *obj)
{
    openObject(obj,true);
}

void ObjectManipulator::showObjectInTree(ObjectTreeViewItem *otvi)
{
    if (otvi==NULL) return;
    widgetStack->raiseWidget( currentTreeView=otvi->getTree() );
    otvi->getTree()->ensureItemVisible( otvi );
    otvi->getTree()->setCurrentItem( otvi );
    otvi->getTree()->clearSelection();
    otvi->getTree()->setSelected( otvi, true );
}

void ObjectManipulator::invalidateDialog()
{
    currentObj=NULL;
}

void ObjectManipulator::libChanged(int ln)
{
    QListView *lv = idxToTrees[ln];
    assert(lv!=NULL);

    ObjectTreeViewItem *otvi=dynamic_cast<ObjectTreeViewItem*>(lv->currentItem());
    assert(otvi!=NULL);

    currentObj=otvi->getFWObject();
    showObjectInTree( otvi );

    info();

    updateCreateObjectMenu( idxToLibs[ln] );
    return;
}

void ObjectManipulator::updateCreateObjectMenu(FWObject* lib)
{
    bool      f   =
        lib->getId()==STANDARD_LIB ||
        lib->getId()==TEMPLATE_LIB ||
        lib->getId()==DELETED_LIB  ||
        lib->isReadOnly();

    newButton->setEnabled( !f );
    QAction *noa = (QAction*)(mw->child("newObjectAction"));
    noa->setEnabled( !f );
}

void ObjectManipulator::back()
{
//    if (!validateDialog()) return;

    if (!history.empty())
    {
        history.pop();

/* skip objects that have been deleted */
        while ( ! history.empty())
        {
            if (mw->db()->getById( history.top().id().latin1(), true )!=NULL) break;
            history.pop();
        }

        if (history.empty())
        {
            mw->backAction->setEnabled( false );
            return;
        }

        openObject( history.top().item(), false );

        if (oe->isVisible())
        {
            ObjectTreeViewItem *otvi=history.top().item();
            edit(otvi->getFWObject());
        }
    }
}

FWObject*  ObjectManipulator::getCurrentLib()
{
    return idxToLibs[ libs->currentItem() ];
}

ObjectTreeView* ObjectManipulator::getCurrentObjectTree()
{
    return currentTreeView;
}

void ObjectManipulator::openLib(FWObject *obj)
{
    openObject(obj->getLibrary(),false);
}

void ObjectManipulator::newObject()
{
//    QToolButton *btn = (QToolButton*)(mw->toolBar)->child("newObjectAction_action_button");
    newButton->openPopup();
}

FWObject* ObjectManipulator::createObject(const QString &objType,
                                          const QString &objName,
                                          FWObject *copyFrom)
{
    QString parentType;
    QString parentName;

    FWBTree::getStandardSlotForObject(objType, parentType, parentName);

    if (fwbdebug)
        qDebug("ObjectManipulator::createObject: parentType=%s parentName=%s",
               parentType.latin1(), parentName.latin1() );

    if (!validateDialog()) return NULL;

    if (fwbdebug) qDebug("ObjectManipulator::createObject   check 2");

    if (parentType.isEmpty() || parentName.isEmpty()) return NULL;

    FWObject *lib  = getCurrentLib();
    int       i = 0;

    if (fwbdebug)
    {
        qDebug("lib: %s %s",lib->getName().c_str(), lib->getId().c_str());
        qDebug("lib: isReadOnly=%d isLoaded=%d",
               lib->isReadOnly(), addOnLibs->isLoaded( lib->getName() ) );
        qDebug("libs->count()=%d", libs->count() );
    }

    while ( lib->getId()==STANDARD_LIB ||
            lib->getId()==TEMPLATE_LIB ||
            lib->getId()==DELETED_LIB  ||
            lib->isReadOnly() )
    {
        if (i>=libs->count())
        {
            if (fwbdebug)
                qDebug("ObjectManipulator::createObject   return NULL");
            return NULL;
        }

        lib= idxToLibs[i];

        if (fwbdebug)
        {
            qDebug("i=%d",i);
            qDebug("lib: %s %s",lib->getName().c_str(), lib->getId().c_str());
            qDebug("lib: isReadOnly=%d isLoaded=%d",
                   lib->isReadOnly(), addOnLibs->isLoaded( lib->getName() ) );
        }
        i++;
    }

    return actuallyCreateObject(lib->findObjectByName(parentType.latin1(),
                                                      parentName.latin1()),
                                objType,objName,copyFrom);
}

FWObject* ObjectManipulator::createObject(FWObject *parent,
                                       const QString &objType,
                                       const QString &objName,
                                       FWObject *copyFrom)
{
    if (!validateDialog()) return NULL;

    FWObject *lib  = getCurrentLib();
    int       i = 0;

    assert(parent!=NULL);

    if (fwbdebug)
    {
        qDebug("ObjectManipulator::createObject 2: parent=%s",
               parent->getName().c_str());
        qDebug("ObjectManipulator::createObject 2: objType=%s  objName=%s",
               objType.latin1(), objName.latin1());
    }

    while ( lib->getId()==STANDARD_LIB ||
            lib->getId()==TEMPLATE_LIB ||
            lib->getId()==DELETED_LIB  ||
            lib->isReadOnly() )
    {
        if (i>=libs->count()) return NULL;
        lib= idxToLibs[i];
        i++;
    }

    if (parent==NULL) parent=lib;

    return actuallyCreateObject(parent,objType,objName,copyFrom);
}

FWObject* ObjectManipulator::actuallyCreateObject(FWObject *parent,
                                                  const QString &objType,
                                                  const QString &objName,
                                                  FWObject *copyFrom)
{
    if (!isTreeReadWrite(this, parent)) return NULL;

    FWObject *nobj = mw->db()->create(objType.latin1(),true);
    assert(nobj!=NULL);

    if (copyFrom!=NULL) nobj->duplicate(copyFrom,true);
    nobj->setName( string(objName.utf8()) );

    makeNameUnique(parent,nobj);
    parent->add(nobj);

    insertSubtree(allItems[parent], nobj);

    return nobj;
}

void ObjectManipulator::newLibrary()
{
    if (!validateDialog()) return;

    FWObject *nlib = FWBTree::createNewLibrary(mw->db());

    addTreePage( nlib );

    openObject( nlib );
    edit(nlib);
}

void ObjectManipulator::newFirewall()
{
    newFirewallDialog *nfd=new newFirewallDialog();
    nfd->exec();
    FWObject *o = nfd->getNewFirewall();
    delete nfd;

    if (o!=NULL)
    {
        openObject(o);
        edit(o);

        mw->addFirewall(o);
        mw->showFirewall(o);
    }
}

void ObjectManipulator::newHost()
{
    newHostDialog *nhd=new newHostDialog();
    nhd->exec();
    FWObject *o = nhd->getNewHost();
    delete nhd;

    if (o!=NULL)
    {
        openObject(o);
        edit(o);
    }
#if 0
    FWObject *o= createObject(Host::TYPENAME,tr("New Host"));
    openObject(o);
    edit(o);
#endif
}

void ObjectManipulator::newInterface()
{
    if ( currentObj->isReadOnly() ) return;

    FWObject *i=NULL;

    if (Host::isA(currentObj) || Firewall::isA(currentObj))
        i=createObject(currentObj,Interface::TYPENAME,tr("New Interface"));

    if (Interface::isA(currentObj))
        i=createObject(currentObj->getParent(),Interface::TYPENAME,tr("New Interface"));

    if (i==NULL) return;

    if (Firewall::isA(i->getParent())) i->add(new InterfacePolicy());

    openObject( i );
    edit(i);
    
    if (Firewall::isA(i->getParent())) mw->showFirewall(i->getParent());
}

void ObjectManipulator::newNetwork()
{
    FWObject *o=createObject(Network::TYPENAME,tr("New Network"));
    openObject(o);
    edit(o);
}

void ObjectManipulator::newAddress()
{
    if ( currentObj->isReadOnly() ) return;

    FWObject *o;
    if (Interface::isA(currentObj))
    {
	QString iname=QString("%1:%2:ip")
	    .arg(QString::fromUtf8(currentObj->getParent()->getName().c_str()))
	    .arg(QString::fromUtf8(currentObj->getName().c_str()));
        o=createObject(currentObj, IPv4::TYPENAME, iname);
    }
    else
    {
        o=createObject(IPv4::TYPENAME,tr("New Address"));
    }
    openObject(o);
    edit(o);
}

void ObjectManipulator::newPhysicalAddress()
{
    if ( currentObj->isReadOnly() ) return;

    if (Interface::isA(currentObj))
    {
	QString iname=QString("%1:%2:mac")
	    .arg(QString::fromUtf8(currentObj->getParent()->getName().c_str()))
	    .arg(QString::fromUtf8(currentObj->getName().c_str()));
        FWObject *o=createObject(currentObj,physAddress::TYPENAME,iname);
        openObject(o);
        edit(o);
    }
}

void ObjectManipulator::newAddressRange()
{
    FWObject *o;
    o=createObject(AddressRange::TYPENAME,tr("New Address Range"));
    openObject(o);
    edit(o);
}

void ObjectManipulator::newObjectGroup()
{
    FWObject *o;
    o=createObject(ObjectGroup::TYPENAME,tr("New Object Group"));
    openObject(o);
    edit(o);
}


void ObjectManipulator::newCustom()
{
    FWObject *o;
    o=createObject(CustomService::TYPENAME,tr("New Custom Service"));
    openObject(o);
    edit(o);
}

void ObjectManipulator::newIP()
{
    FWObject *o;
    o=createObject(IPService::TYPENAME,tr("New IP Service"));
    openObject(o);
    edit(o);
}

void ObjectManipulator::newICMP()
{
    FWObject *o;
    o=createObject(ICMPService::TYPENAME,tr("New ICMP Service"));
    openObject(o);
    edit(o);
}

void ObjectManipulator::newTCP()
{
    FWObject *o;
    o=createObject(TCPService::TYPENAME,tr("New TCP Service"));
    openObject(o);
    edit(o);
}

void ObjectManipulator::newUDP()
{
    FWObject *o;
    o=createObject(UDPService::TYPENAME,tr("New UDP Service"));
    openObject(o);
    edit(o);
}

void ObjectManipulator::newServiceGroup()
{
    FWObject *o;
    o=createObject(ServiceGroup::TYPENAME,tr("New Service Group"));
    openObject(o);
    edit(o);
}


void ObjectManipulator::newInterval()
{
    FWObject *o;
    o=createObject(Interval::TYPENAME,tr("New Time Interval"));
    openObject(o);
    edit(o);
}



bool ObjectManipulator::validateDialog()
{
    if (currentObj==NULL) return true;
    if (!oe->isVisible()) return true;
    return oe->validateDialog();
}

void ObjectManipulator::select()
{
    if (currentObj==NULL) return;
    ObjectTreeViewItem *otvi=allItems[currentObj];
    otvi->listView()->setSelected(otvi,true);
    active=true;
    mw->unselectRules();
}

void ObjectManipulator::unselect()
{
    if (currentObj==NULL) return;

    for (int i=0; i<libs->count(); i++)
        idxToTrees[i]->clearSelection();

    active=false;
}

bool ObjectManipulator::isSelected()
{
    return active;
}
