/* 

                          Firewall Builder

                 Copyright (C) 2004 NetCitadel, LLC

  Author:  Vadim Kurland     vadim@fwbuilder.org

  $Id: instDialog3.cpp,v 1.17 2004/07/25 05:51:55 vkurland Exp $

  This program is free software which we release under the GNU General Public
  License. You may redistribute and/or modify this program under the terms
  of that license as published by the Free Software Foundation; either
  version 2 of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
 
  To get a copy of the GNU General Public License, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#include "../../config.h"
#include "global.h"

#include "instDialog.h"
#include "instConf.h"

#include <qprogressbar.h>
#include <qmessagebox.h>
#include <qregexp.h>
#include <qprocess.h>
#include <qtimer.h>
#include <qtextbrowser.h>
#include <qlineedit.h>

#include "fwbuilder/Resources.h"
#include "fwbuilder/FWObjectDatabase.h"
#include "fwbuilder/Firewall.h"

#ifndef _WIN32
#  include <unistd.h>
#else
#  include <direct.h>
#endif

#include <errno.h>
#include <iostream>

using namespace std;
using namespace libfwbuilder;


void instDialog::stateMachineSSHSUDO()
{
    char     **cptr;

//    QString s=stdoutBuffer;
//    s.replace('\r',"");    
//
//    progressDisplay->moveCursor( QTextEdit::MoveEnd , false );
//    if (!cnf->quiet && cnf->verbose)
//        progressDisplay->insert( QString("\nS='%1'\n").arg(stdoutBuffer) );

    switch (state)
    {
    case LOGGEDIN:  cptr=OSSHerrors2; break;
    default:        cptr=OSSHerrors1; break;
    }

    for( ; *cptr!=NULL; cptr++)
    {
        if ( stdoutBuffer.findRev(*cptr,-1)!=-1 )
        {
            progressDisplay->append( tr("*** Fatal error :") );
            progressDisplay->append( stdoutBuffer+"\n" );
            stdoutBuffer="";
            proc->tryTerminate();
            QTimer::singleShot( 2000, proc, SLOT(kill()) );
            return;
        }
    }

 entry:
    switch (state)
    {
    case NONE:
    {
        if ( cmpPrompt(stdoutBuffer,scp_pwd_prompt) ||
             cmpPrompt(stdoutBuffer,ssh_pwd_prompt) ||
             cmpPrompt(stdoutBuffer,putty_pwd_prompt) ||
             stdoutBuffer.findRev(passphrase_prompt,-1)!=-1 ||

             cmpPrompt(stdoutBuffer,sudo_pwd_prompt) ||
             cmpPrompt(stderrBuffer,sudo_pwd_prompt) ) 
        {
            stdoutBuffer="";
            proc->writeToStdin( cnf->pwd );
            proc->writeToStdin( "\n" );
            break;
        }
/* we may get to LOGGEDIN state directly from NONE, for example when
 * password is supplied on command line to plink.exe
 */
        if (cmpPrompt(stdoutBuffer,normal_prompt) ||
            cmpPrompt(stdoutBuffer,fwb_prompt))
        {
            state=PUSHING_CONFIG;
// **** this is just a hack to make sure user sees what fw script has to say
//            cnf->verbose=true;
            progressDisplay->moveCursor( QTextEdit::MoveEnd , false );
            if (!cnf->quiet) progressDisplay->insert( tr("Logged in\n") );
            stdoutBuffer="";
        }

        QString fingerprint;
        int n1,n2;
        if (stdoutBuffer.find(newKeyOpenSSH)!=-1 ||
            stdoutBuffer.find(newKeyPlink)!=-1   ||
            stdoutBuffer.find(newKeyVsh)!=-1)
        {
/* new key */

            n1=stdoutBuffer.find(fingerprintPrompt) + strlen(fingerprintPrompt);
            n2=stdoutBuffer.find(QRegExp("[^ 0-9a-f:]"), n1+4);
            fingerprint=stdoutBuffer.mid(n1,n2-n1);

            QString fwobjname=cnf->fwobj->getName().c_str();
            QString msg=newKeyMsg.arg(fwobjname).arg(fingerprint).arg(fwobjname);

            int res =QMessageBox::warning( this, tr("New RSA key"), msg,
                                           tr("Yes"), tr("No"), 0,
                                           0, -1 );

            stdoutBuffer="";
            if (res==0)
            {
                if (ssh.find("vsh.exe")!=-1)
                    proc->writeToStdin( "y\n" );
                else
                    proc->writeToStdin( "yes\n" );
                break;
            } else
            {
                state=EXIT;
                goto entry;
            }
        }
    }
    break;

    case PUSHING_CONFIG:
// if verbose is ON, the text has already been printed
        if (!cnf->quiet && !cnf->verbose) 
        {
            progressDisplay->moveCursor( QTextEdit::MoveEnd , false );
            progressDisplay->insert( stdoutBuffer );
        }
#if 0
        if (stdoutBuffer.find("Rule ")==0) lineCounter++;
        progressBar->setProgress(lineCounter);
#endif
        stdoutBuffer="";
        break;

    case FINISH:
        if ( phase==1 )
        {
            if (proc->normalExit() && proc->exitStatus()==0)
            {
                proc->tryTerminate();
                QTimer::singleShot( 2000, proc, SLOT(kill()) );
                delete proc;
                proc=NULL;

                state=NONE;
                phase=2;
                lineCounter=0;

                if (!confFiles.empty())
                {
                    QString cnffile = confFiles.front();
                    confFiles.pop_front();
                    initiateCopy( cnffile );
                } else
                {
                    QStringList args;

#ifdef _WIN32
                    args.push_back(ssh);
                    if (ssh.find("plink.exe")!=-1) args.push_back("-ssh");

                    args.push_back("-pw");
                    args.push_back(cnf->pwd);
#else
                    args.push_back(argv0.c_str());
                    args.push_back("-X");   // fwbuilder works as ssh wrapper
                    args.push_back("-t");
                    args.push_back("-t");
#endif
                    if (cnf->verbose) args.push_back("-v");

                    if (!cnf->user.isEmpty())
                        args.push_back(cnf->user + "@" + cnf->maddr);
                    else
                        args.push_back(cnf->maddr);

                    QString cmd="";
                    if (!cnf->activationCmd.isEmpty())
                    {
                        cmd=cnf->activationCmd;
                    }else
                    {
                        if (cnf->user=="root")
                            cmd=cnf->fwdir+"/"+cnf->conffile;
                        else
                            cmd="sudo -S "+ cnf->fwdir+"/"+cnf->conffile;
                    }
#ifdef _WIN32
                    cmd ="chmod +x "+cnf->fwdir+"/"+cnf->conffile +
                        "; "+ cmd;
#endif

                    args.push_back("echo \'--**--**--\'; " + cmd);

                    progressDisplay->append("\n");
                    progressDisplay->append(
                        tr("Running command on the firewall: ") );
                    progressDisplay->append(cmd);
                    progressDisplay->append("\n");

                    runSSH( args );
                    stateMachineSSHSUDO();
                }
            } else
            {
                progressDisplay->moveCursor( QTextEdit::MoveEnd , false );
                progressDisplay->insert( "\n");
                progressDisplay->insert(
                    tr("Error activating firewall policy") );
                progressDisplay->insert( "\n");
                phase=0;
                state=FINISH;
                setFinishEnabled( page(1), true );
            }
            break;
        } else
        {
            progressDisplay->moveCursor( QTextEdit::MoveEnd , false );

            if (proc->normalExit() && proc->exitStatus()==0)
            {
                progressDisplay->insert( "\n");
            } else
            {   
                progressDisplay->insert( "\n");
                progressDisplay->insert(
                    tr("Error activating firewall policy") );
                progressDisplay->insert( "\n");
            }
            proc->tryTerminate();
            QTimer::singleShot( 2000, proc, SLOT(kill()) );
            delete proc;
            proc=NULL;

        }
        setFinishEnabled( page(1), true );
        break;

    default:    break;
    }
}

