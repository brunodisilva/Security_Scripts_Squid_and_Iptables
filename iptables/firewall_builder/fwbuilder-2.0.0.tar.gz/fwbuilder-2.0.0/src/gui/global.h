/* 

                          Firewall Builder

                 Copyright (C) 2003 NetCitadel, LLC

  Author:  Vadim Kurland     vadim@fwbuilder.org

  $Id: global.h,v 1.21 2004/07/11 06:43:10 vkurland Exp $

  This program is free software which we release under the GNU General Public
  License. You may redistribute and/or modify this program under the terms
  of that license as published by the Free Software Foundation; either
  version 2 of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
 
  To get a copy of the GNU General Public License, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#ifndef __GLOBAL_DEFS_
#define __GLOBAL_DEFS_

#include <string>

class  QApplication;
class  FWWindow;
class  ObjectManipulator;
class  ObjectEditor;
class  ObjectInfo;
class  QTextEdit;
class  FWBSettings;
class  findDialog;
class  listOfLibraries;

extern QApplication      *app;
extern FWWindow          *mw;
extern ObjectManipulator *om;
extern ObjectEditor      *oe;
extern QTextEdit         *oi;
extern FWBSettings       *st;
extern findDialog        *fd;
    
extern listOfLibraries   *addOnLibs;


extern std::string     appRootDir;
extern std::string     userDataDir;
extern std::string     respath;
extern std::string     localepath;
extern std::string     librespath;
extern std::string     sysfname;
extern std::string     tempfname;
extern std::string     argv0;
extern std::string     ee;
extern int             fwbdebug;

#define STANDARD_LIB "syslib000"
#define USER_LIB     "syslib001"
#define TEMPLATE_LIB "syslib100"
#define DELETED_LIB  "sysid99"

#ifdef NDEBUG
#  undef NDEBUG
#  include <assert.h>
#  define NDEBUG
#else
#  include <assert.h>
#endif

#endif
