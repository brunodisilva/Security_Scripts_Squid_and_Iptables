/*

                          Firewall Builder

                 Copyright (C) 2003 NetCitadel, LLC

  Author:  Vadim Kurland     vadim@fwbuilder.org

  $Id: findDialog.h,v 1.3 2004/06/15 05:40:00 vkurland Exp $

  This program is free software which we release under the GNU General Public
  License. You may redistribute and/or modify this program under the terms
  of that license as published by the Free Software Foundation; either
  version 2 of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
 
  To get a copy of the GNU General Public License, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/


#ifndef __FINDDIALOG_H_
#define __FINDDIALOG_H_

#include "config.h"
#include <finddialog_q.h>

#include "fwbuilder/FWObject.h"


class findDialog : public findDialog_q
{
    Q_OBJECT

    QString                   lastSearch;
    libfwbuilder::FWObject   *lastFound;
    libfwbuilder::FWObject::tree_iterator   treeSeeker;

    bool match(const QString &name);
    
 public:
    findDialog(QWidget *p);

    void setObject(libfwbuilder::FWObject *o);

public slots:
    virtual void find();
    virtual void findNext();
    virtual void reset();
    virtual void findTextChanged(const QString&);

    void makeActive();
    
 protected:

    virtual void showEvent( QShowEvent *ev);
    virtual void hideEvent( QHideEvent *ev);
    
};

#endif // __FINDDIALOG_H
