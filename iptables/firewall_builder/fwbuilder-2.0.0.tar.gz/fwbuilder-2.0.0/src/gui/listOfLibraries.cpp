/* 

                          Firewall Builder

                 Copyright (C) 2003 NetCitadel, LLC

  Author:  Vadim Kurland     vadim@fwbuilder.org

  $Id: listOfLibraries.cpp,v 1.7 2004/07/21 05:44:47 vkurland Exp $

  This program is free software which we release under the GNU General Public
  License. You may redistribute and/or modify this program under the terms
  of that license as published by the Free Software Foundation; either
  version 2 of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
 
  To get a copy of the GNU General Public License, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#include "config.h"
#include "global.h"

#include "fwbuilder/Library.h"
#include "fwbuilder/FWObjectDatabase.h"

#include "FWBSettings.h"
#include "upgradePredicate.h"
#include "listOfLibraries.h"

#include "qobject.h"
#include <qdir.h>
#include <qfile.h>

#include <iostream>

using namespace std;
using namespace libfwbuilder;

listOfLibraries::listOfLibraries()
{
// build list of available libraries

/* first read user's preferences. User may want to load some libraries
 * that we usually find but do not load by default (e.g. templates)
 */

    add(sysfname,true);
    add(tempfname);

#ifdef _WIN32
    QString dir = appRootDir + "/lib";
#else
    QString dir = QString(getenv("HOME")) + "/.fwbuilder/lib";
#endif

    QDir d(dir, "*.fwb" );
    for (unsigned int i=0; i<d.count(); ++i)
        add( (dir + "/" + d[i]).latin1() );

    load();
}

void listOfLibraries::load()
{
    int N = st->getInt("Libraries/num");
    for (int i=0; i<N; ++i)
    {
        QString lp;
        QString s;
        bool    l;

        lp = QString("Libraries/lib%1_path").arg(i);
        s = st->getStr( lp );

        lp = QString("Libraries/lib%1_load").arg(i);
        l = st->getBool( lp );

        add( s.latin1() , l );
    }
}

void listOfLibraries::save()
{
    st->setInt("Libraries/num", size() );

    int n = 0;
    for (list<libData>::iterator i=begin(); i!=end(); ++i,++n)
    {
        QString lp;

        lp = QString("Libraries/lib%1_path").arg(n);
        st->setStr( lp , i->path.c_str() );

        lp = QString("Libraries/lib%1_load").arg(n);
        st->setBool( lp , i->load );
    }
}

list<libData>::iterator listOfLibraries::add(const string &path, bool load)
{
    string name;
    string id;

    for (list<libData>::iterator i=begin(); i!=end(); ++i)
        if (i->path == path) return i;

    if ( ! QFile::exists(path.c_str()) ) return end();

    MessageBoxUpgradePredicate upgrade_predicate;

    FWObjectDatabase *ndb = new FWObjectDatabase();
    ndb->load( path, &upgrade_predicate,librespath);
    FWObject *lib=ndb->getFirstByType(Library::TYPENAME);
    if (lib==NULL)
    {
        QMessageBox::critical(
            NULL,"Firewall Builder", 
            QObject::tr("Library file %1 is corrupted.").arg(path.c_str()),
            "&Continue", QString::null, QString::null,
            0, 1 );
        return end();
    }
    name=lib->getName();
    id  =lib->getId();
    for (list<libData>::iterator i=begin(); i!=end(); ++i)
    {
        if (i->id == id )
        {
            delete ndb;
            return i;
        }
    }

    list<libData>::iterator i1=insert(end(),libData( id, name, path, false) );
    i1->load=load;

    delete ndb;
    return i1;
}

void listOfLibraries::setLoad(const string &libPath, bool f)
{
    for (list<libData>::iterator i=begin(); i!=end(); ++i)
    {
        if (i->path == libPath) { i->load=f; break; }
    }
}

bool listOfLibraries::getLoad(const string &libPath)
{
    for (list<libData>::iterator i=begin(); i!=end(); ++i)
    {
        if (i->path == libPath) { return (i->load); }
    }
    return false;
}

bool listOfLibraries::isLoaded(const string &libName)
{
    for (list<libData>::iterator i=begin(); i!=end(); ++i)
    {
        if (i->name == libName ) { return (i->load); }
    }
    return false;
}

bool listOfLibraries::isKnown(const string &id)
{
    for (list<libData>::iterator i=begin(); i!=end(); ++i)
    {
        if (i->id == id ) return true;
    }
    return false;
}

