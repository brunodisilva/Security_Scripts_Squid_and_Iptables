/* 

                          Firewall Builder

                 Copyright (C) 2003 NetCitadel, LLC

  Author:  Vadim Kurland     vadim@fwbuilder.org

  $Id: LibExportDialog.h,v 1.4 2004/06/30 05:43:35 vkurland Exp $

  This program is free software which we release under the GNU General Public
  License. You may redistribute and/or modify this program under the terms
  of that license as published by the Free Software Foundation; either
  version 2 of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
 
  To get a copy of the GNU General Public License, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/


#ifndef __LIBEXPORTDIALOG_H_
#define __LIBEXPORTDIALOG_H_

#include "libexport_q.h"

#include <qfiledialog.h>
#include <qlistview.h>

#include <map>
#include <list>

class RCSFilePreview;

namespace libfwbuilder {
    class FWObject;
    class FWReference;
};

class LibExportDialog : public QFileDialog {

    Q_OBJECT

    LibExport_q  *le;

    std::map<int, libfwbuilder::FWObject*>   mapOfLibs;

    void init();

    void findExternalRefs(libfwbuilder::FWObject *lib,
                          libfwbuilder::FWObject *root,
                          std::list<libfwbuilder::FWReference*> &extRefs);

 public:

    LibExportDialog(const QString& dirName, const QString& filter = QString::null,
                    QWidget* parent=0, const char* name=0, bool modal = FALSE );
    LibExportDialog(QWidget* parent=0, const char* name=0, bool modal = FALSE );

 protected slots:

     virtual void accept();
     virtual void libSelected(QListBoxItem *itm);
};

#endif
