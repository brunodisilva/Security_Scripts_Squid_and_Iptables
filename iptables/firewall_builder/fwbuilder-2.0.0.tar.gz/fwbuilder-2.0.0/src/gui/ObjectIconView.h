/* 

                          Firewall Builder

                 Copyright (C) 2003 NetCitadel, LLC

  Author:  Vadim Kurland     vadim@fwbuilder.org

  $Id: ObjectIconView.h,v 1.2 2004/05/30 00:12:12 vkurland Exp $

  This program is free software which we release under the GNU General Public
  License. You may redistribute and/or modify this program under the terms
  of that license as published by the Free Software Foundation; either
  version 2 of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
 
  To get a copy of the GNU General Public License, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/


#ifndef  __OBJECTICONVIEW_H_
#define  __OBJECTICONVIEW_H_

#include <qiconview.h>
#include <qdragobject.h>
#include <qiconview.h>

namespace libfwbuilder {
    class FWObject;
};

class ObjectIconView : public QIconView {

    Q_OBJECT

 protected:

    virtual QDragObject* dragObject();
    virtual void dragEnterEvent( QDragEnterEvent *ev);
//    virtual void dropEvent(QDropEvent *ev);
    virtual void keyPressEvent( QKeyEvent* ev );
    
    
    
 public:

    ObjectIconView(QWidget* parent = 0, const char * name = 0, WFlags f = 0);
    
 signals:

    void delObject_sign();
};


#endif

