/****************************************************************************
** ui.h extension file, included from the uic-generated form implementation.
**
** If you wish to add, delete or rename functions or slots use
** Qt Designer which will update this file, preserving your code. Create an
** init() function in place of a constructor, and a destroy() function in
** place of a destructor.
*****************************************************************************/

#include "stdio.h"

void FWBMainWindow_q::init()
{

}

void FWBMainWindow_q::fileNew()
{

}


void FWBMainWindow_q::fileOpen()
{

}


void FWBMainWindow_q::fileSave()
{

}


void FWBMainWindow_q::fileSaveAs()
{

}

void FWBMainWindow_q::filePrint()
{

}


void FWBMainWindow_q::fileExit()
{
 
}


void FWBMainWindow_q::editUndo()
{

}


void FWBMainWindow_q::editRedo()
{

}


void FWBMainWindow_q::editCut()
{

}


void FWBMainWindow_q::editCopy()
{

}


void FWBMainWindow_q::editPaste()
{

}


void FWBMainWindow_q::editFind()
{

}


void FWBMainWindow_q::helpIndex()
{

}


void FWBMainWindow_q::helpContents()
{

}


void FWBMainWindow_q::helpAbout()
{

}






void FWBMainWindow_q::openFirewall( int )
{

}


void FWBMainWindow_q::fileClose()
{

}


void FWBMainWindow_q::compile()
{

}


void FWBMainWindow_q::install()
{

}




void FWBMainWindow_q::changeInfoStyle()
{

}


void FWBMainWindow_q::editPrefs()
{

}


void FWBMainWindow_q::windowNew()
{

}


void FWBMainWindow_q::appendRuleAtBottom()
{

}


void FWBMainWindow_q::insertRule()
{

}


void FWBMainWindow_q::moveRuleUp()
{

}


void FWBMainWindow_q::moveRuleDown()
{

}


void FWBMainWindow_q::addRuleAfterCurrent()
{

}


void FWBMainWindow_q::removeRule()
{

}


void FWBMainWindow_q::copyRule()
{

}


void FWBMainWindow_q::cutRule()
{

}


void FWBMainWindow_q::pasteRuleAbove()
{

}


void FWBMainWindow_q::pasteRuleBelow()
{

}


void FWBMainWindow_q::editDelete()
{

}


void FWBMainWindow_q::fileImport()
{

}

void FWBMainWindow_q::fileExport()
{

}

void FWBMainWindow_q::newObject()
{

}


void FWBMainWindow_q::debug()
{

}


void FWBMainWindow_q::fileProp()
{

}

void FWBMainWindow_q::moveRule()
{

}

void FWBMainWindow_q::fileAddToRCS()
{

}

void FWBMainWindow_q::fileDiscard()
{

}