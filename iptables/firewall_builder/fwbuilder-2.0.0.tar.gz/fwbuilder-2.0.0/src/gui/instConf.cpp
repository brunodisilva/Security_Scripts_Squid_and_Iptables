/* 

                          Firewall Builder

                 Copyright (C) 2003 NetCitadel, LLC

  Author:  Vadim Kurland     vadim@fwbuilder.org

  $Id: instConf.cpp,v 1.2 2004/04/25 19:51:24 vkurland Exp $

  This program is free software which we release under the GNU General Public
  License. You may redistribute and/or modify this program under the terms
  of that license as published by the Free Software Foundation; either
  version 2 of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
 
  To get a copy of the GNU General Public License, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/



#include "../../config.h"

#include "instConf.h"

#include "fwbuilder/Resources.h"
#include "fwbuilder/FWException.h"

#include <iostream>

#include <qobject.h>
#include <qregexp.h>
#include <qsettings.h>

using namespace std;
using namespace libfwbuilder;

instConf::instConf()
{
    quiet=false;
    verbose=false;
    debug=0;
    incremental=false;
    dry_run=false;
    save_diff=false;
    diff_pgm="";
    no_gui=false;
    backup=false;
    backup_file="";
    wdir="./";
    fwobj=NULL;
    maddr="";
    user="";
}

