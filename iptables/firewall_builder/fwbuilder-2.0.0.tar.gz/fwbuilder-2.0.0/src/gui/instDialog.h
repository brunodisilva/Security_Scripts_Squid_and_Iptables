/* 

                          Firewall Builder

                 Copyright (C) 2004 NetCitadel, LLC

  Author:  Vadim Kurland     vadim@fwbuilder.org

  $Id: instDialog.h,v 1.14 2004/07/09 05:29:37 vkurland Exp $

  This program is free software which we release under the GNU General Public
  License. You may redistribute and/or modify this program under the terms
  of that license as published by the Free Software Foundation; either
  version 2 of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
 
  To get a copy of the GNU General Public License, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/


#ifndef __INSTDIALOG_H_
#define __INSTDIALOG_H_


#include "../../config.h"

#include "instdialog_q.h"

#include <qstring.h>
#include <qstringlist.h>

#include <fstream>

class instConf;
class QProcess;
class QEventLoop;


class instDialog : public instDialog_q {

    Q_OBJECT
    
    bool        ready;
    instConf   *cnf;
    QProcess   *proc;
    QEventLoop *eloop;

    QString     stdoutBuffer;
    QString     stderrBuffer;
    QStringList env;
    QString     cmdBuffer;
    QString     pendingCommand;

    QString     ssh;
    QString     scp;
    
    std::ifstream   *config_file;
    QStringList      allConfig;
    int              ncmd;
    int              nLines;
    int              lineCounter;

    QString          confScript;
    QStringList      confFiles;
    
    bool       logged_in;
    bool       enable;
    bool       configure;
    
    QString    newKeyMsg;
    
    enum State { NONE,
                 LOGGEDIN,
                 WAITING_FOR_ENABLE,
                 ENABLE,
                 CONFIG,
                 COMMAND_SENT,
                 WAITING_FOR_SHOW_RUN,
                 WAITING_FOR_CONFIG_PROMPT,
                 CLEAR_CONFIG,
                 PUSHING_CONFIG,
                 EXIT_FROM_CONFIG,
                 SAVE_CONFIG,
                 RUN_SCRIPT,
                 EXIT,
                 FINISH,
                 EXECUTING_COMMAND,
                 COMMAND_DONE
    };

    enum State state;
    int        phase;

    bool cmpPrompt(const QString &str,char *prompt);

    void    stateMachinePIX();
    void    stateMachineSSHSUDO();
    void    stateMachineLinksys();

    static char* normal_prompt;
    static char* fwb_prompt;
    static char* enable_prompt;
    static char* pwd_prompt;
    static char* putty_pwd_prompt;
    static char* scp_pwd_prompt;
    static char* ssh_pwd_prompt;
    static char* ssoft_prompt1;
    static char* ssoft_prompt2;
    static char* ssoft_config_prompt;
    static char* sudo_pwd_prompt;
    static char* passphrase_prompt;
    static char* epwd_prompt;
    
    static char* PIXerrors1[];
    static char* PIXerrors2[];
    static char* PIXerrors3[];

    static char* OSSHerrors1[];
    static char* OSSHerrors2[];

    static char* newKeyOpenSSH;
    static char* newKeyPlink;
    static char* newKeyVsh;
    static char* fingerprintPrompt;
    
 public:
    instDialog(instConf *_c);
    virtual ~instDialog();
    
    void append(const QString &s);
    void append(const char *s);

    void setReady(bool f) { ready=f; }

    void summary();

    QString getUName();
    QString getPWD();
    QString getEPWD();

    QWidget* page(int n) { return QWizard::page(n); }
    
    QString cmd(QProcess *proc,const QString &cmd);

    void    runSSH(const QStringList &args);
    void    initiateCopy(const QString &file);
    
    void    stateMachine();

 protected:

    virtual void showEvent( QShowEvent *ev);
    virtual void hideEvent( QHideEvent *ev);
    
 protected slots:
     void readFromStdout();
     void readFromStderr();
     void processExited();
     void selected(const QString &title);
     void rejected();

     void PIXbackup();
     void PIXincrementalInstall();
    
};


#endif
