/* 

                          Firewall Builder

                 Copyright (C) 2004 NetCitadel, LLC

  Author:  Vadim Kurland     vadim@fwbuilder.org

  $Id: instDialog2.cpp,v 1.15 2004/07/09 05:29:37 vkurland Exp $

  This program is free software which we release under the GNU General Public
  License. You may redistribute and/or modify this program under the terms
  of that license as published by the Free Software Foundation; either
  version 2 of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
 
  To get a copy of the GNU General Public License, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#include "../../config.h"
#include "global.h"

#include "instDialog.h"
#include "instConf.h"

#include <qcheckbox.h>
#include <qlineedit.h>
#include <qtextbrowser.h>
#include <qtextedit.h>
#include <qtimer.h>
#include <qfiledialog.h>
#include <qpushbutton.h>
#include <qlabel.h>
#include <qprogressbar.h>
#include <qmessagebox.h>
#include <qregexp.h>
#include <qprocess.h>
#include <qapplication.h>
#include <qeventloop.h>

#include "fwbuilder/Resources.h"
#include "fwbuilder/FWObjectDatabase.h"
#include "fwbuilder/Firewall.h"
#include "fwbuilder/XMLTools.h"

#ifndef _WIN32
#  include <unistd.h>
#else
#  include <direct.h>
#endif

#include <errno.h>
#include <iostream>

using namespace std;
using namespace libfwbuilder;


void instDialog::stateMachinePIX()
{
    char     **cptr;

//    QString s=stdoutBuffer;
//    s.replace('\r',"");    
//
//    progressDisplay->moveCursor( QTextEdit::MoveEnd , false );
//    if (!cnf->quiet && cnf->verbose)  progressDisplay->insert( s );

    switch (state)
    {
    case LOGGEDIN:  cptr=PIXerrors2; break;
    case ENABLE:    cptr=PIXerrors3; break;
    default:        cptr=PIXerrors1; break;
    }

    for( ; *cptr!=NULL; cptr++)
    {
        if ( stdoutBuffer.findRev(*cptr,-1)!=-1 )
        {
            progressDisplay->append( tr("*** Fatal error :") );
            progressDisplay->append( stdoutBuffer+"\n" );
            stdoutBuffer="";
            proc->tryTerminate();
            QTimer::singleShot( 2000, proc, SLOT(kill()) );
            return;
        }
    }

 entry:
    switch (state)
    {
    case NONE:
    {
        if ( cmpPrompt(stdoutBuffer,pwd_prompt) )
        {
            stdoutBuffer="";
            proc->writeToStdin( cnf->pwd );
            proc->writeToStdin( "\n" );
            break;
        }
/* we may get to LOGGEDIN state directly from NONE, for example when
 * password is supplied on command line to plink.exe
 */
        if (cmpPrompt(stdoutBuffer,normal_prompt) )
        {
            state=LOGGEDIN;
            progressDisplay->moveCursor( QTextEdit::MoveEnd , false );
            progressDisplay->insert( "\n");
            progressDisplay->insert( tr("Logged in") );
            progressDisplay->insert( "\n");
            progressDisplay->insert( tr("Switching to enable mode..."));
            progressDisplay->insert( "\n");
            stdoutBuffer="";
            proc->writeToStdin( "enable\n" );
        }

        QString fingerprint;
        int n1,n2;
        if (stdoutBuffer.find(newKeyOpenSSH)!=-1 ||
            stdoutBuffer.find(newKeyPlink)!=-1)
        {
/* new key */

            n1=stdoutBuffer.find(fingerprintPrompt) + strlen(fingerprintPrompt);
            n2=stdoutBuffer.find(QRegExp("[^ 0-9a-f:]"), n1+4);
            fingerprint=stdoutBuffer.mid(n1,n2-n1);

            QString fwobjname=cnf->fwobj->getName().c_str();
            QString msg=newKeyMsg.arg(fwobjname).arg(fingerprint).arg(fwobjname);

            int res =QMessageBox::warning( this, tr("New RSA key"), msg,
                                           tr("Yes"), tr("No"), 0,
                                           0, -1 );

            stdoutBuffer="";
            if (res==0)
            {
                proc->writeToStdin( "yes\n" );
                break;
            } else
            {
                state=EXIT;
                goto entry;
            }
        }
    }
    break;

    case LOGGEDIN:
        if ( cmpPrompt(stdoutBuffer,epwd_prompt) )
        {
            stdoutBuffer="";
            proc->writeToStdin( cnf->epwd );
            proc->writeToStdin( "\n" );
            state=WAITING_FOR_ENABLE;
        }
        break;

    case WAITING_FOR_ENABLE:
        if ( cmpPrompt(stdoutBuffer,epwd_prompt) )
        {
            stdoutBuffer="";
            proc->writeToStdin( cnf->epwd );
            proc->writeToStdin( "\n" );
            state=WAITING_FOR_ENABLE;
            break;
        }
        if ( cmpPrompt(stdoutBuffer,enable_prompt) )
        {       
            progressDisplay->insert( "\n");
            progressDisplay->insert( tr("In enable mode."));
            progressDisplay->insert( "\n");
            state=ENABLE;  // and go to ENABLE target in switch
        }

    case ENABLE:
        if ( cmpPrompt(stdoutBuffer,enable_prompt) )
        {
            stdoutBuffer="";

            if (cnf->backup)
            {
/* the problem is that QProcess uses select and thus is tightly
 * integrated into event loop. QT uses internal private flag inside
 * QProcess to specifically prevent recursive calls to readyReadStdout
 * (look for d->socketReadCalled in kernel/qprocess_unix.cpp ). So, I
 * _must_ exit this callback before I can send commands to the process
 * and collect the output.
 */
                QTimer::singleShot( 0, this, SLOT(PIXbackup()) );
                break;
            }

            proc->writeToStdin( "config t" );
            proc->writeToStdin( "\n" );
            state=WAITING_FOR_CONFIG_PROMPT;
        }
        break;

    case EXECUTING_COMMAND:
        if ( cmpPrompt(stdoutBuffer,enable_prompt) )
        {       
            QApplication::eventLoop()->exitLoop();
            state=COMMAND_DONE;
        }
        break;

    case WAITING_FOR_CONFIG_PROMPT:
        if ( cmpPrompt(stdoutBuffer,enable_prompt) )
        {
            state=CONFIG;

            if (!cnf->incremental)
            {
/* install full policy */
                QString ff = cnf->wdir+"/"+cnf->conffile;
                config_file = new ifstream(ff.latin1());
                if ( ! *config_file)
                {
                    progressDisplay->append(
                        QObject::tr("Can not open file %1").arg(ff)
                    );
                    state=FINISH;
                    break;
                } else
                {
/* read the whole file */
                    string s0;
                    nLines=0;
                    while ( !config_file->eof() )
                    {
                        getline( *config_file, s0);
                    
                        QString s(s0.c_str());
                        s.stripWhiteSpace();
                        allConfig.push_back(s);
                        nLines++;
                    }
                    config_file->close();
                    delete config_file;
                    config_file=NULL;

                    progressBar->setTotalSteps(nLines);
                }
                state=PUSHING_CONFIG; // and drop to PUSHING_CONFIG case
                if (!cnf->dry_run)
                    progressDisplay->insert(tr("Pushing firewall configuration"));
                progressDisplay->insert( "\n");
                ncmd=0;
            } else
            {
/* install incrementally */

                QTimer::singleShot( 1, this, SLOT(PIXincrementalInstall()) );
                break;
            }
        }

    case PUSHING_CONFIG:
        if ( cmpPrompt(stdoutBuffer,enable_prompt) )
        {
        loop1:
            if ( allConfig.size()==0 )
            {
                state=EXIT_FROM_CONFIG;
                progressDisplay->moveCursor( QTextEdit::MoveEnd , false );
                progressDisplay->insert( tr("*** End ") );
                proc->writeToStdin( "exit\n" );
                break;

            } else
            {
                QString s;

                do {
                    s = allConfig.front();
                    allConfig.pop_front();
                } while (cnf->stripComments && s[0]=='!');

                progressBar->setProgress(progressBar->totalSteps()-allConfig.size());

                s.replace('\"','\'');

                if (!cnf->quiet && !cnf->verbose)
                {
                    QString rl="";
                    if (s.find("! Rule ")!=-1)  rl=s.mid(7);
                    if ( !rl.isEmpty())
                    {
                        progressDisplay->insert( tr("Rule %1").arg(rl) );
                        progressDisplay->insert( "\n");
                    }
                }

                if (!cnf->dry_run)
                {
                    if ( !s.isEmpty())  ncmd++;
                    stdoutBuffer="";
                    proc->writeToStdin( s+"\n"); // send even if s is empty
                    break;
                } else
                {
                    progressDisplay->insert( s+"\n" );
                    goto loop1;
                }
            }
        }
        break;

    case EXIT_FROM_CONFIG:
        if ( cmpPrompt(stdoutBuffer,enable_prompt) )
        {
            if (!cnf->dry_run && ncmd!=0)
            {
                state=SAVE_CONFIG;
                proc->writeToStdin( "wr mem\n");
            } else
            {
                state=EXIT;
                proc->writeToStdin( "exit\n");
            }
        }
        break;

    case SAVE_CONFIG:
        if ( cmpPrompt(stdoutBuffer,enable_prompt) )
        {
            state=EXIT;
            proc->writeToStdin( "exit\n");
        }
        break;

    case EXIT:
        proc->tryTerminate();
        QTimer::singleShot( 2000, proc, SLOT(kill()) );
        state=FINISH;
        break;

    case FINISH:
        setFinishEnabled( page(1), true );
        break;

    default:    break;
    }

}

void instDialog::PIXbackup()
{
    bool sv=cnf->verbose;
    cnf->verbose=false;

    progressDisplay->moveCursor( QTextEdit::MoveEnd , false );
    progressDisplay->insert(
        tr("Making backup copy of the firewall configuration"));
    progressDisplay->insert( "\n");

    QString cfg=cmd(proc,"show run");

    cnf->verbose=sv;

/* if state changed to FINISH, there was an error and ssh terminated */
    if (state==FINISH) return;
    if (state==COMMAND_DONE)
    {
        ofstream ofs(cnf->backup_file.latin1());
        ofs << cfg;
        ofs.close();

        cnf->backup=false;  // backup is done
        state=ENABLE;
    }

    proc->writeToStdin( "\n" );
}

void instDialog::PIXincrementalInstall()
{
    QString current_config;

    bool sv=cnf->verbose;
    cnf->verbose=false;

    progressDisplay->moveCursor( QTextEdit::MoveEnd , false );
    progressDisplay->insert(tr("Reading current firewall configuration"));
    progressDisplay->insert( "\n");

    current_config =cmd(proc,"show run | grep ^telnet|^ssh|^icmp");
    if (state==FINISH) return;
    current_config+=cmd(proc,"show object-group");
    if (state==FINISH) return;
    current_config+=cmd(proc,"show access-list");
    if (state==FINISH) return;
    current_config+=cmd(proc,"show global");
    if (state==FINISH) return;
    current_config+=cmd(proc,"show nat");
    if (state==FINISH) return;
    current_config+=cmd(proc,"show static");
    if (state==FINISH) return;

    cnf->verbose=sv;

    if (state==COMMAND_DONE)
    {
        QString statefile = cnf->wdir+"/"+cnf->conffile + "_current";
        ofstream ofs(statefile.latin1());
        ofs << current_config;
        ofs.close();

        progressDisplay->moveCursor( QTextEdit::MoveEnd , false );
        progressDisplay->insert(tr("Generating configuration diff"));
        progressDisplay->insert( "\n");

        QString cm = cnf->diff_pgm + " \"" + statefile + "\" \"" + cnf->wdir+"/"+cnf->conffile + "\"";

//        progressDisplay->insert(tr("Running command: %1\n").arg(cm));

#ifdef _WIN32
        FILE *f = _popen( cm.latin1(), "r");
#else
        FILE *f = popen( cm.latin1(), "r");
#endif
        if (f==NULL)
        {
            progressDisplay->moveCursor( QTextEdit::MoveEnd , false );
            progressDisplay->insert(
                tr("Fork failed for %1").arg(cnf->diff_pgm));
            progressDisplay->insert( "\n");
            switch (errno)
            {
            case EAGAIN: 
            case ENOMEM:
                progressDisplay->insert(tr("Not enough memory."));
                break;
            case EMFILE:
            case ENFILE:
                progressDisplay->insert(
                    tr("Too many opened file descriptors in the system."));
                break;

            }
            progressDisplay->insert( "\n");
            state=FINISH;
            proc->writeToStdin( "\n" );
            return;
        }

        char buf[1024];
        int  nLines=0;
        while (fgets(buf,1024,f))
        {
            allConfig += buf;
            nLines++;
        }
#ifdef _WIN32
        _pclose(f);
#else
        pclose(f);
#endif

	if (allConfig.isEmpty())
	{
	    allConfig="";
            progressDisplay->moveCursor( QTextEdit::MoveEnd , false );
            progressDisplay->insert(tr("Empty configuration diff"));
            progressDisplay->insert( "\n");
	}

        if (cnf->save_diff)
        {
            ofstream odiff(cnf->wdir+"/"+cnf->diff_file.latin1());
            odiff << allConfig.join("");
            odiff.close();
        }

        state=PUSHING_CONFIG;
        progressBar->setTotalSteps(nLines);
        if (!cnf->dry_run)
            progressDisplay->insert(tr("Pushing firewall configuration\n"));
    }
    proc->writeToStdin( "\n" );
}

