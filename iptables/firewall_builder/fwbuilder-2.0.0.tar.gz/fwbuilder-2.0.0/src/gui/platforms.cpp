/* 

                          Firewall Builder

                 Copyright (C) 2000 NetCitadel, LLC

  Author:  Vadim Kurland     vadim@vk.crocodile.org

  $Id: platforms.cpp,v 1.8 2004/06/29 05:17:37 vkurland Exp $

  This program is free software which we release under the GNU General Public
  License. You may redistribute and/or modify this program under the terms
  of that license as published by the Free Software Foundation; either
  version 2 of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
 
  To get a copy of the GNU General Public License, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#include "config.h"
#include "global.h"

#include "platforms.h"

#include <qobject.h>
#include <qstringlist.h>

#include "fwbuilder/Firewall.h"
#include "fwbuilder/FWOptions.h"
#include "fwbuilder/Management.h"
#include "fwbuilder/Resources.h"

using namespace std;
using namespace libfwbuilder;


bool isUsingNetZone(Firewall *fw)
{
    string platform=fw->getStr("platform");
    return (platform=="pix");
}

bool isDefaultOptions(FWOptions *opt)
{
    bool res=false;
    FWObject *p;

    p=opt;
    do {  p=p->getParent();
    } while ( p!=NULL && Firewall::cast(p)==NULL );

    assert(p!=NULL);

    QString platform = p->getStr("platform").c_str();

    if (PolicyRuleOptions::isA(opt))
    {
	if (platform=="ipfilter") 
        {
	    res= ( ! opt->getBool("log_or_block") && 
		   ! opt->getBool("log_body")     &&
		   ! opt->getBool("log_first")    &&
		   ! opt->getBool("icmp_as_dest") &&
		   opt->getStr("action_on_reject").empty() );
	}

	if (platform=="iptables") 
        {
	    res= ( opt->getStr("log_prefix").empty()       && 
                   opt->getStr("log_level").empty()        && 
		   opt->getStr("action_on_reject").empty() && 
		   opt->getInt("limit_value")<=0  &&
		   opt->getInt("limit_burst")<=0  &&
		   opt->getBool("stateless")==false );
	}

	if (platform=="pix") 
        {
            res= ( opt->getStr("log_level").empty()        && 
                   opt->getInt("log_interval")<=0          &&
                   opt->getBool("disable_logging_for_this_rule")==false );
	}

	if (platform=="pf") 
        {
	    res= ( opt->getStr("log_prefix").empty()       && 
                   opt->getStr("action_on_reject").empty() && 
		   opt->getBool("stateless")==false );
	}

	if (platform=="ipf") 
        {
	    res= ( opt->getStr("ipf_log_facility").empty()       && 
                   opt->getStr("log_level").empty()        && 
                   opt->getStr("action_on_reject").empty() && 
		   ! opt->getBool("stateless") &&
		   ! opt->getBool("ipf_keep_frags") &&
                   ! opt->getBool("ipf_return_icmp_as_dest") );
	}

	if (platform=="ipfw") 
        {
	    res= ( opt->getStr("action_on_reject").empty() && 
		   ! opt->getBool("stateless") );
	}

    }
    return res; 
}

QMap<QString,QString> getVersionsForPlatform(const QString &platform)
{
    QMap<QString,QString> res;

    if (platform=="iptables")
    {
        res[""]         = QObject::tr("- any -");
        res["lt_1.2.6"] = "1.2.6";
        res["ge_1.2.6"] = "1.2.6 to 1.2.8";
        res["1.2.9"]    = QObject::tr("1.2.9 or later");
    } else
    {
        if (platform=="pix") 
        {
            QString lst=Resources::platform_res["pix"]->getResourceStr(
                "/FWBuilderResources/Target/versions").c_str();

            QStringList ll=QStringList::split(',', lst);

            for (QStringList::iterator i=ll.begin(); i!=ll.end(); ++i)
                res.insert( *i, *i );
        } else
        {
            if (platform=="pf") 
            {
                res[""]         = QObject::tr("- any -");
/* add pf versions here */
            } else
            {
                if (platform=="ipf") 
                {
                    res[""]         = QObject::tr("- any -");
/* add ipf versions here */
                } else
                {
                    if (platform=="ipfw") 
                    {
                        res[""]         = QObject::tr("- any -");
/* add ipfw versions here */
                    } else
                        res[""]         = QObject::tr("- any -");
                }
            }
        }
    }

    return res;
}

/* currently we return the same list for all platforms */
QStringList getLogLevels(const QString &platform)
{
    QStringList logLevels;

    logLevels.push_back("");
    logLevels.push_back("alert");
    logLevels.push_back("crit");
    logLevels.push_back("error");
    logLevels.push_back("warning");
    logLevels.push_back("notice");
    logLevels.push_back("info");
    logLevels.push_back("debug");

    return logLevels;
}

QStringList getLogFacilities(const QString &platform)
{
    QStringList logFacilities;

    logFacilities.push_back("");
    logFacilities.push_back("kern");
    logFacilities.push_back("user");
    logFacilities.push_back("mail");
    logFacilities.push_back("daemon");
    logFacilities.push_back("auth");
    logFacilities.push_back("syslog");
    logFacilities.push_back("lpr");
    logFacilities.push_back("news");
    logFacilities.push_back("uucp");
    logFacilities.push_back("cron");
    logFacilities.push_back("authpriv");
    logFacilities.push_back("ftp");
    logFacilities.push_back("local0");
    logFacilities.push_back("local1");
    logFacilities.push_back("local2");
    logFacilities.push_back("local3");
    logFacilities.push_back("local4");
    logFacilities.push_back("local5");
    logFacilities.push_back("local6");
    logFacilities.push_back("local7");

    return logFacilities;
}



