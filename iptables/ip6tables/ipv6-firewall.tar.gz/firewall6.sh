#!/bin/bash

# Basic IPv6 FireWall script by Dennis Kruyt (dennis@klingon.nl)
#
# Sun Jan  5 18:26:28 2003 - DK

#debug
#set -x


cd /opt/scripts/firewall


source ./config6

PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/bin/X11

# change to script directory
cd ${SCRIPTSDIR}

SCRIPT=${SCRIPTSDIR}/firewall6.sh


case "$1" in
  flush)
        echo -e "Starting Firewall:"
        ${IPTABLE6} -F  >> /dev/null 2>&1
	${IPTABLE6} -X  >> /dev/null 2>&1
	echo -e "Setting defaults op ACCEPT!"
        echo -e "ALERT: no firewall rules active"
        # 
        ${IPTABLE6} -P INPUT ACCEPT
        ${IPTABLE6} -P OUTPUT ACCEPT
        ${IPTABLE6} -P FORWARD ACCEPT
        ;;
  start|reload)
        echo -n "Starting Firewall: "
	# paging!
        #

        # create a backup
        TIME=`date +%s`
        tar -czf /opt/backups/firewall/firewall.${TIME}.tar.gz /opt/scripts/firewall
        
        # sending mail
        mail email@address.com -s "Firewall - (re)started" < $0

        # wait
        sleep 1

        # kerneloptions
        echo -n "Loading Kernel options.."
	./kernel_options6.sh

	echo -n "Flushing and deleting all chains.."
        ${IPTABLE6} -F  >> /dev/null 2>&1
	${IPTABLE6} -X  >> /dev/null 2>&1

        # default policy
	echo -n "Setting default policy DROP.."
        ${IPTABLE6} -P INPUT   DROP
        ${IPTABLE6} -P OUTPUT  DROP
        ${IPTABLE6} -P FORWARD DROP

        # ?????????????
        #${IPTABLE} -F -t mangle
        #${IPTABLE} -t mangle -X
	
	echo -e "Loading chains.."
	# create chain blacklist
	${IPTABLE6} --new blacklist
	#And drop the evil ones
	for i in $BLACKLIST6;do
	${IPTABLE6} -A blacklist --src $i -j DROP
	done
	
	#icmp chain
	${IPTABLE6} --new icmprules
	${IPTABLE6} -A icmprules -p icmpv6 -j ACCEPT
	
	# create out chain 
	${IPTABLE6} --new out
	#localhost to localhost
	${IPTABLE6} -A out --src $LOCALHOST6 --dst $LOCALHOST6 -j ACCEPT
	# for now accept all outgoing IPv6 traffic
	${IPTABLE6} -A out --src $SIXXS --dst $ANY6 -j ACCEPT

	
        # create in chain
        ${IPTABLE6} --new in
	#localhost to localhost
	${IPTABLE6} -A in --src $LOCALHOST6 --dst $LOCALHOST6 -j ACCEPT
	# for now accept all incomming IPv6 traffic
	${IPTABLE6} -A in --dst $SIXXS --src $ANY6 -j ACCEPT

	#All that are in trusted may ssh
	for i in $THRUSTED6;do
	${IPTABLE6} -A in -p tcp --dst $SIXXS --dport 22 --src $i -j ACCEPT
        done
		
        # jump to all ipv6 chains
	${IPTABLE6} -A INPUT   -j blacklist
        ${IPTABLE6} -A OUTPUT  -j blacklist
        ${IPTABLE6} -A FORWARD -j blacklist
	
	${IPTABLE6} -A INPUT -j icmprules
	${IPTABLE6} -A OUTPUT -j icmprules

        ${IPTABLE6} -A INPUT -j in
	${IPTABLE6} -A OUTPUT -j out
	
        ;;
  show)
        echo -e "Rules in the firewall: ${CHAIN} \n"
        ${IPTABLE6} -L -n
        ;;
  *)
        echo -e "Usage: ${SCRIPT} {flush|start|reload|show} \n"
        exit 1
        ;;
esac
exit 0
