#!/bin/bash


# forwarding on
#echo "1" > /proc/sys/net/ipv6 blablabla

# Set some other IPv6 proc settings
#echo "1" > /proc/sys/net/ipv6 blablabla