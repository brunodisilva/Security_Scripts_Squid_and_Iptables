/* logrule.c -- makes the "LOG Rule" window. 
 *
 * This file is part of Gtk-IPtables.
 *
 * Gtk-IPtables is Copyright (C) 2003  Daniel E. Testa
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <gtk/gtk.h>
#include <string.h>

#include "logrule.h"

void log_level_func();
void log_prefix_func();
void log_tcp_seq_func();
void log_tcp_options_func();
void log_ip_options_func();
void button_ok_log_func();
void button_cancel_log_func();

void log_rule_win()
{
  window_log = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title(GTK_WINDOW(window_log), "LOG Rule");
  gtk_window_set_policy(GTK_WINDOW(window_log), FALSE, FALSE, FALSE);
  gtk_signal_connect(GTK_OBJECT(window_log), "delete_event",
		     GTK_SIGNAL_FUNC(gtk_widget_destroy), NULL);
  gtk_widget_set_usize(window_log, 250, 210);

  box_log[0] = gtk_vbox_new(FALSE, 0);
  box_log[1] = gtk_hbox_new(FALSE, 0);
  box_log[2] = gtk_hbox_new(FALSE, 0);
  box_log[3] = gtk_hbox_new(FALSE, 0);
  box_log[4] = gtk_hbox_new(FALSE, 0);
  box_log[5] = gtk_hbox_new(FALSE, 0);
  box_log[6] = gtk_hbox_new(FALSE, 0);

  gtk_container_add(GTK_CONTAINER (window_log), box_log[0]);
  
  gtk_box_pack_start(GTK_BOX (box_log[0]), box_log[1], FALSE, FALSE, 5);
  gtk_box_pack_start(GTK_BOX (box_log[0]), box_log[2], FALSE, FALSE, 5);
  gtk_box_pack_start(GTK_BOX (box_log[0]), box_log[3], FALSE, FALSE, 5);
  gtk_box_pack_start(GTK_BOX (box_log[0]), box_log[4], FALSE, FALSE, 5);
  gtk_box_pack_start(GTK_BOX (box_log[0]), box_log[5], FALSE, FALSE, 5);
  gtk_box_pack_start(GTK_BOX (box_log[0]), box_log[6], FALSE, FALSE, 5);
  
  log_level_func();
  log_prefix_func();
  log_tcp_seq_func();
  log_tcp_options_func();
  log_ip_options_func();
  button_cancel_log_func();
  button_ok_log_func();

  gtk_widget_show(box_log[1]);
  gtk_widget_show(box_log[2]);
  gtk_widget_show(box_log[3]);
  gtk_widget_show(box_log[4]);
  gtk_widget_show(box_log[5]);
  gtk_widget_show(box_log[6]);
  gtk_widget_show(box_log[0]);
  gtk_widget_show(window_log);
}

void log_level_func()
{
  check_button_log[0] = gtk_check_button_new_with_label("LOG Level");
  gtk_box_pack_start(GTK_BOX (box_log[1]), check_button_log[0],
		     FALSE, FALSE, 5);
  gtk_widget_show(check_button_log[0]);

  entry_log[0] = gtk_entry_new();
  gtk_widget_set_usize(entry_log[0], 70, 0);
  gtk_signal_connect(GTK_OBJECT(entry_log[0]), "changed",
		     GTK_SIGNAL_FUNC(log_level_callback), entry_log[0]);
  gtk_box_pack_start(GTK_BOX (box_log[1]), entry_log[0], FALSE, FALSE, 3);
  gtk_widget_show(entry_log[0]);
}

void log_prefix_func()
{
  check_button_log[1] = gtk_check_button_new_with_label("LOG Prefix");
  gtk_box_pack_start(GTK_BOX (box_log[2]), check_button_log[1], 
		     FALSE, FALSE, 5);
  gtk_widget_show(check_button_log[1]);

  entry_log[1] = gtk_entry_new();
  gtk_widget_set_usize(entry_log[1], 142, 0);
  gtk_signal_connect(GTK_OBJECT(entry_log[1]), "changed",
		     GTK_SIGNAL_FUNC(log_prefix_callback), entry_log[1]);
  gtk_box_pack_start(GTK_BOX (box_log[2]), entry_log[1], FALSE, FALSE, 0);
  gtk_widget_show(entry_log[1]);
}

void log_tcp_seq_func()
{
  check_button_log[2] = gtk_check_button_new_with_label("LOG TCP Sequence");
  gtk_box_pack_start(GTK_BOX (box_log[3]), check_button_log[2], 
		     FALSE, FALSE, 5);
  gtk_widget_show(check_button_log[2]);
}

void log_tcp_options_func()
{
  check_button_log[3] = gtk_check_button_new_with_label("LOG TCP Options");
  gtk_box_pack_start(GTK_BOX (box_log[4]), check_button_log[3], 
		     FALSE, FALSE, 5);
  gtk_widget_show(check_button_log[3]);
}

void log_ip_options_func()
{
  check_button_log[4] = gtk_check_button_new_with_label("LOG IP Options");
  gtk_box_pack_start(GTK_BOX (box_log[5]), check_button_log[4], 
		     FALSE, FALSE, 5);
  gtk_widget_show(check_button_log[4]);
}

void button_ok_log_func()
{
  button_log[0] = gtk_button_new_with_label(" Accept ");
  gtk_signal_connect(GTK_OBJECT(button_log[0]), "clicked",
		     GTK_SIGNAL_FUNC(make_command_line_log), NULL);
  gtk_signal_connect_object(GTK_OBJECT (button_log[0]), "clicked",
			    GTK_SIGNAL_FUNC (gtk_widget_destroy), 
			    GTK_OBJECT (window_log));
  gtk_box_pack_end(GTK_BOX (box_log[6]), button_log[0], FALSE, FALSE, 10);
  gtk_widget_show(button_log[0]);
}

void button_cancel_log_func()
{
  button_log[1] = gtk_button_new_with_label(" Cancel ");
  gtk_signal_connect_object(GTK_OBJECT (button_log[1]), "clicked",
			    GTK_SIGNAL_FUNC (gtk_widget_destroy), 
			    GTK_OBJECT (window_log));
  gtk_box_pack_end(GTK_BOX (box_log[6]), button_log[1], FALSE, FALSE, 10);
  gtk_widget_show(button_log[1]);
}
