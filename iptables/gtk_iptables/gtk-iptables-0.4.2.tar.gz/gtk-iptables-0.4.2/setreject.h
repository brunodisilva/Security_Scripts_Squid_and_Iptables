/* setreject.h -- has some callback functions and other stuff 
 * used by setreject.c 
 *
 * This file is part of Gtk-IPtables.
 *
 * Gtk-IPtables is Copyright (C) 2003  Daniel E. Testa
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef SETREJECT_H
#define SETREJECT_H

GtkWidget *window_sr;
GtkWidget *box_sr[3];
GtkWidget *button_sr[2];
GtkWidget *scrolled_window_sr, *clist_sr; 

extern gchar setreject_buf[50];

gchar *reject_type;
gchar reject_type_buf[30];

void select_reject_callback(GtkWidget *widget, gint row,
			  gint column, GdkEventButton *event,
			  gpointer data)
{
  gtk_clist_get_text(GTK_CLIST(clist_sr), row, 0, &reject_type);
  strcpy(reject_type_buf, reject_type);
}

void button_ok_sr_callback(GtkWidget *widget, gpointer data)
{
  if ((strcmp(reject_type_buf, "None")) == 0)
    strcpy(setreject_buf, "");
  else
    {
      strcpy(setreject_buf, "--reject-with ");
      strcat(setreject_buf, reject_type_buf);
      strcat(setreject_buf, " ");
    }
}

#endif /* SETREJECT_H */
