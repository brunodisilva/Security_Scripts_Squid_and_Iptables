/* addwin.h -- has some callback functions and other stuff 
 * used by addwin.c
 *
 * This file is part of Gtk-IPtables.
 * 
 * Gtk-IPtables is Copyright (C) 2003  Daniel E. Testa
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef ADDWIN_H
#define ADDWIN_H


GtkWidget *window_aw;
GtkWidget *button_aw[6];
GtkWidget *combo_aw[7];
GtkWidget *label_aw[12];
GtkWidget *box_aw[11];
GtkWidget *frame_aw[8];
GtkWidget *entry[4];
GtkWidget *tcp_d_p;
GtkWidget *tcp_d_p_d;
GtkWidget *source_addr;
GtkWidget *destination_addr;
GtkWidget *check_button[5];
GtkWidget *entry_io_interf[2];
GtkTooltips *tooltips[2];

extern gint ins_add_op;
extern gint rule_number;

gchar *table_line;
gchar *chain_line;
gchar *proto_line;
gchar *icmpt_line;
gchar *sport_line;
gchar *dport_line;
gchar *saddr_line;
gchar *daddr_line;
gchar *jump_line;
gchar *ininter_line;
gchar *outinter_line;
gchar *pkts_line;
gchar *bytes_line;

gint state_settcp_f = 0;
gint state_settcp_o = 0;
gint state_settcp_m = 0;
gint state_settcp_s = 0;

gint mark[9];
gchar settcp_buf[40];
gchar seticmp_buf[50];
gchar setreject_buf[50];
gchar logrule_buf[40];

gchar tmp_buffer[6];
gchar tmp_buffer_port[6];
gchar tmp_buffer_sport[6];
gchar tmp_buffer_saddr[50];
gchar tmp_buffer_daddr[50];

void table_callback(GtkWidget *widget, gpointer data)
{
  table_line = gtk_entry_get_text(GTK_ENTRY(GTK_COMBO(combo_aw[4])->entry));
  mark[0] = 1;
}

void chain_callback(GtkWidget *widget, gpointer data)
{
  chain_line = gtk_entry_get_text(GTK_ENTRY(GTK_COMBO(combo_aw[0])->entry));
}

void protocol_callback(GtkWidget *widget, gpointer data)
{
  proto_line = gtk_entry_get_text(GTK_ENTRY(GTK_COMBO(combo_aw[1])->entry));
  strcpy(tmp_buffer, proto_line);
  mark[3] = 1;
}

void sport_callback(GtkWidget *widget, gpointer data)
{
   sport_line = gtk_entry_get_text(GTK_ENTRY (data));
   mark[5] = 1;
}

void saddr_callback(GtkWidget *widget, gpointer data)
{
  saddr_line = gtk_entry_get_text(GTK_ENTRY (data));
  strcpy(tmp_buffer_saddr, saddr_line);
  mark[1] = 1;
}

void daddr_callback(GtkWidget *widget, gpointer data)
{
  daddr_line = gtk_entry_get_text(GTK_ENTRY (data));
  strcpy(tmp_buffer_daddr, daddr_line);
  mark[2] = 1;
}

void dport_callback(GtkWidget *widget, gpointer data)
{
  dport_line = gtk_entry_get_text(GTK_ENTRY (data));
  strcpy(tmp_buffer_port, dport_line);
  mark[4] = 1;
}

void jump_callback(GtkWidget *widget, gpointer data)
{
  jump_line = gtk_entry_get_text(GTK_ENTRY(GTK_COMBO(combo_aw[3])->entry));
  mark[7] = 1;
}

void ininter_callback(GtkWidget *widget, gpointer data)
{
  ininter_line = gtk_entry_get_text(GTK_ENTRY(data));
}

void outinter_callback(GtkWidget *widget, gpointer data)
{
  outinter_line = gtk_entry_get_text(GTK_ENTRY(data));
}

void pkts_func(GtkWidget *widget, gpointer data)
{
  pkts_line = gtk_entry_get_text(GTK_ENTRY(data));
}

void bytes_func(GtkWidget *widget, gpointer data)
{
  bytes_line = gtk_entry_get_text(GTK_ENTRY(data));
}


void make_command_line(GtkWidget *widget, gpointer data)
{
  gchar command_line[200];
  gchar command_line_with_log[200];
  gint i;
  gchar chain_buf[20];
  gchar table_buf[30];
  
  if (mark[0] == 1) 
    {
      strcpy(table_buf, "-t ");
      strcat(table_buf, table_line);
    } 
  else 
    strcpy(table_buf, "-t filter ");
  

  if ((strcmp(chain_line, "")) != 0) 
    {
      strcpy(chain_buf, chain_line);
      if (ins_add_op == 1) 
	{
	  sprintf(command_line, "iptables %s -I %s %i ", table_buf, 
		  chain_buf, rule_number);
	}
      else if (ins_add_op == 2)
	{
	  sprintf(command_line, "iptables %s -A %s ", table_buf, 
		  chain_buf);
	} 
    }
  
  if (GTK_TOGGLE_BUTTON(check_button[3])->active)
    {
      strcat(command_line, "! -f ");
    }

  if (GTK_TOGGLE_BUTTON(check_button[2])->active)
    {
      strcat(command_line, "-f ");
    }

  if (GTK_TOGGLE_BUTTON(check_button[4])->active)
    {
      strcat(command_line, "-c ");
      strcat(command_line, pkts_line);
      strcat(command_line, " ");
      strcat(command_line, bytes_line);
      strcat(command_line, " ");
    }

  if (GTK_TOGGLE_BUTTON(check_button[0])->active)
    {
      strcat(command_line, "-i ");
      strcat(command_line, ininter_line);
      strcat(command_line, " ");
    }
 
  if (GTK_TOGGLE_BUTTON(check_button[1])->active)
    {
      strcat(command_line, "-i ");
      strcat(command_line, outinter_line);
      strcat(command_line, " ");
    }
    

  if ((strcmp(tmp_buffer_saddr, "")) != 0) 
    { 
      if (mark[1] == 1)
	{
	  if ((strcmp(saddr_line, "")) != 0)
	    {
	      strcat(command_line, "-s ");
	      strcat(command_line, saddr_line);
	      strcat(command_line, " ");
	    }
	}
    }

  if ((strcmp(tmp_buffer_daddr, "")) != 0) 
    {
      if (mark[2] == 1)
	{
	  if ((strcmp(daddr_line, "")) != 0)
	    {
	      strcat(command_line, "-d ");
	      strcat(command_line, daddr_line);
	      strcat(command_line, " ");
	    }
	}
    }
    	  
  if (mark[3] == 1)
    {
      strcat(command_line, "-p ");
      strcat(command_line, proto_line);
      strcat(command_line, " ");
    }
  else
    {
      strcat(command_line, "-p ");
      strcat(command_line, "tcp ");
    }    

  if ((strcmp(settcp_buf, "")) != 0)
    {
      strcat(command_line, " ");
      strcat(command_line, settcp_buf);
    }

  if ((strcmp(tmp_buffer_port, "")) != 0) 
    {
      if (mark[4] == 1)
	{
	  strcat(command_line, "--dport ");
	  strcat(command_line, dport_line);
	  strcat(command_line, " ");
	}
    }

  if ((strcmp(tmp_buffer_sport, "")) != 0) 
    {
      if (mark[5] == 1)
	{
	  strcat(command_line, "--sport ");
	  strcat(command_line, sport_line);
	  strcat(command_line, " ");
	}
    }

  if ((strcmp(tmp_buffer, "icmp")) == 0) 
    {
      if ((strcmp(seticmp_buf, "")) != 0)
	strcat(command_line, seticmp_buf);
    }

  if ((strcmp(logrule_buf, "")) != 0)
    {
      strcpy(command_line_with_log, command_line);
      strcat(command_line_with_log, logrule_buf);
    }

  if (mark[7] == 1)
    {
      strcat(command_line, "-j ");
      strcat(command_line, jump_line);
      strcat(command_line, " ");
      if ((strcmp(jump_line, "REJECT")) == 0)
	strcat(command_line, setreject_buf);
    }
  else
    {
      strcat(command_line, "-j ");
      strcat(command_line, "ACCEPT");
    }

  if (ins_add_op == 1)
    {
      system(command_line); 
      system(command_line_with_log);
    }
  else 
    {
      system(command_line_with_log);
      system(command_line); 
    }
  strcpy(command_line, "");
  strcpy(seticmp_buf, "");
  strcpy(setreject_buf, "");
  strcpy(settcp_buf, "");
  strcpy(logrule_buf, "");
  state_settcp_f = 0;
  state_settcp_o = 0;
  state_settcp_m = 0;
  state_settcp_s = 0;
  for (i = 0; i != 9; i++)
    mark[i] = 0;
}

#endif /* ADDWIN_H */





