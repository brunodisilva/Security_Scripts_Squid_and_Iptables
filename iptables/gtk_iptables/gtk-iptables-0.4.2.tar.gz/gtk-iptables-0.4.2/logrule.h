/* logrule.h -- has some callback functions and other stuff 
 * used by logrule.c 
 *
 * This file is part of Gtk-IPtables.
 *
 * Gtk-IPtables is Copyright (C) 2003  Daniel E. Testa
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef LOGRULE_H
#define LOGRULE_H

GtkWidget *window_log;
GtkWidget *box_log[7];
GtkWidget *check_button_log[5];
GtkWidget *entry_log[2];
GtkWidget *button_log[2];

extern gchar logrule_buf[40];

gchar *log_level_line;
gchar *log_prefix_line;


void log_level_callback(GtkWidget *widget, gpointer data)
{
  log_level_line = gtk_entry_get_text(GTK_ENTRY(data));
}

void log_prefix_callback(GtkWidget *widget, gpointer data)
{
  log_prefix_line = gtk_entry_get_text(GTK_ENTRY(data));
}


void make_command_line_log()
{
  if (GTK_TOGGLE_BUTTON(check_button_log[0])->active)
    {
      strcpy(logrule_buf, "-j LOG --log-level ");
      strcat(logrule_buf, log_level_line);
    }
  else if (GTK_TOGGLE_BUTTON(check_button_log[1])->active)
    {
      strcpy(logrule_buf, "-j LOG --log-prefix ");
      strcat(logrule_buf, log_prefix_line);
    }
  else if (GTK_TOGGLE_BUTTON(check_button_log[2])->active)
    {
      strcpy(logrule_buf, "-j LOG --log-tcp-sequence");
    }
  else if (GTK_TOGGLE_BUTTON(check_button_log[3])->active)
    {
      strcpy(logrule_buf, "-j LOG --log-tcp-options");
    }
  else if (GTK_TOGGLE_BUTTON(check_button_log[4])->active)
    {
      strcpy(logrule_buf, "-j LOG --log-ip-options");
    }
  else 
    {
      strcpy(logrule_buf, "");
    }
}

#endif /* LOGRULE_H */
