/* settcp.h -- has some callback functions and other stuff 
 * used by settcp.c 
 *
 * This file is part of Gtk-IPtables.
 *
 * Gtk-IPtables is Copyright (C) 2003  Daniel E. Testa
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef SETTCP_H
#define SETTCP_H

GtkWidget *window_st;
GtkWidget *box_st[6];
GtkWidget *check_button_st[4];
GtkWidget *entry_st[4];
GtkWidget *button_st[2];

extern gchar settcp_buf[40];
extern gint state_settcp_f;
extern gint state_settcp_o;
extern gint state_settcp_m;
extern gint state_settcp_s;

gchar *tcp_flags_a_line;
gchar *tcp_flags_b_line;
gchar *tcp_opt_line;
gchar *tcp_mss_line;


void tcp_flags_a_callback(GtkWidget *widget, gpointer data)
{
  tcp_flags_a_line = gtk_entry_get_text(GTK_ENTRY(data));
}

void tcp_flags_b_callback(GtkWidget *widget, gpointer data)
{
  tcp_flags_b_line = gtk_entry_get_text(GTK_ENTRY(data));
}

void tcp_option_callback(GtkWidget *widget, gpointer data)
{
  tcp_opt_line = gtk_entry_get_text(GTK_ENTRY(data));
}

void tcp_mss_callback(GtkWidget *widget, gpointer data)
{
  tcp_mss_line = gtk_entry_get_text(GTK_ENTRY(data));
}

void make_command_line_st()
{
  if (GTK_TOGGLE_BUTTON(check_button_st[0])->active)
    {
      strcpy(settcp_buf, "--tcp-flags ");
      strcat(settcp_buf, tcp_flags_a_line);
      strcat(settcp_buf, " ");
      strcat(settcp_buf, tcp_flags_b_line);
      strcat(settcp_buf, " ");
      state_settcp_f = 1;
      state_settcp_o = 0;
      state_settcp_m = 0;
      state_settcp_s = 0;
    }
  else if (GTK_TOGGLE_BUTTON(check_button_st[1])->active)
    {
      strcpy(settcp_buf, "--tcp-option ");
      strcat(settcp_buf, tcp_opt_line);
      strcat(settcp_buf, " ");
      state_settcp_f = 0;
      state_settcp_o = 1;
      state_settcp_m = 0; 
      state_settcp_s = 0;

    }
  else if (GTK_TOGGLE_BUTTON(check_button_st[2])->active)
    {
      strcpy(settcp_buf, "--mss ");
      strcat(settcp_buf, tcp_mss_line);
      strcat(settcp_buf, " ");
      state_settcp_f = 0;
      state_settcp_o = 0;
      state_settcp_m = 1;
      state_settcp_s = 0;
    }
  else if (GTK_TOGGLE_BUTTON(check_button_st[3])->active)
    {
      strcpy(settcp_buf, "--syn ");
      strcat(settcp_buf, " ");
      state_settcp_f = 0;
      state_settcp_o = 0;
      state_settcp_m = 0;
      state_settcp_s = 1;
    }
  else 
    {
      strcpy(settcp_buf, "");
    }
}

#endif /* SETTCP_H */
