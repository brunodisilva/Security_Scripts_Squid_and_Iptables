/* seticmp.h -- has some callback functions and other stuff 
 * used by seticmp.c 
 *
 * This file is part of Gtk-IPtables.
 *
 * Gtk-IPtables is Copyright (C) 2003  Daniel E. Testa
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef SETICMP_H
#define SETICMP_H

GtkWidget *window_si;
GtkWidget *box_si[3];
GtkWidget *button_si[2];
GtkWidget *scrolled_window_si, *clist_si; 

extern gchar seticmp_buf[50];

gchar *icmp_type;
gchar icmp_type_buf[30];

void select_icmp_callback(GtkWidget *widget, gint row,
			  gint column, GdkEventButton *event,
			  gpointer data)
{
  gtk_clist_get_text(GTK_CLIST(clist_si), row, 1, &icmp_type);
  strcpy(icmp_type_buf, icmp_type);
}

void button_ok_si_callback(GtkWidget *widget, gpointer data)
{
  if ((strcmp(icmp_type_buf, "None")) == 0)
    strcpy(seticmp_buf, "");
  else
    {
      strcpy(seticmp_buf, "--icmp-type ");
      strcat(seticmp_buf, icmp_type_buf);
      strcat(seticmp_buf, " ");
    }
}

#endif /* SETICMP_H */
