/* main.c is the main file to build Gtk-IPtables
 *
 * This file is part of Gtk-IPtables.
 *
 * Gtk-IPtables is Copyright (C) 2003  Daniel E. Testa
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

 
#include <gtk/gtk.h> 
#include <stdio.h>
#include <stdlib.h>    
#include <string.h>

#include "main.h"   

void button_ins_func()
{
  button = gtk_button_new_with_label(" Ins Rule ");
  gtk_signal_connect(GTK_OBJECT (button), "clicked",
		     GTK_SIGNAL_FUNC (ins_callback), NULL);
  gtk_signal_connect(GTK_OBJECT (button), "clicked",
		     GTK_SIGNAL_FUNC (create_win), NULL);
  gtk_box_pack_start(GTK_BOX (box[1]), button, TRUE, TRUE, 0);
  gtk_widget_show (button);
}

void button_add_func()
{
  button = gtk_button_new_with_label(" Add Rule ");
  gtk_signal_connect(GTK_OBJECT (button), "clicked",
		     GTK_SIGNAL_FUNC (add_callback), NULL);
  gtk_signal_connect(GTK_OBJECT (button), "clicked",
		     GTK_SIGNAL_FUNC (create_win), NULL);
  gtk_box_pack_start(GTK_BOX (box[1]), button, TRUE, TRUE , 0);
  gtk_widget_show (button);
}

void button_del_func()
{
  button = gtk_button_new_with_label(" Del Rule ");
  gtk_signal_connect(GTK_OBJECT (button), "clicked",
		     GTK_SIGNAL_FUNC (del_rule), NULL);
  gtk_box_pack_start(GTK_BOX (box[1]), button, TRUE, TRUE, 0);
  gtk_widget_show (button);
}

void button_quit_func()
{
  button = gtk_button_new_with_label(" Exit ");
  gtk_signal_connect(GTK_OBJECT (button), "clicked",
		     GTK_SIGNAL_FUNC (destroy), NULL);

  gtk_box_pack_start(GTK_BOX (box[1]), button, TRUE, TRUE, 0);
  gtk_widget_show (button);
}

void button_about_func()
{
  button = gtk_button_new_with_label(" About ");
  gtk_signal_connect(GTK_OBJECT (button), "clicked",
		     GTK_SIGNAL_FUNC (about_callback), NULL);

  gtk_box_pack_start(GTK_BOX (box[1]), button, TRUE, TRUE, 0);
  gtk_widget_show(button);
}

void output_func()
{
  gchar *titles[11] = {"Num", "Pkts", "Bytes" ,"Target", "Prot", 
		      "Opt", "In", "Out", "Source", "Destination"};
  
  scrolled_window = gtk_scrolled_window_new( NULL, NULL);
  gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scrolled_window),
				 GTK_POLICY_ALWAYS, GTK_POLICY_ALWAYS);
  gtk_widget_set_usize(scrolled_window, 700, 300);
  gtk_box_pack_start(GTK_BOX (box[2]), scrolled_window, FALSE, FALSE, 0);
  gtk_widget_show(scrolled_window);

  clist = gtk_clist_new_with_titles(11, titles);
  gtk_container_add(GTK_CONTAINER(scrolled_window), clist);
  gtk_signal_connect(GTK_OBJECT (clist), "select_row",
		     GTK_SIGNAL_FUNC(select_row_callback), NULL); 
  gtk_clist_set_column_width(GTK_CLIST(clist), 1, 30);
  gtk_clist_set_column_width(GTK_CLIST(clist), 2, 30);
  gtk_clist_set_column_width(GTK_CLIST(clist), 3, 65);
  gtk_clist_set_column_width(GTK_CLIST(clist), 4, 30);
  gtk_clist_set_column_width(GTK_CLIST(clist), 6, 35);
  gtk_clist_set_column_width(GTK_CLIST(clist), 7, 35);
  gtk_clist_set_column_width(GTK_CLIST(clist), 8, 100);
  gtk_clist_set_column_width(GTK_CLIST(clist), 9, 100);
  gtk_clist_set_column_width(GTK_CLIST(clist), 10, 270);
  
  
  gtk_widget_show(clist);
}
  

void combo_table_func()     
{
  GList *tables = NULL;
 
  tables = g_list_append(tables, "Filter -> INPUT");
  tables = g_list_append(tables, "Filter -> FORWARD");
  tables = g_list_append(tables, "Filter -> OUTPUT");
  
  tables = g_list_append(tables, "Nat -> PREROUTING");
  tables = g_list_append(tables, "Nat -> POSTROUTING");
  tables = g_list_append(tables, "Nat -> OUTPUT");
  
  tables = g_list_append(tables, "Mangle -> PREROUTING");
  tables = g_list_append(tables, "Mangle -> OUTPUT");
  tables = g_list_append(tables, "Mangle -> INPUT");
  tables = g_list_append(tables, "Mangle -> FORWARD");
  tables = g_list_append(tables, "Mangle -> POSTROUTING");

  combo = gtk_combo_new();
  gtk_combo_set_popdown_strings(GTK_COMBO(combo), tables);
  gtk_signal_connect(GTK_OBJECT(GTK_COMBO(combo)->entry), "changed",
		     GTK_SIGNAL_FUNC (choose_t), NULL);
  gtk_box_pack_start(GTK_BOX (box[1]), combo, FALSE, TRUE, 0);
  gtk_widget_show(combo);
}


int main(int argc, char *argv[])
{

  gtk_init(&argc, &argv);

  window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title (GTK_WINDOW(window), "Gtk-IPTables (FrontEnd) v0.4.2");
  gtk_window_set_policy(GTK_WINDOW(window), FALSE, FALSE, FALSE);
  gtk_signal_connect (GTK_OBJECT (window), "delete_event",
		      GTK_SIGNAL_FUNC (delete_event), NULL);
  gtk_container_set_border_width (GTK_CONTAINER (window), 10);

  box[0] = gtk_vbox_new(FALSE, 15);
  box[2] = gtk_hbox_new(FALSE, 0);
  box[1] = gtk_hbox_new(FALSE, 10);
  
  frame = gtk_frame_new("IPTables");

  gtk_container_add(GTK_CONTAINER (window), box[0]);
  gtk_box_pack_end(GTK_BOX (box[0]), box[1], FALSE, FALSE, 0);
  gtk_box_pack_start(GTK_BOX (box[0]), frame, FALSE, TRUE, 0);
  gtk_container_add(GTK_CONTAINER(frame), box[2]);
  gtk_widget_set_usize(frame, 706, 300);
  gtk_widget_show(frame);
  
  
  output_func();
  combo_table_func();
  button_ins_func();
  button_add_func();
  button_del_func();
  button_quit_func();
  button_about_func();
  report();

  gtk_widget_show(box[1]);
  gtk_widget_show(box[2]);
  gtk_widget_show (box[0]);  
  gtk_widget_show (window);

  gtk_main();

  return(0);
}

  

  

  

  
