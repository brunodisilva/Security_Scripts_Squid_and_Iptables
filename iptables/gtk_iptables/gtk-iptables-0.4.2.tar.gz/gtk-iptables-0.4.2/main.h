/* main.h -- has some callback functions and other stuff 
 * used by main.c
 *
 * This file is part of Gtk-IPtables.
 * 
 * Gtk-IPtables is Copyright (C) 2003  Daniel E. Testa
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef MAIN_H
#define MAIN_H

extern void create_win();

/* Widgets used by main.c */

GtkWidget *window;
GtkWidget *button;
GtkWidget *frame;
GtkWidget *box[4];
GtkWidget *label;
GtkWidget *combo;
GtkWidget *clist;
GtkWidget *scrolled_window;

/* Some variables to get table, chain and rule for deletion */

gchar *chain_view;
gchar table_buf[10] = "filter";
gchar chain_buf[10] = "INPUT";
gint rule_number;
gint del_flag;
gint ins_add_op;

/* Callback functionsfor main.c */

gint delete_event(GtkWidget *widget, GdkEvent *event, gpointer data)
{
  gtk_main_quit();
  return(FALSE);
}

void destroy(GtkWidget *widget, gpointer data)
{
  gtk_main_quit();
}

void about_callback(GtkWidget *widget, gpointer data)
{
  GtkWidget *window_a;
  GtkWidget *box_a[2];
  GtkWidget *text;
  GtkWidget *vcroll;
  
  window_a = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title (GTK_WINDOW (window_a), 
			"About Gtk-IPTables");
  gtk_window_set_policy (GTK_WINDOW (window_a), FALSE, FALSE, FALSE);
  gtk_container_set_border_width (GTK_CONTAINER (window_a), 1);
  gtk_signal_connect(GTK_OBJECT (window_a), "delete_event",
		     GTK_SIGNAL_FUNC (gtk_widget_destroy), NULL);
  
  box_a[0] = gtk_vbox_new(FALSE, 1);
  box_a[1] = gtk_hbox_new(FALSE, 0);

  gtk_container_add(GTK_CONTAINER(window_a), box_a[0]);
  gtk_box_pack_start(GTK_BOX(box_a[0]), box_a[1], FALSE, FALSE, 0);

  text = gtk_text_new(NULL, NULL);
  gtk_widget_set_usize(text, 210, 0);
  gtk_box_pack_start(GTK_BOX(box_a[1]), text, FALSE, FALSE, 0);
  gtk_text_set_editable(GTK_TEXT(text), FALSE);

  gtk_text_insert(GTK_TEXT(text), NULL, NULL, NULL,
		  "\n", -1);
  gtk_text_insert(GTK_TEXT(text), NULL, NULL, NULL,
		  "Gtk-IPTables\n", -1);
  gtk_text_insert(GTK_TEXT(text), NULL, NULL, NULL,
		  "Author: Daniel E. Testa\n", -1);
  gtk_text_insert(GTK_TEXT(text), NULL, NULL, NULL,
		  "E-Mail: da_tes@yahoo.com.ar\n", -1);
  gtk_text_insert(GTK_TEXT(text), NULL, NULL, NULL,
		  "HTTP: gtk-iptables.sourceforge.net\n", -1);
  gtk_text_insert(GTK_TEXT(text), NULL, NULL, NULL,
		  "Written in: C and GTK", -1);
  gtk_text_insert(GTK_TEXT(text), NULL, NULL, NULL,
		  "\n\n", -1);
  gtk_text_insert(GTK_TEXT(text), NULL, NULL, NULL,
		  "IPTables\n", -1);
  gtk_text_insert(GTK_TEXT(text), NULL, NULL, NULL,
		  "HTTP: www.netfilter.org\n", -1);
  
  vcroll = gtk_vscrollbar_new(GTK_TEXT(text)->vadj);
  gtk_box_pack_start(GTK_BOX(box_a[1]), vcroll, FALSE, FALSE, 0);

  button = gtk_button_new_with_label("OK");
  gtk_box_pack_end(GTK_BOX(box_a[0]), button, TRUE, TRUE, 0);
  gtk_signal_connect_object(GTK_OBJECT(button), "clicked",
			    GTK_SIGNAL_FUNC(gtk_widget_destroy),
			    GTK_OBJECT(window_a));
  gtk_widget_show(button);
  gtk_widget_show(text);
  gtk_widget_show(vcroll);
  gtk_widget_show(box_a[1]);
  gtk_widget_show(box_a[0]);
  gtk_widget_show(window_a);
}
  

void report()
{
  gint buf = 0;
  gint x = 0;
  gint i = 1; 
  gint y = 0;
  gint u = 0;
  gchar cad[60];
  gchar tmp[30];
  gchar buf1;
  FILE *rfile;
  gchar *hola[12] = { NULL, NULL, NULL, NULL, NULL, NULL,
		      NULL, NULL, NULL, NULL, NULL}; 
  gchar popen_command[100] = "iptables -t ";
  
  
  strcat(popen_command, table_buf);
  strcat(popen_command, " -L ");
  strcat(popen_command, chain_buf);
  strcat(popen_command, " --line-numbers -v");

  rfile = popen(popen_command, "r");
    
  gtk_clist_clear((GtkCList *) clist );
  gtk_clist_insert((GtkCList *) clist, i, hola);
  
  while (feof(rfile) == 0) 
    {
      while (buf != 2) 
	{
	  buf1 = getc(rfile);
	  if (buf1 == '\n')
	    buf++;
	}

      fscanf(rfile, "%s", &cad);
      if (feof(rfile) != 0)
	break;
      if (x == 10)
	{
	  strcpy(tmp, cad);
	  do
	    {
	      buf1 = getc(rfile);
	      cad[u] = buf1;
	      u++;
	    } while (buf1 != '\n');
	  cad[--u] = '\0';
	  strcat(tmp, cad); 
	  gtk_clist_set_text(GTK_CLIST (clist), y, x, tmp);
	}
      else
	gtk_clist_set_text(GTK_CLIST (clist), y, x, cad);
      x++;
      if (x == 11) 
	{
	  gtk_clist_insert((GtkCList *) clist, i, hola);
	  i++;
	  y++;
	  x = 0;
	  u = 0;
	}
    }
  pclose(rfile);
  del_flag = y;
}



void choose_t(GtkWidget *widget, gpointer data)
{
  chain_view = gtk_entry_get_text(GTK_ENTRY(GTK_COMBO(combo)->entry));
    
  if ((strcmp("Filter -> INPUT", chain_view)) == 0)
    {
      strcpy(table_buf, "filter");
      strcpy(chain_buf, "INPUT");
    }

  if ((strcmp("Filter -> FORWARD", chain_view)) == 0)
    {
      strcpy(table_buf, "filter");
      strcpy(chain_buf, "FORWARD");
    }

  if ((strcmp("Filter -> OUTPUT", chain_view)) == 0)
    {
      strcpy(table_buf, "filter");
      strcpy(chain_buf, "OUTPUT");
    }

  if ((strcmp("Nat -> PREROUTING", chain_view)) == 0)
    {
      strcpy(table_buf, "nat");
      strcpy(chain_buf, "PREROUTING");
    }
  
  if ((strcmp("Nat -> POSTROUTING", chain_view)) == 0)
    {
      strcpy(table_buf, "nat");
      strcpy(chain_buf, "POSTROUTING");
    }
  
  if ((strcmp("Nat -> OUTPUT", chain_view)) == 0)
    {
      strcpy(table_buf, "nat");
      strcpy(chain_buf, "OUTPUT");
    }
  
  if ((strcmp("Mangle -> INPUT", chain_view)) == 0)
    {
      strcpy(table_buf, "mangle");
      strcpy(chain_buf, "INPUT");
    }
  
  if ((strcmp("Mangle -> FORWARD", chain_view)) == 0)
    {
      strcpy(table_buf, "mangle");
      strcpy(chain_buf, "FORWARD");
    }
  
  if ((strcmp("Mangle -> OUTPUT", chain_view)) == 0)
    {
      strcpy(table_buf, "mangle");
      strcpy(chain_buf, "OUTPUT");
    }
  
  if ((strcmp("Mangle -> PREROUTING", chain_view)) == 0)
    {
      strcpy(table_buf, "mangle");
      strcpy(chain_buf, "PREROUTING");
    }
  
  if ((strcmp("Mangle -> POSTROUTING", chain_view)) == 0)
    {
      strcpy(table_buf, "mangle");
      strcpy(chain_buf, "POSTROUTING");
    }
  report();
}

void select_row_callback(GtkWidget *widget, gint row, gint column,
			 GdkEventButton *event, gpointer data)
{
  rule_number = ++row;
}


void del_rule(GtkWidget *widget, gpointer data)
{
  gchar command_line[100] = "iptables ";
  gchar buf[5];

  strcat(command_line, "-t ");
  strcat(command_line, table_buf);
  strcat(command_line, " ");

  strcat(command_line, "-D ");
  strcat(command_line, chain_buf);
  strcat(command_line, " ");

  sprintf(buf, "%i", rule_number);
  strcat(command_line, buf);
  system(command_line);
  strcpy(command_line, "");
  report();
  rule_number = ++del_flag;
} 

void ins_callback(GtkWidget *widget, gpointer data)
{
  ins_add_op = 1;
}

void add_callback(GtkWidget *widget, gpointer data)
{
  ins_add_op = 2;
}

#endif /* MAIN_H */
