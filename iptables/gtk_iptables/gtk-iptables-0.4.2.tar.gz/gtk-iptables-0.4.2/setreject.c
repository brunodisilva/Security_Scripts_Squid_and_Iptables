/* setreject.c -- makes the "Set REJECT Type" window. 
 *
 * This file is part of Gtk-IPtables.
 *
 * Gtk-IPtables is Copyright (C) 2003  Daniel E. Testa
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <gtk/gtk.h>
#include <string.h>

#include "setreject.h"

void clist_func_sr();
void button_ok_func_sr();
void button_cancel_func_sr();

void set_reject_win()
{
  window_sr = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title(GTK_WINDOW(window_sr), "Set REJECT Type");
  gtk_window_set_policy(GTK_WINDOW (window_sr), FALSE, FALSE, FALSE);
  gtk_signal_connect(GTK_OBJECT (window_sr), "delete_event",
		     GTK_SIGNAL_FUNC (gtk_widget_destroy), NULL);
  gtk_widget_set_usize(window_sr, 260, 230);

  box_sr[0] = gtk_vbox_new(FALSE, 10);
  box_sr[1] = gtk_hbox_new(FALSE, 0);
  box_sr[2] = gtk_hbox_new(FALSE, 0);

  gtk_container_add(GTK_CONTAINER(window_sr), box_sr[0]);
  gtk_box_pack_end(GTK_BOX(box_sr[0]), box_sr[1], FALSE, FALSE, 10);
  gtk_box_pack_start(GTK_BOX(box_sr[0]), box_sr[2], FALSE, FALSE, 10);
 
  clist_func_sr();
  button_cancel_func_sr();
  button_ok_func_sr();

  gtk_widget_show(box_sr[1]);
  gtk_widget_show(box_sr[2]);
  gtk_widget_show(box_sr[0]);
  gtk_widget_show(window_sr);
}

void button_ok_func_sr()
{
  button_sr[0] = gtk_button_new_with_label(" Accept "); 
  gtk_signal_connect(GTK_OBJECT(button_sr[0]), "clicked",
		     GTK_SIGNAL_FUNC(button_ok_sr_callback),NULL);
  gtk_signal_connect_object(GTK_OBJECT(button_sr[0]), "clicked",
			    GTK_SIGNAL_FUNC(gtk_widget_destroy),
			    GTK_OBJECT(window_sr));			  
  gtk_box_pack_end(GTK_BOX(box_sr[1]), button_sr[0], FALSE, FALSE, 5);
  gtk_widget_show(button_sr[0]);
}

void button_cancel_func_sr()
{
  button_sr[1] = gtk_button_new_with_label(" Cancel ");
  gtk_signal_connect_object(GTK_OBJECT(button_sr[1]), "clicked",
			    GTK_SIGNAL_FUNC(gtk_widget_destroy),
			    GTK_OBJECT(window_sr));
  gtk_box_pack_end(GTK_BOX(box_sr[1]), button_sr[1], FALSE, FALSE, 5);
  gtk_widget_show(button_sr[1]);
}


void clist_func_sr()
{
  gchar *titles_sr[] = {"Type"};
  gchar *type_sr[8][1] = { {"None"},
			   {"icmp-net-unreachable"},
			   {"icmp-host-unreachable"}, 
			   {"icmp-port-unreachable"},
			   {"icmp-proto-unreachable"},
			   {"icmp-net-prohibited"},
			   {"icmp-host-prohibited"},
			   {"tcp-reset"} };
  gint indx_sr;

  scrolled_window_sr = gtk_scrolled_window_new(NULL, NULL);
  gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scrolled_window_sr),
				 GTK_POLICY_AUTOMATIC, GTK_POLICY_ALWAYS);
  gtk_widget_set_usize(scrolled_window_sr, 240, 180);
  gtk_box_pack_start(GTK_BOX (box_sr[2]), scrolled_window_sr, 
		     FALSE, FALSE, 10);
  gtk_widget_show(scrolled_window_sr);
  
  clist_sr = gtk_clist_new_with_titles(1, titles_sr);
  gtk_signal_connect(GTK_OBJECT(clist_sr), "select_row",
		     GTK_SIGNAL_FUNC(select_reject_callback), NULL);
  gtk_container_add(GTK_CONTAINER(scrolled_window_sr), clist_sr);

  for (indx_sr = 0; indx_sr < 8; indx_sr++) 
    gtk_clist_append((GtkCList *) clist_sr, type_sr[indx_sr]);
  
  gtk_widget_show(clist_sr);
}
