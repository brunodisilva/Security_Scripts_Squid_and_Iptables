/* addwin.c -- makes the "Add rules" window. 
 *
 * This file is part of Gtk-IPtables.
 *
 * Gtk-IPtables is Copyright (C) 2003  Daniel E. Testa
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <gtk/gtk.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "createwin.h"

extern void report();
extern void set_tcp_win();
extern void set_icmp_win();
extern void set_reject_win();
extern void log_rule_win();

void table_func()
{
  GList *ltables = NULL;

  label_aw[8] = gtk_label_new("  To Table ");
  gtk_box_pack_start(GTK_BOX (box_aw[1]), label_aw[8], FALSE, TRUE,0);
  gtk_widget_show(label_aw[8]);

  ltables = g_list_append(ltables, "filter");
  ltables = g_list_append(ltables, "nat");  
  ltables = g_list_append(ltables, "mangle");
  
  
  combo_aw[4] = gtk_combo_new();
  gtk_combo_set_popdown_strings(GTK_COMBO(combo_aw[4]), ltables);
  gtk_signal_connect(GTK_OBJECT(GTK_COMBO(combo_aw[4])->entry), "changed",
		     GTK_SIGNAL_FUNC (table_callback), NULL);
  gtk_box_pack_start(GTK_BOX (box_aw[1]), combo_aw[4], FALSE, TRUE, 0);
  gtk_widget_show(combo_aw[4]);
}

void chain_func()
{
  GList *lchain = NULL;

  label_aw[0] = gtk_label_new("      To chain ");
  gtk_box_pack_start(GTK_BOX (box_aw[1]), label_aw[0], FALSE, TRUE,0);
  gtk_widget_show(label_aw[0]);

  lchain = g_list_append(lchain, "--Filter--");
  lchain = g_list_append(lchain, "INPUT");
  lchain = g_list_append(lchain, "FORWARD");
  lchain = g_list_append(lchain, "OUTPUT");
  lchain = g_list_append(lchain, "---Nat---");
  lchain = g_list_append(lchain, "PREROUTING");
  lchain = g_list_append(lchain, "POSTROUTING");
  lchain = g_list_append(lchain, "OUTPUT");
  lchain = g_list_append(lchain, "--Mangle--");
  lchain = g_list_append(lchain, "PREROUTING");
  lchain = g_list_append(lchain, "OUTPUT");
  lchain = g_list_append(lchain, "INPUT");
  lchain = g_list_append(lchain, "FORWARD");
  lchain = g_list_append(lchain, "POSTROUTING");  

  combo_aw[0] = gtk_combo_new();
  gtk_combo_set_popdown_strings(GTK_COMBO(combo_aw[0]), lchain);
  gtk_signal_connect(GTK_OBJECT(GTK_COMBO(combo_aw[0])->entry), "changed",
		     GTK_SIGNAL_FUNC (chain_callback), NULL);
  gtk_box_pack_start(GTK_BOX (box_aw[1]), combo_aw[0], FALSE, TRUE, 0);
  gtk_widget_show(combo_aw[0]);
}

void protocol_func()
{
  GList *lprotocol = NULL;

  label_aw[1] = gtk_label_new("  Protocol ");
  gtk_box_pack_start(GTK_BOX (box_aw[9]), label_aw[1], FALSE, TRUE, 0);
  gtk_widget_show(label_aw[1]);

  lprotocol = g_list_append(lprotocol, "tcp");
  lprotocol = g_list_append(lprotocol, "udp");
  lprotocol = g_list_append(lprotocol, "icmp");

  combo_aw[1] = gtk_combo_new();
  gtk_combo_set_popdown_strings(GTK_COMBO(combo_aw[1]), lprotocol);
  gtk_signal_connect(GTK_OBJECT(GTK_COMBO(combo_aw[1])->entry), "changed",
		     GTK_SIGNAL_FUNC(protocol_callback), NULL);
  gtk_box_pack_start(GTK_BOX (box_aw[9]), combo_aw[1], FALSE, TRUE, 0);
  gtk_widget_show(combo_aw[1]);

}

void button_set_tcp()
{
  button_aw[2] = gtk_button_new_with_label(" Set TCP Protocol ");
  gtk_box_pack_start(GTK_BOX(box_aw[9]), button_aw[2], FALSE, FALSE, 15);
  gtk_signal_connect(GTK_OBJECT(button_aw[2]), "clicked",
		     GTK_SIGNAL_FUNC(set_tcp_win), NULL);
  gtk_widget_show(button_aw[2]);
}

void button_set_icmp()
{
  button_aw[3] = gtk_button_new_with_label(" Set ICMP Protocol ");
  gtk_box_pack_start(GTK_BOX(box_aw[9]), button_aw[3], FALSE, FALSE, 0);
  gtk_signal_connect(GTK_OBJECT(button_aw[3]), "clicked",
		     GTK_SIGNAL_FUNC(set_icmp_win), NULL);
  gtk_widget_show(button_aw[3]);
}

void sport_func()
{
  label_aw[3] = gtk_label_new("     Port ");
  gtk_box_pack_start(GTK_BOX (box_aw[3]), label_aw[3], FALSE, TRUE, 0);
  gtk_widget_show(label_aw[3]);

  tcp_d_p = gtk_entry_new();
  gtk_signal_connect(GTK_OBJECT(tcp_d_p), "changed",
		     GTK_SIGNAL_FUNC (sport_callback), tcp_d_p);
  gtk_box_pack_start(GTK_BOX (box_aw[3]), tcp_d_p, FALSE, TRUE, 0);
  gtk_widget_show(tcp_d_p);
}

void saddr_func()
{
  label_aw[4] = gtk_label_new("  Address ");
  gtk_box_pack_start(GTK_BOX (box_aw[3]), label_aw[4], FALSE, TRUE, 0);
  gtk_widget_show(label_aw[4]);

  source_addr = gtk_entry_new();
  gtk_signal_connect(GTK_OBJECT(source_addr), "changed",
		     GTK_SIGNAL_FUNC (saddr_callback), source_addr);
  gtk_box_pack_start(GTK_BOX (box_aw[3]), source_addr, FALSE, TRUE, 0);
  gtk_widget_show(source_addr);
}

void daddr_func()
{
  label_aw[5] = gtk_label_new("  Address ");
  gtk_box_pack_start(GTK_BOX (box_aw[4]), label_aw[5], FALSE, TRUE, 0);
  gtk_widget_show(label_aw[5]);

  destination_addr = gtk_entry_new();
  gtk_signal_connect(GTK_OBJECT(destination_addr), "changed",
		     GTK_SIGNAL_FUNC (daddr_callback), destination_addr);
  gtk_box_pack_start(GTK_BOX (box_aw[4]), destination_addr, FALSE, TRUE, 0);
  gtk_widget_show(destination_addr);
}


void dport_func()
{
  label_aw[6] = gtk_label_new("     Port ");
  gtk_box_pack_start(GTK_BOX (box_aw[4]), label_aw[6], FALSE, TRUE, 0);
  gtk_widget_show(label_aw[6]);

  tcp_d_p_d = gtk_entry_new();
  gtk_signal_connect(GTK_OBJECT(tcp_d_p_d), "changed",
		     GTK_SIGNAL_FUNC (dport_callback), tcp_d_p_d);
  gtk_box_pack_start(GTK_BOX (box_aw[4]), tcp_d_p_d, FALSE, TRUE, 0);
  gtk_widget_show(tcp_d_p_d);
}


void jump_func()
{
  GList *ljump = NULL;

  label_aw[7] = gtk_label_new("  Jump ");
  gtk_box_pack_start(GTK_BOX (box_aw[10]), label_aw[7], FALSE, TRUE, 0);
  gtk_widget_show(label_aw[7]);

  ljump = g_list_append(ljump, "ACCEPT");
  ljump = g_list_append(ljump, "DROP");
  ljump = g_list_append(ljump, "QUEUE");
  ljump = g_list_append(ljump, "RETURN");
  ljump = g_list_append(ljump, "REJECT");

  combo_aw[3] = gtk_combo_new();
  gtk_combo_set_popdown_strings(GTK_COMBO(combo_aw[3]), ljump);
  gtk_signal_connect(GTK_OBJECT(GTK_COMBO(combo_aw[3])->entry), "changed",
		     GTK_SIGNAL_FUNC(jump_callback), NULL);
  gtk_box_pack_start(GTK_BOX (box_aw[10]), combo_aw[3], FALSE, TRUE, 0);
  gtk_widget_show(combo_aw[3]);
}

void button_set_reject()
{
  button_aw[4] = gtk_button_new_with_label(" Set REJECT Type ");
  gtk_box_pack_start(GTK_BOX(box_aw[10]), button_aw[4], FALSE, FALSE, 15);
  gtk_signal_connect(GTK_OBJECT(button_aw[4]), "clicked",
		     GTK_SIGNAL_FUNC(set_reject_win), NULL); 
  gtk_widget_show(button_aw[4]);
}

void button_log_rule()
{
  button_aw[5] = gtk_button_new_with_label(" LOG This Rule ");
  gtk_box_pack_start(GTK_BOX(box_aw[10]), button_aw[5], FALSE, FALSE, 0);
  gtk_signal_connect(GTK_OBJECT(button_aw[5]), "clicked",
		     GTK_SIGNAL_FUNC(log_rule_win), NULL); 
  gtk_widget_show(button_aw[5]);
}
  
void button_ok()
{
  button_aw[0] = gtk_button_new_with_label(" Accept ");
  gtk_signal_connect(GTK_OBJECT (button_aw[0]), "clicked",
		     GTK_SIGNAL_FUNC (make_command_line), NULL);
  gtk_signal_connect(GTK_OBJECT (button_aw[0]), "clicked",
		       GTK_SIGNAL_FUNC (report), NULL);
  gtk_signal_connect_object(GTK_OBJECT (button_aw[0]), "clicked",
			    GTK_SIGNAL_FUNC (gtk_widget_destroy), 
			    GTK_OBJECT (window_aw));
  gtk_box_pack_end(GTK_BOX (box_aw[6]), button_aw[0], FALSE, FALSE, 0);
  gtk_widget_show(button_aw[0]);
}

void button_cancel()
{
  button_aw[1] = gtk_button_new_with_label(" Cancel ");
  gtk_signal_connect_object(GTK_OBJECT (button_aw[1]), "clicked",
			    GTK_SIGNAL_FUNC (gtk_widget_destroy), 
			    GTK_OBJECT (window_aw));
  gtk_box_pack_end(GTK_BOX (box_aw[6]), button_aw[1], FALSE, FALSE, 0);
  gtk_widget_show(button_aw[1]);
}

void ininter_func()
{
  check_button[0] = gtk_check_button_new_with_label("In-Inter");
  gtk_box_pack_start(GTK_BOX(box_aw[7]), check_button[0], FALSE, FALSE, 5);
  gtk_widget_show(check_button[0]);

  tooltips[0] = gtk_tooltips_new();
  gtk_tooltips_set_tip(tooltips[0], check_button[0],
		       "ONLY for INPUT, FORWARD and PREROUTING", NULL);

  entry_io_interf[0] = gtk_entry_new();
  gtk_signal_connect(GTK_OBJECT(entry_io_interf[0]), "changed",
		     GTK_SIGNAL_FUNC (ininter_callback), entry_io_interf[0]);
  gtk_box_pack_start(GTK_BOX (box_aw[7]), entry_io_interf[0], FALSE, TRUE, 0);
  gtk_widget_show(entry_io_interf[0]);
}

void outinter_func()
{
  check_button[1] = gtk_check_button_new_with_label("Out-Inter");
  gtk_box_pack_start(GTK_BOX(box_aw[7]), check_button[1], FALSE, FALSE, 5);
  gtk_widget_show(check_button[1]);

  tooltips[1] = gtk_tooltips_new();
  gtk_tooltips_set_tip(tooltips[0], check_button[1],
		       "ONLY for OUTPUT, FORWARD and POSTROUTING", NULL);

  entry_io_interf[1] = gtk_entry_new();
  gtk_signal_connect(GTK_OBJECT(entry_io_interf[1]), "changed",
		     GTK_SIGNAL_FUNC (outinter_callback), entry_io_interf[1]);
  gtk_box_pack_start(GTK_BOX (box_aw[7]), entry_io_interf[1], FALSE, TRUE, 0);
  gtk_widget_show(entry_io_interf[1]);
}

void options_func()
{
  check_button[2] = gtk_check_button_new_with_label("Fragment");
  gtk_box_pack_start(GTK_BOX (box_aw[8]), check_button[2], FALSE, TRUE, 5);
  gtk_widget_show(check_button[2]);

  check_button[3] = gtk_check_button_new_with_label("Fragment with ! Option");
  gtk_box_pack_start(GTK_BOX (box_aw[8]), check_button[3], FALSE, TRUE, 5);
  gtk_widget_show(check_button[3]);

  check_button[4] = gtk_check_button_new_with_label("Set Counters");
  gtk_box_pack_start(GTK_BOX(box_aw[8]), check_button[4], FALSE, TRUE, 5);
  gtk_widget_show(check_button[4]);

  entry[0] = gtk_entry_new();
  gtk_signal_connect(GTK_OBJECT(entry[0]), "changed",
		     GTK_SIGNAL_FUNC(pkts_func), entry[0]);
  gtk_box_pack_start(GTK_BOX(box_aw[8]), entry[0], FALSE, TRUE, 0);
  gtk_widget_set_usize(entry[0], 65, 0);
  gtk_widget_show(entry[0]);

  entry[1] = gtk_entry_new();
  gtk_signal_connect(GTK_OBJECT(entry[1]), "changed",
		     GTK_SIGNAL_FUNC(bytes_func), entry[1]);
  gtk_box_pack_start(GTK_BOX(box_aw[8]), entry[1], FALSE, TRUE, 5);
  gtk_widget_set_usize(entry[1], 65, 0);
  gtk_widget_show(entry[1]);

}


void create_win() 
{
 
  window_aw = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title(GTK_WINDOW (window_aw), "Create Rule");
  gtk_window_set_policy(GTK_WINDOW (window_aw), FALSE, FALSE, FALSE);
  gtk_container_set_border_width (GTK_CONTAINER (window_aw), 10);
  gtk_signal_connect(GTK_OBJECT (window_aw), "delete_event",
		     GTK_SIGNAL_FUNC (gtk_widget_destroy), NULL);

  box_aw[0] = gtk_vbox_new(FALSE, 7);
  box_aw[1] = gtk_hbox_new(FALSE, 0);
  box_aw[2] = gtk_vbox_new(FALSE, 40);
  box_aw[3] = gtk_hbox_new(FALSE, 0);
  box_aw[4] = gtk_hbox_new(FALSE, 0);
  box_aw[5] = gtk_vbox_new(FALSE, 0);
  box_aw[6] = gtk_hbox_new(FALSE, 15);
  box_aw[7] = gtk_hbox_new(FALSE, 0);
  box_aw[8] = gtk_hbox_new(FALSE, 0);
  box_aw[9] = gtk_hbox_new(FALSE, 0);
  box_aw[10] = gtk_hbox_new(FALSE, 0);

  frame_aw[0] = gtk_frame_new ("Chain Selection");
  frame_aw[1] = gtk_frame_new ("Protocols"); 
  frame_aw[2] = gtk_frame_new ("Source Address and Port");
  frame_aw[3] = gtk_frame_new ("Destination Address and Port");
  frame_aw[4] = gtk_frame_new ("Actions");
  frame_aw[5] = gtk_frame_new ("Interfaces");
  frame_aw[6] = gtk_frame_new ("Options");
  
  gtk_container_add(GTK_CONTAINER (window_aw), box_aw[0]);

  gtk_box_pack_start(GTK_BOX (box_aw[0]), frame_aw[0], FALSE, FALSE, 0);
  gtk_box_pack_start(GTK_BOX (box_aw[0]), frame_aw[1], FALSE, FALSE, 0);
  gtk_box_pack_start(GTK_BOX (box_aw[0]), frame_aw[2], FALSE, FALSE, 0); 
  gtk_box_pack_start(GTK_BOX (box_aw[0]), frame_aw[3], FALSE, FALSE, 0);
  gtk_box_pack_start(GTK_BOX (box_aw[0]), frame_aw[5], FALSE, FALSE, 0);
  gtk_box_pack_start(GTK_BOX (box_aw[0]), frame_aw[6], FALSE, FALSE, 0);
  gtk_box_pack_start(GTK_BOX (box_aw[0]), frame_aw[4], FALSE, FALSE, 0);
  gtk_box_pack_start(GTK_BOX (box_aw[0]), box_aw[6], FALSE, FALSE, 0);
  gtk_box_pack_start(GTK_BOX (box_aw[2]), box_aw[9], FALSE, FALSE, 5);
  gtk_box_pack_start(GTK_BOX (box_aw[5]), box_aw[10], FALSE, FALSE, 5);

  gtk_container_add(GTK_CONTAINER (frame_aw[0]), box_aw[1]);
  gtk_container_add(GTK_CONTAINER (frame_aw[1]), box_aw[2]);
  gtk_container_add(GTK_CONTAINER (frame_aw[2]), box_aw[3]);
  gtk_container_add(GTK_CONTAINER (frame_aw[3]), box_aw[4]);
  gtk_container_add(GTK_CONTAINER (frame_aw[4]), box_aw[5]);
  gtk_container_add(GTK_CONTAINER (frame_aw[5]), box_aw[7]);
  gtk_container_add(GTK_CONTAINER (frame_aw[6]), box_aw[8]);

  gtk_widget_set_usize(frame_aw[0], 500, 50);
  gtk_widget_set_usize(frame_aw[2], 500, 50);
  gtk_widget_set_usize(frame_aw[3], 500, 50);
  gtk_widget_set_usize(frame_aw[5], 500, 50);
  gtk_widget_set_usize(frame_aw[6], 500, 50);


  gtk_widget_show(frame_aw[0]);
  gtk_widget_show(frame_aw[1]);
  gtk_widget_show(frame_aw[2]);
  gtk_widget_show(frame_aw[3]);
  gtk_widget_show(frame_aw[4]);
  gtk_widget_show(frame_aw[5]);
  gtk_widget_show(frame_aw[6]);
  
  table_func();   
  chain_func();
  protocol_func();
  button_set_tcp();
  button_set_icmp();
  saddr_func();
  sport_func();  
  daddr_func();
  dport_func(); 
  ininter_func();
  outinter_func();
  options_func();
  jump_func();
  button_set_reject();
  button_log_rule();
  button_cancel(); 
  button_ok();


  gtk_widget_show(box_aw[1]);  
  gtk_widget_show(box_aw[2]);  
  gtk_widget_show(box_aw[3]);
  gtk_widget_show(box_aw[4]);
  gtk_widget_show(box_aw[5]);
  gtk_widget_show(box_aw[6]);
  gtk_widget_show(box_aw[7]);
  gtk_widget_show(box_aw[8]);
  gtk_widget_show(box_aw[9]);
  gtk_widget_show(box_aw[10]);
  gtk_widget_show(box_aw[0]);  
  gtk_widget_show(window_aw);
}


