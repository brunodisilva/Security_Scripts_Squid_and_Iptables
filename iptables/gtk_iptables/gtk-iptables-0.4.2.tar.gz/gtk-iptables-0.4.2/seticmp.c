/* seticmp.c -- makes the "Set ICMP" window. 
 *
 * This file is part of Gtk-IPtables.
 *
 * Gtk-IPtables is Copyright (C) 2003  Daniel E. Testa
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <gtk/gtk.h>
#include <string.h>

#include "seticmp.h"

void clist_func();
void button_ok_func_si();
void button_cancel_func_si();

void set_icmp_win()
{
  window_si = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title(GTK_WINDOW(window_si), "Set ICMP");
  gtk_window_set_policy(GTK_WINDOW (window_si), FALSE, FALSE, FALSE);
  gtk_signal_connect(GTK_OBJECT (window_si), "delete_event",
		     GTK_SIGNAL_FUNC (gtk_widget_destroy), NULL);
  gtk_widget_set_usize(window_si, 260, 230);

  box_si[0] = gtk_vbox_new(FALSE, 10);
  box_si[1] = gtk_hbox_new(FALSE, 0);
  box_si[2] = gtk_hbox_new(FALSE, 0);

  gtk_container_add(GTK_CONTAINER(window_si), box_si[0]);
  gtk_box_pack_end(GTK_BOX(box_si[0]), box_si[1], FALSE, FALSE, 10);
  gtk_box_pack_start(GTK_BOX(box_si[0]), box_si[2], FALSE, FALSE, 10);
 
  clist_func();
  button_cancel_func_si();
  button_ok_func_si();

  gtk_widget_show(box_si[1]);
  gtk_widget_show(box_si[2]);
  gtk_widget_show(box_si[0]);
  gtk_widget_show(window_si);
}

void button_ok_func_si()
{
  button_si[0] = gtk_button_new_with_label(" Accept "); 
  gtk_signal_connect(GTK_OBJECT(button_si[0]), "clicked",
		     GTK_SIGNAL_FUNC(button_ok_si_callback),NULL);
  gtk_signal_connect_object(GTK_OBJECT(button_si[0]), "clicked",
			    GTK_SIGNAL_FUNC(gtk_widget_destroy),
			    GTK_OBJECT(window_si));			  
  gtk_box_pack_end(GTK_BOX(box_si[1]), button_si[0], FALSE, FALSE, 5);
  gtk_widget_show(button_si[0]);
}

void button_cancel_func_si()
{
  button_si[1] = gtk_button_new_with_label(" Cancel ");
  gtk_signal_connect_object(GTK_OBJECT(button_si[1]), "clicked",
			    GTK_SIGNAL_FUNC(gtk_widget_destroy),
			    GTK_OBJECT(window_si));
  gtk_box_pack_end(GTK_BOX(box_si[1]), button_si[1], FALSE, FALSE, 5);
  gtk_widget_show(button_si[1]);
}


void clist_func()
{
  gchar *titles[] = {"Type", "Alias"};
  gchar *type[37][2]= { {" ", "None"},
			{"0", "echo-reply"},
			{"3", "destination-unreachable"}, 
			{" ", "network-unreachable"},
			{" ", "host-unreachable"},
			{" ", "protocol-unreachable"},
			{" ", "port-unreachable"},
			{" ", "fragmentation-needed"},
			{" ", "source-route-failed"},
			{" ", "network-unknown"},
			{" ", "host-unknown"},
			{" ", "network-prohibited"},
			{" ", "host-prohibited"},
			{" ", "TOS-network-unreachable"},
			{" ", "TOS-host-unreachable"},
			{" ", "communication-prohibited"},
			{" ", "host-precedence-violation"},
			{" ", "precedence-cutoff"},
			{"4", "source-quench"},
			{"5", "redirect"},
			{" ", "network-redirect"},
			{" ", "host-redirect"},
			{" ", "TOS-network-redirect"},
			{" ", "TOS-host-redirect"},
			{"8", "echo-request"},
			{"9", "router-advertisement"},
			{"10", "router-solicitation"},
			{"11", "time-exceeded"},
			{" ", "ttl-zero-during-transit"},
			{" ", "ttl-zero-during-reassembly"},
			{"12", "parameter-problem"},
			{" ", "ip-header-bad"},
			{" ", "required-option-missing"},
			{"13", "timestamp-request"},
			{"14", "timestamp-reply"},
			{"17", "address-mask-request"},
			{"18", "address-mask-reply"} };
  gint indx;

  scrolled_window_si = gtk_scrolled_window_new(NULL, NULL);
  gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scrolled_window_si),
				 GTK_POLICY_AUTOMATIC, GTK_POLICY_ALWAYS);
  gtk_widget_set_usize(scrolled_window_si, 240, 180);
  gtk_box_pack_start(GTK_BOX (box_si[2]), scrolled_window_si, 
		     FALSE, FALSE, 10);
  gtk_widget_show(scrolled_window_si);
  
  clist_si = gtk_clist_new_with_titles(2, titles);
  gtk_signal_connect(GTK_OBJECT(clist_si), "select_row",
		     GTK_SIGNAL_FUNC(select_icmp_callback), NULL);
  gtk_container_add(GTK_CONTAINER(scrolled_window_si), clist_si);

  for (indx = 0; indx < 37; indx++) 
    gtk_clist_append((GtkCList *) clist_si, type[indx]);
  
  gtk_widget_show(clist_si);
}
