<? $ip = getenv("REMOTE_ADDR"); ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<HTML><HEAD><TITLE>Iptables Script Generator</TITLE>
<META http-equiv=Content-Type content="text/html; charset=windows-1252"><LINK 
href="style.css" type=text/css rel=stylesheet>
<META content="MSHTML 6.00.2719.2200" name=GENERATOR></HEAD>
<BODY onload="if (self != top) top.location = self.location">
<DIV style="WIDTH: 100%; TEXT-ALIGN: center">
<form name="form1" method="post" action="generate.php"">
<DIV id=box>
    <DIV id=title>Iptables Script Generator v. 0.1 </DIV>
<DIV id=body>
      <H2>Basic Information</H2>
      <p>Fill in all the required items below.</p>
      <PRE><form name="form1" method="post" action="generate.php"">
   External IP address: <input name=WAN_IP type="text" size="12" color="red" value="<? echo "$ip"; ?>"  style="<? echo "color: $error"; ?>"> NIC: <select name=WAN_NIC><option value="eth1" selected>eth1</option> <option value="eth0" selected>eth0</option> </select>
   Internal IP address: <select name=LAN_IP_NET> <option value="10.0.0.1/8" selected>10.0.0.0/8</option>   <option value="192.168.0.1/24" selected>192.168.0.1/24</option> </select> <select name=LAN_NIC>    <option value="eth0" selected>eth0</option>    <option value="eth1" selected>eth1</option>  </select>
   <br>
   <input CHECKED type="checkbox" name="NAT"> Enable NAT
        </PRE>
      <p><strong>External IP address:</strong> bl.a. bl.a. bl.a. bl.a.<strong><br>
        Internal IP address</strong>: bl.a. bl.a. bl.a. bl.a.<br>
        <strong>Enable NAT</strong>: this options makes it possible for computers
        inside LAN to surf on internet. Default is ON</p>
      <H2>Open ports on router</H2>
      <p></p>If you need to enable services on the router itself, such as webserver,
        mailservers, you need to use this section. </p>
      <PRE>
      <table width="99%"><col width="33%"><col width="33%"><col width="33%"><tbody>
      <td><input type="checkbox" name="INPUT_OK"> <b>Enable this section</b> </td>
      <td><input type="checkbox" name="INPUT_WWW"> WWW (80) </td>
      <td><input type="checkbox" name="INPUT_POP"> MAIL/POP3 (110) </td>
    </tr>
       <tr>
      <td><input type="checkbox" name="INPUT_FTP">  FTP (21)</td>
      <td><input type="checkbox" name="INPUT_SMTP"> MAIL/SMTP (25) </td>
      <td><input type="checkbox" name="INPUT_SSH"> SSH (22 </td>
    </tr>
  </tbody>
</table>
</PRE>
      <P>If you intend to use your router as an web/mail/ftp server or needs to open
  a specific port, please insert requirements above. Otherwise skip this section.
  If you wish to run a webserver on a server inside your LAN but not on the router,
  you also need to skip this section, and goto the Server on Portforwarding section below.</P>
      <H2>Portforwarding to servers on LAN</H2>
      <PRE>
      <table width="99%"><col width="33%"><col width="33%"><col width="33%"><tbody>
      <td><input type="checkbox" name="FORWARD_OK">Enable forwarding</td>
      <td><input type="checkbox" name="FORWARD_WWW"> WWW (80) </td>
      <td><input type="checkbox" name="FORWARD_POP"> MAIL/POP3 (110) </td>
    </tr>
       <tr>
      <td><input type="checkbox" name="FORWARD_FTP">  FTP (21)</td>
      <td><input type="checkbox" name="FORWARD_SMTP"> MAIL/SMTP (25) </td>
      <td><input type="checkbox" name="FORWARD_SSH"> SSH (22 </td>
    </tr>
  </tbody>
</table>
    LAN server IP: <input type="text" name="FORWARD_IP" value="0.0.0.0" size=15 maxlength=15> i.e. 192.168.0.5


</PRE>
      <P> This section is only if you need to make a server on LAN visible to outside
  world (WAN). Let's say you wish to run a server on 192.168.0.100, then you have
  to enable this section and forward the required port to that specific server.</P>
      <P><h2>Finish</h2></P>
      <p>Now doublecheck all the value that you have filled in this form. Whenever you think this is ok. press generate to continue.
You still need to setup the script on your linux box. If this gives you any problems, please consult a Linux News Group or Forum.  </p>

      <p><input type="submit" align="right" value="Generate"></p>

      <br><br>
      

      </DIV>
    <DIV id=footer></DIV></form>
  </DIV></DIV></BODY></HTML>
