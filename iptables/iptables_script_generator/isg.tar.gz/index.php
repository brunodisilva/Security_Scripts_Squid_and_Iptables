<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<HTML><HEAD><TITLE>Iptables Script Generator</TITLE>
<META http-equiv=Content-Type content="text/html; charset=windows-1252"><LINK 
href="style.css" type=text/css rel=stylesheet>
<META content="MSHTML 6.00.2719.2200" name=GENERATOR></HEAD>
<BODY onload="if (self != top) top.location = self.location">
<DIV style="WIDTH: 100%; TEXT-ALIGN: center">
<DIV id=box>
    <DIV id=title>Iptables Script Generator v. 0.1 </DIV>
<DIV id=body>
      <DIV id=whereami> </DIV>
      <H2>General Information</H2>
      <p>Iptables Script generator is an attemp to make it easy for you to setup 
        an custom linux router/firewall using Iptables. Getting this script to 
        work requires some knowledge of how to start the script from your linux 
        box. </p>
      <p>I would appriciate any comments and suggestion you might have. Please 
        send them to michael@1go.dk</p>
	<p>The purpose of this webpage is to make it easy to make a customized iptables script.</p>
      <p><strong>Iptables script generator:</strong></p>
      <UL>
        <LI><A href="index1.php">Iptables Script Generator</A>
      </UL>
      <p><strong>Development</strong></p>
      <p>If you wish to contribute to the development of this script, please mail 
        me. Contributing developers should have some experience programming PHP 
        and have some experience with iptables.</p>
      <p><strong>Credits to:</strong></p>
      <p>Langbein: For helping me to understanding the basic concept of iptables :o)</p>
      <p>MBN: For the nice stylesheet which he at this stage hasn't approved :o|</p>	
      <p><strong>and last but not least...</strong></p>
      <p>This script comes with absolutely no warranty.</p>
    </DIV>
    <DIV id=footer><font color="#000000">e-mail: michael@1go.dk</font></DIV>
  </DIV></DIV></BODY></HTML>
