<?
if (ereg("^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$",$WAN_IP)) {

$WAN_IP="$WAN_IP";
$LAN_NIC="$LAN_NIC";
$WAN_NIC="$WAN_NIC";
$LAN_IP_NET="$LAN_IP_NET";
$NAT="$NAT";

$INPUT_OK="$INPUT_OK";
$INPUT_WWW="$INPUT_WWW";
$INPUT_FTP="$INPUT_FTP";
$INPUT_POP="$INPUT_POP";
$INPUT_SMTP="$INPUT_SMTP";
$INPUT_SSH="$INPUT_SSH";
$INPUT_OTHER="$INPUT_OTHER";

$FORWARD_OK="$FORWARD_OK";
$FORWARD_WWW="$FORWARD_WWW";
$FORWARD_FTP="$FORWARD_FTP";
$FORWARD_POP="$FORWARD_POP";
$FORWARD_SMTP="$FORWARD_SMTP";
$FORWARD_SSH="$FORWARD_SSH";
$FORWARD_IP="$FORWARD_IP";
$FORWARD_OTHER="$FORWARD_OTHER";


echo "<font face='courier' size='3' color='#000000'>";
echo "#!/bin/sh";
echo "<br><br>";
echo "# iptables script generator: V0.1-2002<br>";
echo "# Comes with no warranty!<br>";
echo "# e-mail: michael@1go.dk<br>";
echo "<br>";

echo "# Diable forwarding<br>";
echo "echo 0 > /proc/sys/net/ipv4/ip_forward<br>";
echo "<br>";
echo "LAN_IP_NET='$LAN_IP_NET'<br>";
echo "LAN_NIC='$LAN_NIC'<br>";
echo "WAN_IP='$WAN_IP'<br>";
echo "WAN_NIC='$WAN_NIC'<br>";


if ($FORWARD_OK=='on'){
echo "FORWARD_IP='$FORWARD_IP'<br>";
}
echo "<br>";


echo "# load some modules (if needed)<br>";
if ($INPUT_FTP==on || $FORWARD_FTP==on) {
echo "modprobe ip_nat_ftp<br>";
echo "modprobe ip_conntrack_ftp<br>";
}
echo "<br>";



echo "# Flush<br>";
echo "iptables -t nat -F POSTROUTING<br>";
echo "iptables -t nat -F PREROUTING<br>";
echo "iptables -t nat -F OUTPUT<br>";
echo "iptables -F<br>";
echo "<br>";

echo "iptables -P INPUT DROP<br>";
echo "iptables -P FORWARD DROP<br>";
echo "iptables -P OUTPUT ACCEPT<br>";
echo "<br>";

# echo "# accept traffic from LAN to router<br>";
# echo "iptables -A INPUT -i lo -j ACCEPT<br>";
# echo "<br>";

if ($NAT=='on'){
echo "# enable Masquerade and forwarding<br>";
echo "iptables -t nat -A POSTROUTING -s \$LAN_IP_NET -j MASQUERADE<br>";
echo "iptables -A FORWARD -j ACCEPT -i \$LAN_NIC -s \$LAN_IP_NET<br>";
echo "iptables -A FORWARD -m state --state ESTABLISHED,RELATED -j ACCEPT<br>";

echo "<br>";
}

################################
# open ports on router (INPUT) #
################################
if ($INPUT_OK=='on'){
echo "# Open ports on router for server/services<br>";


if ($INPUT_WWW=='on'){
echo "iptables -A INPUT -j ACCEPT -p tcp --dport 80<br>";
}
if ($INPUT_FTP=='on'){
echo "iptables -A INPUT -j ACCEPT -p tcp --dport 21<br>";
}
if ($INPUT_POP=='on'){
echo "iptables -A INPUT -j ACCEPT -p tcp --dport 110<br>";
}
if ($INPUT_SMTP=='on'){
echo "iptables -A INPUT -j ACCEPT -p tcp --dport 25<br>";
}
if ($INPUT_SSH=='on'){
echo "iptables -A INPUT -j ACCEPT -p tcp --dport 22<br>";
}

#if (isset($INPUT_OTHER)){
#$ports_array = explode(',', $INPUT_OTHER);
#while (list(, $value) = each ($ports_array)) {
#echo "iptables -A INPUT -j ACCEPT -p tcp --dport $value<br>";
#}
# }

echo "<br>";
}

echo "# STATE RELATED for router<br>";
echo "iptables -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT<br><br>";

##################################
# Forward ports to server on LAN #
##################################


if ($FORWARD_OK=='on'){
echo "# Open ports to server on LAN<br>";

if ($FORWARD_WWW=='on'){
echo "iptables -A FORWARD -j ACCEPT -p tcp --dport 80<br>";
echo "iptables -t nat -A PREROUTING -i $WAN_NIC -p tcp --dport 80 -j DNAT --to $FORWARD_IP:80<br>";
}
if ($FORWARD_FTP=='on'){
echo "iptables -A FORWARD -j ACCEPT -p tcp --dport 21<br>";
echo "iptables -t nat -A PREROUTING -i $WAN_NIC -p tcp --dport 21 -j DNAT --to $FORWARD_IP:21<br>";
}
if ($FORWARD_SSH=='on'){
echo "iptables -A FORWARD -j ACCEPT -p tcp --dport 22<br>";
echo "iptables -t nat -A PREROUTING -i $WAN_NIC -p tcp --dport 22 -j DNAT --to $FORWARD_IP:22<br>";
}
if ($FORWARD_SMTP=='on'){
echo "iptables -A FORWARD -j ACCEPT -p tcp --dport 25<br>";
echo "iptables -t nat -A PREROUTING -i $WAN_NIC -p tcp --dport 25 -j DNAT --to $FORWARD_IP:25<br>";
}
if ($FORWARD_POP=='on'){
echo "iptables -A FORWARD -j ACCEPT -p tcp --dport 110<br>";
echo "iptables -t nat -A PREROUTING -i $WAN_NIC -p tcp --dport 110 -j DNAT --to $FORWARD_IP:110<br>";
}


#if (isset($FORWARD_OTHER)){
#$ports_array = explode(',', $FORWARD_OTHER);
#while (list(, $value) = each ($ports_array)) {
#echo "iptables -A FORWARD -j ACCEPT -p tcp --dport $value<br>";
#echo "iptables -t nat -A PREROUTING -i $WAN_NIC -p tcp --dport $value -j DNAT --to $FORWARD_IP:$value<br>";
# }
#}




}
###################################
# End forward port to LAN         #
###################################


echo "<br># Enable forwarding<br>";
echo "echo 1 > /proc/sys/net/ipv4/ip_forward<br>";




} else {
$error="red";
header( "Location: indexnew.php?error=red" );
}
?>
