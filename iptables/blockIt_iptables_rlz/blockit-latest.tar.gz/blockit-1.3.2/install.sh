#!/bin/sh

INSTALLDIR="/usr/local/blockit"

echo -n "Please Enter Install Directory [$INSTALLDIR]: "
read userinstall

if [ -z $userinstall ] 
then userinstall="$INSTALLDIR" 
fi

mkdir -p $userinstall 
mkdir -p $userinstall/logs

cp -R bin $userinstall 
cp -R conf $userinstall
cp -R contrib $userinstall
cp -R doc $userinstall
cp -R src $userinstall

ln -fns $userinstall/conf /etc/blockit
ln -fns $userinstall/logs /var/log/blockit

touch $userinstall/logs/intruders
echo -n "Do you want to configure MySQL support? [y/n]: "
read mysql

case $mysql in 
[yY]*)
	echo -n "Enter Username : "
	read user
	echo -n "Enter Password : "
	read password
	mysqladmin -u$user -p$password create blockit
	mysql -u$user -p$password blockit < $userinstall/contrib/blockit.mysql 
	;;
esac


