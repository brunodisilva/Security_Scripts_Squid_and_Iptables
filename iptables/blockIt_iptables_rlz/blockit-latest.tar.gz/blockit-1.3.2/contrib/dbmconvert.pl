#!/usr/bin/perl 

print "This Utility will convert your BlockIt Intruder File to a DBM File\n";
print "You will need this utility to convert pre 1.2.6 intruder files\n\n";

print "Please enter the path to your current Intruder file: ";
chomp($file = <STDIN>);


open(INTOLD, $file);
@OLD = <INTOLD>;
close(INTOLD);

dbmopen(%NEWHASH, "newintruderfile", 0644);
print "This is your old Intruder File\n";
foreach $line (@OLD) {
  chomp($line);
  next if ($line =~ /^\s*$/);
  print "$line\n";
  $NEWHASH{$line}=1;
}
print "\nThis is your new file called newintruderfile <- What an original name\n"; 
while (($key, $value) = each(%NEWHASH)) {
    print "$key\n";
}
dbmclose(%FRED);

print "\n\nCopy newintruderfile over over your current BlockIt Intruder File\n";
