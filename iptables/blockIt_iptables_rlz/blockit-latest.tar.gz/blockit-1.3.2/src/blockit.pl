#!/usr/bin/perl  
# V 1.3.2 - 10/08/2003
# This program was written by Hugo "Lord Vega" Samayoa (lordvega@teknofx.com)


#perl2exe_include DBI
use DBI;
#perl2exe_include DBD/mysql
use DBD::mysql;
#perl2exe_include DB_File
use DB_File;
#perl2exe_include Term/ANSIColor
use Term::ANSIColor;

&import_modules;
&defineconst;
&load_config;
&check_config;
&sig_handler_setup;
&getargv;
&init_iptables;
&build_ignorehash;
&build_targethash;
&build_intruderhash;
&daemonize;
&agent;


###############################################################################
#				PROCEDURES				      #
###############################################################################
sub agent {
  $presize=(stat($config{alertfile}))[7];
  my $date = localtime();
  &write_log ("Starting BlockIt Agent at $date\n");
  open (ALERT, $config{alertfile}) or die "open $config{alertfile}: $!\n";
  seek (ALERT, 0, 2);
  $rulecounter=0;
  my $priority = 0;
  for (;;) { 
    sleep 1; 
    if (seek(ALERT,0,1)){ 
      while (<ALERT>) { 
        chop;
        if (/snort/) { 
          my @parse=split(/\s+/,$_);
          my @data=();
          my $grabnext=0;
          my $priority=0;
          foreach $str (@parse) {
            if ($grabnext eq 1) {
              $str =~ /(\d)/;
              $priority = $1;
              $grabnext = 0;
            }
            if ($str=~/(\d+\.\d+\.\d+\.\d+)/) {
              $data[$#data+1]=$1;
            }
            if ($str=~/Priority:/) { $grabnext = 1 }
          }
          if ($data[1] eq "") { $data[1]=0; }
          if ($data[0] eq $data[1]) { $priority=-1; }
          &rules ($data[0], $data[1], $priority);
        } else {
          if (/spp_portscan: PORTSCAN DETECTED from (\d+\.\d+\.\d+\.\d+)/) {
            $priority=-1;
            &rules ($1, $1, $priority);
          }
          if (/spp_portscan2\) Portscan detected from (\d+\.\d+\.\d+\.\d+)/) {
            $priority=-1;
            &rules ($1, $1, $priority);
          }
          if (/\[Priority:\s*(\d*)\]/){
            $priority=$1;
          }
          if (/(\d+\.\d+\.\d+\.\d+):\d+ -\> (\d+\.\d+\.\d+\.\d+):\d+/) {
            &rules ($1, $2, $priority);
          }
          if (/(\d+\.\d+\.\d+\.\d+) -\> (\d+\.\d+\.\d+\.\d+)/) {
            &rules ($1, $2, $priority);
          }
        }
      }
    }
    if ($rulecounter == $minute) {
      &minutecall;
      &checkfilesize;
      $rulecounter=0; 
    } else {
      $rulecounter++;
    }
  }
}

	
sub build_ignorehash {
  my $count =0;
  $ignore{$config{gatewayaddress}}=1;
  $ignore{$config{hostipaddr}}=1;
  if ($config{ignorefile} ne "") {
    open (IGNORE, $config{ignorefile}) or die "open $config{ignorefile}: $!\n";
    while (<IGNORE>) {
      chop;
      next if (/\#/);  
      next if (/^\s*$/); 
      if ($_ =~ /^(\d{1,3}).(\d{1,3}).(\d{1,3}).(\d{1,3})\/(\d{1,2})/) { 
      	$start_ip = $4;
      	$bits = $5; 
        if ($bits == 24) {
                $end_ip = ($4+255);
        }
        if ($bits == 25) {
                $end_ip = ($4+127);
        }
        if ($bits == 26) {
                $end_ip = ($4+63);
        }
        if ($bits == 27) {
                $end_ip = ($4+31);
        }
        if ($bits == 28) {
                $end_ip = ($4+15);
        }
        if ($bits == 29) {
                $end_ip = ($4+7);
        }
        if ($bits == 30) {
                $end_ip = ($4+3);
        }
        if ($bits == 31) {
                $end_ip = ($4+1);
        }
	print "Generating Ignore Hash for $1.$2.$3.$4 - $1.$2.$3.$end_ip\n";
	$end_ip++;
	for ($i = $start_ip; $i < $end_ip; $i++) {
	   $ignoreip = "$1.$2.$3.$i";
	   $ignore{$ignoreip}=1; 
	   $count++;
	}
      }
      if ($_ =~ /^(\d{1,3}).(\d{1,3}).(\d{1,3}).(\d{1,3})$/) {
        $ignore{$_}=1;
        $count++;
      }
    }
    close (IGNORE);
    print "Loaded $count addresses from $config{ignorefile}\n";
  } else {
    print "No ignore file was loaded!\n";
  }
}

sub build_intruderhash {
  if ($config{useintruders} eq "1") { 
    dbmopen(%intruderhash, $config{intruderfile}, $mode) || die "Can\'t Access Database\n";
    print "Applying Intruders File\n";
    my $count = 0;
    while (($key, $value) = each(%intruderhash)) {
	  &write_log ("Running from Intruders File ");
          &firewall_add($key);
	  $count++;
    }
    print "Loaded $count addresses from $config{intruderfile}\n";
    dbmclose(%intruderhash);
  }
}

sub build_targethash {
  my $count =0;
  $targethash{$config{hostipaddr}}=1;
  if ($config{extrahostsfile} ne "") {
    open (XTRA, $config{extrahostsfile}) or die "open $config{extrahostsfile}: $!\n";
    while (<XTRA>) {
      chop;
      next if (/\#/);  
      next if (/^\s*$/); 
      if ($_ =~ /^(\d{1,3}).(\d{1,3}).(\d{1,3}).(\d{1,3})\/(\d{1,2})/) { 
      	$start_ip = $4;
      	$bits = $5; 
        if ($bits == 24) {
                $end_ip = ($4+255);
        }
        if ($bits == 25) {
                $end_ip = ($4+127);
        }
        if ($bits == 26) {
                $end_ip = ($4+63);
        }
        if ($bits == 27) {
                $end_ip = ($4+31);
        }
        if ($bits == 28) {
                $end_ip = ($4+15);
        }
        if ($bits == 29) {
                $end_ip = ($4+7);
        }
        if ($bits == 30) {
                $end_ip = ($4+3);
        }
        if ($bits == 31) {
                $end_ip = ($4+1);
        }
	print "Generating Target Hash for $1.$2.$3.$4 - $1.$2.$3.$end_ip\n";
	$end_ip++;
	for ($i = $start_ip; $i < $end_ip; $i++) {
	   $target = "$1.$2.$3.$i";
	   $targethash{$target}=1; 
	   $count++;
	}
      }
      if ($_ =~ /^(\d{1,3}).(\d{1,3}).(\d{1,3}).(\d{1,3})$/) {
        $targethash{$_}=1;
        $count++;
      }
    }
    close (XTRA);
    print "Loaded $count addresses from $config{extrahostsfile}\n";
  } else {
    print "No Host file was loaded!\n";
  }
}

sub check_config {
  if ($config{interface} eq "") {
    die "Fatal! Interface is undefined.. Please define it in $conffile with keyword Interface\n";
  }
  if ($config{alertfile} eq "") {
    print "Warning! AlertFile is undefined.. Assuming $def_snortlog\n";
    $config{alertfile}=$def_snortlog;
  }
  if ($config{ignorefile} eq "") {
    print "Warning! IgnoreFile is undefined.. going with default ignore list (hostname and gateway)!\n";
  }
  if ($config{gatewayaddress} eq "") {
    print "Warning! GatewayAddress is undefined.. gateway will not be in ignore list!\n";
  }
  if ($config{firewalltype} eq "") {
    print "Warning Firewall Type is undefined. Using default of $def_ftype\n";
    $config{firewalltype}=$def_ftype;
  }
  if ($config{firewallpath} eq "") {
    print "Warning! Firewall Path is undefined.. Using default of $def_fpath\n";
    $config{firewallpath}=$def_fpath;
  }
  if ($config{intruderfile} eq "") {
    print "Warning! IntruderFile is undefined.. Assuming $def_intruders\n";
    $config{intruderfile}=$def_intruders;
  }
  if ($config{dtime} eq "") {
    print "Warning! DTime is undefined.. Assuming Forever\n";
    $config{dtime}=$def_time;
  }
  if ($config{ptime} eq "") {
    print "Warning! PTime is undefined.. Assuming Forever\n";
    $config{ptime}=$config{dtime};
  }
  if ($config{htime} eq "") {
    print "Warning! HTime is undefined.. Assuming Forever\n";
    $config{htime}=$config{dtime};
  }
  if ($config{mtime} eq "") {
    print "Warning! MTime is undefined.. Assuming Forever\n";
    $config{mtime}=$config{dtime};
  }
  if ($config{ltime} eq "") {
    print "Warning! LTime is undefined.. Assuming Forever\n";
    $config{ltime}=$config{dtime};
  }
  if ($config{logfile} eq "") {
    print "Warning! LogFile is undefined.. Assuming debug mode, output to STDOUT\n";
    $debug = 1;
  }
  if (! -w $config{logfile}) {
    print "Warning! Logfile $config{logfile} is not writeable! Engaging debug mode, output to STDOUT\n";
    $debug = 1;
  }  
  if ($config{hostipaddr} !~ /^(\d{1,3}).(\d{1,3}).(\d{1,3}).(\d{1,3})/) {
    print "This ip address is bad : $config{hostipaddr}\n";
    die "BlockIt needs a good host hostipaddress\n";
  }
}

sub checkfilesize {
  $size = (stat($config{alertfile}))[7];
  if ($size < $presize) {
    close(ALERT);
    open (ALERT, "$config{alertfile}");
    &write_log ("Alert File Changed Size. Re-Opening\n"); 
  } 
  $presize=$size;
}

sub cleanup {
  dbmopen(%intruderhash, $config{intruderfile}, $mode) || die "Can\'t Access Database\n"; 
  while (($key, $value) = each(%intruderhash)) {
    &write_log ("Running from Intruders File ");
    &firewall_del($key);
  }
  dbmclose(%intruderhash);
  close(ALERT);
}

sub daemonize {
  print "Becoming a daemon..\n";
  my ($home);
  if (fork()) {
    exit(0);
  } else {
    &write_log ("BlockIt process id $$\n");
    open(PIDFILE,">".$pidfile) or die "open $pidfile: $!\n";
    print PIDFILE "$$\n";
    close(PIDFILE);
    $home = (getpwuid($>))[7] || die "No home directory!\n";
    chdir($home);                   
    setpgrp(0,0);                   
    close(STDOUT);
    close(STDIN);
    close(STDERR);
  }
}

sub defineconst {
  $version = "v1.3.2\n";
  $conffile = "/etc/blockit/blockit.conf";
  $pidfile = "/var/run/blockit.pid";
  $def_intruders = "/etc/blockit/blockit.intruders";
  $def_snortlog = "/var/log/snort/alert";
  $def_ftype = 0;
  $def_fpath = "/usr/sbin/iptables";
  $mode = "0644";
  $def_time = 0;
  $minute = 60;
}

sub firewall_add {
  my $f_ip = $_[0];
  my $firewall_command;
  if ($config{firewalltype} == 0) {
    $firewall_command = "$config{firewallpath} -I BLOCKIT -s $f_ip -i $config{interface} -j DROP\n";
  } elsif ($config{firewalltype} == 1) {
    $firewall_command = "$config{firewallpath} -I input -s $f_ip -i $config{interface} -j DENY\n";
  } elsif ($config{firewalltype} == 2) {
    $firewall_command = "$config{firewallpath} -I -a deny -W $config{interface} -S $f_ip\n";
  } elsif ($config{firewalltype} == 3) {
    $firewall_command = "$config{firewallpath} sam -s localhost -f all -t forever -I src $f_ip\n";
  } else {
    $firewall_command = "$config{firewallpath} -I BLOCKIT -s $f_ip -i $config{interface} -j DROP\n";
  }
  &write_log ("$firewall_command\n");
  system ("$firewall_command");
}

sub firewall_del {
  my $f_ip = $_[0];
  my $firewall_command;
  if ($config{firewalltype} == 0) {
    $firewall_command = "$config{firewallpath} -D BLOCKIT -s $f_ip -i $config{interface} -j DROP\n";
  } elsif ($config{firewalltype} == 1) {
    $firewall_command = "$config{firewallpath} -D input -s $f_ip -i $config{interface} -j DENY\n";
  } elsif ($config{firewalltype} == 2) {
    $firewall_command = "$config{firewallpath} -I -d deny -W $config{interface} -S $f_ip\n";
  } elsif ($config{firewalltype} == 3) {
    $firewall_command = "$config{firewallpath} sam -C -s localhost -f all -t forever -I src $f_ip\n";
  } else {
    $firewall_command = "$config{firewallpath} -D BLOCKIT -s $f_ip -i $config{interface} -j DROP\n";
  }
  &write_log ("$firewall_command\n");
  system ("$firewall_command");
}

sub getargv {  
  $command1 = $ARGV[0];
  $command2 = $ARGV[1];
  $command3 = $ARGV[2];
  chomp($command1);
  chomp($command2);
  chomp($command3);
  print colored ("BlockIt $version\n\n", 'GREEN');
  print color 'BOLD WHITE';
  if ($command1 == "") {
        if (-e $pidfile) {
            die "Sorry Server is running or $pidfile file still exists\n";
        }    
  }      
  if ($command1 eq "stop") {
	open(PIDFILE, $pidfile) or die "open $pidfile: $!\n";
	@PID = <PIDFILE>;
	close(PIDFILE);
	$PID = $PID[0];
        &cleanup;
	&write_log ("Killing BlockIt Process $PID\n");
	system("kill -9 $PID");
	system("rm $pidfile");
	die "Killed BlockIt Process $PID\n";
  }
  if ($command1 eq "remove") {
    if ($command2 !~ /^(\d{1,3}).(\d{1,3}).(\d{1,3}).(\d{1,3})/) {
      die "Invalid IP Address\n";
    } else {
      dbmopen(%intruderhash, $config{intruderfile}, $mode) || die "Can\'t Access Database\n";
      delete $intruderhash{$command2};
      dbmclose(%intruderhash);
      &write_log ("Running ");
      &firewall_del($command2);
      die "Removed $command2 from Intruder Hash\n";
    }
  }
  if ($command1 eq "insert") {
    if ($command2 !~ /^(\d{1,3}).(\d{1,3}).(\d{1,3}).(\d{1,3})/) {
      die "Invalid IP Address\n";
    } else {
      if (!$command3) { $command3 = 0 };
      dbmopen(%intruderhash, $config{intruderfile}, $mode) || die "Can\'t Access Database\n";
      $intruderhash{$command2}=$command3;
      dbmclose(%intruderhash);
      &write_log ("Running ");
      &firewall_add($command2);
      die "Added $command2 to Intruder Hash\n";
    }
  }
  if ($command1 eq "list") {
    dbmopen(%intruderhash, $config{intruderfile}, $mode) || die "Can\'t Access Database\n";
    print "IP\t\tTime In Minutes\n";  
    while (($key, $value) = each(%intruderhash)) {
      print "$key\t";
      print "$intruderhash{$key}\n";
    }
    dbmclose(%intruderhash);
    exit 0;
  }
  if ($command1 eq "help") {
    print "blockit\t\t\t\t\t=\tStart BlockIt (DEFAULT)\n";
    print "blockit help\t\t\t\t=\tThis Screen *DUH*\n";
    print "blockit stop\t\t\t\t=\tStop BlockIt Process\n";
    print "blockit list\t\t\t\t=\tLists Intruder Hash\n";
    print "blockit insert <ip address> <time>\t=\tInserts IP Address to BlockIt Intruder Hash for the specified amount of time\n";
    print "blockit remove <ip address>\t\t=\tRemoves IP Address from BlockIt Intruder Hash\n";
    exit;
  }
  print color 'RESET';
  print "\n";
}

sub getpri {
  my $privar = $_[0];
  if ($privar == -1) {
    return $config{ptime};
  } elsif ($privar == 0) {
    return $config{dtime};
  } elsif ($privar == 1) {
    return $config{htime};
  } elsif ($privar == 2) {
    return $config{mtime};
  } elsif ($privar == 3) {
    return $config{ltime};
  } else {
    return $config{dtime};
  }
}

sub init_iptables {
  if ($config{firewalltype} == 0) {
    $test_chain = `$config{firewallpath} -L -n | grep "Chain BLOCKIT"`;
    $test_reference = `$config{firewallpath} -L INPUT -n | grep BLOCKIT`;
    chomp($test_chain);
    chomp($test_reference);
    if ($test_chain eq "") {
      system("$config{firewallpath} -N BLOCKIT");
    }
    if ($test_reference eq "") {
      system("$config{firewallpath} -I INPUT -j BLOCKIT");
    }
    system("$config{firewallpath} -F BLOCKIT");
  }
}

sub import_modules {
  BEGIN {
        unless (eval "use DBI; 1") {
          warn "couldn't load DBI";
      }
  }
  BEGIN {
        unless (eval "use DBD::mysql; 1") {
          warn "couldn't load DBD::mysql";
      }
  }
  BEGIN {
        unless (eval "use DB_File; 1") {
          warn "couldn't load DB_File";
      }
  }
  BEGIN {
        unless (eval "use Term::ANSIColor; 1") {
          warn "couldn't load Term::ANSIColor";
      }
  }
}

sub iptable { 
  my ($source, $dest, $priority) = @_;
  dbmopen(%intruderhash, $config{intruderfile}, $mode) || die "Can\'t Access Database\n";
  $intruderhash{$source}=&getpri($priority);
  dbmclose(%intruderhash);
  &write_log("$source\t$priority\n");
  &write_log("Running ");
  &firewall_add($source);
  if ($config{mysql} eq "1") {
	print "$config{mysql}\n";
	&write_intruders_mysql("$source");
  }
  if ($config{email} eq "1") {
	print "email\n";
	&write_intruders_email("$source");
  }
}

sub load_config {
    open (CONF, $conffile) or die "Cannot read the config file $conffile, $!\n";
    while (<CONF>) {
        next if /^\s*#/;
        /^\s*(\S*)\s*=\s*(\S*)\s*$/ or next; 
        my ($temp_k, $v) = ($1, $2);
        $k = lc($temp_k);
        $config{$k} = $v;
    }
    close(CONF);
}

sub minutecall {
  dbmopen(%intruderhash, $config{intruderfile}, $mode) || die "Can\'t Access Database\n";
  while (($key, $value) = each(%intruderhash)) {
    if (!defined $intruderhash{$key}) { 
      $intruderhash{$key} -= 1;
      #&write_log ("IP = $key\tMinutes = $value\n");
      if ($intruderhash{$key} == 0) {
        delete $intruderhash{$key};
        my $date = localtime();
        &write_log ("Un-Blocking Intruder at $date\n");
        &write_log ("Running ");
        &firewall_del($key);
      }
    }
  }
  dbmclose(%intruderhash);
}

sub rules {
  my ($source, $dest, $priority) = @_;
  my $flag=0;
  my $date = localtime();
  if ($ignore{$source} == 1) { 
     &write_log("Intruder found at $date: ");
     &write_log("$source $priority\n");
     &write_log("Ignoring attack because $source is in my ignore list\n");
     return 1;
  }
  dbmopen(%intruderhash, $config{intruderfile}, $mode) || die "Can\'t Access Database\n";
  if (!defined $intruderhash{$source}) {
    if ($targethash{$dest} == 1) {   
      &write_log("Intruder found at $date: ");
      &iptable($source, $dest, $priority);
    }
    else { 
      &write_log ("Odd.. source = $source, dest = $dest. No action done.\n"); 
      if (defined ($debug)) {
        foreach $key (keys %targethash) {
          &write_log ("targethash{$key} = $targethash{$key}\n");
        }
      }
    }
    dbmclose(%intruderhash);
  }
}

sub sig_handler_setup {
  $SIG{TERM} = \&cleanup;
  $SIG{QUIT} = \&cleanup;
}

sub write_intruders_mysql {
  my $message = $_[0];
  chomp($message);
  $dbh = DBI->connect("DBI:mysql:$config{database}",$config{username},$config{password},{RaiseError => 1});
  $results=$dbh->prepare(q{INSERT INTO INTRUDERS (IP) values (?)});
  $results->execute($message) . "\n";
}

sub write_intruders_email {
  my $message = $_[0];
  chomp($message);
  open(MAIL, "|$config{mailprogram} -t") or die "open $config{mailprogram}: $!\n";
  print MAIL "To: $config{toemail}\n";
  print MAIL "From: $config{fromemail}\n";
  print MAIL "Subject: BlockIt Intruder Detected\n\n";
  print MAIL "$message\n";
  close(MAIL);
}
sub write_log {
  my $message = $_[0];
  if (defined($debug)) {  
    print STDOUT $message;
  } else {
    open (LOG, ">>$config{logfile}") or die "open $config{logfile}: $!\n";
    print LOG $message;
    close (LOG);
  }
}
