#!/bin/bash
# Author: Joerg Strehlau
echo -e "# THIS IS AN INSTALL SCRIPT FOR \033[32mjsfirewall v0.5.2\033[m.\n# DO YOU WANT TO INSTALL jsfirewall ON YOUR LINUX(TM) BOX?\n# TYPE [yes] TO START THE INSTALLATION, TYPE [no] TO CANCEL.\n# AFTER YOUR TYPING PRESS THE \"RETURN BUTTOM\"."
while $1 ; do
read INPUT
case "$INPUT" in
 "yes")
	echo -e "# OK, START INSTALLATION.\n# MAKE UNDER /etc/ MY jsfirewall DIRECTORY ..."
	mkdir -v /etc/jsfirewall
	echo "# COPY ALL THE STUFF TO MY TARGET ..."
	cp -rfv language /etc/jsfirewall/
	cp -v jsfw.conf /etc/jsfirewall/
	cp -v jsfwoff /etc/jsfirewall/
	cp -v inputstyle /etc/jsfirewall/
	cp -v server /etc/jsfirewall/
	cp -v sensitivity /etc/jsfirewall/
	cp -v jsfirewall /usr/local/sbin/
	mkdir -v /usr/share/doc/jsfirewall
	cp -v README /usr/share/doc/jsfirewall/
	echo "# NOW TYPE IN YOUR LANGUAGE [default: EN, optional: DE]"
	echo "# THEN PRESS THE \"RETURN BUTTOM\""
	while $1 ; do
	 read INPUT
	 case "$INPUT" in
	 "")
	 	echo "LANG=\"EN\"" >>/etc/jsfirewall/jsfw.conf
		break
		;;
	 "EN")
	 	echo "LANG=\"EN\"" >>/etc/jsfirewall/jsfw.conf
		break
		;;
	 "DE")
	 	echo "LANG=\"DE\"" >>/etc/jsfirewall/jsfw.conf
		break
		;;
	 *)
	 	echo -e "# USAGE:\033[31m PRESS RETURN OR TYPE EN OR DE\033[m"
		;;
	 esac
	done	
	echo -e "#\033[32m GRATULATION ... FINISHED INSTALLATION!\033[m \n# YOU CAN START THE PROGRAMM ONLY AS ROOT BY TYPING IN THE SHELL: \033[038mjsfirewall\033[m"
	break
	;;
 "no")
 	echo -e "# $INPUT \033[m"
	break
	;;
 *)
 	echo -e "# USAGE:\033[31m yes | no\033[m"
	;;
esac
done
exit

