#!/bin/sh

PROTOCOLS="fasttrack gnutella edonkey dc bittorrent openft"

for proto in $PROTOCOLS
do
	iptables -A FORWARD -m p2p --p2p $proto
done
