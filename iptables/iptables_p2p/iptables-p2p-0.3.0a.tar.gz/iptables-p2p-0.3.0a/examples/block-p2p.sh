#!/bin/sh

iptables -A FORWARD -m p2p --p2p all -j DROP
