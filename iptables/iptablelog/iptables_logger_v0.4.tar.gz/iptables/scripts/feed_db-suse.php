#!/usr/bin/php -q
<?
# SuSE Firewall2 - IPTable log analyzer
# Copyright (C) 2002 Sandor Bakos
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Plac<B2>e - Suite 330, Boston, MA  02111-1307, USA.
#
# Contact author : nacon@nacon.hu

# feed_db.php v1.0 2002/11/01 22:50 saca

  $LOG_TAG="SuSE-FW";
  $DB_HOST="localhost";
  $DB_USER="iptables_admin";
  $DB_PASSW="ip2admin";
  $DATABASE="iptables";

  if($ab=mysql_connect($DB_HOST,$DB_USER,$DB_PASSW)){
    mysql_select_db($DATABASE);
  }else{
    echo "Database Open Error !! \n";
    exit;
  };

  $stdin=fopen("php://stdin","r");
  if (!$stdin) exit;
  while (!feof ($stdin)) {
     $s = fgets($stdin,4096);
     if (strstr($s,$LOG_TAG)){
         $date=date("Y.m.d H:i:s",strtotime(substr($s,0,6).", ".date("Y",time())." ".substr($s,7,8)));
         $host=substr($s,16,strpos($s," kernel:")-16);
         $chain=( (strstr($s,"ICMP")) ? "ICMP" : ((strstr($s,"ACCEPT")) ? "ACCEPT" :  ((strstr($s,"DROP")) ? "DROP" : "OTHER") ) );
         if ($chain!="OTHER") {
            $s=substr($s,strpos($s,"IN=")+3);
            $substr=strtok($s," ");
            $interface_in=$substr;
            $substr=strtok(" ");$substr=strtok(" ");$substr=strtok(" ");
            $src_ip=substr($substr,strpos($substr,"=")+1);
            $src_name=gethostbyaddr($src_ip);
            if ($src_ip==$src_name) $src_name="unknown";
            $substr=strtok(" ");
            $dst_ip=substr($substr,strpos($substr,"=")+1);
            $dst_name=gethostbyaddr($dst_ip);
            if ($dst_ip==$dst_name) $dst_name="unknown";
            $s=substr($s,strpos($s,"PROTO=")+5);$substr=strtok($s," ");
            $porto=substr($substr,strpos($substr,"=")+1);
            $substr=strtok(" ");
            $port_src=substr($substr,strpos($substr,"=")+1);
            $substr=strtok(" ");
            $port_dst=substr($substr,strpos($substr,"=")+1);

            $sql_command="INSERT INTO logs (host,date,chain,interface_in, ip_src, name_src, ip_dest, name_dest, proto, port_src, port_dest) ";
            $sql_command.="VALUES ('$host','$date','$chain','$interface_in','$src_ip','$src_name','$dst_ip','$dst_name','$porto','$port_src','$port_dst')";
            $con=mysql_query($sql_command);
            if (!$con) {
               echo "SQL INSERT ERROR !!! \n";
               exit;
            };
         };
     };
  };
?>