<?php  
/////////////////////////////////////////////////////////////////////////////////////
// IPTable log analyzer
// Copyright (C) 2002 Gerald GARCIA
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Plac<B2>e - Suite 330, Boston, MA  02111-1307, USA.
//
// Contact author : gege@gege.org
/////////////////////////////////////////////////////////////////////////////////////

// $Id: elems.php,v 1.11 2002/12/16 20:19:42 gege Exp $


require_once("config.php");
require_once("modules/TopDomains.php");
require_once("modules/DatabaseStats.php");
require_once("modules/TopProto.php");
require_once("modules/TopPorts.php");
require_once("modules/TopHosts.php");
require_once("modules/PacketSelector.php");
require_once("utils/Context.php");

//require_once("utils/Misc.php");

if (debug) {
  $time_start = getmicrotime();
  $timings = array();
}

if (debug) { $local_time_start=getmicrotime(); }
$link = mysql_connect($db_host, $db_user, $db_password) or die ("Unable to connect to mysql");
mysql_select_db ($db_name);
if (debug) { $timings["MySQL connection"]=getmicrotime()-$local_time_start; }

if (count($ignored_ports) != 0) {
  $ignored_list="and port_dest not in (";
  $first=1;
  foreach(array_keys($ignored_ports) as $ignored_port) {
    
    if ($first) { 
      $ignored_list=$ignored_list.$ignored_port;
      $first=0;
    } else {
      $ignored_list=$ignored_list.",".$ignored_port;
    }
  }
  $ignored_list=$ignored_list.")";
}

if (debug) { $local_time_start=getmicrotime(); }

mysql_query("set @date_minus_day=NOW() - INTERVAL $date DAY") or handleDBError("Unable to execute $query");

if ($chain == "ALL") {
    $query = "create temporary table filtered_logs select * from logs where date > @date_minus_day $ignored_list";
} else {
    $query = "create temporary table filtered_logs select * from logs where chain='$chain' and  date > @date_minus_day $ignored_list";
}
mysql_query($query) or handleDBError("Unable to execute $query");

if (debug) { $timings["Temp table creation"]=getmicrotime()-$local_time_start; }

function pageHeader() {
  global $chain;
  global $first;
  global $number;
  global $url_base;
  global $debug;
  global $date;
  global $dateToString;
  global $ignored_ports;
  global $css_style;
  global $css_styles;

  if ($debug) { print_session(); }
   ?>
<html>
<head>
   <title>IPTables logs</title>   
   <meta content="text/html;charset=UTF-8" http-equiv="content-type">
   <link rel="stylesheet" type="text/css" href="themes/<?php print $css_styles[$css_style]; ?>/<?php print $css_styles[$css_style]; ?>.css" />

<script language="JavaScript">
  function add_sidebar()
    { if ((typeof window.sidebar == "object") && 
         (typeof window.sidebar.addPanel == "function"))
    { window.sidebar.addPanel ("IPTables","http://<?php print $GLOBALS["HTTP_HOST"].$url_base."sidebar/index.php"; ?>",""); } } 
</script>   

</head>
<body>

    <? include "themes/$css_styles[$css_style]/header.inc"; ?>


<!--<table width="100%" class="ToolBar"><tr><td>-->
<table class="ToolBar">
<tr class="ToolBar">
 <td class="ToolBarTD"><form method="link" action="<? print $url_base; ?>"><input type="image" src="images/home.gif"></form></td>
 <td class="ToolBarTD"><a href="not_implemented.php" class="TitleLink">R&nbsp;e&nbsp;p&nbsp;o&nbsp;r&nbsp;t&nbsp;s</a></td>
 <td class="ToolBarTD"><a href="not_implemented.php" class="TitleLink">A&nbsp;d&nbsp;m&nbsp;i&nbsp;n</a></td>
 <td class="ToolBarTD" width="100%">&nbsp;</td>
 <td class="ToolBarTD"><a href="not_implemented.php" class="TitleLink">H&nbsp;e&nbsp;l&nbsp;p&nbsp;</a></td>
</tr>
</table>
<!--</tr></td></table>-->

<br>
<br>

<table width="100%"><tr>
<td width="75%" valign='top'>

   <?php
}










function pageFooter() {
  global $link;
  global $chain;
  global $debug;
  global $date;
  global $dateToString;
  global $module_display;
  global $css_style;
  global $css_styles;
  if (debug) {
    global $time_start;
    global $timings;
  }
?>  
</td> <!-- end of first main columm -->
<td width="25%" valign='top'>

<table width="100%">
<tr><td>
<?php
    beginModule("Packet selection","PacketSelection");
  $packetSelector = new PacketSelector();
  $packetSelector->display();
  endModule("PacketSelection");
?>
</td></tr>
<tr><td>
<br>
<?php
    $name="DatabaseStats";
    if ($module_display[$name]) {
      beginModule("Database stats",$name);
      $databaseStats = new DatabaseStats($date);
      $databaseStats->display();
      endModule("Database stats");
    } else {
        $module_display_string="?";
	foreach (array_keys($module_display) as $module) {
	  if (!($module == $name)) {
	    $module_display_string=$module_display_string."_module_display[".$module."]=".$module_display[$module]."&";
	  }	  
	}	
	$module_display_string=$module_display_string."_module_display[".$name."]=1";
	print "<a class=\"AddButton\" href=\"$module_display_string\">Display Database Stats</a>";
    }
?>
</td></tr>
<tr><td>
<br>
<?php
    $name="TopHosts";
    if ($module_display[$name]) {
      beginModule("Top Hosts [$chain] [${dateToString[$date]}]",$name);
      $topHosts = new TopHosts();
      $topHosts->display();
      endModule("Top Hosts [$chain] [${dateToString[$date]}]");
    } else {
        $module_display_string="?";
	foreach (array_keys($module_display) as $module) {
	  if (!($module == $name)) {
	    $module_display_string=$module_display_string."_module_display[".$module."]=".$module_display[$module]."&";
	  }	  
	}	
	$module_display_string=$module_display_string."_module_display[".$name."]=1";
	print "<a class=\"AddButton\" href=\"$module_display_string\">Display Top Hosts</a>";
    }
    
?>
</td></tr>
<tr><td>
<br>
<?php
    $name="TopProto";
    if ($module_display[$name]) {
      beginModule("Top Proto [ALL] [${dateToString[$date]}]",$name);
      $topProto = new TopProto();
      $topProto->display();
      endModule("Top Proto [ALL] [${dateToString[$date]}]");
    } else {
        $module_display_string="?";
	foreach (array_keys($module_display) as $module) {
	  if (!($module == $name)) {
	    $module_display_string=$module_display_string."_module_display[".$module."]=".$module_display[$module]."&";
	  }	  
	}	
	$module_display_string=$module_display_string."_module_display[".$name."]=1";
	print "<a class=\"AddButton\" href=\"$module_display_string\">Display Top Proto</a>";
    }
?>
</td></tr>
<tr><td>
<br>
<?php
    $name="TopPorts";
    if ($module_display[$name]) {
      beginModule("Top Ports [${dateToString[$date]}]",$name);
      $topPorts = new TopPorts();
      $topPorts->display();
      endModule("Top Ports [${dateToString[$date]}]");
    } else {
        $module_display_string="?";
	foreach (array_keys($module_display) as $module) {
	  if (!($module == $name)) {
	    $module_display_string=$module_display_string."_module_display[".$module."]=".$module_display[$module]."&";
	  }	  
	}	
	$module_display_string=$module_display_string."_module_display[".$name."]=1";
	print "<a class=\"AddButton\" href=\"$module_display_string\">Display Top Ports</a>";
    }
?>
</td></tr>
<tr><td>
<br>
<?php
    $name="TopDomains";
    if ($module_display[$name]) {
      beginModule("Top Domains [$chain] [${dateToString[$date]}]",$name);
      $topDomains = new TopDomains();
      $topDomains->display();
      endModule("Top Domains [$chain] [${dateToString[$date]}]");
    } else {
        $module_display_string="?";
	foreach (array_keys($module_display) as $module) {
	  if (!($module == $name)) {
	    $module_display_string=$module_display_string."_module_display[".$module."]=".$module_display[$module]."&";
	  }	  
	}	
	$module_display_string=$module_display_string."_module_display[".$name."]=1";
	print "<a class=\"AddButton\" href=\"$module_display_string\">Display Top Domains</a>";
    }
?>
</td></tr>
</table>


</td>
</tr></table>

<form action="" method="post">
  Style : <select name="_css_style" onchange="this.form.submit()">
<?php
    foreach (array_keys($css_styles) as $style) {
      if ($style==$css_style) {	
	print "<option value=\"$style\" selected>$style</option>\n";
      } else {
	print "<option value=\"$style\">$style</option>\n";
      }
    }
?>
  </select>
</form>

<a href="javascript:add_sidebar();">Add the sidebar</a>

<?php if ($debug) { ?>
  <form action="" method="post">
    <input type="hidden" name="_close_session" value="1"/>
    <input type="submit" value="Destroy session">
  </form>


 
<?php 
     $time_end = getmicrotime();
  $time = $time_end - $time_start;
  
  echo "<!-- Processing time : $time -->\n";

  echo "<!--\n";
  foreach (array_keys ($timings) as $location) {
    echo "$location : ",$timings[$location]," s\n";
  }
  echo "-->\n";

     } 
?>

</body>
</html>
<?php


  mysql_close($link);
}

function beginModule($title,$name) {
  global $debug;
  global $timings;
  global $module_display;
  $timings[$title]=getmicrotime();

  $module_display_string="?";
  foreach (array_keys($module_display) as $module) {
    if (!($name == $module)) {
      $module_display_string=$module_display_string."_module_display[".$module."]=".$module_display[$module]."&";
    }
  }

  ?> 
  <table border='0' cellpadding='1' cellspacing='0' width='100%'>
    <tr class='ModuleTitle'><td>
        <table width='100%' cellpadding='0' cellspacing='0'>
          <tr bgcolor='#ffffff'><td>
             <table width='100%' cellpadding='2' cellspacing='0'>
               <tr class='ModuleTitle'><td><?php print $title; ?>&nbsp;<a href="<?php print $module_display_string."_module_display[".$name."]=0"; ?>" class="DelButton">[HIDE]</a></td></tr>
               <tr><td class="ModuleBody">
<?php
}

function endModule($title) {
  global $debug;
  global $timings;
  $timings[$title]=getmicrotime()-$timings[$title];
?>
               </td></tr>
             </table>
          </td></tr>
       </table>
    </td></tr>
  </table>
  <?php
}
?>