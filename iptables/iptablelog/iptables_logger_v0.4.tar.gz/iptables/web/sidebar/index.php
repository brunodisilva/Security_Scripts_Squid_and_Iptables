<?php
/////////////////////////////////////////////////////////////////////////////////////
// IPTable log analyzer
// Copyright (C) 2002 Gerald GARCIA
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Plac<B2>e - Suite 330, Boston, MA  02111-1307, USA.
//
// Contact author : gege@gege.org
/////////////////////////////////////////////////////////////////////////////////////

// $Id: index.php,v 1.2 2002/11/27 18:44:08 gege Exp $


require_once("../config.php");
require_once("../utils/Db.php");
require_once("../utils/Misc.php");

$link = mysql_connect($db_host, $db_user, $db_password) or die ("Unable to connect to mysql");
mysql_select_db ($db_name);

?>

<html>
<head>
   <link rel="stylesheet" type="text/css" href="../themes/sidebar.css" />
   <meta http-equiv="Refresh" content="300"/>
   <meta http-equiv="Pragma" content="no-cache"/>
<?php $now_string=date("D, M j Y G:i:s T"); ?>
   <meta http-equiv="Cache-Control" content="no-cache"/>
   <meta http-equiv="Expires" content="<?php print $now_string; ?>"/>
   <meta http-equiv="Date" content="<?php print $now_string; ?>"/>
</head>

<body>

<div class="title">IPTables logs</div>

<div class="content">
   <div class="module">
     <table>
      <tr class="databaseStats">
         <td>
<?php            
$query = "SELECT count(date) as nb_packets FROM logs";
$result = mysql_query ($query) or handleDBError("Unable to query log table");
$line = mysql_fetch_object($result);
print $line->nb_packets;
?> 
         </td>
	 <td>packets in database</td>
      </tr>
      <tr class="databaseStats">
	 <td>
<?php            
$query = "SELECT count(date) as nb_packets FROM logs where date > NOW() - INTERVAL 1 DAY";
$result = mysql_query ($query) or handleDBError("Unable to query log table");
$line = mysql_fetch_object($result);
print $line->nb_packets;
?> 
	 </td>
	 <td>packets today</td></tr>
     </table>
   </div>

   <br/>

   <div class="tabletitle">Last filtered packets :</div>
 
   <table class="filteredPacketsTable">

      <tr><td class="filteredPacketsTitle">Chain</td><td class="filteredPacketsTitle">Host</td><td class="filteredPacketsTitle">Port</td></tr>

<?php
   $query = "SELECT date,chain,interface_in,ip_src,proto,name_src,name_dest,port_dest,ip_dest FROM logs order by date desc limit 15";
   $result = mysql_query ($query) or handleDBError("Unable to query log table");

   while($line = mysql_fetch_object($result)) {
     $port_name=findPortNameFromNumber($line->port_dest);
     if (strlen($port_name)==0) {
       $port_name=$line->port_dest;
     }
     if ($line->name_src=="unknown") { $long_name=$line->ip_src; } else { $long_name=$line->name_src; }
     $name="";

     while (strpos($long_name,".")) {
       if (strlen($name)>0) {
	 $name=$name.".".substr($long_name,0,strpos($long_name,"."));
       } else {
	 $name=substr($long_name,0,strpos($long_name,"."));
       }
       $long_name=substr($long_name,strpos($long_name,".")+1);
       if ((strlen($name)-strrpos($name,">")) > 20) {
	 $name=$name."<br/>";
       }

     }
     $name=$name.".".$long_name;

     
?>
      <tr><td class="filteredPackets"><?php print $line->chain; ?></td>
          <td class="filteredPackets"><a href="../from_host.php?ip=<?php print $line->ip_src; ?>" target='_blank'><?php print $name; ?></a></td>
	  <td class="filteredPackets"><a href="../to_port.php?port=<?php print $line->port_dest; ?>" target='_blank'><?php print $port_name; ?></a></td></tr>

<?php } ?>
   </table>
   
   <br/>
   <div class="pagelink"><a href="../" target='_blank'>IPTables log page</a></div><br/>
   <div class="pagelink"><a href="">Refresh</a></div>

</div>

</body>
</html>