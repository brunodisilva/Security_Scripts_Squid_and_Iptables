<?php
/////////////////////////////////////////////////////////////////////////////////////
// IPTable log analyzer
// Copyright (C) 2002 Gerald GARCIA
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Plac<B2>e - Suite 330, Boston, MA  02111-1307, USA.
//
// Contact author : gege@gege.org
/////////////////////////////////////////////////////////////////////////////////////

// $Id: Cache.php,v 1.2 2002/11/27 18:44:08 gege Exp $

require_once("config.php");

Class Cache {
  
  var $cache_delay = 60;

  function put($module, $content) {
    global $cache_dir;    

    if (strlen($cache_dir)!=0) {

      $dir_name=$cache_dir."/".session_id();
      $file_name=$dir_name."/".$module;

      if (is_dir($cache_dir)!=true) {
	mkdir($cache_dir, 0700);
      }

      if (is_dir($dir_name)!=true) {
	mkdir($dir_name, 0700);
      }

      $fd = fopen ($file_name, "w");
      if ($fd) {
	fwrite($fd,"$content");
	fclose($fd);
      }
    }

  }
  

  function get($module) {
    
    global $cache_dir;

    if (strlen($cache_dir)!=0) {

      $file_name=$cache_dir."/".session_id()."/".$module;
      if (file_exists($file_name)) {
	$fd = fopen ($file_name, "r");  
	if ($fd != false) {
	  $filedate = filectime($file_name);
	  $age=time() - $filedate;
	  if ($age < $this->cache_delay) {
	    $out = fread ($fd, filesize ($file_name));
	    $age=time() - $filedate;
	    $out .= "<!-- Generated from cache file (file : $file_name - age : $age s) -->";
	  } else { $out=""; }
	  fclose($fd);
	  return $out;
	}
      }
    
      return "";
    }
  }

  function clearCache() {
    global $cache_dir;

    if (strlen($cache_dir)!=0) {
      
      $dir_name=$cache_dir."/".session_id();
      
      if (is_dir($dir_name)) {
	$handle = opendir($dir_name);
	while($filename = readdir($handle)) {
	  if ($filename != "." && $filename != "..") {
	    unlink($dir_name."/".$filename);
	  }
	} 
	closedir($handle);
	rmdir($dir_name);
      }
    }
  }

}

?>