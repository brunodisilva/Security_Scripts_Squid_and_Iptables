<?php
/////////////////////////////////////////////////////////////////////////////////////
// IPTable log analyzer
// Copyright (C) 2002 Gerald GARCIA
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Plac<B2>e - Suite 330, Boston, MA  02111-1307, USA.
//
// Contact author : gege@gege.org
/////////////////////////////////////////////////////////////////////////////////////

// $Id: Context.php,v 1.8 2002/11/27 18:44:08 gege Exp $

require_once("config.php");
require_once("utils/Cache.php");


session_set_cookie_params (60*60*24*30*12);


function session_var_init($var, $new_var, $control_var, $val,  $clear_cache=0, $null_value=0) {
  if (!isset($_SESSION[$var])) {
    $GLOBALS[$var] = $val;
    $_SESSION[$var] = $val;
  } else {
    $GLOBALS[$var] = $_SESSION[$var];
  }
  if (isset($_REQUEST[$control_var]) && isset($_REQUEST[$new_var])) { 
    $GLOBALS[$var] = $_REQUEST[$new_var];
    $_SESSION[$var] = $_REQUEST[$new_var];
    if ($clear_cache==1) {
      $cache = new Cache();
      $cache->clearCache();
      print "<!-- Cache cleared -->\n";
    }
  } else { 
    if (isset($_REQUEST[$control_var])) { 
      $GLOBALS[$var] = $null_value;  
      $_SESSION[$var] = $null_value;  
      if ($clear_cache==1) {
	$cache = new Cache();
	$cache->clearCache();
	print "<!-- Cache cleared -->\n";
      }
    }
  }
} 

function print_session() {

  global $number;
  global $first;
  global $chain;
  global $last_page;
  global $date;
  global $ignored_ports;
  global $module_display;

  echo "<!-- Session Infos \n";
  echo "session id      : ", session_id(), "\n";  
  echo "number          : ", $number, "\n";  
  echo "first           : ", $first, "\n";
  echo "chain           : ", $chain, "\n";
  echo "last_page       : ", $last_page, "\n";
  echo "date            : ", $date, "\n";
  echo "ignored_ports   : ", print_r(array_keys($ignored_ports)), "\n";
  echo "module_display  : ", print_r($module_display), "\n";
  echo "\n";
  echo "QUERY_STRING : ", getenv("QUERY_STRING"), "\n";
  echo "SCRIPT_URL   : ", getenv("SCRIPT_URL"), "\n";
  echo "-->\n";
  
}

session_start();

if (isset($_REQUEST["_close_session"])) {
  $cache = new Cache();
  $cache->clearCache();
  session_destroy(); 
  session_start();
}

session_var_init("number",
		 "_number",
		 "_number",
		 $default_number);

session_var_init("chain",
		 "_chain",
		 "_chain",
		 $default_chain,
		 1);

session_var_init("first",
		 "_first",
		 "_first",
		 0);

session_var_init("last_page",
		 "_last_page",
		 "_last_page",
		 "");

session_var_init("date",
		 "_date",
		 "_date",
		 $default_date,
		 1);

session_var_init("ignored_ports",
		 "_ignored_ports",
		 "_set_ignored_ports",
		 $default_ignored_ports, 
		 1,
		 array());

session_var_init("display_netfilter_destination",
		 "_display_netfilter_destination",
		 "_display_netfilter_destination",
		 $display_netfilter_destination_default,
		 0);

session_var_init("display_netfilter_interface",
		 "_display_netfilter_interface",
		 "_display_netfilter_interface",
		 $display_netfilter_interface_default,
		 0);

session_var_init("display_netfilter_host",
		 "_display_netfilter_host",
		 "_display_netfilter_host",
		 $display_netfilter_host_default,
		 0,
		 array());

session_var_init("module_display",
		 "_module_display",
		 "_module_display",
		 $module_display_default,
		 0);

session_var_init("css_style",
		 "_css_style",
		 "_css_style",
		 $css_style_default,
		 0);

if (isset($_chain)) { $first = 0; }

?>