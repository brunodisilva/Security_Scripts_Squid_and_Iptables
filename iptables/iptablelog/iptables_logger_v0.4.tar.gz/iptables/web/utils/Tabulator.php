<?php
/////////////////////////////////////////////////////////////////////////////////////
// IPTable log analyzer
// Copyright (C) 2002 Gerald GARCIA
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Plac<B2>e - Suite 330, Boston, MA  02111-1307, USA.
//
// Contact author : gege@gege.org
/////////////////////////////////////////////////////////////////////////////////////

// $Id: Tabulator.php,v 1.3 2002/12/16 20:19:42 gege Exp $

Class Tabulator {
  
  function Tabulator() {
    global $last_page;
    global $first;

//    if (strcmp(getenv("REQUEST_URI"), $last_page)!=0) {

//    is it usefull ?
//    $query_witout_first_param = ereg_replace( "&?_first=[0-9]+", "", getenv("REQUEST_URI"));
//    if (strcmp($query_witout_first_param, $last_page)!=0) {      
//      $last_page=$query_witout_first_param;
//      $first=0;
//    }

  }

  function display($nb_record) {
    global $number;
    global $first;

    $page=getenv("SCRIPT_URL");
    $page=$page."?";

    $query_string=getenv("QUERY_STRING");
    $query_string=ereg_replace( "&?_first=[0-9]+", "", $query_string );

    if (strlen($query_string)!=0) {
      $page=${page}.$query_string."&";
    }
?>



<table width="100%">
<tr>
<td class="NbRecords">Records <?php print $first; ?> to <?php if ($nb_record > $number) { print $first + $number; } else { print $nb_record; } ?> of <?php print $nb_record; ?></td>

<td>

<div align="right">

<?php if ($nb_record > $number) { ?>

<?php if ($first > 0) { ?>
<a href='<?php print $page; ?>_first=0' class="image"><img src="images/2leftarrow.gif"></a>
   <?php } else { ?>
   <img src="images/2leftarrowdis.gif">
 <?php } ?>

<?php if (($first - $number) >= 0) { ?>
<a href='<?php print $page; ?>_first=<?php print $first - $number; ?>' class="image"><img src="images/leftarrow.gif"></a>
   <?php } else { ?>
   <img src="images/leftarrowdis.gif">
 <?php } ?>



<?php if ($first!=$nb_record - $number) { ?>
<a href='<?php print $page; ?>_first=<?php print $first + $number; ?>' class="image"><img src="images/rightarrow.gif"></a>
<?php } else { ?>
 <img src="images/rightarrowdis.gif">
<?php } ?>


<?php if ($first!=$nb_record - $number) { ?>
 <a href='<?php print $page; ?>_first=<?php print $nb_record - $number; ?>' class="image"><img src="images/2rightarrow.gif"></a>
<?php } else { ?>
 <img src="images/2rightarrowdis.gif">
<?php } ?>


<?php } else { ?>
 <img src="images/2leftarrowdis.gif"><img src="images/leftarrowdis.gif"><img src="images/rightarrowdis.gif"><img src="images/2rightarrowdis.gif">
<?php } ?>

</div>

</td>
</tr>
</table>

<?php    
  }
}

?>