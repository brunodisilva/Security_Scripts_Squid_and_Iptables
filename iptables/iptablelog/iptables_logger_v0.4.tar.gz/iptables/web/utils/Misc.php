<?php

/////////////////////////////////////////////////////////////////////////////////////
// IPTable log analyzer
// Copyright (C) 2002 Gerald GARCIA
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Plac<B2>e - Suite 330, Boston, MA  02111-1307, USA.
//
// Contact author : gege@gege.org
/////////////////////////////////////////////////////////////////////////////////////

// $Id: Misc.php,v 1.3 2002/11/27 18:44:08 gege Exp $

$dateToString[1]="1 day";
$dateToString[2]="2 days";
$dateToString[7]="1 week";
$dateToString[14]="2 weeks";
$dateToString[31]="1 month";
$dateToString[10000]="any";

$port_names = array();

function findPortNameFromNumber($nb) {
  global $port_names;
  
  if (!isset($port_names[$nb])) {
    $query = "SELECT name FROM ports where port=$nb limit 1";
    $result = mysql_query ($query) or handleDBError("Unable to query log table");
    if ($port_desc=mysql_fetch_object($result)) {
      $port_names[$nb] = $port_desc->name;
    } else {
      $port_names[$nb] = "";
    }
  }

  return $port_names[$nb];
}


function getmicrotime()
{
  list($usec, $sec) = explode(" ",microtime());
   return ((float)$usec + (float)$sec);
}

?>