<?php
/////////////////////////////////////////////////////////////////////////////////////
// IPTable log analyzer
// Copyright (C) 2002 Gerald GARCIA
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Plac<B2>e - Suite 330, Boston, MA  02111-1307, USA.
//
// Contact author : gege@gege.org
/////////////////////////////////////////////////////////////////////////////////////

// $Id: from_domain.php,v 1.7 2002/11/27 18:44:08 gege Exp $


require_once("elems.php");
require_once("utils/Context.php");
require_once("utils/Tabulator.php");

$tabulator = new Tabulator();

pageHeader();

$domain=$_REQUEST['domain'];

?>


<b>Packets filtered from domain <?php print "$domain"; ?> for chain <?php print $chain; ?> younger than <?php print $dateToString[$date]; ?> :</b><br><br>
Whois for <?php print "<a href=whois.php?host=$domain>"; ?><?php print "$domain"; ?></a>
<br><br>


<table cellspacing="0" cellpadding="0" width="100%"><tr bgcolor="#DDDDDD"><td>
<table cellspacing="1" cellpadding="2" width="100%">
<tr><td><center>Chain</center></td><td><center>Date</center></td><td><center>Host</center></td><td><center>Interf.</center></td><td><center>Proto</center></td><td><center>IP</center></td><td><center>Dest. port</center></td></tr>

<?php
$query = "SELECT chain,date,host,interface_in,proto,ip_src, name_src, port_dest FROM filtered_logs where SUBSTRING_INDEX(name_src,'.',-2)='$domain' order by date desc limit $first,$number";
$result = mysql_query ($query) or die ("Unable to query log table");

if ( mysql_num_rows($result) == 0 ) {
  print "<tr bgcolor=\"#FFFFFF\"><td colspan=7>No packets match the request</td></tr>";
} else {


while($line = mysql_fetch_object($result)){
   print "<tr bgcolor=\"#FFFFFF\">";
   print "<td>$line->chain</td>"; 
   print "<td>$line->date</td>"; 
   print "<td>$line->host</td>";
   print "<td>$line->interface_in</td>"; 
   print "<td>$line->proto</td>"; 
   print "<td><a href=\"from_host.php?ip=$line->ip_src\">";  
   if ($line->name_src=="unknown") { print "$line->ip_src"; } else { print "$line->name_src"; }
   print "</a></td>";
   if (strcmp($line->proto,"ICMP")!=0) {
     print "<td><a href=\"to_port.php?port=$line->port_dest\">$line->port_dest ";
     $query2 = "SELECT name FROM ports where port=$line->port_dest limit 1";
     $result2 = mysql_query ($query2) or die ("Unable to query ports table");
     if ($port_desc=mysql_fetch_object($result2)) {
       print "($port_desc->name)";
     }
     print "</a></td>";
   } else {
     print "<td><center>-</center></td>";
   }


   print "</tr>";
}

} // nb packet != 0
?>

</table>
</td></tr></table>

<?php
$query = "SELECT count(date) FROM filtered_logs where SUBSTRING_INDEX(name_src,'.',-2)='$domain'";
$result = mysql_query ($query) or handleDBError("Unable to query log table");
$nb=mysql_fetch_array($result);
?>

<?php
$tabulator->display($nb[0]); 
?>

<?php pageFooter(); ?>