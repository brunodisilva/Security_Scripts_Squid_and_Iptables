<?php
/////////////////////////////////////////////////////////////////////////////////////
// IPTable log analyzer
// Copyright (C) 2002 Gerald GARCIA
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Plac<B2>e - Suite 330, Boston, MA  02111-1307, USA.
//
// Contact author : gege@gege.org
/////////////////////////////////////////////////////////////////////////////////////

// $Id: set_filter.php,v 1.2 2002/11/27 18:44:08 gege Exp $


require_once("elems.php");
require_once("utils/Context.php");


pageHeader();

?>

<b>Select the ports that shall be filtered</b><br><br>


<form action="set_filter.php" method="post">

<input type="submit" value="Update filter"/><br><br>

<input type="hidden" name="_set_ignored_ports" value="1"/>

<table cellspacing="0" cellpadding="0" width="100%"><tr bgcolor="#DDDDDD"><td>
<table cellspacing="1" cellpadding="2" width="100%">
<tr><td><center></center></td><td><center>Port</center></td><td><center>Port Name</center></td><td>&nbsp;</td>
    <td><center></center></td><td><center>Port</center></td><td><center>Port Name</center></td></tr>

<?php
$query = "SELECT distinct port_dest from logs where port_dest <> 0 order by port_dest";
$result = mysql_query ($query) or handleDBError("Unable to query log table");

$col=1;

while($line = mysql_fetch_object($result)){

  if ($col==1) {
    print "<tr bgcolor=\"#FFFFFF\">";
  }
  
  if (isset($ignored_ports[$line->port_dest])) {
    print "<td><center><input type='checkbox' name='_ignored_ports[$line->port_dest]' checked/></center></td>"; 
  } else {
    print "<td><center><input type='checkbox' name='_ignored_ports[$line->port_dest]'/></center></td>"; 
  }

  print "<td>$line->port_dest</td>"; 
  
  print "<td>";
  $query2 = "SELECT name FROM ports where port=$line->port_dest limit 1";
  $result2 = mysql_query ($query2) or handleDBError("Unable to query ports table");
  if ($port_desc=mysql_fetch_object($result2)) {
    print "$port_desc->name";
  }
  print "</td>";

  if ($col==2) {
    print "</tr>";
    $col=1;
  } else {
    print "<td>&nbsp;</td>";
    $col=2;
  }
}

?>

</table>
</td></tr></table>

<br><br><input type="submit" value="Update filter"/>

</form>

<?php pageFooter(); ?>