<?php
/////////////////////////////////////////////////////////////////////////////////////
// IPTable log analyzer
// Copyright (C) 2002 Gerald GARCIA
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Plac<B2>e - Suite 330, Boston, MA  02111-1307, USA.
//
// Contact author : gege@gege.org
/////////////////////////////////////////////////////////////////////////////////////

// $Id: to_host.php,v 1.3 2002/11/27 18:44:08 gege Exp $


require_once("elems.php");
require_once("utils/Context.php");
require_once("utils/Tabulator.php");
require_once("utils/Misc.php");


$tabulator = new Tabulator();

pageHeader();

$ip=$_REQUEST['ip'];

$query = "SELECT name_src FROM logs where ip_dest='$ip' limit 1";
$result = mysql_query ($query) or die ("Unable to query log table");
if ($res=mysql_fetch_object($result)) {
  $host_name=$res->name_src;
}
?>

<b>Filtered packets to <?php print "$host_name ($ip)" ; ?> for chain <?php print $chain; ?> younger than <?php print $dateToString[$date]; ?> :</b><br><br>
Whois for <?php print "<a href=whois.php?host=$ip>"; ?><?php print "$ip"; ?></a>
<br><br>


<table cellspacing="0" cellpadding="0" width="100%"><tr bgcolor="#DDDDDD"><td>
<table cellspacing="1" cellpadding="2" width="100%">
<tr><td><center>Chain</center></td><td><center>Date</center></td>
<?php if ($display_netfilter_host) { ?><td><center>Host&nbsp;<a href="?_display_netfilter_host=0&ip=<?php print $ip; ?>" class="DelButton">[HIDE]</a></center></td><?php } ?>
<?php if ($display_netfilter_interface) { ?><td><center>Interf.&nbsp;<a href="?_display_netfilter_interface=0&ip=<?php print $ip; ?>" class="DelButton">[HIDE]</a></center></td><?php } ?>
<td><center>Proto</center></td>
<td><center>Dest. port</center></td>
<td><center>From. IP</center></td>
</tr>

<?php
$query = "SELECT chain,date,host,interface_in,proto,port_dest,name_src,ip_src FROM filtered_logs where ip_dest='$ip' order by date desc limit $first,$number";
$result = mysql_query ($query) or die ("Unable to query log table");

if ( mysql_num_rows($result) == 0 ) {
  print "<tr bgcolor=\"#FFFFFF\"><td colspan=6>No packets match the request</td></tr>";
} else {

while($line = mysql_fetch_object($result)){
   print "<tr bgcolor=\"#FFFFFF\">";
   print "<td>$line->chain</td>"; 
   print "<td>$line->date</td>"; 
   if ($display_netfilter_host) { print "<td>$line->host</td>"; }
   if ($display_netfilter_interface) { print "<td>$line->interface_in</td>"; }
   print "<td>$line->proto</td>"; 
 
   if (strcmp($line->proto,"ICMP")!=0) {
     print "<td><a href=\"to_port.php?port=$line->port_dest\">$line->port_dest ";
     $query2 = "SELECT name FROM ports where port=$line->port_dest limit 1";
     $result2 = mysql_query ($query2) or die ("Unable to query ports table");
     if ($port_desc=mysql_fetch_object($result2)) {
       print "($port_desc->name)";
     }
     print "</a></td>";
   } else {
     print "<td><center>-</center></td>";
   }

   print "<td><a href=\"from_host.php?ip=$line->ip_src\">";
   if ($line->name_src=="unknown") { print "$line->ip_src"; } else { print "$line->name_src"; }
   print "</a></td>";
   


   print "</tr>";   
   
}
?>

    <?php } // nb packet != 0 ?>

</table>
</td></tr></table>

<?php
$query = "SELECT count(date) FROM filtered_logs where ip_src='$ip'";
$result = mysql_query ($query) or handleDBError("Unable to query log table");
$nb=mysql_fetch_array($result);
?>

<?php
$tabulator->display($nb[0]); 
?>

<?php if (!$display_netfilter_host) { ?><a href="?_display_netfilter_host=1&ip=<?php print $ip; ?>" class="AddButton">Show Host</a><br> <?php } ?>
<?php if (!$display_netfilter_interface) { ?><a href="?_display_netfilter_interface=1&ip=<?php print $ip; ?>" class="AddButton">Show Interface</a><br> <?php } ?>

<?php pageFooter(); ?>