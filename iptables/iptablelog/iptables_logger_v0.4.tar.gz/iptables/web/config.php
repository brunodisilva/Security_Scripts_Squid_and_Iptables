<?php

/////////////////////////////////////////////////////////////////////////////////////
// IPTable log analyzer
// Copyright (C) 2002 Gerald GARCIA
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Plac<B2>e - Suite 330, Boston, MA  02111-1307, USA.
//
// Contact author : gege@gege.org
/////////////////////////////////////////////////////////////////////////////////////

// $Id: config.php,v 1.12 2002/12/16 20:35:53 gege Exp $

# Host of the MySQL database
$db_host="localhost";

# User of the MySQL database
$db_user="iptables_user";

# Password of the MySQL database
$db_password="xxxxxx";

# Name of the database
$db_name="iptables";

# URL Path to your installation
$url_base="/newiptables/";

#debug mode
$debug=1;

#The default number of record displayed
$default_number=20;

#The default chain displayed
$default_chain="ALL";

#The default date for packets (10000 means any)
$default_date=10000;

#The default ignored ports
$default_ignored_ports= array();

#############################
# CACHE CONFIGURATION
#############################

#The cache directory (set it to "" means no cache)
$cache_dir="/tmp/iptables";

#The cache delay (items younger than $cache_delay in second will not be regenerated)
$cache_delay = 120;

#############################
# COLUMNS TO BE DISPLAYED
#############################

#Display netfilter host in listings (0->no - 1->yes)
$display_netfilter_host_default=1;

#Display netfilter interface in listings (0->no - 1->yes)
$display_netfilter_interface_default=1;

#Display netfilter destination in listings (0->no - 1->yes)
$display_netfilter_destination_default=1;

#############################
# MODULES TO BE DISPLAYED
#############################

#Modules visibility (0->no - 1->yes)
$module_display_default["TopHosts"]=1;
$module_display_default["TopProto"]=1;
$module_display_default["TopPorts"]=1;
$module_display_default["TopDomains"]=1;
$module_display_default["DatabaseStats"]=1;


#############################
# CSS STYLES
#############################
$css_style_default="blue";

$css_styles["green"]="iptables";
$css_styles["blue"]="iptables_blue";

?>
