<?php
/////////////////////////////////////////////////////////////////////////////////////
// IPTable log analyzer
// Copyright (C) 2002 Gerald GARCIA
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Plac<B2>e - Suite 330, Boston, MA  02111-1307, USA.
//
// Contact author : gege@gege.org
/////////////////////////////////////////////////////////////////////////////////////

// $Id: index.php,v 1.11 2002/11/27 18:44:08 gege Exp $


require_once("utils/Context.php");
require_once("utils/Tabulator.php");
//require_once("utils/Misc.php");
require_once("elems.php");
?>

<?php 


  $tabulator = new Tabulator();

  pageHeader(); 
?>


<b>Last packets filtred by chain <?php print $chain; ?> younger than <?php print $dateToString[$date]; ?> : </b><br><br>



<table cellspacing="1" cellpadding="1" width="100%">
  <tr bgcolor="#DDDDDD"><td>
<table cellspacing="1" cellpadding="2" width="100%">
<tr>
  <td><center>Chain</center></td>
<td><center>Date</center></td>
<?php if ($display_netfilter_host) { ?><td><center>Host&nbsp;<a href="?_display_netfilter_host=0" class="DelButton">[HIDE]</a></center></td><?php } ?>
<?php if ($display_netfilter_interface) { ?><td><center>Interf.&nbsp;<a href="?_display_netfilter_interface=0" class="DelButton">[HIDE]</a></center></td><?php } ?>
<td><center>Proto.</center></td><td><center>Src IP</center></td>
<?php if ($display_netfilter_destination) { ?><td><center>Dest IP&nbsp;<a href="?_display_netfilter_destination=0" class="DelButton">[HIDE]</a></center></td><?php } ?>
<td><center>Dest. port</center></td></tr>

<?php
  $query = "SELECT date,host,chain,interface_in,ip_src,proto,name_src,port_dest,name_dest,ip_dest FROM filtered_logs order by date desc limit $first,$number";

$result = mysql_query ($query) or handleDBError("Unable to query log table");

  while($line = mysql_fetch_object($result)){
    print "<tr bgcolor=\"#FFFFFF\">";

    print "<td><center>$line->chain</center></td>";
    print "<td>$line->date</td>";
    if ($display_netfilter_host) { print "<td>$line->host</td>"; }
    if ($display_netfilter_interface) { print "<td>$line->interface_in</td>"; }
    print "<td>$line->proto</td>";
    print "<td><a href=\"from_host.php?ip=$line->ip_src\">";
    if ($line->name_src=="unknown") { print "$line->ip_src"; } else { print "$line->name_src"; }
    print "</a></td>";

    if ($display_netfilter_destination) {
      print "<td><a href=\"to_host.php?ip=$line->ip_dest\">";
      if ($line->name_dest=="unknown") { print "$line->ip_dest"; } else { print "$line->name_dest"; }
      print "</a></td>";
    }

  
    if (strcmp($line->proto,"ICMP")!=0) {
      print "<td><a href=\"to_port.php?port=$line->port_dest\">$line->port_dest";
      $port_name=findPortNameFromNumber($line->port_dest);
      if (strlen($port_name)!=0) {
	print "($port_name)";
      }
      print "</a></td>";
    } else {
      print "<td><center>-</center></td>";
    }
    
    print "</tr>\n";
  }

?>
</td></tr></table>
</td></tr></table>


<?php
$query = "SELECT count(date) FROM filtered_logs";
$result = mysql_query ($query) or handleDBError("Unable to query log table");
$nb=mysql_fetch_array($result);
?>

<?php

$tabulator->display($nb[0]); 
?>

<?php if (!$display_netfilter_host) { ?><a href="?_display_netfilter_host=1" class="AddButton">Show Host</a><br> <?php } ?>
<?php if (!$display_netfilter_interface) { ?><a href="?_display_netfilter_interface=1" class="AddButton">Show Interface</a><br> <?php } ?>
<?php if (!$display_netfilter_destination) { ?><a href="?_display_netfilter_destination=1" class="AddButton">Show Destination IP</a><?php } ?>


<?php pageFooter(); ?>

