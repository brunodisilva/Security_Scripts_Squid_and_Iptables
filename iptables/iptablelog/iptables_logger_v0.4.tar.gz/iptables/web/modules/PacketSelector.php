<?php
/////////////////////////////////////////////////////////////////////////////////////
// IPTable log analyzer
// Copyright (C) 2002 Gerald GARCIA
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Plac<B2>e - Suite 330, Boston, MA  02111-1307, USA.
//
// Contact author : gege@gege.org
/////////////////////////////////////////////////////////////////////////////////////

// $Id: PacketSelector.php,v 1.1 2002/12/16 20:19:42 gege Exp $

require_once("utils/Misc.php");

Class PacketSelector {

  function PacketSelector() {
  }

  function display() {
    global $dateToString;
    global $ignored_ports;
    global $number;
    global $date;
    global $chain;
    

    $out=$out."<form action=\"\" method=\"post\">"."\n";
    $out=$out."<table width=\"100%\" class=\"PacketSelector\">"."\n";
   
    // current chain

    $out=$out."<tr class=\"PacketSelector\">"."\n";

    $out=$out."<td>Current chain : </td>"."\n";

    $out=$out."<td><select name=\"_chain\" onchange=\"this.form.submit()\">"."\n";
    
    if ($chain=="ALL") { $out=$out."<option selected>ALL</option>"; } else { $out=$out."<option>ALL</option>"; }
    
    $query = "SELECT distinct chain FROM logs";
    $result = mysql_query ($query) or die ("Unable to query log table");
    while($line = mysql_fetch_object($result)){
      if ($chain==$line->chain) {
	$out=$out."<option selected>$line->chain</option>"."\n";
      } else {
	$out=$out."<option>$line->chain</option>"."\n";
      }
    }
    
    $out=$out."</select><td>"."\n";

    $out=$out."</tr>"."\n";    

    // current nb of packets

    $out=$out."<tr class=\"PacketSelector\">"."\n";

    $out=$out."<td>Nb packets / page : </td>"."\n";

    $out=$out."<td><select name=\"_number\" onchange=\"this.form.submit()\">"."\n";

    $out=$out."<option value=\"10\" ";
    if ($number==10) { $out=$out."selected"; }
    $out=$out.">10</option>"."\n";

    $out=$out."<option value=\"20\" ";
    if ($number==20) { $out=$out."selected"; }
    $out=$out.">20</option>"."\n";

    $out=$out."<option value=\"50\" ";
    if ($number==50) { $out=$out."selected"; }
    $out=$out.">50</option>"."\n";

    $out=$out."<option value=\"100\" ";
    if ($number==100) { $out=$out."selected"; }
    $out=$out.">100</option>"."\n";

    $out=$out."</select></td></tr>"."\n";

    // packet date

    $out=$out."<tr class=\"PacketSelector\">"."\n";

    $out=$out."<td>Packets date : </td>"."\n";
    
    $out=$out."<td><select name=\"_date\" onchange=\"this.form.submit()\">"."\n";

    $out=$out."<option value=\"1\" ";
    if ($date==1) { $out=$out."selected"; }
    $out=$out.">\n";
    $out=$out.$dateToString[1];
    $out=$out."</option>"."\n";

    $out=$out."<option value=\"2\" ";
    if ($date==2) { $out=$out."selected"; }
    $out=$out.">\n";
    $out=$out.$dateToString[2];
    $out=$out."</option>"."\n";

    $out=$out."<option value=\"7\" ";
    if ($date==7) { $out=$out."selected"; }
    $out=$out.">\n";
    $out=$out.$dateToString[7];
    $out=$out."</option>"."\n";

    $out=$out."<option value=\"14\" ";
    if ($date==14) { $out=$out."selected"; }
    $out=$out.">\n";
    $out=$out.$dateToString[14];
    $out=$out."</option>"."\n";

    $out=$out."<option value=\"31\" ";
    if ($date==31) { $out=$out."selected"; }
    $out=$out.">\n";
    $out=$out.$dateToString[31];
    $out=$out."</option>"."\n";

    $out=$out."<option value=\"10000\" ";
    if ($date==10000) { $out=$out."selected"; }
    $out=$out.">\n";
    $out=$out.$dateToString[10000];
    $out=$out."</option>"."\n";
    
    $out=$out."</select></td></tr>"."\n";

    // packet filter
    $out=$out."<tr class=\"PacketSelector\">";
    if (count($ignored_ports)>0) {
      $out=$out."<td colspan=\"2\"><a class=\"TitleLink\" href=\"set_filter.php\">Some packets are filtered</a></td>"."\n"; 
    }  else { 
      $out=$out."<td colspan=\"2\"><a class=\"TitleLink\" href=\"set_filter.php\">Packet filter</a></td>"."\n"; 
    }
    $out=$out."</tr>";

    $out=$out."</table>"."\n";
    $out=$out."</form>"."\n";

    print $out;
  }

  function generate() {
  }
}

?>