#!/usr/bin/perl -w
#
# squint.pl  --  Quick and DIRTY squid log analysis
#
# Copyright (c) 2001-2002 Andrew McGill and Leading Edge Business Solutions
# (South Africa).  This software may be redistributed and/or modified only
# under the terms of the GNU General Public Licence, version 2, as published by
# the Free Software Foundation, and contained in the file COPYING. 
# 
# All other rights are reserved, and no warranty is implied.  Despite any
# appearance to the contrary, this software is not fit for ANY purpose you may
# conceive, and should not be used on your system under any circumstances.
# 
# This program reads a squid log from stdin and prints the volume of traffic
# url's and time on-line for each person / ip address.

use English;
no warnings qw{uninitialized};
use POSIX qw(strftime);

$revision = '$Id: squint.pl,v 1.23 2004/06/14 14:47:48 andrewm Exp $';
$bodyattr = 'bgcolor=white text=#000000 link=#0000C0 vlink=#0000C0';
$cellheadcolour = 'bgcolor=#DDDDDD';
$startprofile = time();
$usedlinecount=0;
$showall = 0;
$onlyip = 0;   # we should only find IP addresses in the log (1=yes, 0=no)

sub usage()
{
	die "Usage: $0 [options] output-dir [start-time] [end-time] [userfile]\n" .
	"\n".
	"Options:\n".
	"  --anon 5    Anonymise results - 5 user names\n".
	"  --nodns     Sanity check that log file contains IP's only for log_fqdn off\n".
	"  output-dir  Directory for generated HTML (created if necessary)\n".
	"  start-time  Report start time in seconds-since-1970 format or 0\n".
	"  end-time    Report end time in seconds-since-1970 format or 0\n".
	"  userfile    Map IP address or logins to full names, and limit scope of report\n".
	"  --showall   Show all users/IP's, not just those in the userfile\n".
	"\n".
	"squint reads squid format log lines from standard input and writes\n".
	"a browseable usage report to the named directory.\n".
	"\n";
}

while ($ARGV[0] =~ m/^(-.*)/) {
	$option = $1;
	# Anonymise results for web display?
	if ($option eq "--anon") {
		shift @ARGV;
		$useanonnames = $ARGV[0] || usage();
		# Some names to use when anonymising entries
		open NAMES,"< fakenames";
		@anonavail = <NAMES>;
		close NAMES;
		foreach $item (@anonavail) {
			chomp $item;
		}
	}
	elsif ($option eq "--showall") {
		$showall = 1;
	}
	elsif ($option eq "--nodns") {
		$nodns = 1;
	}
	else {
		die "Unrecognised option $option\n";
	}
	shift @ARGV;
}

$hostname = $ENV{HOSTNAME};
if ($useanonnames) {
	$hostname = 'squid.example.com';
	# $revision = 'squint.pl';
}
$chdir  = shift @ARGV || usage();
$timefrom = shift @ARGV || 0;
$timeto  = shift @ARGV || 0;
if (($userlistfilename  = shift @ARGV)) {
	open USERLIST, "<$userlistfilename" || die "$userlistfilename: $!\n";
	while (<USERLIST>) {
		# User list is either names, or name <space> description
		chomp;
		s/(^\s+|\s+$)//g;
		if ( m/^\s*#/ ) { next; }
		if ( m/^\s*(\S+)\s+(\S.*)/ ) {
			$userlist{lc($1)}=$2;
		}
		elsif ( m/^\s*(\S+)/ ) {
			$userlist{lc($1)}=$1;
		}
	}
	close USERLIST;
	$useuserlist = 1;
}
else {
	$useuserlist = 0;
}
# activesites{$user}{$site} = $lastvisited;
# Determine the period - if we know it
if ($timefrom) {
	$timefromascii = strftime ("%a %d %b %Y", localtime($timefrom));
	$timetoascii = strftime ("%a %d %b %Y", localtime($timeto-1));
	$reportperiod = "$timefromascii to $timetoascii";
}
else {
	$reportperiod = "";
}


$timezero = `date +\%s -d '2 January 1972'`; # hacky FIXME to get timezone

# Make a directory to put our stuff ...
if (! -d $chdir) { mkdir $chdir,0755 or die "mkdir $chdir: $!"; }
chdir $chdir or die "can't change directory to $chdir: $!";
open (INDEX,"> index.html")  or die "can't write to index.html: $!";

# Seconds that must pass before an on-line session is considered terminated
$onlinetimeout = 5*60;	# session timeout in seconds
$listlimit = 100;	# how long the output lists can get

while (<STDIN>) {
	$linecount++;
	@line = split / +/;

	# 0=date 1=transfer-msec? 2=ipaddr 3=status/code 4=size 5=operation
	# 6=url 7=user 8=method/connected-to... 9=content-type
	$time = $line[0];
	$time =~ s/\..*//; # discard milliseconds

	# FIXME we use the the ending time, and discard the cache transfer
	# time, since it is significantly more difficult to account
	# for times a sequence of times which are not in the order they occurred.
	# This bug is particulary noticeable for https connections, where the
	# connections are usually sustained for a while, and not repeated.
	# The one exception to this is where for the first transfer of a
	# session.
	if ($timefrom && $time < $timefrom || ( $timeto && $time > $timeto ) ) {
		next;
	}

	# Get and normalise user
	$user = lc($line[7]);
	$line[3] =~ m/\b(NONE|TCP_DENIED)\b/ and next;	# exclude failed whatevers
	if ( $user eq "-" ) {
		$user = $line[2];
		if ($nodns) {
			$user =~ m/^[\d.]+$/ or next;	# only valid ip address things, or reject the record
		}
	}

	# If we are doing a user list, then insist that the user be in the list
	# unless the --showall option was on the command line
	if ($useuserlist) {
		if ($temp = $userlist{$user}) {
			$user = $temp;
		}
		elsif (! $showall) {
			next;   # He's not in the list
		}
	}

	$transferseconds = ($line[1]+500)/1000;
	# track usage patterns - time of day and day of week:
	$hour = int(($time-$timezero) / 3600) % 24;
	# FIXME: use >1h periods -- 0-3,4-7,7,...14,15,16,17-19,19-24
	$day  = int(($time-$timezero) / 86400 ) * 86400 + $timezero; # which day was this on ...
	# Report 4
	if ($daymin==0 || $day < $daymin ) { $daymin = $day; }
	if ($day != $lastday && $lastday) {
		if ($day > $daymax ) { $daymax = $day; }
		writeusersitereports($lastday);
		undef %usersite;
	}
	$lastday=$day;


	# Get site name from URL:
	if ( $line[6] =~ m{[^:]+://([^:@]+(:[^@]+)?\@)?([^:/]+)(:\d+)?/} )  {
		$url = $line[6];
		$site = $3; # FIXME we should not silently discard protocol and port
	}
	elsif ( $line[5] eq 'CONNECT' ) { # CONNECT URL's are site name and port only
		# FIXME: we should probably count this as one `page' or so ...
		$site = $line[6];
		$url = "https://$site/";  # we're guessing
		$site =~ s/:\d*//; # Strip :443
		# FIXME: this should probably happen later (e.g. below)
		$userpages{$user}++;
		$pagesviewed{$user}{$day}{$site}++;
	}
	else {
		# print STDOUT "no match: $line[6]\n";
		next;   # Strange -no site name in url...
	}
	$contenttype = $line[9];
	$size = $line[4];
	if ($size == 0) { next ; }
	# count data transferred
	$usersize{$user} += $size;
	$dayusersize{$day}{$user} += $size;
	# guesstimate time on-line
	$last = $lasttime{$user};
	$seconds = $time - $last;
	if ( (! $last) || $seconds < 0 || $seconds > $onlinetimeout) {
		$seconds = $transferseconds;  # New session starts with zero
		if ($thissession{$user} > $maxsession{$user} ) {
			$maxsession{$user} = $thissession{$user};
			$maxsessiondate{$user} = $lasttime{$user};
		}
		$thissession{$user} = $seconds;
	}
	$thissession{$user} += $seconds;
	$userduration{$user} += $seconds;
	$hourlyseconds{$user}[$hour] += $seconds;
	$dailyseconds{$user}{$day}[$hour] += $seconds ;
	$lasttime{$user} = $time;

# Report 4: For each user, a list of visits to web sites, sorted by starting
# time -- time, site, duration, pages viewed
#
# Algorithm: A file for each user, consisting of time, site, duration, pages viewed
# Sort file by time.  Reset each day and emit user files

	# FIXME - this structure is sufficient for reporting one site per
	# day, and no more.
	#
	# Report 4 ... unfinished

	# $currentsite = \$usersite{$user}{$site}; # this might work ...
	$last  = \$usersite{$user}{$site}{"last"};
	$start = \$usersite{$user}{$site}{"start"};
	$usersite{$user}{$site}{"size"} += $size;
	$usersite{$user}{$site}{"hits"} ++;
	if (! $$start) {
		$$start = $time-$transferseconds;
		if ($$start < $day) { $$start = $day; } # ugly fixme hack
		$usersite{$user}{$site}{"time"} += $transferseconds;
		$usersite{$user}{$site}{"url"} = $url;
	}
	elsif ( $time - $$last < $onlinetimeout && $time > $$last ) {
		$usersite{$user}{$site}{"time"} += ( $time - $$last );
		if ($time-$transferseconds < $$start) {
			# take first URL (even if not first completed)
			$usersite{$user}{$site}{"url"} = $url;
		}
	}
	else {
		$usersite{$user}{$site}{"time"} += $transferseconds;
	}
	$$last = $time;

	# Report 3: Count the number of pages viewed that day
	if ($contenttype =~ m'text/html'i) {
		$pagesviewed{$user}{$day}{$site}++;
		$userpages{$user}++;
		$usersite{$user}{$site}{"pages"} ++;
	}
	$usedlinecount++;
}
# Write reports for each day, and then discard the information
# for that day
writeusersitereports($lastday);
undef %usersite;

## User web counts and sizes, sorted by user name
#foreach $user (sort keys %usersize) {
#	print INDEX "$user $usersize{$user}\n";
#}

sub fileheader()
{
	return "<p align=center>
	<A href=$basename-m$ext>Top addresses</A> |
	<A href=$basedom-m$ext>Top domains</A> |
	<A href=$messagelog>Message log</A>
	</p>
	";
}

# Print a header
sub htmlheader($$)
{
	my $headline = shift;
	my $subhead = shift;
	my $lang=$ENV{"LANG"};
	$lang =~ s/.*\.//;
	if ($lang) { $lang = "<meta http-equiv charset=$lang>\n"; }

	return '<meta name="robots" content="noindex,nofollow">' ."
$lang<HTML>
<HEAD>
<TITLE>$headline</TITLE>
</HEAD>
<BODY $bodyattr>$subhead
<H1>$headline</H1>
";
}

sub htmlfooter()
{
	return "<HR><FONT size=-4>Generated by <a href=http://www.ledge.co.za/software/squint/>squint</a> at ".
	localtime()." by $hostname [$usedlinecount of $linecount records in ".
	secstoms(time-$startprofile)."]<br>$revision</FONT></BODY></HTML>\n";
}

# Return an anonymous identity for the name
sub getanonname($)
{
	my $user = shift ;
	if (!$useanonnames) {
		return $user;
	}
	if ($anonregister{$user}) {
		return $anonregister{$user};
	}
	my $pseudonym = shift @anonavail;
	$anonregister{$user} = $pseudonym;
	return $pseudonym;
}

# Write a report for the day for all users
sub writeusersitereports($)
{
	my $day = shift;
	my $site, $user, $currentsort;
	my $stringday = strftime ("%a %d %b %Y", localtime($day));
	my %sortorder= (
		"start" => "",
		"site" => "-w",
		"time" => "-m",
		"pages" => "-p",
		"hits" => "-h",
		"size" => "-s"
		);
	foreach $user ( sort keys %usersite ) {
		# emit by various sorting orders ... 
		foreach $currentsort ( keys %sortorder ) {
			$useranon=getanonname($user);
			open USER,"> ". namedatetofilename($useranon,$stringday,$sortorder{$currentsort});
			# Special compensation - we are inside a directory
			$relative = '../';
			print USER htmlheader("Internet access by $useranon - $stringday",
				"<P align=center>
				<A href=${relative}../index.html>Overview</A> | 
				<A href=${relative}index.html>Index</A> | 
				<A href=${relative}".nametofilename($useranon).">$useranon activity</A>
				</P>");
			print USER "<TABLE><TR>
				<TD $cellheadcolour><a href=${relative}".namedatetofilename($useranon,$stringday,'').">Time</A></TD>
				<TD $cellheadcolour><a href=${relative}".namedatetofilename($useranon,$stringday,'-w').">Site</A></TD>
				<TD $cellheadcolour><a href=${relative}".namedatetofilename($useranon,$stringday,'-m').">Minutes</A></TD>
				<TD $cellheadcolour><a href=${relative}".namedatetofilename($useranon,$stringday,'-p').">Pages</A></TD>
				<TD $cellheadcolour><a href=${relative}".namedatetofilename($useranon,$stringday,'-h').">Downloads</A></TD>
				<TD $cellheadcolour><a href=${relative}".namedatetofilename($useranon,$stringday,'-s').">Size</A></TD>
				</TR>";
			my $sites = $usersite{$user};
			my @sitelist;
			# Sorting stuff ...
			if ($currentsort eq "start") {
				@sitelist = sort { $$sites{$a}{$currentsort} <=>
						   $$sites{$b}{$currentsort} } keys %$sites;
			}
			elsif ($currentsort ne "site") {
				@sitelist = sort { $$sites{$b}{$currentsort} <=>
						   $$sites{$a}{$currentsort} } keys %$sites;
			}
			else {
				@sitelist = sort keys %$sites;
			}
			# Now show detail for each site ...
			foreach $site ( @sitelist ) {
				my $record=$$sites{$site};
				if ($$record{"pages"}) {
					$pre="<B>";
					$post="</B>"
				}
				else {
					$pre=""; $post="";
				}
				$url = \$$record{"url"};
				print USER "<TR>
					<TD>" . strftime("%H:%M",localtime($$record{"start"})) . "&nbsp;-&nbsp;"
					 . strftime("%H:%M",localtime($$record{"last"})) . "</TD>
					<TD>$pre<A href=\"$$url\">" . $site . "</A>$post</TD>
					<TD align=right>$pre" . secstoms($$record{"time"}) . "$post</TD>
					<TD align=right>$pre" . $$record{"pages"} . "$post</TD>
					<TD align=right>" . $$record{"hits"} . "</TD>
					<TD align=right>" . bytestok($$record{"size"}) . "</TD>
					</TR>\n";
			}
			printf USER "</TABLE>
				<p>Interpretation:
				<UL>
				<LI>Time: Time of day (hours:minute:second) at which
				this site was first visited. The time of the last visit
				is also shown.</LI>
				<LI>Site: The name of the site to which this user
				connected</LI>
				<LI>Minutes: The number of minutes and seconds
				that were spent connected to this site. All breaks of
				more than ".secstoms($onlinetimeout)." minutes are not
				included in this amount.</LI>
				<LI>Pages: The number of HTML pages that were
				downloaded from this site. If any HTML pages were
				downloaded from the site, the entry for the is
				highlighted. HTTPS connections are counted as a single
				page.</LI>
				<LI>Downloads: The number of objects of any type that
				were downloaded from this site, ie. a HTML page, a
				HTTPS connection, an image, a style sheet, a javascript
				page, etc</LI>
				<LI>Size: The volume of data downloaded over the
				connection to this site</LI>
				</UL>";
			print USER htmlfooter();
			close USER;
		}
	}
}

# Convert seconds to hours:minutes:seconds
sub secstohms($)
{
	my $secs=shift;
	return sprintf("%d:%.2d:%.2d",$secs / 3600, $secs/60%60, $secs%60);
}

# Convert seconds to minutes:seconds
sub secstoms($)
{
	my $secs=shift;
	return sprintf("%d:%.2d", $secs/60, $secs%60);
}

sub bytestok($)
{
	my $bytes=shift;
	if ($bytes<4000) {
		return sprintf("%d bytes", $bytes);
	} 
	elsif ($bytes<4*1024*1024) {
		return sprintf("%d kbytes", $bytes>>10);
	} 
	else {
		return sprintf("%d Mbytes", $bytes>>20)
	} 
}

# remove bad stuff
sub namedatetofilename($$$)
{
	my $name = shift;
	my $date = shift;
	my $sort = shift;
	my $relative = shift;
	$name =~ s/[^a-zA-Z0-9]/-/g;
	$date =~ s/[^a-zA-Z0-9]/-/g;
	mkdir "$date";
	return "$date/$name$sort.html";
}

# remove bad stuff
sub nametofilename($)
{
	my $name = shift;
	$name =~ s/[^\w\d.]/-/g;
	$nametofilenamebasehref = '';
	return "usage-$name.html";
}

# Convert the value (0.000->1.000) to a red value #808080 .. #FF8080
# er ... isn't there an easy way to do this?
sub scalecolour($$$)
{
	my $ratio=shift;
	my $min=shift;
	my $max=shift;
	my $res;
	if ( $ratio<0 ) { return $min; }
	if ( $ratio>1 ) { return $max; }
	$res =0xFF0000 & int(0.5+($min&0xFF0000)+(($max&0xFF0000)-($min&0xFF0000))*$ratio);
	$res+=0x00FF00 & int(0.5+($min&0x00FF00)+(($max&0x00FF00)-($min&0x00FF00))*$ratio);
	$res+=0x0000FF & int(0.5+($min&0x0000FF)+(($max&0x0000FF)-($min&0x0000FF))*$ratio);
	return $res;
}

# Return a colour value for bgcolor=...
sub getredness($)
{
	return sprintf("#%.6x",scalecolour(shift,0xFFFFFF,0xFF0000));
}

# User statistics
sub userstats($)
{
	my $user = shift;
	$useranon=getanonname($user);
	open REPORT,">" . nametofilename($useranon) ;
	print REPORT htmlheader("$useranon activity $reportperiod",
		"<P align=center>
		<A href=../index.html>Overview</A> | 
		<A href=index.html>Index</A>
		</P>");

	# Vital statistics for the user
	print REPORT "
		Internet usage summary for $useranon:
		<OL>
		<TABLE>
		<TR>
		<TD valign=top>Time on-line</TD>
		<TD valign=top>".secstohms($userduration{$user})."</TD>
		<TD valign=top>(The total time spent by this user on the internet)</TD>
		</TR>
		<TR>
		<TD valign=top>Total data transferred</TD>
		<TD valign=top>".bytestok($usersize{$user})."</TD>
		<TD valign=top>(The number of bytes downloaded by this user)</TD>
		</TR>
		<TR>
		<TD valign=top>Longest session</TD>
		<TD valign=top>".secstohms($maxsession{$user})."</TD>
		<TD valign=top>The longest continuous time spent by this user on the internet (on ".
		strftime("%A %d %B",localtime($maxsessiondate{$user}))
		.")</TD>
		</TR>
		</TABLE>
		</OL>
		";

	#-------------------------------------------------------------
	# Time of day per day: headings
	print REPORT "Daily usage summary
		<OL>
		<TABLE border=1 cellpadding=1 cellspacing=1>
		<TR>
		<TD $cellheadcolour>Date</TD>
		<TD $cellheadcolour align=right>Minutes</TD>
		<TD $cellheadcolour align=right>Sites</TD>
		<TD $cellheadcolour align=right>Pages</TD>
		<TD $cellheadcolour align=right>Size</TD>
		</TR>
		";

	foreach $day (sort keys %{$dailyseconds{$user}} ) {
		$stringday = strftime ("%a %d %b %Y", localtime($day));
		$link=namedatetofilename($useranon,$stringday,'');
		$stringday =~ s/ /&nbsp;/g;
		$sitecount=0;
		$pagecount=0;
		foreach $site (sort keys %{$pagesviewed{$user}{$day}} ) {
			$sitecount++;
			$pagecount+=$pagesviewed{$user}{$day}{$site};
		}
		# Record for later use:
		$usersites{$user} += $sitecount;
		$seconds=0;
		for ($hour=0; $hour<24; $hour++) {
			$seconds += $dailyseconds{$user}{$day}[$hour];
		}
		printf REPORT "<TR>
			<TD align=right><a href=$link>%s</a></TD>
			<TD align=right>%s</TD>
			<TD align=right>%s</TD>
			<TD align=right>%s</TD>
			<TD align=right>%s</TD>
			</TR>",
			$stringday,
			secstoms($seconds),
			$sitecount,
			$pagecount,
			bytestok($dayusersize{$day}{$user}) ;
	}
	printf REPORT "</TABLE></OL>";

	print REPORT "Time of day usage pattern (Number of minutes per hour
		that this user browses the internet)
		<OL>
		<TABLE border=1 cellpadding=1 cellspacing=1>
		<TR><TD $cellheadcolour></TD><TD $cellheadcolour colspan=24 align=center>Hour of day (8 means 08h00 - 08h59)</TD><TD $cellheadcolour></TD></TR>
		<TR><TD $cellheadcolour>Date</TD>";

	for ($hour=0; $hour<24; $hour++) {
		print REPORT "<TD align=right>${hour}</TD>";
	}
	print REPORT "<TD $cellheadcolour>Total</TD></TR>";

	#-------------------------------------------------------------
	# Time of day per day: For each day browsed, show the time for each hour
	foreach $day (sort keys %{$dailyseconds{$user}} ) {
		$stringday = strftime ("%a %d %b %Y", localtime($day));
		$link=namedatetofilename($useranon,$stringday,'');
		$stringday =~ s/ /&nbsp;/g;
		print REPORT "<TR><TD align=right><a href=$link>$stringday</a></TD>";
		$peak = 60;
		$totalseconds = 0;
		# Sort out hours where there is overflow from the previous hour
		$carry = 0;
		for ($hour=23; $hour>=0; $hour--) {
			$seconds = \$dailyseconds{$user}{$day}[$hour];
			$$seconds += $carry;
			$carry=0;
			if ($$seconds>3600) {
				$carry = $$seconds - 3600;
				$$seconds=3600;
			}
		}
		for ($hour=0; $hour<24; $hour++) {
			$seconds = \$dailyseconds{$user}{$day}[$hour];
			if ($$seconds >= 30) {
				printf REPORT "<TD bgcolor=%s align=right>%d</TD>", 
					getredness($$seconds/(3600/2)), # red = .5 hours out of 1 hour
					($$seconds+30)/60;
				$totalseconds += $$seconds;
			} 
			elsif ($$seconds) {
				print REPORT "<TD>..</TD>";
			}
			else {
				print REPORT "<TD></TD>";
			}
		}
		# Total
		printf REPORT "<TD bgcolor=%s align=right>%d:%.2d</TD>", 
			getredness($totalseconds/(3600*2)), # red = 2 hours total
			(($totalseconds+30)/3600),
			(($totalseconds+30)/60)%60;
		print REPORT "</TR>";
	}

	#-------------------------------------------------------------
	# Time of day per day: Time of day usage totals
	if (0) {
		print REPORT "<TR><TD>Total</TD>";
		for ($hour=0; $hour<24; $hour++) {
			$seconds = $hourlyseconds{$user}[$hour];
			printf REPORT "<TD align=right>%d:%.2d</TD>", 
				($seconds/3600),
				($seconds/60)%60;
			$totalseconds += $seconds;
		}
		printf REPORT '<TD>%d:%.2d</TD>', 
			($totalseconds/3600),
			($totalseconds/60)%60;
		print REPORT "</TR>";
	}
	print REPORT "</TABLE>
		</OL>";

	print REPORT "
	<p>Interpretation:
	<UL>
	<LI>Sites: The number of individual web sites at which text/html pages
	were downloaded by this user</LI>
	<LI>Pages: The number of distinct text/html pages downloaded at the
	sites which were visited.</LI>
	<LI>Minutes: The number of minutes (minutes:seconds) spent connected to
	the internet for this user ID.  An quiet period of more than ".secstoms($onlinetimeout)."
	minutes counts as the end of a session.</LI>
	<LI>Size: The number of bytes (kilobytes / megabytes, etc) downloaded
	during the time period.  This includes both text, images and any other
	data</LI>
	<LI>Time of day highlighting: 30 minutes corresponds to 100% highlighting.
	</LI>
	</UL>";

	print REPORT htmlfooter();
	close REPORT;
}

# Report 2: Top offenders, orderded by various categories
# Top users, sorted by Duration, pages, sites
sub topreport($$)
{
	$sortedby=shift;
	$list=shift;

	open TOPREPORT,">topreport-$sortedby.html";
	print TOPREPORT htmlheader("Top users $reportperiod",
		"<P align=center>
		<A href=../index.html>Overview</A> |
		<A href=index.html>Index</A>
		</P>");
	print TOPREPORT "<TABLE>
		<TR>
		<TD $cellheadcolour><a href=topreport-name.html>Name</a></TD>
		<TD $cellheadcolour align=right><a href=topreport-duration.html>Hours</a></TD>
		<TD $cellheadcolour align=right><a href=topreport-sites.html>Sites</a></TD>
		<TD $cellheadcolour align=right><a href=topreport-pages.html>Pages</a></TD>
		<TD $cellheadcolour align=right><a href=topreport-size.html>Size</a></TD>
		</TR>
		";

	foreach $user (@$list) {
		$useranon=getanonname($user);
		printf TOPREPORT "<TR>
			<TD><A href=%s>%s</A></TD>
			<TD align=right>%s</TD>
			<TD align=right>%d</TD>
			<TD align=right>%s</TD>
			<TD align=right>%s</TD>
			</TR>",
			nametofilename($useranon),
			$useranon,
			secstohms($userduration{$user}),
			$usersites{$user},
			$userpages{$user}, 
			bytestok($usersize{$user});
	}

	print TOPREPORT "</TABLE>";
	print TOPREPORT "
		<p>Interpretation:
		<UL>
		<LI>Name: The log-on name with which internet access was
		authenticated</LI>
		<LI>Hours: The number of hours (hours:minutes) spent
		connected to the internet for this user ID.  An quiet period
		of more than ".secstoms($onlinetimeout)." minutes counts as the end of a
		session.</LI>
		<LI>Sites: The number of individual web sites at which text/html pages
		were downloaded</LI>
		<LI>Pages: The number of distinct text/html pages downloaded
		at the sites which were visited.</LI>
		<LI>Size: The number of bytes (kilobytes / megabytes, etc)
		downloaded during the time period.  This includes both text,
		images and any other data</LI>
		</UL>";

	print TOPREPORT htmlfooter();
	close TOPREPORT;

}


# Generate user statistics
foreach $user (sort keys %hourlyseconds) {
	userstats($user);
}

# set reportperiod based on the actual period the report covers
# in the remaining output files
if ($day > $daymax ) { $daymax = $day; }
if ($timefrom == 0 ) { $timefrom = $daymin; }
if ($timeto == 0 ) { $timeto = $daymax; } else {
	$timeto--;
}
$timefromascii = strftime ("%a %d %b %Y", localtime($timefrom));
$timetoascii = strftime ("%a %d %b %Y", localtime($timeto));
if ($timefrom != $timeto) {
	$reportperiod = "$timefromascii to $timetoascii";
}
else {
	$reportperiod = $timefromascii;
}

# Limit the number of thingies
if ($useanonnames)
{
	my @ar = sort keys %userduration;
	my $minimum = $useanonnames;
	while (@ar > $minimum) {
		$index = int (int(rand(@ar))+int(rand(@ar)) / 2);
		$user = $ar[$index];
		splice @ar, $index, 1;
		$useranon = getanonname($user);
		unlink nametofilename($useranon);
		print "Deleting $user($useranon)($index)\n";
		foreach $day (sort keys %{$dailyseconds{$user}} ) {
			$stringday = strftime ("%a %d %b %Y", localtime($day));
			foreach $ext ('','-w','-m','-p','-h','-s') {
				unlink namedatetofilename($useranon,$stringday,$ext);
			}
		}
		delete $userpages{$user};
		delete $usersites{$user};
		delete $usersize{$user};
		delete $userduration{$user};
	}
}

# Generate it in various sorting orders
@ar = sort keys %userpages;
topreport("name", \@ar);

@ar = sort {$userpages{$b} <=> $userpages{$a} } keys %userpages;
topreport("pages", \@ar);

@ar = sort {$usersites{$b} <=> $usersites{$a} } keys %usersites;
topreport("sites", \@ar);

@ar = sort {$usersize{$b} <=> $usersize{$a} } keys %usersize;
topreport("size", \@ar);

@ar = sort {$userduration{$b} <=> $userduration{$a} } keys %userduration;
topreport("duration", \@ar);

# record the date range
open RANGE,"> range.txt";
print RANGE "$timefromascii - $timetoascii\n";
close RANGE;

qx{ cp topreport-duration.html index.html };

