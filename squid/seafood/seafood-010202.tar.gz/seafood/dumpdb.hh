//
//
//
#ifndef _DUMPDB_HH
#define _DUMPDB_HH

#if defined(__GNUC__) || defined(__GNUG__)
#pragma interface
#endif

#include <stdio.h>

void
dumpResults( FILE* out, const char* cache, 
	     DNSCache* dns, IRRCache* irr, const Counters& cnt,
	     double looptime, double startup, MyUInt32 lineno );

#endif //  _DUMPDB_HH
