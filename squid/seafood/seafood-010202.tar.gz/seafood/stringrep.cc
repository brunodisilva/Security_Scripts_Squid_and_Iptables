//
// $Id: stringrep.cc,v 1.5 1999/08/22 11:33:02 voeckler Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    stringrep.cc
//          Sun Jun 28 1998
//
// (c) 1998 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: stringrep.cc,v $
// Revision 1.5  1999/08/22 11:33:02  voeckler
// added c'tor interface for constructing a string of a repeated
// number of the same character.
//
// Revision 1.4  1999/08/05 21:21:20  voeckler
// minor changes, mostly dealing with MyUInt32 instead of size_t.
//
// Revision 1.3  1998/07/23 18:27:49  voeckler
// speed improvements due to design improvements: move string size into
// base class, thus inlinable.
//
// Revision 1.2  1998/07/02 09:38:39  voeckler
// added forgotten refcount, added string sentinel static singleton data.
//
// Revision 1.1  1998/06/28 19:47:54  voeckler
// Initial revision
//

#if defined(__GNUC__) || defined(__GNUG__)
#pragma implementation
#endif

#include <ctype.h>
#include <memory.h>
#include <string.h>
#include "stringrep.hh"

static const char* RCS_ID = 
"$Id: stringrep.cc,v 1.5 1999/08/22 11:33:02 voeckler Exp $";

StringRep::StringRep()
  :StringBaseRep(0),refcount(1),hashcache(C_U32(0xFFFFFFFF))
{
  string = new char[1];
  *((char*) string) = '\0';
}

StringRep::StringRep( const size_t _size, char prefill )
  :StringBaseRep(_size),refcount(1),hashcache(C_U32(0xFFFFFFFF))
{
  string = new char[size+1];
  memset( (void*) string, prefill, size );
  *((char*) string+size) = '\0';
}

StringRep::StringRep( const char* s )
  :StringBaseRep(0),refcount(1),hashcache(C_U32(0xFFFFFFFF))
{
  if ( s ) {
    size = strlen(s);
    string = new char[size+1];
    memmove( (void*) string, s, size+1 );
  } else {
    string = new char[1];
    *((char*) string) = 0;
  }
}

StringRep::StringRep( const StringRep& s )
  :StringBaseRep(s.size),refcount(1),hashcache(C_U32(0xFFFFFFFF))
  // deep copy
{
  string = new char[size+1];
  memmove( (void*) string, s.string, size+1 );
}

StringRep& 
StringRep::operator=( const char* s )
{
  delete[] (char*) string;
  if ( s ) {
    size = strlen(s);
    string = new char[size+1];
    memmove( (void*) string, s, size+1 );
  } else {
    size = 0;
    string = new char[1];
    memset( (void*) string, 1, 0 );
  }
  refcount = 1;
  hashcache = C_U32(0xFFFFFFFF);
  return *this;
}

StringRep& 
StringRep::operator=( const StringRep& s )
  // deep copy
{
  if ( this != &s ) {
    delete[] (char*) string;
    size = s.size;
    string = new char[size+1];
    memmove( (void*) string, s.string, size+1 );
    refcount = 1;
  }
  hashcache = C_U32(0xFFFFFFFF);
  return *this;
}

StringSentinel* StringSentinel::singleton = 0;

