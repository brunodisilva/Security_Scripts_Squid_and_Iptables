//
// $Id: stringrep.hh,v 1.6 1999/08/27 19:59:33 voeckler Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    stringrep.hh
//          Sun Jun 28 1998
//
// (c) 1998 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: stringrep.hh,v $
// Revision 1.6  1999/08/27 19:59:33  voeckler
// made copy c'tor and assignment op for sentinel inaccessible.
//
// Revision 1.5  1999/08/22 11:33:02  voeckler
// added c'tor interface for constructing a string of a repeated
// number of the same character.
//
// Revision 1.4  1999/08/05 21:21:20  voeckler
// minor changes, mostly dealing with MyUInt32 instead of size_t.
//
// Revision 1.3  1998/07/23 18:27:49  voeckler
// speed improvements due to design improvements: move string size into
// base class, thus inlinable.
//
// Revision 1.2  1998/07/02 09:37:27  voeckler
// added forgotten virtual base class dtor.
// made the string sentinel a singleton to avoid races in the dtor of
// static data.
//
// Revision 1.1  1998/06/28 19:47:54  voeckler
// Initial revision
//
#ifndef _STRINGREP_HH
#define _STRINGREP_HH

#if defined(__GNUC__) || defined(__GNUG__)
#pragma interface
#endif

#ifndef HAS_BOOL
#define HAS_BOOL
typedef int bool;
#define false 0
#define true  1
#endif

#include <sys/types.h> // size_t
#include <limits.h>
#include <string.h>
#include "typedefs.h"
#include "hash.hh"

class String;

class StringBaseRep : public Hashable {
  // internal representation, not for general use.
  // still abstract, to be used by two siblings
  // refines the interface of hashable towards a string applicability
public:
  // concrete base ctor
  StringBaseRep( size_t s = 0 ):size(s) { }

  // virtual dtor, must exist!
  virtual ~StringBaseRep() { }
  
  // Accessors
  virtual const char* content( void ) const = 0;    
    // purpose: accessor to ASCIIZ C string
  inline size_t length( void ) const { return size; }
    // purpose: accessor to length of internal C string
    // warning: this is *inline*, not virtual, for performance reasons
  virtual size_t references( void ) const = 0;      
    // purpose: accessor to the internal reference counter

  // Actions
  virtual size_t increase( void ) = 0; 
    // purpose: increase ref counter
    // returns: new value of counter
  virtual size_t decrease( void ) = 0;
    // purpose: decrease ref counter
    // returns: new value of counter

protected:
  size_t size;

private:
  // render inaccessible (make compiler warn about incorrect usage).
  StringBaseRep( const StringBaseRep& );
  StringBaseRep& operator=( const StringBaseRep& );
};



class StringRep : public StringBaseRep {
  // internal representation, not for general use.
  // general string representation
public:
  // construct, init and destroy
  StringRep();
  StringRep( const size_t _size, char prefill = 0 );
  StringRep( const char* s );
  StringRep( const StringRep& s );
  StringRep& operator=( const char* s );
  StringRep& operator=( const StringRep& s );
  virtual ~StringRep() { delete[] ((char*) string); }

  // Accessors
  virtual const char* content( void ) const { return string; }
  virtual size_t references( void ) const { return refcount; }
  virtual MyUInt32 hash( void ) const
  {
    if ( hashcache == C_U32(-1) )
#if 1
#ifdef HAS_MUTABLE    
      hashcache = hashpjw( string, size );
#else
      (((StringRep*) this)->hashcache) = hashpjw( string, size );
#endif    
#else
#ifdef HAS_MUTABLE    
      hashcache = hashstl( string );
#else
      (((StringRep*) this)->hashcache) = hashstl( string );
#endif    
#endif
    return hashcache;
  }

  // Actions
  virtual size_t increase( void ) { return ++refcount; }
  virtual size_t decrease( void ) { return --refcount; }
  
  // friends will be friends...
  friend class String;
  friend String operator+( const String& s1, const char* s2 );
  friend String operator+( const char* s1, const String s2 );
  // friend String operator+( const char* s1, const char* s2 );
  friend String substring( const char* s, unsigned start, unsigned size );
			  
protected:
  unsigned refcount;          // refcounts are always critical with threads!
#ifndef HAS_MUTABLE
#define mutable
#endif 
  mutable MyUInt32 hashcache; // hashcache is critical with operator() abuse!
  // Base::size is also critical with operator() result abuse!
  const char* string;         // consider *real* private
};



class StringSentinel : public StringBaseRep {
  // class to represent an unchangable string as property for a fast
  // default String class ctor. You might not believe it, but using
  // this sibling for the default (array alloction) ctor of String,
  // really improves performance (of the array allocation) by the factor
  // of 150...
  //
  // Also, this class implements the Singleton design pattern, as
  // described in Gamma et. al. For reasons of the unpredictable and
  // undefinable order of static dtor calls, the Singleton got introduced.
  // If you use "purify" on this project, it will report that the static
  // pointer StringSentinel::singleton was never freed. I think we can
  // live with these few ( < 20 ) lost bytes...
public:
  virtual ~StringSentinel() { /* nothing to do */ }

  // Accessors
  virtual const char* content( void ) const { return string; }
  virtual size_t references( void ) const { return INT_MAX; }
  virtual MyUInt32 hash( void ) const { return 0; }

  // Actions
  virtual size_t increase( void ) { return INT_MAX; }
  virtual size_t decrease( void ) { return INT_MAX; }

  inline static StringSentinel* instance()
    // purpose: access the singleton
    // returns: pointer to one and only StringSentinel
  {
    if ( singleton == 0 ) singleton = new StringSentinel;
    return singleton;
  }
  
protected:
  StringSentinel():StringBaseRep(0) { *string = 0; }
    // purpose: protected c'tor for a Singleton (see "design patterns")

private:  
  char string[1];  // consider *real* private
  static StringSentinel* singleton;

  // make inaccessible
  StringSentinel( const StringSentinel& );
  StringSentinel& operator=( const StringSentinel& );
};

#endif // _STRINGREP_HH
