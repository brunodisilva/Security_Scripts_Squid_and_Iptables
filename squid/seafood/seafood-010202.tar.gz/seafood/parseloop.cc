//
// $Id: parseloop.cc,v 1.3 2001/02/02 09:27:07 cached Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    parseloop.cc
//          Sun Jul 30 2000
//
// (c) 2000 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: parseloop.cc,v $
// Revision 1.3  2001/02/02 09:27:07  cached
// changed abs (== std::abs) to labs.
//
// Revision 1.2  2000/08/10 12:42:08  voeckler
// added shortcut for time and size, added TCP internal requests status counts.
//
// Revision 1.1  2000/07/29 22:14:15  voeckler
// Initial revision
//
//
#if defined(__GNUC__) || defined(__GNUG__)
#pragma implementation
#endif

#include <sys/types.h>
#include <stdlib.h>
#include "ctype.hh"
#include "fsm01.hh"
#include "typedefs.h"
#include "parseloop.hh"
#include "global.hh"
#include "tools.hh"

static const char* RCS_ID =
"$Id: parseloop.cc,v 1.3 2001/02/02 09:27:07 cached Exp $";

double
processFile( BaseInput* in, Counters& cnt )
  // purpose: big loop around file for parsing the contents
  // paramtr: in (IO): input stream to read until it ends
  // returns: time spent processing this file
{
  char temp[8192];
  FSM_01 fsm;
  LogLine log;
  int urlsize, column;
  size_t index;
  bool runOnce = true;
  String log_tld, log_sld, log_hierhost, log_client;
  String log_internal_host, log_internal_path;
  size_t iurlPrefixSize = globals.iurlPrefix ? strlen(globals.iurlPrefix) : 0;

  MyUInt32 lastStamp = 0;	// copy of last timestamp
  unsigned long linenoCopy;	// file based line nr after LF was read

  char* const urlComponents[3] = { temp, temp+256, temp+(256+256) };
  const size_t urlCompSizes[3] = { 256, 256, 32 };

  // fix for CONNECT method which does not have a scheme nor path
  int method_connect = LogLine::mtable.find("CONNECT") & 0xFFFF;

  // fixes for Squid false log messages
#ifdef REFRESH_FIX
  int tcp_refresh_hit = LogLine::stable.find("TCP_REFRESH_HIT") & 0xFFFF;
#endif // REFRESH_FIX
  int hier_none = LogLine::htable.find("NONE") | IS_NONE;

  double start = now();
  while ( ! in->eof() ) {
    // report the line we are currently looking at.
    if ( (in->lineno & 65535) == 0 )
      fprintf( stderr, "# %lu lines processed from this file\n", in->lineno );

    //
    // STAGE 1: start parsing a log line
    //
    log.shallow_clear();
    column = 0;

    // 1st column, timestamp, e.g. 931212014.216
    // just read the integer portion and discard fractional value
    if ( in->integer( log._stamp ) < 9 ) {
      fprintf( stderr, "%lu: illegal timestamp, skipping\n", in->lineno );
    } else {
      // we didn't read the '.xxx' part, so skip forward over it.
      in->skiptolws();
      // log._stamp += globals.gmtOffset; 
      column++;
    }

    // 2nd column, duration, e.g. 25812, or 0, or even -1
    if ( in->integer( log._duration ) == 0 ) {
      fprintf( stderr, "%lu: illegal duration, skipping\n", in->lineno );
    } else
      column++;


    // 3rd column, client address, e.g. "130.75.3.218" or "rot-lane.rvs...."
    if ( in->get( log._requester, sizeof(log._requester) ) < 3 ) {
      fprintf( stderr, "%lu: illegal client host address, skipping\n", 
	       in->lineno );
    } else
      column++;


    // 4th column, cache hit status, e.g.: "TCP_MISS/200"
    if ( log.parseStatus( in ) < 6 || log._statuscode == -1 ) {
      fprintf( stderr, "%lu: illegal return status, skipping\n", in->lineno );
    } else
      column++;


    // 5th column, reply size, e.g. 8838
    if ( in->integer( log._size ) == 0 ) {
      fprintf( stderr, "%lu: illegal reply size, skipping\n", in->lineno );
    } else
      column++;


    // 6th column, method string, e.g. "GET" or "CONNECT"
    if ( log.parseMethod( in ) < 3 || log._method == 0 ) {
      fprintf( stderr, "%lu: unknown method, skipping\n", in->lineno );
    } else
      column++;

    // 7th column, URI, e.g. "http://www.user.cityline.ru:8083/~itbshake/"
    if ( (urlsize = in->get( log._url, sizeof(log._url)) ) < 5 ) {
      fprintf( stderr, "%lu: strange URL, skipping\n", in->lineno );
    } else
      column++;
    
    // 8th column, ident, e.g. "-"
    if ( globals.noIdent ) {
      // precondition: no ident lookups, value will always be "-"
      // if it isn't, the URL contains whitespaces (which are illegal)
      // FIXME: what happens, if the line ends prematurely ?!
      int allow = globals.allowedWhiteSpaces;
      while ( in->get( temp, sizeof(temp) ) != 1 && *temp != '-' && 
	      allow > 0 && ! in->eof() ) {
	--allow;
#if 0 // NOT YET NEEDED, SAVE EXEC TIME HERE!
	// whoa! there were whitespaces in the url...
	strncat( log._url, "%20", sizeof(log._url) );
	strncat( log._url, temp, sizeof(log._url) );
	urlsize += strlen(temp) + 3;
#endif
	fprintf( stderr, "%lu: URL contains whitespaces, fixing!\n", 
		 in->lineno );
      }

      // too many whitespaces
      if ( allow == 0 ) {
	fprintf( stderr, "%lu: too many whitespaces in URL, skipping!\n",
		 in->lineno );
	column--;
      }

      // we found what we were looking for (hopefully).
      log._ident[0] = '-';
      log._ident[1] = '\0';
      column++;
    } else {
      // precondition: ident lookups --> url ws cognition system is down :-(
      if ( in->get( log._ident, sizeof(log._ident) ) == 0 ) {
	fprintf( stderr, "%lu: unknown ident string, skipping\n", in->lineno );
      } else
        column++;
    }

    // 9th column, hierarchy info, e.g. "DIRECT/www.user.cityline.ru"
    if ( log.parseHierarchy(in) == 0 || log._hierarchy == 0 ) {
      fprintf( stderr, "%lu: unknown hierarchy, skipping\n", in->lineno );
    } else
      column++;

    // 10th column, mime type, e.g. "text/html"
    // Illegal media types are 'valid' and counted as error.
    // Only parse media type for TCP et. al., skip for UDP
    if ( (log._status & IS_UDP) == 0 ) {
      if ( log.parseMediaType(in) == 0 ) {
	fprintf( stderr, "%lu: strange MIME type, skipping\n", in->lineno );
      } else
	column++;
    } else {
      column++;
    }

    // 11th and 12th column may contain request and reply headers, skip
    // also, skippasteoln() will update the line counter and positioner
    linenoCopy = in->lineno;
    in->skippasteoln();
    if ( column < 10 ) {
      log.dump( stderr, 10 );
      continue;
    }

    //
    // STAGE 2: convert some values into something even better computable
    //
    unsigned short log_port = 0;   // default: no port --> port 80
    bool log_internal = false;     // default: not an internal object
    int log_scheme = 0;            // default: no scheme (e.g. CONNECT)
    int log_suffix = 0;            // default: suffix is <unknown>
    log_client = log._requester;

    if ( runOnce ) {
      if ( cnt.startTime == 0 || cnt.finalTime > log._stamp )
	cnt.startTime = log._stamp;
      runOnce = false;
    }
    if ( cnt.finalTime < log._stamp ) 
      cnt.finalTime = log._stamp;
    MyUInt32 log_peak = log._stamp / globals.peakInterval;

    if ( lastStamp && 
	 MyUInt32(labs(log._stamp-lastStamp)) > globals.warnCrashInterval ) {
      char oldstamp[32], newstamp[32];
      time_t t1 = lastStamp;
      time_t t2 = log._stamp;
      strftime( oldstamp, 32, "%d.%m.%Y %H:%M:%S %Z", localtime(&t1) );
      strftime( newstamp, 32, "%d.%m.%Y %H:%M:%S %Z", localtime(&t2) );
      fprintf( stderr, "%lu: detected %.0f s silence between two time stamps\n"
	       "+ last \"%s\", current \"%s\"\n", linenoCopy,
	       difftime(t2,t1), oldstamp, newstamp  );
    }
    lastStamp = log._stamp;

    if ( (log._status & IS_UDP) == 0 ) {
      // determine scheme, hostname (tld,2ld) and portnumber
      index = fsm.parse( log._url, urlComponents, urlCompSizes );
      if ( (log_scheme = LogLine::schemes.find(urlComponents[0])) == 0 &&
	   log._method != method_connect && // don't warn "CONNECT host.na.me"
	   globals.warnUnknownScheme )
	fprintf( stderr, "%lu: unknown URL scheme \"%s\"\n", 
		 linenoCopy, urlComponents[0] );
      getDomainFromHost( urlComponents[1], log_tld, log_sld );
      if ( log_tld.length() == 0 || 
	   LogLine::domains.find(log_tld.c_str()) == 0 ) {
	if ( globals.warnUnknownTLD )
	  fprintf( stderr, "%lu: unknown TLD \"%s\" in hostname \"%s\"\n",
		   linenoCopy, log_tld.c_str(), urlComponents[1] );
	log_tld = str_error;
	log_sld = str_error;
      }

      // do some port checking
      log_port =
	ISDIGIT( urlComponents[2][0] ) ?
	strtol(urlComponents[2],0,10) & 0xFFFF :
	80; // FIXME: check with getservbyname()
      log_port = (( log_port == 80 ) ? 64 : ( log_port >> 10 ));

      // convert the hierarchy host into something standard (all lower).
      log_hierhost = String( log._hierhost ).lower();

      // log_internal==true, iff path starts in common prefix for
      // squid-internal-(periodic|dynamic|static)
      log_internal = (iurlPrefixSize != 0 ) &&
	( strncmp( log._url+index, globals.iurlPrefix, iurlPrefixSize ) == 0 );
      if ( log_internal ) {
	String temp( log._url );
	log_internal_host = temp.substring(0,index);
	log_internal_path = temp.substring(index);
      } else {
	// not a squid internal component --> may have a suffix
	char suffix[16];
	char* s = strrchr( log._url+index, '.' );
	if ( s && strchr( s, '/' ) == 0 ) {
	  // convert via trie lookup into number!
	  int i=0;
	  ++s;
	  while ( i < sizeof(suffix)-1 && ISHNAME(s[i]) ) {
	    suffix[i] = TOLOWER(s[i]);
	    ++i;
	  }
	  suffix[i] = '\0'; // terminate string
	} else {
	  // no suffix
	  strcpy( suffix, "<empty>" );
	}

	// use numerical value for later perusal
	log_suffix = LogLine::suffices.find( suffix );
	if ( log_suffix == 0 && globals.warnUnknownSuffix )
	  fprintf( stderr, "# unknown suffix .%s\n", suffix );
      }
    }
    
    // use 'natural' sizes for indexing, should be fastest
    int log_status  = (log._status & 0xFFFF);
    int log_method  = (log._method & 0xFFFF);
    int log_media   = (log._mediatype & 0xFFFF);
    int log_subtype = (log._mediasubtype & 0xFFFF);

#if 0
    // try some speed-ups
    register MyUInt32 my_size = log._size;
    register double   my_time = log._duration;
#else
# define my_size log._size
# define my_time log._duration
#endif

    // fix Squid false log messages
#define TCP_HIT (IS_HIT | IS_TCP)
#ifdef REFRESH_FIX
    if ( log_status == tcp_refresh_hit && log._statuscode == 200 )
      log._status &= ~IS_HIT;
    else
#endif // REFRESH_FIX
    if ( (log._status & TCP_HIT) == TCP_HIT &&
	 ( log._statuscode == 301 || log._statuscode == 302 ) )
      log._hierarchy = hier_none;

    //
    // STAGE 3: count!
    //
#ifdef LOOP_ADD
    cnt.all.incr( my_size, my_time );
#endif
    cnt.methods[log_method ].incr( my_size, my_time );

    if ( (log._status & IS_UDP) != 0 ) {
      //
      // UDP
      //
#ifdef LOOP_ADD
      cnt.udp.incr( my_size, my_time );
#endif
      cnt.udp_client[ log_client ].incr( my_size, my_time );
      cnt.peak_udp[ log_peak ].incr( my_size, my_time );
      if ( (log._status & IS_HIT) != 0 ) {
	// count UDP HITs here
	cnt.udp_hit.incr( my_size, my_time );
	cnt.udp_hit_client[ log_client ].incr( my_size, my_time );
	cnt.udp_hit_status[ log_status ].incr( my_size, my_time );
	cnt.hit_methods[ log_method ].incr( my_size, my_time );
	cnt.peak_udp_hit[ log_peak ].incr( my_size, my_time );
      } else {
	// count UDP MISSes here
	cnt.udp_miss.incr( my_size, my_time );
	cnt.udp_miss_status[ log_status ].incr( my_size, my_time );
      }

    } else if ( log_internal ) {
      //
      // internal traffic ( cache digests, network db, ftp icons )
      //
#ifdef LOOP_ADD
      cnt.internal.incr( my_size, my_time );
#endif
      cnt.internal_host[log_internal_host].incr( my_size, my_time );
      cnt.internal_path[log_internal_host][log_internal_path].incr( my_size, my_time );
      if ( globals.showExtendedInternal )
	cnt.internal_hpc[log_internal_host][log_internal_path][log_client].incr( my_size, my_time );
      cnt.internal_client[log_client].incr( my_size, my_time );
      cnt.peak_int[ log_peak ].incr( my_size, my_time );

      if ( (log._status & TCP_HIT) == TCP_HIT ) {
	// TCP internal HITs
#ifdef LOOP_ADD
	cnt.internal_hit.incr( my_size, my_time );
#endif
	cnt.internal_hit_host[log_internal_host].incr( my_size, my_time );
	cnt.internal_hit_path[log_internal_host][log_internal_path].incr( my_size, my_time );
	if ( globals.showExtendedInternal ) 
	  cnt.internal_hit_hpc[log_internal_host][log_internal_path][log_client].incr( my_size, my_time );

	cnt.int_hit_status[ log_status ].incr( my_size, my_time );
	cnt.internal_hit_client[log_client].incr( my_size, my_time );
	cnt.peak_int_hit[ log_peak ].incr( my_size, my_time );
      } else if ( (log._hierarchy & IS_NONE) || log._hierarchy == 0 ) {
	//
	// MISSes with NONE (mostly errors)
	//
	cnt.int_none_status[ log_status ].incr( my_size, my_time );
#ifdef LOOP_ADD
	cnt.internal_none.incr( my_size, my_time );
#endif
      } else {
	cnt.int_miss_status[ log_status ].incr( my_size, my_time );
#ifdef LOOP_ADD
	cnt.internal_miss.incr( my_size, my_time );
#endif
      }

    } else {
      //
      // TCP and else
      //
      int log_hier = log._hierarchy & 0xFFFF;

      if ( (log._status & IS_TCP) == 0 && globals.warnNoneAsTCP ) {
	fprintf( stderr, "%lu: neither TCP nor UDP, counting as TCP\n", 
		 linenoCopy );
	log.dump(stderr,10);
      }

      // count all ***OTHER*** traffic here (not limited to TCP)
#ifdef LOOP_ADD
      cnt.tcp.incr( my_size, my_time );
      cnt.tcp_client[ log_client ].incr( my_size, my_time );
#endif
      cnt.tcp_tld[ log_tld ].incr( my_size, my_time );
      cnt.tcp_sld[ log_sld ].incr( my_size, my_time );
      cnt.tcp_scheme[ log_scheme ].incr( my_size, my_time );
      cnt.tcp_suffix[ log_suffix & 0xFFFF ].incr( my_size, my_time );
      cnt.tcp_mime[ log_media ].incr( my_size, my_time );
      if ( cnt.nSubtype[log_media] )
	cnt.tcp_submime[ log_media ][ log_subtype ].incr( my_size, my_time );

      cnt.tcp_ports[ log_port ].incr( my_size, my_time );
      cnt.peak_tcp[ log_peak ].incr( my_size, my_time );

      if ( (log._status & TCP_HIT) == TCP_HIT ) {
	//
	// TCP HITs
	//
	cnt.distribution[Counters::D_HIT].add( my_size, my_time );

	cnt.tcp_hit.incr( my_size, my_time );
	cnt.tcp_hit_client[ log_client ].incr( my_size, my_time );
	cnt.tcp_hit_status[ log_status ].incr( my_size, my_time );
	cnt.tcp_hit_tld[ log_tld ].incr( my_size, my_time );
	cnt.tcp_hit_sld[ log_sld ].incr( my_size, my_time );
	cnt.tcp_hit_mime[ log_media ].incr( my_size, my_time );
	if ( cnt.nSubtype[log_media] )
	  cnt.tcp_hit_submime[ log_media ][ log_subtype ].incr( my_size, my_time );
	cnt.tcp_hit_scheme[ log_scheme ].incr( my_size, my_time );
	cnt.tcp_hit_suffix[ log_suffix & 0xFFFF ].incr( my_size, my_time );
	cnt.hit_methods[ log_method ].incr( my_size, my_time );

	cnt.tcp_hit_hier[ log_hier ].incr( my_size, my_time );
	if ( (log._hierarchy & (IS_DIRECT|IS_NONE))==IS_DIRECT && log_hier )
	  cnt.tcp_hit_direct_host[ log_hierhost ].incr( my_size, my_time );
	cnt.peak_tcp_hit[ log_peak ].incr( my_size, my_time );
      } else if ( (log._hierarchy & IS_NONE) || log._hierarchy == 0 ) {
	//
	// MISSes with NONE (mostly errors)
	//
	cnt.distribution[Counters::D_NONE].add( my_size, my_time );

	cnt.tcp_miss_none.incr( my_size, my_time );
	cnt.tcp_miss_none_status[ log_status ].incr( my_size, my_time );
	cnt.tcp_miss_none_client[ log_client ].incr( my_size, my_time );
      } else {
	//
	// TCP MISSes
	//
	cnt.distribution[Counters::D_MISS].add( my_size, my_time );

	cnt.tcp_miss.incr( my_size, my_time );
	cnt.tcp_miss_status[ log_status ].incr( my_size, my_time );
	cnt.tcp_miss_client[ log_client ].incr( my_size, my_time );
      }

      //
      // for further TCP and alike traffic, look into the hierarchy
      //
      if ( log_hier && (log._hierarchy & IS_NONE) == 0 ) {
	// any kind of traffic with attached hierarchy code
#ifdef LOOP_ADD
	cnt.hier.incr( my_size, my_time );
#endif
	//---cnt.hier_method[ log_hier ].incr( my_size, my_time );
	// cnt.hier_host[ log_hierhost ].incr( my_size, my_time );
	// cnt.hier_status[ log_hier ][ log_hierhost ].incr(my_size,my_time);
	if ( (log._hierarchy & IS_DIRECT) != 0 ) {
	  // directly to destination transcentral
	  cnt.hier_direct.incr( my_size, my_time );
	  cnt.hier_direct_method[ log_hier ].incr( my_size, my_time );
	  cnt.hier_direct_host[ log_hierhost ].incr( my_size, my_time );
	  cnt.peak_hier_direct[ log_peak ].incr( my_size, my_time );
	} else if ( (log._hierarchy & IS_PEER) != 0 ) {
	  // any peer business (carp, cache digests, etc)
	  cnt.hier_peer.incr( my_size, my_time );
	  cnt.hier_peer_method[ log_hier ].incr( my_size, my_time );
	  cnt.hier_peer_host[ log_hierhost ].incr( my_size, my_time );
	  cnt.hier_peer_status[ log_hier ][ log_hierhost ].incr( my_size, my_time );
	  cnt.peak_hier_peer[ log_peak ].incr( my_size, my_time );
	} else if ( (log._hierarchy & IS_PARENT) != 0 ) {
	  cnt.hier_parent.incr( my_size, my_time );
	  cnt.hier_parent_method[ log_hier ].incr( my_size, my_time );
	  cnt.hier_peer_host[ log_hierhost ].incr( my_size, my_time );
	  cnt.hier_peer_status[ log_hier ][ log_hierhost ].incr( my_size, my_time );
	  cnt.peak_hier_parent[ log_peak ].incr( my_size, my_time );
	} else {
	  fprintf( stderr, 
		   "%lu: unknown hierarchy 0x%08x (not hier counted)!\n", 
		   linenoCopy, log._hierarchy );
	}
      }	// hierarchy traffic
    } // !UDP
  } // big loop

#ifndef LOOP_ADD
  // save cycles by *not* counting deducables values in the loop
  cnt.hier = cnt.hier_direct + cnt.hier_peer + cnt.hier_parent;
  cnt.tcp = cnt.tcp_hit + cnt.tcp_miss_none + cnt.tcp_miss;
  cnt.udp = cnt.udp_hit + cnt.udp_miss;
  for ( CountMap::Iterator i(cnt.internal_client); i.avail(); i++ )
    cnt.internal += i();
  cnt.all = cnt.udp + cnt.tcp + cnt.internal;

  for ( CountMap::Iterator i(cnt.internal_hit_client); i.avail(); i++ )
    cnt.internal_hit += i();
  for ( MyUInt32 i(C_U32(0)); i<cnt.nStatus; ++i ) {
    cnt.internal_miss += cnt.int_miss_status[i];
    cnt.internal_none += cnt.int_none_status[i];
  }
  for ( CountMap::Iterator i(cnt.tcp_hit_client); i.avail(); i++ )
    cnt.tcp_client[i.key()] += i();
  for ( CountMap::Iterator i(cnt.tcp_miss_client); i.avail(); i++ )
    cnt.tcp_client[i.key()] += i();
  for ( CountMap::Iterator i(cnt.tcp_miss_none_client); i.avail(); i++ )
    cnt.tcp_client[i.key()] += i();
#endif

  fprintf( stderr, "# %lu lines processed from this file\n", in->lineno-1 );
  return now() - start;
}
