//
// $Id: global.cc,v 1.14 2001/02/02 10:49:34 voeckler Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    global.cc
//          Thu Aug 05 1999
//
// (c) 1999 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: global.cc,v $
// Revision 1.14  2001/02/02 10:49:34  voeckler
// Minimum() still troublesome!
//
// Revision 1.13  2001/02/02 10:33:58  voeckler
// separated Minimum() into template and inline of its own.
//
// Revision 1.12  2000/08/10 12:38:28  voeckler
// added report interval lookup_report_interval, added minimum client requests
// client_min_reqs_udp, client_min_reqs_tcp and client_min_reqs_int.
//
// Revision 1.11  2000/07/29 22:13:07  voeckler
// added sortDBaseByByte configuration option, which allows to chose whether
// top-N are either volume-sorted, or request sorted.
//
// Revision 1.10  2000/07/27 07:38:22  voeckler
// created new configuration tags for suffix lists, suffix list implementation,
// internal clients, internal client list length, extendend internal list and
// configurable internal path component prefix.
//
// Revision 1.9  1999/11/29 15:04:17  voeckler
// added separate flag to warn about status codes which are neither TCP nor UDP,
// but which are counted as TCP. Formerly, the unknown status flag was also
// responsible for this.
//
// Revision 1.8  1999/10/29 14:06:57  voeckler
// moved global time stamps to counter local stamps into counters module,
// added UTC offset variable (this is junk!) to be fed from the configuration
// file.
//
// Revision 1.7  1999/09/03 08:26:43  voeckler
// adjusted maxfd and nproc to 45 % instead of 50 %.
//
// Revision 1.6  1999/09/02 10:17:03  voeckler
// added helper process name and number, fixed method to obtain the
// maximum number of processes possible.
//
// Revision 1.5  1999/08/27 20:02:02  voeckler
// added code to setDNSChildren to make is dependent on the
// number of open files, the number of processes per user and
// the wanted number of helper processes.
//
// Revision 1.4  1999/08/26 19:41:35  voeckler
// added dnsChildren configuration parameter.
//
// Revision 1.3  1999/08/25 21:16:42  voeckler
// added distribution flag and variable size of large tables to globals.
//
// Revision 1.2  1999/08/22 11:20:49  voeckler
// added flag to indicate a preference of data rates instead of durations.
// added the seconds interval, needed for counters.
//
// Revision 1.1  1999/08/05 21:08:11  voeckler
// Initial revision
//
//
#if defined(__GNUC__) || defined(__GNUG__)
#pragma implementation
#endif

#include <limits.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <time.h>
#include "global.hh"

static const char* RCS_ID =
"$Id: global.cc,v 1.14 2001/02/02 10:49:34 voeckler Exp $";

Global globals;

Global::Global()
  :noIdent(false),clientFQDN(true),preferDatarate(false),
   showDistributions(false),showExtendedInternal(false),
   sortDBaseByByte(false),
   warnUnknownMethod(false),
   warnUnknownHier(false),
   warnUnknownStatus(false),
   warnNoneAsTCP(false),
   warnUnknownScheme(false),
   warnUnknownSuffix(false),
   warnUnknownTLD(false),
   dnsChildren(C_U08(16)),
   irrChildren(C_U08(8)),
   debugClass(0u),debugLevel(0u),
   allowedWhiteSpaces(C_U32(32)),
   warnCrashInterval(C_U32(1800)),
   peakInterval(C_U32(3600)),
   dailyInterval(C_U32(86400)),
   gmtOffset(C_S32(0)),
   progressReports(C_U32(60)),
   dnsPositiveTTL(C_U32(2592000)),
   dnsNegativeTTL(C_U32(604800)),
   irrPositiveTTL(C_U32(2592000)),
   irrNegativeTTL(C_U32(604800)),
   dnsCacheFile(strdup("/var/tmp/dns")),
   dnsHelper(strdup("dnshelper")),
   irrCacheFile(strdup("/var/tmp/irr")),
   irrServer(strdup("whois.ripe.net")),
   irrHelper(strdup("irrhelper")),
   iurlPrefix(strdup("squid-internal-"))
{ 
  memset( tableSize, 0, sizeof(tableSize) );

  tzset();
  time_t now = time(0);
  gmtOffset = now - mktime(gmtime(&now));
  
  if ( (openMax = sysconf( _SC_OPEN_MAX )) == -1 )
    openMax = _POSIX_OPEN_MAX;
#ifdef RLIMIT_NOFILE
  if ( getrlimit( RLIMIT_NOFILE, &maxOpen ) == -1 )
    perror( "# obtaining maxfd limits" );
  else
    fprintf( stderr, "# maxfd hard=%ld, soft=%ld, sys=%ld\n",
	     maxOpen.rlim_max, maxOpen.rlim_cur, openMax );
#else
  fprintf( stderr, "# maxfd sys=%ld\n", openMax );
#endif // RLIMIT_NOFILE



  if ( (childMax = sysconf( _SC_CHILD_MAX )) == -1 )
    childMax = _POSIX_CHILD_MAX;
#ifdef RLIMIT_NPROC
  if ( getrlimit( RLIMIT_NPROC, &maxChild ) == -1 )
    perror( "# obtaining nproc limits" );
  else
    fprintf( stderr, "# nproc hard=%d, soft=%d, sys=%ld\n",
	     maxChild.rlim_max, maxChild.rlim_cur, childMax );
#else
  fprintf( stderr, "# nproc sys=%ld\n", childMax );
#endif // RLIMIT_NPROC
}

Global::~Global()
{
  free((void*) dnsCacheFile );
  free((void*) irrCacheFile );
  if ( irrServer ) free((void*) irrServer );
  free((void*) dnsHelper );
  free((void*) irrHelper );
}

inline
int 
Minimum( int a, int b ) 
#if __GNUG__ >= 2 && __GNUC_MINOR__ >= 8
{ return a <? b; }
#else
{ return a < b ? a : b; }
#endif


void
Global::setChildren( long wanted, MyUInt08& what )
{
  int nopen =
#ifdef RLIMIT_NOFILE
    Minimum(this->openMax, this->maxOpen.rlim_cur) * 0.45;
#else
  this->openMax * 0.45;
#endif

  int nproc =
#ifdef RLIMIT_NPROC
    Minimum(this->childMax,this->maxChild.rlim_cur) * 0.45;
#else
  this->childMax * 0.45;
#endif

  if ( wanted < 1 ) wanted = 16;
  if ( wanted > 255 ) wanted = 255;
  if ( wanted > nproc ) wanted = nproc;
  if ( wanted > nopen ) wanted = nopen;
  what = wanted;
}
