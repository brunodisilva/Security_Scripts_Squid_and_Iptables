//
// $Id: network.hh,v 1.6 2000/08/10 12:49:25 voeckler Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    network.hh
//          Sun Aug 29 1999
//
// (c) 1999 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: network.hh,v $
// Revision 1.6  2000/08/10 12:49:25  voeckler
// added equality operators.
//
// Revision 1.5  2000/08/02 11:57:28  voeckler
// the broadcast shortcut originally taken as a fix for an even stupider
// mistake is also buggy. Now doing the regular comparison of network and
// netmask separately.
//
// Revision 1.4  2000/06/09 09:27:17  voeckler
// fixes for FreeBSD 4.0
//
// Revision 1.3  1999/11/29 15:09:48  voeckler
// bug fix: Changed network addr. key to broadcast addr. as key.
//
// Revision 1.2  1999/09/02 19:38:11  voeckler
// changed code to determine endianess during runtime.
//
// Revision 1.1  1999/09/02 10:11:57  voeckler
// Initial revision
//
//
#ifndef _NETWORK_HH
#define _NETWORK_HH

#if defined(__GNUC__) || defined(__GNUG__)
#pragma interface
#endif

#include <assert.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "typedefs.h"
#include "string.hh"
#include <algorithm>

class Netmask {
  // small helper class, solely to be used via static instance from Network.
public:
  Netmask();
    // purpose: determine endianess at run-time and adjust CIDR table.

  inline MyUInt32 operator[]( int index ) const
    // purpose: accessor to correct endianess CIDR masks
    // returns: 0..32 the correct mask, -1ul otherwise
  {
    return ( index < 0 || index > 32 ) ? C_U32(-1) : current[index];
  }

  inline int find( MyUInt32 mask ) const
    // purpose: find a given netmask
    // returns: 0..32 as CIDR of the netmask, or -1 in case of error.
  {
    const MyUInt32* where = std::find( &current[0], &current[33], mask );
    return ( where == &current[33] ) ? -1 : (where - current);
  }

private:
  static const MyUInt32 cidrtable[2][33];
  const MyUInt32* current;
};

struct Network
  // uses network byte order (big endian)
{
  Network()
    :network(C_U32(0)),netmask(C_U32(-1)) 
    { }
  Network( MyUInt32 netaddr, MyUInt32 maskaddr )
    :network(netaddr & maskaddr),netmask(maskaddr)
    { }
  Network( const String& s );
  String toString() const;

  inline MyUInt32 broadcast( ) const
    { return network | ~netmask; }
  inline bool match( MyUInt32 hostaddr ) const
    { return ((hostaddr & netmask) == network); }
  inline bool operator==( const Network& pair ) const
    { return network == pair.network && netmask == pair.netmask; }
  inline bool operator!=( const Network& pair ) const
    { return network != pair.network || netmask != pair.netmask; }
  inline bool operator<( const Network& pair ) const
    { 
      return ( network == pair.network ) ?
	pair.netmask < netmask :
	network < pair.network;
    }

  static const Netmask cidrmask;
  MyUInt32 network;
  MyUInt32 netmask;
};

#endif // _NETWORK_HH
