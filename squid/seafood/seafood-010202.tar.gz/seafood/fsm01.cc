//
// $Id: fsm01.cc,v 1.3 2000/07/27 07:12:20 voeckler Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    fsm01.cc - first finite state machine
//          Thu Aug 05 1999
//
// (c) 1999 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: fsm01.cc,v $
// Revision 1.3  2000/07/27 07:12:20  voeckler
// added code to return the start of the urlpath.
//
// Revision 1.2  1999/08/06 13:07:08  voeckler
// added stats to fsm01 in order to parse "CONNECT some.host:443" correctly.
//
// Revision 1.1  1999/08/05 21:08:11  voeckler
// Initial revision
//
//
#if defined(__GNUC__) || defined(__GNUG__)
#pragma implementation
#endif

#include <string.h>
#include "ctype.hh"
#include "fsm01.hh"

static const char* RCS_ID =
"$Id: fsm01.cc,v 1.3 2000/07/27 07:12:20 voeckler Exp $";

FSM_01::FSM_01()
{
  memset( cclass, 1, 32 );
  memset( cclass+128, 5, 128 );
  for ( unsigned char ch=32; ch<128; ch++ )
    cclass[ch] = isalnum(ch) ? 4 : 5;
  cclass['/'] = 0;
  cclass['?'] = 1;
  cclass['#'] = 1;
  cclass[':'] = 2;
  cclass['@'] = 3;
}

//    | / | EOS ? # | :     | @      | alnum  | else  
// ---+---+---------+-------+--------+--------+-------
//  0 | 5 |    5    | 3     | 0,s    | 0,s    | 0,s  
//  1 | 5 |    5    | 2     | 1,E(hp)| 1,h    | 1,h   
//  2 | 5 |    5    | 2,p   | 1,E(hp)| 2,p    | 2,p
//  3 | 4 |    5    | 5     | 5      | 2,h=s  | 5
//    |   |         |       |        |   E(s) |
//  4 | 1 |    5    | 5     | 5      | 5      | 5
//
// final=5, s=scheme, h=host, p=port, E()=flush
//
int FSM_01::stateTable[6][6] = {
  { 5, 5, 3, 0, 0, 0 },
  { 5, 5, 2, 1, 1, 1 },
  { 5, 5, 2, 1, 2, 2 },
  { 4, 5, 5, 5, 2, 5 },
  { 1, 5, 5, 5, 5, 5 },
  { 5, 5, 5, 5, 5, 5 }
};

size_t
FSM_01::parse( const char* url, char* const out[3], const size_t size[3] )
  // purpose: extract the three items from a URL
  // paramtr: url (IN): the URL, possibly malformed
  //          out (OUT): array of pointers to three char arrays --> content
  //          size (IN): size of each of the out[x] pointers
  // returns: position of start of path components (excluding absolute slash)
  // warning: results may be empty, but not NULL
{
  char* ptr[3] = { out[0]+0, out[1]+0, out[2]+0 };
  char* end[3] = { out[0]+size[0]-1, out[1]+size[1]-1, out[2]+size[2]-1 };
  int next, state = 0;
  const unsigned char* s = (unsigned char*) url;
  while ( *s && state<5 ) {
    next = stateTable[state][cclass[*s]];

    if ( *s == '@' && ( state == 1 || state == 2 ) ) {
      // stateTable[1..2][3]
      ptr[1] = out[1];
      ptr[2] = out[2];
    } else if ( next == state && state <= 2 && ptr[state] < end[state] ) {
      // stateTable[0][3..5] && stateTable[1..2][4..5]
      *(ptr[state])++ = TOLOWER(*s);
    } else if ( state == 3 && cclass[*s] == 4 ) {
      // stateTable[3][4]
      for ( char* s=out[0]; s < ptr[0] && ptr[1] < end[1]; )
	*(ptr[1])++ = *s++;
      ptr[0] = out[0];
    }

    state = next;
    s++;
  }

  *(ptr[0]) = '\0';
  *(ptr[1]) = '\0';
  *(ptr[2]) = '\0';
  return ( s - ((unsigned char*) url) );
}
