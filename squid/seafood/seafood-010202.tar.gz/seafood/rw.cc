//
// $Id: rw.cc,v 1.1 1999/08/25 21:27:33 voeckler Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    rw.cc
//          Tue Aug 24 1999
//
// (c) 1999 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: rw.cc,v $
// Revision 1.1  1999/08/25 21:27:33  voeckler
// Initial revision
//
//
#if defined(__GNUC__) || defined(__GNUG__)
#pragma implementation
#endif

#include <errno.h>
#include <unistd.h>
#include "rw.hh"

static const char* RCS_ID =
"$Id: rw.cc,v 1.1 1999/08/25 21:27:33 voeckler Exp $";

ssize_t
writen( int fd, const char* buffer, size_t n )
{
  ssize_t wsize;
  size_t  nleft = n;
  const char* ptr = buffer;
  while ( nleft > 0 ) {
    if ( (wsize=write(fd,ptr,nleft)) < 0 ) {
      if ( errno == EINTR ) continue;
      else return wsize;
    }

    nleft -= wsize;
    ptr   += wsize;
  }
  return n; 
}

ssize_t
readn( int fd, char* buffer, size_t n )
{
  ssize_t rsize;
  size_t  nleft = n;
  char* ptr = buffer;
  while ( nleft > 0 ) {
    if ( (rsize=read(fd,ptr,nleft)) < 0 ) {
      if ( errno == EINTR ) continue;
      else return rsize;
    } else if ( rsize == 0 ) break;

    nleft -= rsize;
    ptr   += rsize;
  }
  return ( n - nleft );
}

ssize_t
readline( int fd, char* buffer, size_t max )
{
  char    ch;
  char* ptr = buffer;
  size_t  n;
  ssize_t rsize;

  for ( n=1; n<max; ++n ) {
  again:
    if ( (rsize=read(fd,&ch,1)) == 1 ) {
      // regular input
      *ptr++ = ch;
      if ( ch == '\n' ) break;
    } else if ( rsize == 0 ) {
      // EOF
      if ( n == 1 ) return 0;
      else break;
    } else {
      // error
      if ( errno == EINTR ) goto again;
      return -1;
    }
  }
  *ptr = 0;
  return n;
}
