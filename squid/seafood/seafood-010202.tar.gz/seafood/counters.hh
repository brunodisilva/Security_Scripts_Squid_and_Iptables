//
// $Id: counters.hh,v 1.7 2000/08/10 12:40:08 voeckler Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    counters.hh
//          Thu Aug 05 1999
//
// (c) 1999 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: counters.hh,v $
// Revision 1.7  2000/08/10 12:40:08  voeckler
// added counters for the TCP internal request TCP status (HME).
//
// Revision 1.6  2000/07/27 07:14:23  voeckler
// added suffix counter support, and all internal object counters.
//
// Revision 1.5  1999/12/24 00:13:53  voeckler
// *** empty log message ***
//
// Revision 1.4  1999/10/29 14:01:18  voeckler
// added time stamps (FIXME: this is not perfect).
//
// Revision 1.3  1999/09/01 21:58:38  voeckler
// the string map iterator type is now part of the strmap itself.
//
// Revision 1.2  1999/08/25 21:15:06  voeckler
// added distribution count to counters.
//
// Revision 1.1  1999/08/05 21:02:33  voeckler
// Initial revision
//
//
#ifndef _COUNTERS_HH
#define _COUNTERS_HH

#if defined(__GNUC__) || defined(__GNUG__)
#pragma interface
#endif

#include <string.h>
#include "typedefs.h"
#include "strmap.hh"
#include "counter.hh"
#include "logline.hh"
#include "offvector.hh"

typedef StringMap<Counter,false> CountMap;
typedef StringMap<CountMap,false> CountMMap;
typedef StringMap<CountMMap,false> CountMMMap;

typedef Counter* CounterPtr;
typedef OffsetVector<Counter> PeakVec;

inline
int
intlog2( MySInt32 x )
{
  register int result = 0;
  while ( x > 0 ) {
    x >>= 1;
    ++result;
  }
  return result;
}

inline
int
intlog2( MyUInt64 x )
{
  register int result = 0;
  while ( x ) {
    x >>= 1;
    ++result;
  }
  return result;
}

class Distribution {
public:
  Distribution();

  inline void add( MyUInt64 size, MySInt32 duration )
    {
      int log2size = intlog2(size);
      int log2time = intlog2(duration);
      ++timeDist[log2time];
      ++sizeDist[log2size];
      ++timeSizeDist[log2time][log2size];
    }

  MyUInt32  timeDist[32];
  MyUInt32  sizeDist[32];
  MyUInt32  timeSizeDist[32][32];
};

class Counters {
public:
  Counters();
  ~Counters();

  MyUInt32  nMethod;
  MyUInt32  nStatus;
  MyUInt32  nHier;
  MyUInt32  nScheme;
  MyUInt32  nSuffix;
  MyUInt32  nMedia;
  MyUInt32* nSubtype;

  MyUInt32  startTime;	// start stamp of this counter collection
  MyUInt32  finalTime;	// final stamp of this counter collection

  PeakVec   peak_udp;
  PeakVec   peak_udp_hit;
  PeakVec   peak_tcp;
  PeakVec   peak_tcp_hit;
  PeakVec   peak_int;
  PeakVec   peak_int_hit;
  PeakVec   peak_hier_direct;
  PeakVec   peak_hier_parent;
  PeakVec   peak_hier_peer;

  enum TcpStatus { D_HIT, D_MISS, D_NONE, D_END };
  Distribution distribution[D_END]; // time and size distribution counters
  
  Counter   all;		// count all traffic seen
  Counter   udp;		// count all UDP traffic
  Counter   tcp;		// count all TCP traffic
  Counter*  methods;		// count all methods
  Counter*  hit_methods;	// count all HIT methods

  CountMap  udp_client;		// count UDP by requesting client

  Counter   udp_hit;		// count UDP HITs
  CountMap  udp_hit_client;	// count UDP HITs by requesting client
  Counter*  udp_hit_status;	// count UDP HITs by UDP status

  Counter   udp_miss;		// count UDP MISSes
  Counter*  udp_miss_status;	// count UDP MISSes by UDP status

  Counter   internal;		// count TCP internal 
  CountMap  internal_host;	// count TCP internal host
  CountMMap internal_path;	// count TCP internal host + paths
  CountMMMap internal_hpc;	// count TCP internal host + path + client 
  CountMap  internal_client;	// count TCP internal clients

  Counter   internal_hit;	// count TCP internal 
  CountMap  internal_hit_host;	// count TCP internal host
  CountMMap internal_hit_path;	// count TCP internal host + paths
  CountMMMap internal_hit_hpc;	// count TCP internal host + path + client 
  CountMap  internal_hit_client; // count TCP internal clients

  Counter*  int_hit_status;	// count TCP internal hits by TCP status
  Counter*  int_miss_status;	// count TCP internal miss by TCP status
  Counter   internal_miss;	// count TCP internal miss
  Counter*  int_none_status;	// count TCP internal none by TCP status
  Counter   internal_none;	// count TCP internal none

  CountMap  tcp_client;		// count TCP by requesting client
  CountMap  tcp_sld;		// count TCP by 2nd level domain
  CountMap  tcp_tld;		// count TCP by top level domain
  Counter*  tcp_scheme;		// count TCP by scheme
  Counter*  tcp_suffix;         // count TCP by suffix
  Counter*  tcp_mime;		// count TCP by media type
  Counter** tcp_submime;	// count TCP by media subtype for type
  Counter*  tcp_ports;		// count TCP destination ports

  Counter   tcp_hit;		// count TCP HITs
  Counter*  tcp_hit_hier;	// count TCP HITs by hierarchy method
  Counter*  tcp_hit_status;	// count TCP HITs by status tag
  CountMap  tcp_hit_client;	// count TCP HITs by requesting client
  CountMap  tcp_hit_sld;	// number of HITs for 2nd level domains
  CountMap  tcp_hit_tld;	// number of HITs for top level domains
  Counter*  tcp_hit_scheme;	// count TCP HITs by scheme
  Counter*  tcp_hit_suffix;	// count TCP HITs by suffix
  Counter*  tcp_hit_mime;	// count TCP HITs by media type
  Counter** tcp_hit_submime;	// count TCP HITs by media subtype for type
  CountMap  tcp_hit_direct_host; // count TCP DIRECT HITs by hierarchy host
  Counter   tcp_miss_none;	// count TCP ERR_* or NONE
  Counter*  tcp_miss_none_status; // count TCP ERR_* or NONE by status
  CountMap  tcp_miss_none_client; // count TCP ERR_* or NONE by requestor
  
  Counter   tcp_miss;		// count TCP MISSes
  Counter*  tcp_miss_status;	// count TCP MISSes by status
  CountMap  tcp_miss_client;	// count TCP MISSes by requesting client

  Counter   hier;		// count TCP !NONE hierarchy codes
  Counter   hier_direct;	// count TCP direct traffic
  Counter*  hier_direct_method;	// count TCP direct hier methods
  CountMap  hier_direct_host;	// !!! count TCP direct by destination host

  Counter   hier_peer;		// count TCP peers requests
  Counter*  hier_peer_method;	// count TCP peers by hier method

  CountMap  hier_peer_host;	// count TCP peers+parents by peer host
  CountMap* hier_peer_status;	// count TCP peers+parents by hmethod and dst

  Counter   hier_parent;	// count TCP parent requests
  Counter*  hier_parent_method;	// count TCP parents by method

private:
  // disallow these
  Counters( const Counters& );
  Counters& operator=( const Counters& );
};

#endif // _COUNTERS_HH
