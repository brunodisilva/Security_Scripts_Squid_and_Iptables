//
// $Id: gdbm.cc,v 1.2 2000/07/27 07:11:36 voeckler Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    gdbm.cc
//          Sun Sep 12 1999
//
// (c) 1999 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: gdbm.cc,v $
// Revision 1.2  2000/07/27 07:11:36  voeckler
// added some move verbose error messaging.
//
// Revision 1.1  1999/10/29 13:57:22  voeckler
// Initial revision
//
//
#if defined(__GNUC__) || defined(__GNUG__)
#pragma implementation
#endif

#include <assert.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "gdbm.hh"

static const char* RCS_ID =
"$Id: gdbm.cc,v 1.2 2000/07/27 07:11:36 voeckler Exp $";

GDBM::GDBM( const char* fn, bool readOnly, bool fastMode )
  :filename( strdup(fn) ),
   database( gdbm_open( filename, 0, 
			(readOnly ? GDBM_READER : GDBM_WRCREAT) |
			(fastMode ? GDBM_FAST : 0),
			0666, 0 ) )
{
  assert( filename );
  if ( database == NULL ) {
    fputs( gdbm_strerror(gdbm_errno), stderr );
    fputc( '\n', stderr );
    perror( "gdbm system error" );
  }
  assert( database );
}

GDBM::GDBM( const String& s, bool readOnly, bool fastMode )
  :filename( strdup(s.c_str()) ),
   database( gdbm_open( filename, 0, 
			(readOnly ? GDBM_READER : GDBM_WRCREAT) |
			(fastMode ? GDBM_FAST : 0),
			0666, 0 ) )
{
  assert( filename );
  if ( database == NULL ) {
    fputs( gdbm_strerror(gdbm_errno), stderr );
    fputc( '\n', stderr );
    perror( "gdbm system error" );
  }
  assert( database );
}

GDBM::~GDBM()
{
  gdbm_close(database);
  if ( filename ) free((void*) filename);
}

bool 
GDBM::exists( const String& key ) const
  // purpose: check for existence of key w/o allocating memory for it
  // paramtr: key (IN): key to check for
  // results: true: key was in database, false: key was *not* in database
{
  datum dbkey = { (char*) key.c_str(), key.length()+1 };
  return gdbm_exists( database, dbkey );
}

String 
GDBM::fetch( const String& key ) const
  // purpose: obtain the value for a key
  // paramtr: key (IN): key to fetch from database
  // returns: value fetched from database, or empty string, if key not found
{
  datum dbkey = { (char*) key.c_str(), key.length()+1 };
  datum value = gdbm_fetch( database, dbkey );

  String result;
  if ( value.dptr != 0 ) {
    // FIXME: sanity checks, if string terminator NUL is missing
    result = String( value.dptr );
    free((void*) value.dptr );
  }
  return result;
}

bool 
GDBM::insert( const String& key, String value, bool replace )
  // purpose: insert a new value or overwrite an existing value
  // paramtr: key (IN): key to associate with
  //          value (IN): value to store
  //          replace (IN): true: overwrite existing values,
  //                        false: do not overwrite existing values
  // returns: true, if key was inserted into database,
  //          false, if no key was inserted (e.g. key exists && ! replace )
{
  datum dbkey = { (char*) key.c_str(), key.length()+1 };
  datum dbvalue = { (char*) value.c_str(), value.length()+1 };
  return ( gdbm_store( database, dbkey, dbvalue, 
		       replace ? GDBM_REPLACE : GDBM_INSERT ) == 0 );
}

bool 
GDBM::erase( const String& key )
  // purpose: remove a key/value pair from the database
  // paramtr: key (IN): key to remove with its value
  // returns: true, if the delete was successful
{
  datum dbkey = { (char*) key.c_str(), key.length()+1 };
  return ( gdbm_delete( database, dbkey ) == 0 );
}

bool 
GDBM::setFastMode( bool fastMode )
{
  int what = fastMode ? 1 : 0;
  return ( gdbm_setopt( database, GDBM_FASTMODE, &what, sizeof(int) ) == 0 );
}

String 
GDBM::errmsg( void ) const
{
  return String( gdbm_strerror(gdbm_errno) );
}

String 
GDBM::version( void ) const
{
  return String( gdbm_version );
}
