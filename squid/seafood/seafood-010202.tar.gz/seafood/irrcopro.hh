//
// $Id: irrcopro.hh,v 1.3 1999/09/02 10:06:58 voeckler Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    irrcopro.hh
//          Mon Aug 30 1999
//
// (c) 1999 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: irrcopro.hh,v $
// Revision 1.3  1999/09/02 10:06:58  voeckler
// added debugging mode and statistics pointer to ctor, added virtual
// functions to be used during querying, added internal network database
// for host address matches.
//
// Revision 1.2  1999/08/31 09:53:27  voeckler
// managed to derive a concrete class from a template base.
//
// Revision 1.1  1999/08/31 08:46:15  voeckler
// Initial revision
//
//
#ifndef _IRRCOPRO_HH
#define _IRRCOPRO_HH

#if defined(__GNUC__) || defined(__GNUG__)
#pragma interface
#endif

#include "cache.hh"
#include "copro.hh"
#include "cotempl.hh"
#include "irritem.hh"
#include "network.hh"
#include "nwset.hh"

typedef CoProTemplate< IRRItem > IRRCoPro;

class IRRCoProcess : public IRRCoPro {
public:
  typedef IRRCoPro::ItemMap IRRItemMap;
  inline IRRCoProcess( size_t n, const char* prg, char* const argv[],
		       bool debugClass, short debugLevel,
		       const BaseCache* cache )
    :IRRCoPro(n,prg,argv,debugClass,debugLevel,cache)
    { }
  virtual ~IRRCoProcess();

  virtual void addToMap( IRRItemMap& map, const String& key, IRRItem& value );
  // purpose: if the key is a host address, transform the address into a 
  //          network, and add it to the map *and* to the set of networks 
  // paramtr: map (IO): map to insert into
  //          key (IN): key of item to add
  //          value (IN): value to add - must not be const

  virtual bool isKnown( const IRRItemMap& map, const String& key );
  // purpose: if the key is a host address, find a match in the set of
  //          networks, otherwise find the match in the map.
  // paramtr: map (IN): map to check for the key
  //          key (IN): key to check for
  // returns: true, if the key was found.

private:
  // set of network/netmask pairs. This set will be checked back with
  // any host address look up for matches. If a match is found, the
  // look up is not necessary.
  NetworkSet networks;
};

#endif // _IRRCOPRO_HH
