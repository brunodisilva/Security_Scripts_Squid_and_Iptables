package Scripts;		# Hi emacs, please use -*-perl-*- mode.
require 5.003;
use strict;
use vars qw(@ISA @EXPORT @EXPORT_OK @day @mon);
use POSIX;

use Exporter;
@ISA = qw(Exporter);
@EXPORT = qw(parseQueryString now);
@EXPORT_OK = qw(@day @mon);

@day = qw( Sun Mon Tue Wed Thu Fri Sat );
@mon = qw( Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec );

sub parseQueryString {
    # purpose: parse options from QUERY_STRING and put all into an assoc
    # warning: you have to sanitize the options yourself!
    # returns: an assoc containing the name to value pairs.
    #
    my $query = shift || $ENV{QUERY_STRING};

    my (%form,$key);
    foreach ( split( /&/, $query ) ) {
	($key,$_) = split /=/;
	s/\+/ /go;
	s/%([0-9A-F]{2})/pack('C',hex($1))/eig;
	if ( exists $form{$key} ) {
	    # already there, check for repetitions
	    if ( ref $form{$key} ) {
		# already repeated, just add
		push @{$form{$key}}, $_;
	    } else {
		# make an array ref of it
		$form{$key} = [ $form{$key}, $_ ];
	    }
	} else {
	    # new item
	    $form{$key} = $_;
	}
    }
    %form;
}

sub now (;$) {
    # purpose: return string containing the current time as GMT in RFC format
    my @x = gmtime(shift || time());
    strftime( "%a, %d %b %Y %H:%M:%S GMT", @x );
#    sprintf("%3s, %2d %3s %4d %02d:%02d:%02d GMT",
#	    $day[$x[6]], $x[3], $mon[$x[4]], $x[5]+1900, @x[2,1,0] );
}

BEGIN {
    select((select(STDOUT),$|=1)[$[]); # make stdout unbuffered
    select((select(STDERR),$|=1)[$[]); # dito for stderr
}

1;
