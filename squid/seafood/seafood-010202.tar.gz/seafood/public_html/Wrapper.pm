package Wrapper;
require 5.005;
use strict;
use vars qw(@ISA @EXPORT @EXPORT_OK);

use DBI;
use Exporter;
@ISA = qw(Exporter);
@EXPORT_OK = qw(loginOra loginPg);
@EXPORT = qw(database_login);

# FIXME: what database are you using?!
sub database_login { &loginOra8; }

sub loginOra7 {
    # purpose: recreate Oracle 7 environment and login into Oracle
    my $sid = die "use your SID here";
    my $user = die "use your DBUSER here";
    my $pass = die "use your DBPASS here";

    # recreate Oracle environment
    $ENV{ORACLE_BASE}='/opt/oracle/app/oracle';
    $ENV{ORACLE_HOME}='/opt/oracle/app/oracle/product/7.3.3';
    $ENV{NLS_LANG}='American_America.we8iso8859p1';
    $ENV{TWO_TASK} = $sid;
    delete $ENV{ORACLE_SID};
    $ENV{PATH} .= ':/opt/oracle/app/oracle/product/7.3.3/bin';

    # open the DB
    # WARNING: This relies on tnsname.ora to be correctly set up.
    # The advantage is that your db admin may migrate the db server
    # without you needing to correct this script.
    $Apache::Registry::sf =
	DBI->connect( "dbi:Oracle:$sid", $user, $pass ) or
	    die "connect(Oracle)";
}

sub loginOra8 {
    # purpose: recreate Oracle 8 environment and login into Oracle
    my $sid = die "use your SID here";
    my $user = die "use your DBUSER here";
    my $pass = die "use your DBPASS here";

    # recreate Oracle environment
    $ENV{ORACLE_BASE}='/opt/oracle/app/oracle';
    $ENV{ORACLE_HOME}='/opt/oracle/app/oracle/product/8.1.5';
    if ( 1 ) {
	$ENV{ORACLE_SID} = 'RVS.rvs.uni-hannover.de';
    } else {
	$ENV{TWO_TASK} = $sid;
	delete $ENV{ORACLE_SID};
    }
    $ENV{PATH} .= ':' . $ENV{ORACLE_HOME} . '/bin';

    # open the DB
    # WARNING: This relies on tnsname.ora to be correctly set up.
    # The advantage is that your db admin may migrate the db server
    # without you needing to correct this script.
    $Apache::Registry::sf =
	DBI->connect( "dbi:Oracle:$sid", $user, $pass ) or
	    die "connect(Oracle)";
}

sub loginPg {
    my $host = `hostname` ne "xxgrafzahl\n" ? 'localhost' : 'champux.sean.de';
    my $user = 'voeckler';
    $ENV{PATH}=$ENV{PATH} . ':/usr/lib/pgsql/bin';

    # open the DB
    $Apache::Registry::sf =
	DBI->connect( "dbi:Pg:dbname=$user\@$host:5432", $user, undef ) or
	    die "connect(Pg)";
}

1;
