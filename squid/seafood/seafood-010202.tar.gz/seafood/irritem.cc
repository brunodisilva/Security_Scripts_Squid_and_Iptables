//
// $Id: irritem.cc,v 1.3 1999/10/29 13:49:31 voeckler Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    irritem.cc
//          Fri Aug 27 1999
//
// (c) 1999 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: irritem.cc,v $
// Revision 1.3  1999/10/29 13:49:31  voeckler
// added some unused code for test purposes.
//
// Revision 1.2  1999/09/01 22:02:49  voeckler
// added clear() method, fixed string conversion bugs, added
// length in front of item.
//
// Revision 1.1  1999/08/27 20:52:16  voeckler
// Initial revision
//
//
#if defined(__GNUC__) || defined(__GNUG__)
#pragma implementation
#endif

#include <assert.h>
#include "ctype.hh"
#include "string.hh"
#include "irritem.hh"

static const char* RCS_ID =
"$Id: irritem.cc,v 1.3 1999/10/29 13:49:31 voeckler Exp $";

IRRItem& 
IRRItem::operator=( const IRRItem& irr )
{
  if ( &irr != this ) {
    empty = irr.empty;
    expires = irr.expires;
    item = irr.item;
  }
  return *this;
}

bool 
IRRItem::operator==( const IRRItem& irr )
{
  if ( empty ) {
    // a is empty
    return irr.empty;
  } else {
    // a has some value
    if ( irr.empty ) return false;
    else return item == irr.item;
  }
}

void
IRRItem::clear()
{
  item = String();
  empty = true;
  expires = 0;
}

bool 
IRRItem::operator!=( const IRRItem& irr )
{
  if ( empty ) {
    // a is empty
    return !irr.empty;
  } else {
    // a has some value
    if ( irr.empty ) return true;
    else return item != irr.item;
  }
}

String
IRRItem::toString( void ) const
{
  char temp[32];
  sprintf( temp, "(%lu", expires );

  String result(temp);
  if ( ! empty ) {
    sprintf( temp, ";%u:", item.length() );
    result += temp + item;
  }
  result += ")";
  return result;
}

inline
MyUInt32
number( const char*& s )
{
  MyUInt32 result = 0;
  while ( ISDIGIT(*s) ) {
    result = 10*result + ( *s - '0' );
    s++;
  }
  return result;
}

IRRItem::IRRItem( const char* s )
  :BaseItem(0,true)
{
  assert( s != 0 );
  while ( ISSPACE(*s) ) ++s;
 
  if ( *s == '(' ) {
    ++s; // skip '('
    expires = number(s);
    if ( *s == ';' ) {
      empty = false;
      
      ++s; // skip ';'
      size_t length = number(s);
      ++s; // skip ':'
      if ( length > strlen(s) ) length = strlen(s);

      const char* t = s;
      const char* e = t+length;
      while ( *s && s < e && *s != '\n' ) ++s;
      item = String( t, s-t );
    } else if ( *s == ')' ) {
      empty = true;
    }
  }
}

#if 0

inline
MyUInt32
number( const String& s, int& i )
{
  MyUInt32 result = 0;
  while ( ISDIGIT(s[i]) ) {
    result = 10*result + ( s[i] - '0' );
    i++;
  }
  return result;
}

IRRItem::IRRItem( const String& s )
  :BaseItem(0,true)
{
  int i=0;
  while ( ISSPACE(s[i]) ) ++i;
 
  if ( s[i] == '(' ) {
    ++i; // skip '('
    expires = number(s,i);
    if ( s[i] == ';' ) {
      empty = false;
      
      ++i; // skip ';'
      size_t length = number(s,i);
      ++i; // skip ':'
      if ( length > s.length()-i ) length = s.length()-i;

      int t = i;
      int e = t+length;
      while ( s[i] && i < e && s[i] != '\n' ) ++i;
      item = s.substring( t, i-t );
    } else if ( s[i] == ')' ) {
      empty = true;
    }
  }
}

#endif
