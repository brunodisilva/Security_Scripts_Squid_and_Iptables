//
// $Id: counter.hh,v 1.3 1999/10/29 14:00:45 voeckler Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    counter.hh
//          Sun Jul 18 1999
//
// (c) 1998,99 Lehrgebiet Rechnernetze und Verteilte Systeme
//             Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: counter.hh,v $
// Revision 1.3  1999/10/29 14:00:45  voeckler
// *** empty log message ***
//
// Revision 1.2  1999/08/23 12:43:15  voeckler
// removed unecessary header file.
//
// Revision 1.1  1999/08/05 21:02:33  voeckler
// Initial revision
//
//
#ifndef _COUNTER_HH
#define _COUNTER_HH

#if defined(__GNUC__) || defined(__GNUG__)
#pragma interface
#endif

#include "typedefs.h"

class Counter {
public:
  inline Counter()
    :_reqs(C_U32(0)),_size(C_U64(0)),_time(0.0)
    { }
  inline Counter( const Counter& f )
    :_reqs(f._reqs),_size(f._size),_time(f._time)
    { }
  inline Counter( MyUInt32 a, MyUInt64 b, double c )
    :_reqs(a),_size(b),_time(c)
    { }
  inline ~Counter()
    { }

  inline MyUInt32 reqs() const
    { return _reqs; }
  inline MyUInt64 size() const
    { return _size; }
  inline double time() const
    { return _time; }

  inline void incr( MyUInt64 s, double t )
    { _reqs++; _size += s; _time += t; }
  inline void incr( MyUInt32 r, MyUInt64 s, double t )
    { _reqs += r; _size += s; _time += t; }
  inline void incr( const Counter& f )
    { _reqs += f._reqs; _size += f._size; _time += f._time; }

  inline bool operator==( const Counter& f )
    { return ( _reqs == f._reqs && _size == f._size ); }
  inline bool operator!=( const Counter& f )
    { return ( _reqs != f._reqs || _size != f._size ); }
  
  inline Counter operator+( const Counter& f )
    { return Counter( _reqs + f._reqs, _size + f._size, _time + f._time ); }
  inline Counter& operator+=( const Counter& f )
    { 
      _reqs += f._reqs;
      _size += f._size;
      _time += f._time;
      return *this;
    }
  friend Counter operator+( const Counter& a, const Counter& b )
    { return Counter( a._reqs+b._reqs, a._size+b._size, a._time+b._time ); }
protected:
  MyUInt32 _reqs;
  MyUInt64 _size;
  double   _time;
};

#endif // _COUNTER_HH
