//
// $Id: strmap.hh,v 1.4 2000/07/27 07:08:02 voeckler Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    strmap.hh
//          Thu Aug 05 1999
//
// (c) 1999 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: strmap.hh,v $
// Revision 1.4  2000/07/27 07:08:02  voeckler
// remove explicit assignment of zero to basic types, since
// the compiler does not know what to do with that (cannot
// generate correct code, if the type is not basic).
//
// Revision 1.3  1999/09/01 21:57:02  voeckler
// added exists() method.
//
// Revision 1.2  1999/08/27 20:53:39  voeckler
// added copy ctor, assignment operator, a clear() method, and a way
// to extend a map with another map plus the operator+ for maps.
//
// Revision 1.1  1999/08/06 13:41:20  voeckler
// Initial revision
//
//
#ifndef _STRMAP_HH
#define _STRMAP_HH

#if defined(__GNUC__) || defined(__GNUG__)
#pragma interface
#else
#ifndef HAS_BOOL
#define HAS_BOOL
typedef int bool;
#define false 0
#define true  1
#endif
#endif

#include <assert.h>
#include "string.hh"
#include "primetab.hh"

template <class Value, bool Basic> class StringMapIterator;

template <class Value, bool Basic> class StringMap {
  //
  // requirements for 'Value' to make it as value type for the map:
  //
  // 1) needs a moderately fast array c'tor.
  // 2) the default empty c'tor yields a valid element.
  // 3) Basic == true --> memset() can be applied to init vector
  //    Basic == false --> default ctor will init vector elments
  //
  size_t       count;
  short        primeref;
  size_t       primenum;
  size_t       doublenum;
  String*      keytable;
  Value*       valuetable;
  char*        statustable;

public:
  StringMap( short start = 0 )
    :count(0),primeref( start >= 0 && start < SIZE ? start : 0 ),
     primenum(primes[primeref]),
     doublenum(fillup[primeref])
  {
    keytable = new String[primenum];
    valuetable = new Value[primenum];
    statustable = new char[primenum];
    memset( statustable, 0, primenum );
    if ( Basic ) memset( valuetable, 0, sizeof(Value) * primenum );
  }

  StringMap( const StringMap& m )
    :count(m.count),primeref(m.primeref),
     primenum(primes[primeref]),
     doublenum(fillup[primeref])
  {
    keytable = new String[primenum];
    valuetable = new Value[primenum];
    if ( Basic ) memset( valuetable, 0, sizeof(Value) * primenum );
    statustable = new char[primenum];
    for ( size_t i=0; i<primenum; ++i ) {
      if ( (statustable[i] = m.statustable[i]) ) {
	keytable[i] = m.keytable[i];		// shallow copy of strings
	valuetable[i] = m.valuetable[i];	// depends on assign op.
//    } else {
//      if ( Basic ) valuetable[i] = 0;		// init basic values to zero
      }
    }
  }

  StringMap& operator=( const StringMap& m )
  {
    if ( this != &m ) {
      delete[] statustable;
      delete[] valuetable;
      delete[] keytable;

      count = m.count;
      primeref = m.primeref;
      primenum = primes[primeref];
      doublenum = fillup[primeref];

      keytable = new String[primenum];
      valuetable = new Value[primenum];
      statustable = new char[primenum];
      if ( Basic ) memset( valuetable, 0, sizeof(Value) * primenum );

      for ( size_t i=0; i<primenum; ++i ) {
	if ( (statustable[i] = m.statustable[i]) ) {
	  keytable[i] = m.keytable[i];		// shallow copy of strings
	  valuetable[i] = m.valuetable[i];	// depends on assign op.
//	} else {
//	  if ( Basic ) valuetable[i] = 0;	// init basic values to zero
	}
      }
    }
    return *this;
  }

  ~StringMap()
  {
    delete[] statustable;
    delete[] valuetable;
    delete[] keytable;
  }

  inline size_t size() const { return count; }

  void clear( short start = 0 ) 
  {
    if ( count ) {
      delete[] statustable;
      delete[] valuetable;
      delete[] keytable;
    
      count = 0;
      primeref = ( start >= 0 && start < SIZE ? start : 0 );
      primenum = primes[primeref];
      doublenum = fillup[primeref];
      keytable = new String[primenum];
      valuetable = new Value[primenum];
      statustable = new char[primenum];
      memset( statustable, 0, primenum );
      if ( Basic ) memset( valuetable, 0, sizeof(Value) * primenum );    
    }
  }

  inline
  bool exists( const String& s ) const
    // purpose: check for the existence of a string in the map
  {
    size_t hashvalue = indexOf(s);
    return ( statustable[hashvalue] != 0 && keytable[hashvalue] == s );
  }

  inline 
  Value operator[]( const String& s ) const
    // purpose: right hand side operator, read only, no insertions
  {
    size_t hashvalue = indexOf(s);
    return statustable[hashvalue] ? valuetable[hashvalue] : Value();
  }

#if 0 // superflous, as const char* --> const String& via String ctor
  inline
  bool exists( const char* s ) const
    // purpose: check for the existence of a string in the map
  {
    size_t hashvalue = indexOf(s);
    return ( statustable[hashvalue] != 0 && keytable[hashvalue] == s );
  }

  inline 
  Value operator[]( const char* s ) const
    // purpose: right hand side operator, read only, no insertions
  {
    size_t hashvalue = indexOf(s);
    return statustable[hashvalue] ? valuetable[hashvalue] : Value();
  }
#endif

  inline 
  Value operator[]( size_t hashvalue ) const
    // purpose: right hand side operator, read only, no insertions
  {
    return statustable[hashvalue] ? valuetable[hashvalue] : Value();
  }

  inline
  String key( size_t hashvalue ) const
    // purpose: obtain key for direct access
  {
    return statustable[hashvalue] ? keytable[hashvalue] : String();
  }

  inline 
  Value& operator[]( const String& s )
    // purpose: left hand side operator, do insertions
  {
    size_t hashvalue = indexOf(s);
    if ( !statustable[hashvalue] ) {
      // fit new entry into maps, do remapping, if necessary
      if ( ++count > doublenum ) {
	rehash( primeref+1 );
	hashvalue = indexOf(s);
      }
      keytable[hashvalue] = s;
      statustable[hashvalue] = 1;
      valuetable[hashvalue] = Value();
    }
    return valuetable[hashvalue];
  }

  void replace( const String& s, Value& v )
    // purpose: insert new values, replace already existing values
  {
    size_t hashvalue = indexOf(s);
    if ( !statustable[hashvalue] ) {
      // fit new entry into maps, do remapping, if necessary
      if ( ++count > doublenum ) {
	rehash( primeref+1 );
	hashvalue = indexOf(s);
      }
      keytable[hashvalue] = s;
      statustable[hashvalue] = 1;
    }
    valuetable[hashvalue] = v;
  }

  size_t indexOf( const String& s ) const
    // purpose: find position where s fits into, or already exists
  {
    size_t raw = s.hash();
    size_t hashvalue = raw % primenum;
    if ( statustable[hashvalue] && s != keytable[hashvalue] ) {
      size_t doublehash = ( raw % doublenum ) | 0x01l;
      hashvalue = (hashvalue+doublehash) % primenum;
      while ( statustable[hashvalue] && s != keytable[hashvalue] ) 
	hashvalue = (hashvalue+doublehash) % primenum;
    }
    return hashvalue;
  }

  void rehash( short newref )
    // purpose: increase hashtable size
  {
    assert( newref > 0 && newref < SIZE && newref != primeref );
    size_t newprime( primes[newref] );
    size_t newfillup( fillup[newref] );
    String* newkeys = new String[newprime];
    Value* newvals = new Value[newprime];
    if ( Basic ) memset( newvals, 0, sizeof(Value) * newprime );
    char*   newstat = new char[newprime];
    memset( newstat, 0, newprime );

    for ( unsigned i=0; i<primenum; i++ )
      if ( statustable[i] ) {
	size_t raw = keytable[i].hash();
	size_t hashvalue = raw % newprime;
	size_t doublehash = ( raw % newfillup ) | 0x01l;
	while ( newstat[hashvalue] ) 
	  hashvalue = (hashvalue+doublehash) % newprime;
	newkeys[hashvalue] = keytable[i];
	newvals[hashvalue] = valuetable[i];
	newstat[hashvalue] = 1;
      }
    
    delete[] statustable;
    delete[] keytable;
    delete[] valuetable;

    statustable = newstat;
    keytable = newkeys;
    valuetable = newvals;
    primeref = newref;
    primenum = newprime;
    doublenum = newfillup;
  }

  friend StringMapIterator<Value,Basic>;
  typedef StringMapIterator<Value,Basic> Iterator;

  StringMap& operator+=( const StringMap& m )
  {
    if ( this != &m )
      for ( StringMapIterator<Value,Basic> i(m); i.avail(); i++ )
        replace( i.key(), i.value() );
    return *this;
  }

  StringMap operator+( const StringMap& m ) const
  {
    size_t n = m.size() + size();
    size_t p = 0; 
    while ( fillup[p] <= n && p < SIZE-1 ) p++;

    StringMap result(p);
    for ( StringMapIterator<Value,Basic> i(*this); i.avail(); i++ )
      result[ i.key() ] = i.value();
    for ( StringMapIterator<Value,Basic> i(m); i.avail(); i++ )
      result[ i.key() ] = i.value();
    return result;
  }
};


template <class Value, bool Basic>
class StringMapIterator {
public:
  inline 
  StringMapIterator( const StringMap<Value,Basic>& m )
    :map(&m),current(0)
  { while ( current < primes[map->primeref] && 
	    !map->statustable[current] ) current++; }

  inline bool avail( void ) const
  { return ( current < primes[map->primeref] ); }

  inline void operator++( int )
  { 
    do { current++; } 
    while ( current < primes[map->primeref] && !map->statustable[current] ); 
  }

  inline Value& operator()( void ) const
  { return map->valuetable[current]; }

  inline const String& key( void ) const
  { return map->keytable[current]; }

  inline Value& value( void ) const
  { return map->valuetable[current]; }
  
  inline size_t indexOf( void ) const
  { return current; }

protected:
  const StringMap<Value,Basic>* map;
  size_t current;
};

#endif // _STRMAP_HH
