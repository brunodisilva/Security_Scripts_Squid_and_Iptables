//
// $Id: generic.hh,v 1.2 2000/08/10 12:52:46 voeckler Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    generic.hh
//          Thu Jul 27 2000
//
// (c) 2000 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: generic.hh,v $
// Revision 1.2  2000/08/10 12:52:46  voeckler
// added minimum request option to table dumps, added HME count dumps to the
// generics.
//
// Revision 1.1  2000/07/29 22:14:15  voeckler
// Initial revision
//
//
#ifndef _GENERIC_HH
#define _GENERIC_HH

#if defined(__GNUC__) || defined(__GNUG__)
#pragma interface
#endif

#include <stdio.h>	// FILE*
#include <time.h>	// time_t
#include "basetrie.hh"	// BasicTrie
#include "counter.hh"	// Counter
#include "counters.hh"	// CountMap, etc.
#include "string.hh"	// String

#define _TS "%ld" 
#define _DB " " ## SF_U32 ## " " ## SF_U64 ## " %.3f"
#define _dump(c) c.reqs(),c.size(),c.time()/1E3

extern const CountMap _noHits;
extern String str_other;

typedef StringMap<String,false> StringStringMap;

class NullLookup {
  // class to encapsulate a translation operator, 
  // here: null function (input equals output).
public: 
  virtual String lookup( const String& a ) const { return a; }
};

inline 
void
fputstr( FILE* out, const char* msg )
{
  fputs( msg, out );
  fputc( '\n', out );
}

CountMap
distinct( const CountMap& src, const StringStringMap& xlate );
  // purpose: translate count map with external lookup - make distinct!
  // paramtr: src (IN): count map to make distinct.
  //          xlate (IN): translation for src keys.
  // returns: map containing translated keys and sums.
  // remarks: this helps against multi-homed hosts etc.

void
dumpGeneric( FILE* out, const char* prefix, const time_t stamp,
	     const BasicTrie* trie, 
	     const Counter* count,
	     const Counter* hit_count );
  // purpose: print database dump file in *unsorted* order
  // paramtr: out (IO): destination to format results into
  //          prefix (IN): table key for dump
  //          stamp (IN): beautified time stamp to protocol
  //          trie (IN): pointer to used trie method
  //          count (IN): array of counters to display
  //          hit_count (IN): 0, if there are not HITs to show
  // remarks: there is no "number" limit, as in the map function, because
  //          the tries are always rather limited in size.

void
dumpGeneric( FILE* out, const char* prefix, time_t stamp,
	     const size_t number, const size_t min_reqs,
	     const size_t* index,
	     const NullLookup* lookup,
	     const CountMap&   count,
	     const CountMap&   hit_count );
  // purpose: print database dump file in optionally sorted order
  // paramtr: out (IO): destination to format results into
  //          prefix (IN): table key for dump
  //          stamp (IN): beautified time stamp to protocol
  //          number (IN): maximum nr of result lines, 0 for unlimited
  //          min_reqs (IN): minimum nr of requests, 0 for unlimited
  //          index (IN): sorted array of indices, NULL for unsorted order
  //          lookup (IN): object to map reverse lookups on keys 
  //          count (IN): array of counters to display
  //          hit_count (IN): 0, if there are not HITs to show

void
dumpGeneric( FILE* out, const char* prefix, time_t stamp,
	     const size_t number, const size_t min_reqs,
	     const size_t* index,
	     const NullLookup* lookup,
	     const CountMap&   count,
	     const CountMap&   hit_count,
	     const CountMap&   miss_count,
	     const CountMap&   none_count );
  // purpose: print database dump file in optionally sorted order
  // paramtr: out (IO): destination to format results into
  //          prefix (IN): table key for dump
  //          stamp (IN): beautified time stamp to protocol
  //          number (IN): maximum nr of result lines, 0 for unlimited
  //          min_reqs (IN): minimum nr of requests, 0 for unlimited
  //          index (IN): sorted array of indices, NULL for unsorted order
  //          lookup (IN): object to map reverse lookups on keys 
  //          count (IN): array of counters to display
  //          hit_count (IN): Counter(), if there are not HITs to show
  //          miss_count (IN): number of MISSes
  //          none_count (IN): number of NONE. 
  //                           hit_count + miss_count + none_count = count



size_t* 
showGeneric( FILE* out, const char* title, size_t length,
	     bool useRate, bool byByte,
	     const BasicTrie* trie, 
	     const Counter* count,
	     const Counter  base_count,
	     const Counter* hit_count, 
	     const Counter  base_compare,
	     const Counter  hit_compare,
	     bool returnIndex = false );
  // paramtr: out (IO): destination to format results into
  //          title (IN): table title
  //          length (IN): size of first column
  //          useRate (IN): globals.preferDatarate
  //          byByte (IN): false -> sort by req; true -> sort by volume
  //          trie (IN): pointer to used trie method
  //          count (IN): array of counters to display
  //          hit_count (IN): 0, if there are not HITs to show
  //          base_count (IN): count of TCP or UDP or INT to compare with
  //          base_compare (IN): to compare sums against for discrepancies
  //          hit_compare (IN): to compare hit sums against for discrep.
  //          returnIndex (IN): true: return index, false: kill index + ret. 0
  // returns: pointer to array of indices sorted according to "byByte".
  // remarks: there is no "number" limit, as in the map function, because
  //          the tries are always rather limited in size.

size_t*
showGeneric( FILE* out, const char* title, size_t length,
	     bool useRate, bool byByte, const size_t number,
	     const size_t min_reqs,
	     const NullLookup* lookup,
	     const CountMap&   count,
	     const Counter     base_count,
	     const CountMap&   hit_count, 
	     const Counter     base_compare,
	     const Counter     hit_compare,
	     bool  returnIndex = false );
  // paramtr: out (IO): destination to format results into
  //          title (IN): table title
  //          length (IN): size of first column
  //          useRate (IN): globals.preferDatarate
  //          byByte (IN): false -> sort by req; true -> sort by volume
  //          number (IN): maximum nr of result lines, 0 for unlimited
  //          count (IN): array of counters to display
  //          hit_count (IN): 0, if there are not HITs to show
  //          base_count (IN): count of TCP or UDP or INT to compare with
  //          base_compare (IN): to compare sums against for discrepancies
  //          hit_compare (IN): to compare hit sums against for discrep.
  //          returnIndex (IN): true: return index, false: kill index + ret. 0
  // returns: pointer to array of indices sorted according to "byByte".

size_t*
showGeneric( FILE* out, const char* title, size_t length,
	     bool useRate, bool byByte, const size_t number,
	     const size_t min_reqs,
	     const NullLookup* lookup,
	     const CountMap&   count,
	     const Counter     base_count,
	     const CountMap&   hit_count, 
	     const CountMap&   miss_count,
	     const CountMap&   none_count,
	     const Counter     base_compare,
	     const Counter     hit_compare,
	     const Counter     miss_compare,
	     const Counter     none_compare,
	     bool  returnIndex = false );
  // paramtr: out (IO): destination to format results into
  //          title (IN): table title
  //          length (IN): size of first column
  //          useRate (IN): globals.preferDatarate
  //          byByte (IN): false -> sort by req; true -> sort by volume
  //          number (IN): maximum nr of result lines, 0 for unlimited
  //          count (IN): array of counters to display
  //          hit_count (IN): Counter(), if there are not HITs to show
  //          miss_count (IN): number of MISSes
  //          none_count (IN): number of NONE. 
  //                           hit_count + miss_count + none_count = count
  //          base_count (IN): count of TCP or UDP or INT to compare with
  //          base_compare (IN): to compare sums against for discrepancies
  //          hit_compare (IN): to compare hit sums against for discrep.
  //          miss_compare (IN): to compare miss sums against for discrep.
  //          none_compare (IN): to compare none sums against for discrep.
  //          returnIndex (IN): true: return index, false: kill index + ret. 0
  // returns: pointer to array of indices sorted according to "byByte".

#endif // _GENERIC_HH
