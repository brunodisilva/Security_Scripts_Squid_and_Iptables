// This may look like C code, but it is really -*- C++ -*-
//
// $Id: hash.hh,v 1.6 1999/08/05 21:09:48 voeckler Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//          n.i.c.e. - Projekt
//
// File:    hash.hh
//          Fri Oct  7 1994
//          general purpose hash function
//
// hashfunction based upon [ASU87]:
//   Aho, Sethi, Ullmann "COMPILERS Principles, Techniques and Tools"
//   (c) 1986/87 Bell Telephone Lab. Inc.
//
// (c) 1994 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universitaet Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
// 
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND, 
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY 
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  
// 
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
// 

#ifndef _HASH_HH
#define _HASH_HH

#if defined(__GNUC__) || defined(__GNUG__)
#pragma interface
#endif

#include <stddef.h>
#include "typedefs.h"

class Hashable {
  // interface class a la Java
public:
  virtual MyUInt32 hash( void ) const = 0;
  // purpose: describes interface of hashable objects
  // returns: raw hash value between [0..2^31-1].

  static MyUInt32 hashpjw( const char* start, 
			   size_t length, 
			   MyUInt32 mask = 0xf0000000ul, 
			   short int shift = 24 );
  // purpose: provide general purpose 'good' hash function.
  // paramtr: The 'start' and 'length' of a piece of memory to be converted.
  //          This function can be configured for non-default masks and shift
  //          which heavily influence the returned values. The defaults 
  //          configure to the values suggested by [ASU87].
  // returns: The hashvalue, ranging in [0..2^31-1].
  // hashfunction based on [ASU87]. Translates a key into a hashvalue.
  // The adaption to a different range will be done by the calling function.

  static inline MyUInt32 hashstl( const char* s )
  // purpose: provide fast hash function for language strings
  // paramtr: The 's' specifies a NUL terminated C string.
  // returns: The hashvalue, ranging in [0..2^31-1].
  // hashfunction based on [STL]. Translates a key into a hashvalue.
  {
    MyUInt32 h = 0;
    for ( ; *s; s++ ) h = 5*h + *s;
    return h;
  }
};

#endif // _HASH_HH
