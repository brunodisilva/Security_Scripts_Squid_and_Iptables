//
// $Id: output.cc,v 1.14 2001/02/02 10:43:32 voeckler Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    output.cc
//          Thu Aug 05 1999
//
// (c) 1999 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING out OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: output.cc,v $
// Revision 1.14  2001/02/02 10:43:32  voeckler
// removed superflous variable.
//
// Revision 1.13  2000/08/10 12:46:16  voeckler
// added TCP internal requests statistics by status report, added minimum
// request requirement option to client tables, domain tables and AS table,
// though currently only applied with client tables, moved generation of
// TCP client table into the generics module, added version number to time
// stamps for dbi file.
//
// Revision 1.12  2000/07/29 22:14:15  voeckler
// joined database and textual output, split generic part of output into
// separate file, split main parsing loop from seafood.cc into separate
// file.
//
// Revision 1.11  2000/07/27 07:36:21  voeckler
// reworked to create new sections for internal code, and updated the API
// to write into a FILE* of its own instead of stdout.
//
// Revision 1.10  2000/01/12 14:03:59  voeckler
// fixed spelling error.
//
// Revision 1.9  1999/11/29 15:11:18  voeckler
// added new parameter to statistics output, in order to print statistics
// as comments into the database intermediate file.
//
// Revision 1.8  1999/10/29 14:08:38  voeckler
// made many functions module private, added entry point function
// printResults(), adjusted to moval of time stamps into counters.
//
// Revision 1.7  1999/09/02 10:20:48  voeckler
// added massive parallel look up facilities. The AS# lookup facilities
// are rather difficult.
//
// Revision 1.6  1999/08/27 21:51:27  voeckler
// changed String operator() to method c_str() call.
//
// Revision 1.5  1999/08/25 21:14:10  voeckler
// fixed yet another dns lookup bug, added distribution output.
//
// Revision 1.4  1999/08/22 11:52:56  voeckler
// added functionality to display duration as an alternative
// to data rates.
//
// Revision 1.3  1999/08/20 22:43:50  voeckler
// made dns cache a pointer. now prints full statistics of the
// irr and dns cache, if they are available.
//
// Revision 1.2  1999/08/15 22:31:44  voeckler
// The sublevel of the hierarchy overview are now sorted by requests.
//
// Revision 1.1  1999/08/05 21:17:11  voeckler
// Initial revision
//
//

#if defined(__GNUC__) || defined(__GNUG__)
#pragma implementation
#endif

#include <time.h>
#include <math.h> // modf()
#include <string.h>
#include <stdlib.h>
#include "cache.hh"
#include "ctype.hh"
#include "string.hh"
#include "stringset.hh"
#include "output.hh"
#include "tools.hh"
#include "global.hh"
#include "basetrie.hh"
#include "generic.hh"	// *generic(), fputstr(), str_other, ...

static const char* RCS_ID =
"$Id: output.cc,v 1.14 2001/02/02 10:43:32 voeckler Exp $";

static const char* timeFormat = "%d.%m.%Y %H:%M:%S";
static const MyUInt32 version = 2;

inline
bool
isSymbolic( const String& s )
{ return ( DNSItem::aton(s) == C_U32(-1) ); }

inline
bool
isNumeric( const String& s )
{ return ( DNSItem::aton(s) != C_U32(-1) ); }

void
clientLookup( DNSCache* dns, const CountMap& clients, StringStringMap& result )
  // purpose: look up clients
  // paramtr: dns (IO): DNS lookup handler
  //          clients (IN): map containing IPv4 addresses to look up as key
  //          result (IO): translation table for all keys, may be pre-filled!
  // remarks: 29.07.2000: API change, result may be pre-filled
{
#if 0
  // init result unless empty
  if ( result.size() ) result.clear();
#endif

  // combine all clients into a map for massive parallel lookups
  StringSet clientSet;
  for ( CountMap::Iterator i(clients); i.avail(); i++ ) {
    String key( i.key().lower() );
    if ( globals.clientFQDN && isNumeric(key) ) {
      // insert only unknown keys
      if ( ! result.exists(key) ) clientSet.insert(key);
    } else {
      // no translation wanted
      result[key] = key;
    }
  }

  // if there is something to be looked up, do it now
  if ( ! clientSet.empty() ) {
    DNSCache::DNSItemMap local( dns->getanybyany(clientSet) );
    for ( DNSCache::DNSItemMap::Iterator i(local); i.avail(); i++ ) {
      StringSet::iterator j = clientSet.find( i.key() );
      if ( j != clientSet.end() ) {
	DNSItem value( i.value() );
	result[i.key()] = value.empty ? i.key() : value.fqdn;
      }
    }
  }
}

static
time_t
gmtOffset( time_t utc )
  // purpose: calculate the number of seconds between local time and UTC
  // paramtr: utc (IN): UTC time stamp to calculate the UTC offset for.
  // returns: number of seconds between local time and UTC.
  // warning: Please note that areas with daylight savings have two or
  //          more different values over a year.
{
  // FIXME: localtime() and gmtime() are not reentrant!
  struct tm a, b;
  memcpy( &a, localtime(&utc), sizeof(a) );
  memcpy( &b, gmtime(&utc), sizeof(b) );
  a.tm_isdst = b.tm_isdst = 0;
  return ( mktime(&a) - mktime(&b) );
}

// -------------------------------------------------------------------

static
void
showTitle( FILE* out, const char* cache, time_t start, time_t final )
{
  char s[80];
  strftime( s, sizeof(s), "%c %Z", localtime( &start ) );
  fprintf( out, "# Host \"%s\" from \"%s\" ", cache, s );
  strftime( s, sizeof(s), "%c %Z", localtime( &final ) );
  fprintf( out, "till \"%s\"\n\n", s );
}

static
void
showOverview( FILE* out, const Counters& counters )
{
  bool useRate( globals.preferDatarate );
  char s[64];
  Counter temp;

  fputstr( out, valueHead( "# SUM", 6, useRate, true ).c_str() );
  fputstr( out, valueTail( 6, true ).c_str() );
  fprintf( out, "UDP    %s\n", 
	  valueBody(counters.udp, counters.all, 
		    counters.udp_hit, useRate).c_str() );
  temp += counters.udp_hit;
  fprintf( out, "INT    %s\n", 
	  valueBody(counters.internal, counters.all, 
		    counters.internal_hit, useRate).c_str() );
  temp += counters.internal_hit;
  fprintf( out, "TCP    %s\n", 
	  valueBody(counters.tcp, counters.all, 
		    counters.tcp_hit, useRate).c_str() );
  temp += counters.tcp_hit;
  fprintf( out, "%s\n", valueTail( 6, true ).c_str() );
  fprintf( out, "ALL    %s\n", 
	  valueBody(counters.all, counters.all, temp, useRate).c_str() );
  fputc('\n',out);
  
  fputstr( out, valueHead( "# UDP BY STATUS", 20, useRate, false ).c_str() );
  fputstr( out, valueTail( 20, false ).c_str() );
  fprintf( out, "%-20s %s\n", "HIT", 
	  valueBody(counters.udp_hit,counters.udp,useRate).c_str() );
  size_t size = LogLine::stable.distinct()+1; // include zeroth element!
  size_t* index = indexByReqs( counters.udp_hit_status, size );
  for ( MyUInt32 i=0; i<size; ++i )
    if ( counters.udp_hit_status[index[i]].reqs() )
      fprintf( out, " %-19s %s\n", 
	      LogLine::stable.reverse(s,sizeof(s),index[i]),
	      valueBody(counters.udp_hit_status[index[i]],
			counters.udp, useRate).c_str() );
  delete[] index;
  fprintf( out, "%-20s %s\n", "MISS", 
	  valueBody(counters.udp_miss,counters.udp,useRate).c_str() );
  index = indexByReqs( counters.udp_miss_status, size );
  for ( MyUInt32 i=0; i<size; ++i )
    if ( counters.udp_miss_status[index[i]].reqs() )
      fprintf( out, " %-19s %s\n", 
	      LogLine::stable.reverse(s,sizeof(s),index[i]),
	      valueBody(counters.udp_miss_status[index[i]],
			counters.udp, useRate).c_str() );
  delete[] index;
  fputstr( out, valueTail( 20, false ).c_str() );
  fprintf( out, "%-20s %s\n", "SUM", 
	  valueBody(counters.udp,counters.udp,useRate).c_str() );
  fputc('\n',out);



  fputstr( out, valueHead( "# INT BY STATUS", 32, useRate, false ).c_str() );
  fputstr( out, valueTail( 32, false ).c_str() );
  fprintf( out, "%-32s %s\n", "HIT", 
	  valueBody(counters.internal_hit,counters.internal,useRate).c_str() );
  index = indexByReqs( counters.int_hit_status, size );
  for ( MyUInt32 i=0; i<size; ++i )
    if ( counters.int_hit_status[index[i]].reqs() )
      fprintf( out, " %-31s %s\n", 
	      LogLine::stable.reverse(s,sizeof(s),index[i]),
	      valueBody(counters.int_hit_status[index[i]],
			counters.internal,useRate).c_str() );
  delete[] index;
  fprintf( out, "%-32s %s\n", "MISS", 
	   valueBody(counters.internal_miss,counters.internal,useRate).c_str() );
  index = indexByReqs( counters.int_miss_status, size );
  for ( MyUInt32 i=0; i<size; ++i )
    if ( counters.int_miss_status[index[i]].reqs() )
      fprintf( out, " %-31s %s\n", 
	      LogLine::stable.reverse(s,sizeof(s),index[i]),
	      valueBody(counters.int_miss_status[index[i]],
			counters.internal,useRate).c_str() );
  delete[] index;
  fprintf( out, "%-32s %s\n", "NONE", 
	   valueBody(counters.internal_none,counters.internal,useRate).c_str() );
  index = indexByReqs( counters.int_none_status, size );
  for ( MyUInt32 i=0; i<size; ++i )
    if ( counters.int_none_status[index[i]].reqs() )
      fprintf( out, " %-31s %s\n", 
	      LogLine::stable.reverse(s,sizeof(s),index[i]),
	      valueBody(counters.int_none_status[index[i]],
			counters.internal,useRate).c_str() );
  delete[] index;
  fputstr( out, valueTail( 32, false ).c_str() );
  fprintf( out, "%-32s %s\n", "SUM", 
	  valueBody(counters.internal,counters.internal,useRate).c_str() );
  fputc('\n',out);



  fputstr( out, valueHead( "# TCP BY STATUS", 32, useRate, false ).c_str() );
  fputstr( out, valueTail( 32, false ).c_str() );
  fprintf( out, "%-32s %s\n", "HIT", 
	  valueBody(counters.tcp_hit,counters.tcp,useRate).c_str() );
  index = indexByReqs( counters.tcp_hit_status, size );
  for ( MyUInt32 i=0; i<size; ++i )
    if ( counters.tcp_hit_status[index[i]].reqs() )
      fprintf( out, " %-31s %s\n", 
	      LogLine::stable.reverse(s,sizeof(s),index[i]),
	      valueBody(counters.tcp_hit_status[index[i]],
			counters.tcp,useRate).c_str() );
  delete[] index;
  fprintf( out, "%-32s %s\n", "MISS", 
	  valueBody(counters.tcp_miss,counters.tcp,useRate).c_str() );
  index = indexByReqs( counters.tcp_miss_status, size );
  for ( MyUInt32 i=0; i<size; ++i )
    if ( counters.tcp_miss_status[index[i]].reqs() )
      fprintf( out, " %-31s %s\n", 
	      LogLine::stable.reverse(s,sizeof(s),index[i]),
	      valueBody(counters.tcp_miss_status[index[i]],
			counters.tcp,useRate).c_str() );
  delete[] index;
  fprintf( out, "%-32s %s\n", "NONE", 
	  valueBody(counters.tcp_miss_none,counters.tcp,useRate).c_str() );
  index = indexByReqs( counters.tcp_miss_none_status, size );
  for ( MyUInt32 i=0; i<size; ++i )
    if ( counters.tcp_miss_none_status[index[i]].reqs() )
      fprintf( out, " %-31s %s\n", 
	      LogLine::stable.reverse(s,sizeof(s),index[i]),
	      valueBody(counters.tcp_miss_none_status[index[i]],
			counters.tcp,useRate).c_str() );
  delete[] index;
  fputstr( out, valueTail( 32, false ).c_str() );
  fprintf( out, "%-32s %s\n", "SUM", 
	  valueBody(counters.tcp,counters.tcp,useRate).c_str() );
  fputc('\n',out);
}

static
void
dumpOverview( FILE* out, time_t ts, const Counters& counters )
{
  char s[128];
  size_t size = LogLine::stable.distinct()+1;

  for ( MyUInt32 i=0; i<size; ++i ) {
    LogLine::stable.reverse(s,sizeof(s),i);
    if ( counters.udp_hit_status[i].reqs() ) 
      fprintf( out, "udp hit " _TS " %s" _DB "\n", ts, s, 
	       _dump(counters.udp_hit_status[i]) );
    if ( counters.udp_miss_status[i].reqs() )
      fprintf( out, "udp miss " _TS " %s" _DB "\n", ts, s,
	       _dump(counters.udp_miss_status[i]) );
    if ( counters.int_hit_status[i].reqs() )
      fprintf( out, "int hit " _TS " %s" _DB "\n", ts, s,
	       _dump(counters.int_hit_status[i]) );
    if ( counters.int_miss_status[i].reqs() )
      fprintf( out, "int miss " _TS " %s" _DB "\n", ts, s,
	       _dump(counters.int_miss_status[i]) );
    if ( counters.int_none_status[i].reqs() )
      fprintf( out, "int none " _TS " %s" _DB "\n", ts, s,
	       _dump(counters.int_none_status[i]) );
    if ( counters.tcp_hit_status[i].reqs() )
      fprintf( out, "tcp hit " _TS " %s" _DB "\n", ts, s,
	       _dump(counters.tcp_hit_status[i]) );
    if ( counters.tcp_miss_status[i].reqs() )
      fprintf( out, "tcp miss " _TS " %s" _DB "\n", ts, s,
	       _dump(counters.tcp_miss_status[i]) );
    if ( counters.tcp_miss_none_status[i].reqs() )
      fprintf( out, "tcp none " _TS " %s" _DB "\n", ts, s,
	       _dump(counters.tcp_miss_none_status[i]) );
  }
}



static
void
showHierarchy( FILE* out, DNSCache* dns, const Counters& counters,
	       StringStringMap& clientmap )
{
  bool useRate( globals.preferDatarate );
  char s[80];
  Counter temp, thit;
  size_t size = LogLine::htable.distinct()+1; // include zeroth element!

  fputstr( out, valueHead( "# HIERARCHY OVERVIEW", 32, useRate, true ).c_str() );
  fputstr( out, valueTail( 32, true ).c_str() );
  fprintf( out, "%-32s %s\n", "DIRECT to source", 
	  valueBody( counters.hier_direct, counters.hier, useRate ).c_str() );
  size_t* index = indexByReqs( counters.hier_direct_method, size );
  for ( MyUInt32 i=0; i<size; ++i ) 
    if ( counters.hier_direct_method[index[i]].reqs() ) {
      fprintf( out, " %-31s %s\n", 
	       LogLine::htable.reverse(s,sizeof(s),index[i]),
	       valueBody( counters.hier_direct_method[index[i]],
			  counters.hier,
			  counters.tcp_hit_hier[index[i]],
			  useRate ).c_str() );
      temp += counters.hier_direct_method[index[i]];
      thit += counters.tcp_hit_hier[index[i]];
    }
  delete[] index;

  fprintf( out, "%-32s %s\n", "PARENT fetches", 
	  valueBody( counters.hier_parent, counters.hier, useRate ).c_str() );
  index = indexByReqs( counters.hier_parent_method, size );
  for ( MyUInt32 i=0; i<size; ++i ) 
    if ( counters.hier_parent_method[index[i]].reqs() ) {
      fprintf( out, " %-31s %s\n", 
	       LogLine::htable.reverse(s,sizeof(s),index[i]),
	       valueBody( counters.hier_parent_method[index[i]],
			  counters.hier,
			  counters.tcp_hit_hier[index[i]],
			  useRate ).c_str() );
      temp += counters.hier_parent_method[index[i]];
      thit += counters.tcp_hit_hier[index[i]];
    }
  delete[] index;

  fprintf( out, "%-32s %s\n", "PEER fetches", 
	  valueBody( counters.hier_peer, counters.hier, useRate ).c_str() );
  index = indexByReqs( counters.hier_peer_method, size );
  for ( MyUInt32 i=0; i<size; ++i ) 
    if ( counters.hier_peer_method[index[i]].reqs() ) {
      fprintf( out, " %-31s %s\n", 
	       LogLine::htable.reverse(s,sizeof(s),index[i]),
	       valueBody( counters.hier_peer_method[index[i]],
			  counters.hier,
			  counters.tcp_hit_hier[index[i]],
			  useRate ).c_str() );
      temp += counters.hier_peer_method[index[i]];
      thit += counters.tcp_hit_hier[index[i]];
    }
  delete[] index;

  fputstr( out, valueTail( 32, true ).c_str() );
  fprintf( out, "%-32s %s\n", "SUM", 
	   valueBody(temp,counters.hier,thit,useRate).c_str() );
  if ( temp != counters.hier )
    fprintf( out, "%-32s %s\n", "SHOULD-BE", 
	    valueBody(counters.hier,counters.hier,counters.tcp_hit,useRate).c_str() );
  fputc('\n',out);

  // -----------------------------------------------------------------

  // combine all peers (neighbours + parents) into one map
  // for massive parallel DNS lookups of their respective address
  clientLookup( dns, counters.hier_peer_host, clientmap );
  
  fputstr( out, valueHead( "# HIERARCHY BY HOST", 40, useRate, false ).c_str() );
  fputstr( out, valueTail( 40, false ).c_str() );
  fprintf( out, "%-40s %s\n", "DIRECT to source", 
	  valueBody( counters.hier_direct, counters.hier, useRate ).c_str() );

  index = indexByReqs( counters.hier_peer_host );
  Counter* sub = new Counter[size];
  temp = counters.hier_direct;
  for ( size_t i=0; i<counters.hier_peer_host.size(); ++i ) {
    String key( counters.hier_peer_host.key(index[i]) );
    fprintf( out, "%-40s %s\n", 
	     clientmap[key.lower()].substring(0,40).c_str(),
	     valueBody( counters.hier_peer_host[index[i]], 
			counters.hier, useRate ).c_str() );
    temp += counters.hier_peer_host[index[i]];
    
    for ( size_t j=0; j<size; ++j ) 
      sub[j] = counters.hier_peer_status[j][key];
    size_t* local = indexByReqs(sub,size);
    for ( size_t j=0; j<size; ++j ) {
      if ( sub[local[j]].reqs() ) 
	fprintf( out, " %-39s %s\n", 
		 LogLine::htable.reverse(s,sizeof(s),local[j]),
		 valueBody( sub[local[j]], counters.hier, useRate ).c_str() );
    }
    delete[] local;
  }
  delete[] sub;
  delete[] index;
  fputstr( out, valueTail( 40, false ).c_str() );
  fprintf( out, "%-40s %s\n", "SUM", 
	   valueBody(temp,counters.hier,useRate).c_str() );
  if ( temp != counters.hier )
    fprintf( out, "%-40s %s\n", "SHOULD-BE", 
	    valueBody(counters.hier,counters.hier,useRate).c_str() );
  fputc('\n',out);
}

static
void
dumpHierarchy( FILE* out, DNSCache* dns, time_t ts, const Counters& counters,
	       StringStringMap& clientmap )
{
  char tag[128];
  size_t size = LogLine::htable.distinct()+1;
  clientLookup( dns, counters.hier_peer_host, clientmap );

  for ( MyUInt32 i=0; i<size; ++i ) {
    LogLine::htable.reverse(tag,sizeof(tag),i);
    if ( counters.hier_direct_method[i].reqs() ) {
      fprintf( out, "hier direct " _TS " %s" _DB "\n", 
	       ts, tag, _dump(counters.hier_direct_method[i]) );
    } else if ( counters.hier_peer_status[i].size() ) {
      for ( CountMap::Iterator j(counters.hier_peer_status[i]); 
	    j.avail(); 
	    j++ ) {
	if ( j().reqs() ) {
	  if ( counters.hier_parent_method[i].reqs() ) {
	    fprintf( out, "hier parent " _TS " %s %s" _DB "\n", 
		     ts, tag, clientmap[j.key().lower()].c_str(), 
		     _dump(j.value()) );
	  } else if ( counters.hier_peer_method[i].reqs() ) {
	    fprintf( out, "hier peer " _TS " %s %s" _DB "\n", 
		     ts, tag, clientmap[j.key().lower()].c_str(), 
		     _dump(j.value()) );
	  }
	}
      }
    }
  }
}



static
void
showInternal( FILE* out, DNSCache* dns, const Counters& counters, 
	      const size_t number, StringStringMap& clientmap )
{
  bool useRate( globals.preferDatarate );
  Counter temp, thit, leftover, lhitover;

  // combine all INT clients into a map for massive parallel lookups
  clientLookup( dns, counters.internal_client, clientmap );

  fputstr( out, valueHead( "# INTERNALLY SERVICED REQUESTS", 48, 
		   useRate, true ).c_str() );
  fputstr( out, valueTail( 48, true ).c_str() );
  size_t  size  = counters.internal_host.size();
  size_t* index = indexByReqs( counters.internal_host );
  for ( size_t i=0; i<size; ++i ) {
    if ( counters.internal_host[index[i]].reqs() ) {
      String host( counters.internal_host.key(index[i]) );
      fprintf( out, "%-48s %s\n", host.substring(0,48).c_str(),
	      valueBody( counters.internal_host[index[i]],
			 counters.internal,
			 counters.internal_hit_host[host],
			 useRate ).c_str() );

      size_t  size2 = counters.internal_path[host].size();
      size_t* jndex = indexByReqs( counters.internal_path[host] );
      for ( size_t j=0; j<size2; ++j ) {
	if ( counters.internal_path[host][jndex[j]].reqs() ) {
	  String key( counters.internal_path[host].key(jndex[j]) );
	  fprintf( out, "  %-46s %s\n", 
		  key.substring(0,46).c_str(),
		  valueBody( counters.internal_path[host][jndex[j]], 
			     counters.internal,
			     counters.internal_hit_path[host][key], 
			     useRate ).c_str() );

	  if ( globals.showExtendedInternal ) {
	    MyUInt32 n = C_U32(0);
	    size_t  size3 = counters.internal_hpc[host][key].size();
	    size_t* kndex = indexByReqs( counters.internal_hpc[host][key] );
	    for ( size_t k=0; k<size3; ++k ) {
	      if ( counters.internal_hpc[host][key][kndex[k]].reqs() ) {
		String client( counters.internal_hpc[host][key].key(kndex[k]) );
		if ( number == 0 || number > k ) {
		  fprintf( out, "    %-44s %s\n", 
			  clientmap[client.lower()].substring(0,44).c_str(),
			  valueBody( counters.internal_hpc[host][key][kndex[k]],
				     counters.internal,
				     counters.internal_hit_hpc[host][key][client],
				     useRate ).c_str() );
		} else {
		  n++;
		  leftover += counters.internal_hpc[host][key][kndex[k]];
		  lhitover += counters.internal_hit_hpc[host][key][client];
		}
		temp += counters.internal_hpc[host][key][kndex[k]];
		thit += counters.internal_hit_hpc[host][key][client];
	      }
	    }
	    delete[] kndex;

	    // print any leftovers
	    if ( n ) {
	      char here[80];
	      sprintf( here, str_other.c_str(), n );
	      fprintf( out, "    %-44s %s\n", here,
		      valueBody( leftover, counters.internal, 
				 lhitover, useRate ).c_str() );
	    }
	  } else { // if showExtendedInternal
	    temp += counters.internal_path[host][key];
	    thit += counters.internal_hit_path[host][key];
	  }
	} // if internal_path.reqs
      }
      delete[] jndex;
    }
  }
  delete[] index;

  fputstr( out, valueTail( 48, true ).c_str() );
  fprintf( out, "%-48s %s\n", "SUM", 
	  valueBody(temp,counters.internal,thit,useRate).c_str() );
  fputc('\n',out);
}

#ifdef ONE_INTERNAL_TABLE

static
void
dumpInternal( FILE* out, DNSCache* dns, time_t ts, const Counters& counters,
	      bool byByte, const size_t number )
{
  // combine all INT clients into a map for massive parallel lookups
  StringStringMap map;
  clientLookup( dns, counters.internal_client, map );

  size_t  size1 = counters.internal_host.size();
  size_t* index = byByte ?
    indexBySize( counters.internal_host ) :
    indexByReqs( counters.internal_host );
  for ( size_t i=0; i<size1; ++i ) {
    if ( counters.internal_host[index[i]].reqs() ) {
      String host( counters.internal_host.key(index[i]) );
      size_t  size2 = counters.internal_path[host].size();
      size_t* jndex = byByte ?
	indexBySize( counters.internal_path[host] ) :
	indexByReqs( counters.internal_path[host] );

      for ( size_t j=0; j<size2; ++j ) {
	if ( counters.internal_path[host][jndex[j]].reqs() ) {
	  String key( counters.internal_path[host].key(jndex[j]) );
	  
	  Counter leftover, lhitover;
	  MyUInt32 n, m = n = C_U32(0);
	  size_t  size3 = counters.internal_hpc[host][key].size();
	  size_t* kndex = byByte ? 
	    indexBySize( counters.internal_hpc[host][key] ) : 
	    indexByReqs( counters.internal_hpc[host][key] );
	  for ( size_t k=0; k<size3; ++k ) {
	    if ( counters.internal_hpc[host][key][kndex[k]].reqs() ) {
	      String client( counters.internal_hpc[host][key].key(kndex[k]) );
	      if ( number == 0 || number > ++m ) {
		// ok to dump entry
		fprintf( out, "internal uri " TS " %s%s %s %s ", ts, 
			 host.c_str(), key.c_str(), map[client].c_str(), 
			 dump(counters.internal_hpc[host][key][kndex[k]]) );
		fputs( dump(counters.internal_hit_hpc[host][key][client]), 
		       out );
		fputc( '\n', out );
	      } else {
		++n;
	      }
	    }
	  }
	  delete[] kndex;
	  if ( n ) {
	    // dump leftovers
	    fprintf( out, "internal uri " TS " %s %s more[" SF_U32 "] %s ", 
		     ts, host.c_str(), key.c_str(), n, dump(leftover) );
	    fputs( dump(lhitover), out );
	    fputc( '\n', out );
	  }
	}
      } // foreach j
      delete[] jndex;
    } 
  } // foreach i 
  delete[] index;
}

#else // !ONE_INTERNAL_TABLE

static
void
dumpInternal( FILE* out, time_t ts, const Counters& counters, bool byByte )
{
  size_t  size1 = counters.internal_host.size();
  size_t* index = byByte ?
    indexBySize( counters.internal_host ) :
    indexByReqs( counters.internal_host );
  for ( size_t i=0; i<size1; ++i ) {
    if ( counters.internal_host[index[i]].reqs() ) {
      String host( counters.internal_host.key(index[i]) );
      size_t  size2 = counters.internal_path[host].size();
      size_t* jndex = byByte ?
	indexBySize( counters.internal_path[host] ) :
	indexByReqs( counters.internal_path[host] );

      for ( size_t j=0; j<size2; ++j ) {
	if ( counters.internal_path[host][jndex[j]].reqs() ) {
	  String key( counters.internal_path[host].key(jndex[j]) );
	  fprintf( out, "internal uri " _TS " %s %s" _DB _DB "\n", ts, 
		   host.c_str(), key.c_str(),
		   _dump(counters.internal_path[host][jndex[j]]),
		   _dump(counters.internal_hit_path[host][key]) );
	}
      } // foreach j
      delete[] jndex;
    } 
  } // foreach i 
  delete[] index;
}
#endif // ONE_INTERNAL_TABLE



static
void
bothMethods( FILE* text, FILE* dbase, time_t stamp, 
	     const Counters& counters )
{
  showGeneric( text, "# METHODS", 10, 
	       globals.preferDatarate, false, &LogLine::mtable, 
	       counters.methods,
	       counters.all,
	       counters.hit_methods,
	       counters.all,
	       counters.tcp_hit + counters.udp_hit );

  if ( dbase )
    dumpGeneric( dbase, "method", stamp, &LogLine::mtable,
		 counters.methods,
		 counters.hit_methods );
}



static
void
bothSchemes( FILE* text, FILE* dbase, time_t stamp,
	     const Counters& counters )
{
  showGeneric( text, "# SCHEMES", 16, 
	       globals.preferDatarate, false, &LogLine::schemes, 
	       counters.tcp_scheme,
	       counters.tcp,
	       counters.tcp_hit_scheme,
	       counters.tcp,
	       counters.tcp_hit );

  if ( dbase )
    dumpGeneric( dbase, "scheme", stamp, &LogLine::schemes,
		 counters.tcp_scheme, counters.tcp_hit_scheme );
}



static
void
bothSuffices( FILE* text, FILE* dbase, time_t stamp, 
	      const Counters& counters )
{
  showGeneric( text, "# EXT. BY REQ.", 14, 
	       globals.preferDatarate, false, &LogLine::suffices,
	       counters.tcp_suffix,
	       counters.tcp,
	       counters.tcp_hit_suffix,
	       counters.tcp,
	       counters.tcp_hit );

  if ( dbase )
    dumpGeneric( dbase, "suffix", stamp, &LogLine::suffices,
		 counters.tcp_suffix, counters.tcp_hit_suffix );

  showGeneric( text, "# EXT. BY VOL.", 14, 
	       globals.preferDatarate, true, &LogLine::suffices,
	       counters.tcp_suffix,
	       counters.tcp,
	       counters.tcp_hit_suffix,
	       counters.tcp,
	       counters.tcp_hit );
}




static
void
bothTLD( FILE* text, FILE* dbase, time_t stamp,
	 const Counters& counters, const size_t number, const size_t min_reqs )
{
  NullLookup none;
  size_t* index =
    showGeneric( text, "# TLD BY REQ.", 13, 
		 globals.preferDatarate, false, number, min_reqs, &none,
		 counters.tcp_tld,
		 counters.tcp,
		 counters.tcp_hit_tld,
		 counters.tcp,
		 counters.tcp_hit,
		 ! globals.sortDBaseByByte );

  size_t* jndex = 
    showGeneric( text, "# TLD BY VOL.", 13, 
		 globals.preferDatarate, true, number, min_reqs, &none,
		 counters.tcp_tld,
		 counters.tcp,
		 counters.tcp_hit_tld,
		 counters.tcp,
		 counters.tcp_hit,
		 globals.sortDBaseByByte );

  if ( dbase )
    dumpGeneric( dbase, "tld", stamp, number, min_reqs,
		 globals.sortDBaseByByte ? jndex : index, &none,
		 counters.tcp_tld, counters.tcp_hit_tld );

  delete[] (globals.sortDBaseByByte ? jndex : index);
}



static
void
bothSLD( FILE* text, FILE* dbase, time_t stamp,
	 const Counters& counters, const size_t number, const size_t min_reqs )
{
  NullLookup none;
  size_t* index = 
    showGeneric( text, "# 2ND LEVEL DOMAIN BY REQUEST", 33,
		 globals.preferDatarate, false, number, min_reqs, &none,
		 counters.tcp_sld,
		 counters.tcp,
		 counters.tcp_hit_sld,
		 counters.tcp,
		 counters.tcp_hit,
		 ! globals.sortDBaseByByte );

  size_t* jndex = 
    showGeneric( text, "# 2ND LEVEL DOMAIN BY VOLUME", 33,
		 globals.preferDatarate, true, number, min_reqs, &none,
		 counters.tcp_sld,
		 counters.tcp,
		 counters.tcp_hit_sld,
		 counters.tcp,
		 counters.tcp_hit,
		 globals.sortDBaseByByte );

  if ( dbase )
    dumpGeneric( dbase, "sld", stamp, number, min_reqs,
		 globals.sortDBaseByByte ? jndex : index, &none,
		 counters.tcp_sld, counters.tcp_hit_sld );

  delete[] (globals.sortDBaseByByte ? jndex : index);
}



static
void
showMediatypes( FILE* out, const Counters& counters )
{
  bool useRate( globals.preferDatarate );
  char s[80];
  Counter thit;
  Counter temp;

  fputstr( out, valueHead( "# MEDIATYPES BY REQUESTS", 24, useRate, true ).c_str() );
  fputstr( out, valueTail( 24, true ).c_str() );
  size_t* index = indexByReqs( counters.tcp_mime, counters.nMedia );
  for ( size_t i=0; i<counters.nMedia; ++i ) {
    if ( counters.tcp_mime[index[i]].reqs() ) {
      fprintf( out, "%-24s %s\n", 
	      LogLine::mediatypes.reverse(s,sizeof(s),index[i]),
	      valueBody( counters.tcp_mime[index[i]], 
			 counters.tcp,
			 counters.tcp_hit_mime[index[i]],
			 useRate ).c_str() );
      if ( counters.tcp_submime[index[i]] ) {
	size_t* sub = indexByReqs( counters.tcp_submime[index[i]],
				   counters.nSubtype[index[i]] );
	for ( size_t j=0; j<counters.nSubtype[index[i]]; ++j ) {
	  if ( counters.tcp_submime[index[i]][sub[j]].reqs() ) {
	    fprintf( out, " /%-22s %s\n",
		    LogLine::subtypes[index[i]].reverse(s,sizeof(s),sub[j]),
		    valueBody( counters.tcp_submime[index[i]][sub[j]],
			       counters.tcp,
			       counters.tcp_hit_submime[index[i]][sub[j]],
			       useRate ).c_str() );
	  }
	}
	delete[] sub;
      }
    }
    temp += counters.tcp_mime[index[i]];
    thit += counters.tcp_hit_mime[index[i]];
  }
  delete[] index;
  fputstr( out, valueTail( 24, true ).c_str() );
  fprintf( out, "%-24s %s\n", "SUM", valueBody(temp,counters.tcp,thit,useRate).c_str() );
  if ( temp != counters.tcp || thit != counters.tcp_hit )
    fprintf( out, "%-24s %s\n", "SHOULD-BE", 
	    valueBody(counters.tcp,counters.tcp,counters.tcp_hit,useRate).c_str() );
  fputc('\n',out);




  fputstr( out, valueHead( "# MEDIATYPES BY VOLUME", 24, useRate, true ).c_str() );
  fputstr( out, valueTail( 24, true ).c_str() );
  index = indexBySize( counters.tcp_mime, counters.nMedia );
  thit = temp = Counter();
  for ( size_t i=0; i<counters.nMedia; ++i ) {
    if ( counters.tcp_mime[index[i]].reqs() ) {
      fprintf( out, "%-24s %s\n", 
	      LogLine::mediatypes.reverse(s,sizeof(s),index[i]),
	      valueBody( counters.tcp_mime[index[i]], 
			 counters.tcp,
			 counters.tcp_hit_mime[index[i]],
			 useRate ).c_str() );
      if ( counters.tcp_submime[index[i]] ) {
	size_t* sub = indexBySize( counters.tcp_submime[index[i]],
				   counters.nSubtype[index[i]] );
	for ( size_t j=0; j<counters.nSubtype[index[i]]; ++j ) {
	  if ( counters.tcp_submime[index[i]][sub[j]].reqs() ) {
	    fprintf( out, " /%-22s %s\n",
		    LogLine::subtypes[index[i]].reverse(s,sizeof(s),sub[j]),
		    valueBody( counters.tcp_submime[index[i]][sub[j]],
			       counters.tcp,
			       counters.tcp_hit_submime[index[i]][sub[j]],
			       useRate ).c_str() );
	  }
	}
	delete[] sub;
      }
    }
    temp += counters.tcp_mime[index[i]];
    thit += counters.tcp_hit_mime[index[i]];
  }
  delete[] index;
  fputstr( out, valueTail( 24, true ).c_str() );
  fprintf( out, "%-24s %s\n", "SUM", valueBody(temp,counters.tcp,thit,useRate).c_str() );
  if ( temp != counters.tcp || thit != counters.tcp_hit )
    fprintf( out, "%-24s %s\n", "SHOULD-BE", 
	    valueBody(counters.tcp,counters.tcp,counters.tcp_hit,useRate).c_str() );
  fputc('\n',out);
}

static
void
dumpMediatypes( FILE* out, time_t ts, const Counters& counters )
{
  char s[128], t[128];
  size_t size = counters.nMedia;
  for ( MyUInt32 i=0; i<size; ++i ) 
    if ( counters.tcp_mime[i].reqs() ) {
      LogLine::mediatypes.reverse(s,sizeof(s),i);
      fprintf( out, "mime " _TS " %s/*" _DB _DB "\n", ts, s, 
	       _dump(counters.tcp_mime[i]),
	       _dump(counters.tcp_hit_mime[i]) );
      if ( counters.tcp_submime[i] ) {
	size_t subs = counters.nSubtype[i];
	for ( MyUInt32 j=0; j<subs; ++j ) 
	  if ( counters.tcp_submime[i][j].reqs() ) {
	    LogLine::subtypes[i].reverse(t,sizeof(t),j);
	    fprintf( out, "mime " _TS " %s/%s" _DB _DB "\n", ts, s, t, 
		     _dump( counters.tcp_submime[i][j] ),
		     _dump(counters.tcp_hit_submime[i][j]) );
	  }
      }
    }
}



static
void
showPorts( FILE* out, const Counters& counters )
{
  bool useRate( globals.preferDatarate );
  char temp[80];
  Counter sum;
  // with without port 80, which is stored in ports[64]...
  for ( int i=0; i<64; ++i ) sum += counters.tcp_ports[i];
  fputstr( out, valueHead( "# NON-STD PORTS", 15, useRate, false ).c_str() );
  fputstr( out, valueTail( 15, false ).c_str() );
  for ( int i=0; i<64; ++i )
    if ( counters.tcp_ports[i].reqs() ) {
      sprintf( temp, "%5d-%-5d", i << 10, ((i+1)<<10)-1 );
      if ( i==0 ) strcat( temp, "\\80" );
      fprintf( out, "%-15s %s\n", temp, 
	      valueBody( counters.tcp_ports[i], sum, useRate ).c_str() );
    }
  fputstr( out, valueTail( 15, false ).c_str() );
  Counter total = sum + counters.tcp_ports[64];
  fprintf( out, "%-15s %s\n", "NON-STD SUM", 
	  valueBody( sum, total, useRate ).c_str() );
  fprintf( out, "%-15s %s\n", "Port 80", 
	   valueBody( counters.tcp_ports[64], total, useRate ).c_str() );
  fputstr( out, valueTail( 15, false ).c_str() );
  fprintf( out, "%-15s %s\n", "SUM", 
	   valueBody( total, total, useRate ).c_str() );
  fputc('\n',out);
}

static
void
dumpPorts( FILE* out, time_t ts, const Counters& counters )
{
  for ( MyUInt32 i=0; i<64; ++i ) {
    if ( counters.tcp_ports[i].reqs() ) {
      fprintf( out, "ports " _TS " %5d-%-5d" _DB "\n", 
	       ts, i << 10, ((i+1)<<10)-1,
	       _dump(counters.tcp_ports[i]) );
    }
  }

  fprintf( out, "ports " _TS " %5d-%-5d" _DB "\n", ts, 80, 80, 
	   _dump(counters.tcp_ports[64]) );
}



static
void
bothUDPClients( FILE* text, FILE* dbase, time_t stamp, DNSCache* dns, 
		const Counters& counters, 
		const size_t number, const size_t min_reqs,
		StringStringMap& clientmap )
{
  // combine all UDP clients into a map for massive parallel lookups
  clientLookup( dns, counters.udp_client, clientmap );
  CountMap udp_client( distinct( counters.udp_client, clientmap ) );
  CountMap udp_hit_client( distinct( counters.udp_hit_client, clientmap ) );
  NullLookup none;

  size_t* index = 
    showGeneric( text, "# UDP CLIENTS BY REQUESTS", 40,
		 globals.preferDatarate, false, number, min_reqs, &none,
		 udp_client, // counters.udp_client,
		 counters.udp,
		 udp_hit_client, // counters.udp_hit_client,
		 counters.udp,
		 counters.udp_hit,
		 ! globals.sortDBaseByByte );

  size_t* jndex = 
    showGeneric( text, "# UDP CLIENTS BY VOLUME", 40,
		 globals.preferDatarate, true, number, min_reqs, &none,
		 udp_client, // counters.udp_client,
		 counters.udp,
		 udp_hit_client, // counters.udp_hit_client,
		 counters.udp,
		 counters.udp_hit,
		 globals.sortDBaseByByte );

  if ( dbase )
    dumpGeneric( dbase, "client udp", stamp, number, min_reqs, 
		 globals.sortDBaseByByte ? jndex : index, &none,
		 udp_client, udp_hit_client );

  delete[] (globals.sortDBaseByByte ? jndex : index);
}

static
void
bothINTClients( FILE* text, FILE* dbase, time_t stamp, DNSCache* dns, 
		const Counters& counters, 
		const size_t number, const size_t min_reqs,
		StringStringMap& clientmap )
{
  // combine all UDP clients into a map for massive parallel lookups
  clientLookup( dns, counters.internal_client, clientmap );
  
  // create unique keys
  CountMap int_client( distinct( counters.internal_client, clientmap ) );
  CountMap int_hit_client( distinct( counters.internal_hit_client, clientmap ) );
  NullLookup none;

  size_t* index = 
    showGeneric( text, "# INT CLIENTS BY REQUESTS", 40, 
		 globals.preferDatarate, false, number, min_reqs, &none,
		 int_client, // counters.internal_client,
		 counters.internal,
		 int_hit_client, // counters.internal_hit_client,
		 counters.internal,
		 counters.internal_hit,
		 ! globals.sortDBaseByByte );

  size_t* jndex = 
    showGeneric( text, "# INT CLIENTS BY VOLUME", 40, 
		 globals.preferDatarate, true, number, min_reqs, &none,
		 int_client, // counters.internal_client,
		 counters.internal,
		 int_hit_client, // counters.internal_hit_client,
		 counters.internal,
		 counters.internal_hit,
		 globals.sortDBaseByByte );

#ifndef ONE_INTERNAL_TABLE
  if ( dbase )
    dumpGeneric( dbase, "client int", stamp, number, min_reqs,
		 globals.sortDBaseByByte ? jndex : index, &none,
		 int_client, int_hit_client );
#endif

  delete[] (globals.sortDBaseByByte ? jndex : index);
}

static
void
bothTCPClients( FILE* text, FILE* dbase, time_t stamp, DNSCache* dns, 
		const Counters& counters, 
		const size_t number, const size_t min_reqs,
		StringStringMap& clientmap )
{
  // combine all TCP clients into a map for massive parallel lookups
  clientLookup( dns, counters.tcp_client, clientmap );

  // make all TCP clients unique keys
  CountMap tcp_client( distinct(counters.tcp_client,clientmap) );
  CountMap tcp_hit_client( distinct(counters.tcp_hit_client,clientmap) );
  CountMap tcp_miss_client( distinct(counters.tcp_miss_client,clientmap) );
  CountMap tcp_none_client( distinct(counters.tcp_miss_none_client,clientmap) );
  NullLookup none;

  size_t* index = 
    showGeneric( text, "# TCP CLIENTS BY REQUST", 40, 
		 globals.preferDatarate, false, number, min_reqs, &none,
		 tcp_client,
		 counters.tcp,
		 tcp_hit_client,
		 tcp_miss_client,
		 tcp_none_client,
		 counters.tcp,
		 counters.tcp_hit,
		 counters.tcp_miss,
		 counters.tcp_miss_none,
		 ! globals.sortDBaseByByte );

  size_t* jndex = 
    showGeneric( text, "# TCP CLIENTS BY REQUST", 40, 
		 globals.preferDatarate, true, number, min_reqs, &none,
		 tcp_client,
		 counters.tcp,
		 tcp_hit_client,
		 tcp_miss_client,
		 tcp_none_client,
		 counters.tcp,
		 counters.tcp_hit,
		 counters.tcp_miss,
		 counters.tcp_miss_none,
		 globals.sortDBaseByByte );

  if ( dbase )
    dumpGeneric( dbase, "client tcp", stamp, number, min_reqs,
		 globals.sortDBaseByByte ? jndex : index, &none,
		 tcp_client, tcp_hit_client, 
		 tcp_miss_client, tcp_none_client );

  delete[] (globals.sortDBaseByByte ? jndex : index);
}



const String no_dns( "<NODNS>" );
const String no_irr( "<NO_AS>" );

void
hierarchyHostLookup( DNSCache* dns,
		     const CountMap& clients, AddressMap& result )
{
  // init result unless empty
  if ( result.size() ) result.clear();

  // combine all addresses into a map for massive parallel lookups
  StringSet clientSet;
  for ( CountMap::Iterator i(clients); i.avail(); i++ ) {
    String key( i.key().lower() );
    MyUInt32 address = DNSItem::aton(key);
    if ( address == C_U32(-1) ) clientSet.insert(key);
    else result[key] = address;
  }

  // if there is something to be looked up, do it now
  if ( ! clientSet.empty() ) {
    DNSCache::DNSItemMap local( dns->getanybyany(clientSet) );
    for ( DNSCache::DNSItemMap::Iterator i(local); i.avail(); i++ ) {
      StringSet::iterator j = clientSet.find( i.key() );
      if ( j != clientSet.end() ) {
	DNSItem value( i.value() );
	result[i.key()] = ( value.empty || value.n_addresses == 0 ) ?
	  C_U32(-1) :
	  value.addresses[0];
      }
    }
  }
}

void
hierarchyASLookup( IRRCache* irr, 
		   const CountMap& clients, const AddressMap& addr_map, 
		   IRRCache::IRRItemMap& dest_map, CountMap& asnmap )
{
  // create ASN map
  StringSet destination;
  for ( CountMap::Iterator i(clients); i.avail(); i++ ) {
    if ( i.value().reqs() ) {
      MyUInt32 address = addr_map[ i.key().lower() ];
      if ( address != C_U32(-1) ) {
	// DNS success, add host address to lookup for IRR
	destination.insert(DNSItem::ntoa(address));
      }
    }
  }

  // massive parallel IRR lookup, address to origin
  dest_map = irr->getOriginByAddress( destination );
  // The answers in dest_map contain the host address,
  // NOT the network/CIDR address.

  // count all items, while collecting AS numbers in "asnumber" for 
  // further lookups of the AS description
  StringSet asnumber;
  for ( CountMap::Iterator i(clients); i.avail(); i++ ) {
    if ( i.value().reqs() ) {
      MyUInt32 address = addr_map[ i.key().lower() ];
      if ( address != C_U32(-1) ) {
	// DNS success, now check IRR
	IRRItem what = dest_map[ DNSItem::ntoa(address) ];
	if ( what.empty ) {
	  // IRR failure
	  asnmap[ no_irr ] += i.value();
	} else {
	  // IRR success
	  asnmap[what.item] += i.value();
	  asnumber.insert(what.item);
	}
      } else {
	// DNS failure
	asnmap[ no_dns ] += i.value();
      }
    }
  }

  // massive parallel IRR lookup, origin to description
  dest_map += irr->getanybyany( asnumber );
}

class IRRLookup : public NullLookup {
public:
  IRRLookup( const IRRCache::IRRItemMap& imap, size_t maxsize )
    :_map(imap),_max(maxsize) { }
  virtual String lookup( const String& a ) const
  {
    String result( a );
    while ( result.length() < 7 ) result += " ";
    return ( result += " \"" + _map[a].item.substring(0,_max-10) + "\"" );
  }
private:
  const IRRCache::IRRItemMap& _map;
  size_t _max;
};

static
void
bothASN( FILE* text, FILE* dbase, time_t stamp, DNSCache* dns, IRRCache* irr, 
	 const Counters& counters, const size_t number, const size_t min_reqs )
{
  // combine all HIER hosts into a map for massive parallel DNS lookups
  CountMap   asnmap;
  AddressMap addr_map;
  hierarchyHostLookup( dns, counters.hier_direct_host, addr_map );
  // POSTCONDITION: addr_map contains all addresses belonging to the 
  // direct hosts. If the HNo patch was applied, the address conversion
  // will be done without needing to bother DNS (much faster).

  // combine all HIER addresses from HIER hosts for massive parallel IRR
  IRRCache::IRRItemMap dest_map;
  hierarchyASLookup( irr, counters.hier_direct_host, addr_map,
		     dest_map, asnmap );
  // POSTCONDITION: dest_map will contain *hosts* key (not network/CIDR)
  // as dotted quad derived from addr_map which got its hosts from the
  // hier_direct_host map. The value type is the AS#, <NO_AS>, or <NODNS>.
  // It will also contain for the key AS# the description of the AS.
  // asnmap is a count map

  // custom-convert lookups on output functions
  IRRLookup lookup( dest_map, 60 );
  size_t* index = 
    showGeneric( text, "# DIRECT DST BY REQUESTS", 60,
		 globals.preferDatarate, false, number, min_reqs, &lookup,
		 asnmap,
		 counters.hier_direct,
		 _noHits,
		 counters.hier_direct,
		 Counter(),
		 ! globals.sortDBaseByByte );

  size_t* jndex = 
    showGeneric( text, "# DIRECT DST BY VOLUME", 60,
		 globals.preferDatarate, true, number, min_reqs, &lookup,
		 asnmap,
		 counters.hier_direct,
		 _noHits,
		 counters.hier_direct,
		 Counter(),
		 globals.sortDBaseByByte );

  if ( dbase )
    dumpGeneric( dbase, "as", stamp, number, min_reqs,
		 globals.sortDBaseByByte ? jndex : index, &lookup,
		 asnmap, _noHits );
  
  delete[] (globals.sortDBaseByByte ? jndex : index);
}

static
void
showPeaks( FILE* out, const Counters& counters )
{
  char tbuf[256];

  fprintf( out, "%-19s %8s %8s      %8s %8s      %8s %8s      %8s      %8s      %8s\n",
	  "# REQUEST PEAKS", "udp", "udp-hit", "int", "int-hit", "tcp", "tcp-hit",
	  "direct", "parent", "peer" );
  fputstr( out, "------------------- -------- ------------- -------- ------------- -------- ------------- ------------- ------------- -------------" );
  for ( MyUInt32 i=counters.startTime / globals.peakInterval;
	i <= counters.finalTime / globals.peakInterval; 
	++i ) {
    time_t then = i * globals.peakInterval;
    strftime( tbuf, sizeof(tbuf), timeFormat, localtime(&then) );
    fprintf( out, "%s " SF_wU32(8) " " SF_wU32(8) "%s"
	     SF_wU32(8) " " SF_wU32(8) "%s"
	     SF_wU32(8) " " SF_wU32(8) "%s" 
	     SF_wU32(8) "%s" SF_wU32(8) "%s" SF_wU32(8) "%s\n",
	     tbuf,
	     counters.peak_udp[i].reqs(), 
	     counters.peak_udp_hit[i].reqs(),
	     autoPercent( counters.peak_udp[i].reqs(),
			  counters.peak_udp_hit[i].reqs() ).c_str(),
	     counters.peak_int[i].reqs(), 
	     counters.peak_int_hit[i].reqs(),
	     autoPercent( counters.peak_int[i].reqs(),
			  counters.peak_int_hit[i].reqs() ).c_str(),
	     counters.peak_tcp[i].reqs(), 
	     counters.peak_tcp_hit[i].reqs(),
	     autoPercent( counters.peak_tcp[i].reqs(),
			  counters.peak_tcp_hit[i].reqs() ).c_str(),
	     counters.peak_hier_direct[i].reqs(),
	     autoPercent( counters.peak_tcp[i].reqs(), 
			  counters.peak_hier_direct[i].reqs() ).c_str(),
	     counters.peak_hier_parent[i].reqs(),
	     autoPercent( counters.peak_tcp[i].reqs(), 
			  counters.peak_hier_parent[i].reqs() ).c_str(),
	     counters.peak_hier_peer[i].reqs(),
	     autoPercent( counters.peak_tcp[i].reqs(), 
			  counters.peak_hier_peer[i].reqs() ).c_str() );
  }
  fputc('\n',out);

  fprintf( out, "%-19s %10s %10s      %10s %10s      %10s %10s      %10s      %10s      %10s\n",
	  "# VOLUME PEAKS", "udp", "udp-hit", "int", "int-hit", "tcp", "tcp-hit",
	  "direct", "parent", "peer" );
  fputstr( out, "------------------- ---------- --------------- ---------- --------------- ---------- --------------- --------------- --------------- ---------------" );
  for ( MyUInt32 i=counters.startTime / globals.peakInterval;
	i <= counters.finalTime / globals.peakInterval; 
	++i ) {
    time_t then = i * globals.peakInterval;
    strftime( tbuf, sizeof(tbuf), timeFormat, localtime(&then) );
    fprintf( out, "%s %s %s%s%s %s%s%s %s%s%s%s%s%s%s%s\n",
	    tbuf,
	    autoSize( counters.peak_udp[i].size() ).c_str(), 
	    autoSize( counters.peak_udp_hit[i].size() ).c_str(),
	    autoPercent( counters.peak_udp[i].size(),
			 counters.peak_udp_hit[i].size() ).c_str(),
	    autoSize( counters.peak_int[i].size() ).c_str(), 
	    autoSize( counters.peak_int_hit[i].size() ).c_str(),
	    autoPercent( counters.peak_int[i].size(),
			 counters.peak_int_hit[i].size() ).c_str(),
	    autoSize( counters.peak_tcp[i].size() ).c_str(), 
	    autoSize( counters.peak_tcp_hit[i].size() ).c_str(),
	    autoPercent( counters.peak_tcp[i].size(),
			 counters.peak_tcp_hit[i].size() ).c_str(),
	    autoSize( counters.peak_hier_direct[i].size() ).c_str(),
	    autoPercent( counters.peak_tcp[i].size(), 
			 counters.peak_hier_direct[i].size() ).c_str(),
	    autoSize( counters.peak_hier_parent[i].size() ).c_str(),
	    autoPercent( counters.peak_tcp[i].size(), 
			 counters.peak_hier_parent[i].size() ).c_str(),
	    autoSize( counters.peak_hier_peer[i].size() ).c_str(),
	    autoPercent( counters.peak_tcp[i].size(), 
			 counters.peak_hier_peer[i].size() ).c_str() );
  }
  fputc('\n',out);

  fprintf( out, "%-19s %10s%10s      %10s%10s      %10s      %10s      %10s\n",
	  "# DURATION PEAKS", "int", "int-hit", "tcp", "tcp-hit", "direct", "parent", "peer" );
  fputstr( out, "------------------- ---------- --------------- ---------- --------------- --------------- --------------- ---------------" );
  for ( MyUInt32 i=counters.startTime / globals.peakInterval;
	i <= counters.finalTime / globals.peakInterval; 
	++i ) {
    time_t then = i * globals.peakInterval;
    strftime( tbuf, sizeof(tbuf), timeFormat, localtime(&then) );
    fprintf( out, "%s %s%s%s%s%s%s%s%s%s%s%s%s\n",
	    tbuf,
	    autoTime( counters.peak_int[i].time(), 7, 1 ).c_str(), 
	    autoTime( counters.peak_int_hit[i].time(), 7, 1 ).c_str(),
	    autoPercent( counters.peak_int[i].time(),
			 counters.peak_int_hit[i].time() ).c_str(),
	    autoTime( counters.peak_tcp[i].time(), 7, 1 ).c_str(), 
	    autoTime( counters.peak_tcp_hit[i].time(), 7, 1 ).c_str(),
	    autoPercent( counters.peak_tcp[i].time(),
			 counters.peak_tcp_hit[i].time() ).c_str(),
	    autoTime( counters.peak_hier_direct[i].time(), 7, 1 ).c_str(),
	    autoPercent( counters.peak_tcp[i].time(), 
			 counters.peak_hier_direct[i].time() ).c_str(),
	    autoTime( counters.peak_hier_parent[i].time(), 7, 1 ).c_str(),
	    autoPercent( counters.peak_tcp[i].time(), 
			 counters.peak_hier_parent[i].time() ).c_str(),
	    autoTime( counters.peak_hier_peer[i].time(), 7, 1 ).c_str(),
	    autoPercent( counters.peak_tcp[i].time(), 
			 counters.peak_hier_peer[i].time() ).c_str() );
  }
  fputc('\n',out);
}


static
void
dumpPeaks( const char* cache, FILE* out, time_t ts, const Counters& counters )
{
  for ( MyUInt32 i=counters.startTime / globals.peakInterval;
	i <= counters.finalTime / globals.peakInterval; 
	++i ) {
    time_t then = i * globals.peakInterval;
    fprintf( out, "stamp2 %s " _TS " %+d " SF_U32 " " SF_U32 "\n", 
	     cache,
	     then, gmtOffset(then), globals.peakInterval, ::version );
    fprintf( out, "peak " _TS _DB _DB _DB _DB _DB _DB _DB _DB _DB "\n", then,
	     _dump(counters.peak_udp[i]), _dump(counters.peak_udp_hit[i]),
	     _dump(counters.peak_int[i]), _dump(counters.peak_int_hit[i]),
	     _dump(counters.peak_tcp[i]), _dump(counters.peak_tcp_hit[i]),
	     _dump(counters.peak_hier_direct[i]), 
	     _dump(counters.peak_hier_parent[i]),
	     _dump(counters.peak_hier_peer[i]) );
  }
}



static
void
showDistribution( FILE* out, const Counters& counters )
{
  static const char* msg[Counters::D_END] = { "HIT", "MISS", "NONE" };

  for ( int d=Counters::D_HIT; d<Counters::D_END; ++d ) {
    fprintf( out, "# TCP %s DISTRIBUTION\n", msg[d] );

    // find start and stop of columns
    int sizes[2] = { 0, 31 };
    while ( counters.distribution[d].sizeDist[sizes[0]] == 0 && 
	    sizes[0] <= sizes[1] ) sizes[0]++;
    while ( counters.distribution[d].sizeDist[sizes[1]] == 0 &&
	    sizes[0] <= sizes[1] ) sizes[1]--;

    // find start and stop of lines
    int times[2] = { 0, 31 };
    while ( counters.distribution[d].timeDist[times[0]] == 0 && 
	    times[0] <= times[1] ) times[0]++;
    while ( counters.distribution[d].timeDist[times[1]] == 0 &&
	    times[0] <= times[1] ) times[1]--;
    fprintf( out, "%10s:", "duration" );

    // sanity check
    if ( times[1] < times[0] || sizes[1] < sizes[0] ) {
      fputstr( out, "<empty>" );
      continue;
    }

    // print header
    for ( int s=sizes[0]; s<=sizes[1]; ++s ) {
      String msg( autoSize( s ? pow(2.0,s-1) : 0, 999.9, 5, 0 ) );
      fprintf( out, "%6s", msg.substitute(" ","",true).c_str() );
    }
    fputstr( out, " = TIME-SUM" );

    // print tail
    fputs( " ----------", out );
    for ( int s=sizes[0]; s<=sizes[1]; ++s ) fputs( " -----", out );
    fputstr( out, "   --------" );

    for ( int t=times[0]; t<=times[1]; ++t ) {
      fprintf( out, " %s:", autoTime( t ? pow(2.0,t-1) : 0, 6, 1 ).c_str() );
      for ( int s=sizes[0]; s<=sizes[1]; ++s ) {
	fprintf( out, " %5lu", counters.distribution[d].timeSizeDist[t][s] );
      }
      fprintf( out, " = %8lu\n", counters.distribution[d].timeDist[t] );
    }

    // print tail
    fputs( " ----------", out );
    for ( int s=sizes[0]; s<=sizes[1]; ++s ) fputs( " -----", out );
    fputstr( out, "   --------" );

    // print size sums
    MyUInt64 sum = C_U64(0);
    fprintf( out, "%10s:", "SIZE-SUM" );
    for ( int s=sizes[0]; s<=sizes[1]; ++s ) {
      fprintf( out, " %5lu", counters.distribution[d].sizeDist[s] );
      sum += counters.distribution[d].sizeDist[s];
    }
    fprintf( out, " = " SF_wU64(8) "\n\n", sum );
  }
}

static
void
dumpDistribution( FILE* out, time_t ts, const Counters& counters )
{
  static const char* msg[Counters::D_END] = { "hit", "miss", "none" };

  for ( int d=Counters::D_HIT; d<Counters::D_END; ++d ) {

    fprintf( out, "dist size %s " _TS "", msg[d], ts );
    for ( int s=0; s<32; ++s ) 
      fprintf( out, " %lu", counters.distribution[d].sizeDist[s] );
    fputc( '\n', out );

    fprintf( out, "dist time %s " _TS "", msg[d], ts );
    for ( int t=0; t<32; ++t ) 
      fprintf( out, " %lu", counters.distribution[d].timeDist[t] );
    fputc( '\n', out );

    for ( int s=0; s<32; ++s ) {
      fprintf( out, "dist both[%d] %s " _TS "", s, msg[d], ts );
      for ( int t=0; t<32; ++t )
	fprintf( out, " %lu", counters.distribution[d].timeSizeDist[t][s] );
      fputc( '\n', out );
    }
  }
}



static
String
sftime( double stamp )
{
  char temp[3][32];
  double integer;
  sprintf( temp[0], "%.3f", modf( stamp, &integer ) );
  time_t what = (time_t) integer;
  
  strftime( temp[1], 32, "%H:%M:%S", localtime(&what) );
  strcpy( temp[2], temp[1] );
  strcat( temp[2], temp[0]+1 );
  return String(temp[2]);
}

static
void
cacheStats( FILE* out, const char* prefix,
	    const char* name, size_t size, const BaseCache* cache )
{
  MyUInt32 all = cache->request(BaseCache::C_ALL);
  MyUInt32 hit = cache->request(BaseCache::C_HIT);
  fprintf( out, "%s%s cache (%u items) had " SF_U32 " requests with " 
	   SF_U32 " hits (%s),\n", prefix,
	   name, size, all, hit, autoPercent(all,hit).trim().c_str() );

  MyUInt32 miss = cache->request(BaseCache::C_MISS);
  MyUInt32 ttl = cache->request(BaseCache::C_TTL);
  MyUInt32 late = cache->request(BaseCache::C_LATE);
  fprintf( out, "%s " SF_U32 " ttl expiries (%s) + "
	   SF_U32 " cache misses (%s) - "
	   SF_U32 " late hits (%s),\n", prefix,
	   ttl, autoPercent(all,ttl).trim().c_str(), 
	   miss, autoPercent(all,miss).trim().c_str(),
	   late, autoPercent(all,late).trim().c_str() );

  MyUInt32 pos = cache->request(BaseCache::C_POS);
  MyUInt32 neg = cache->request(BaseCache::C_NEG);
  fprintf( out, "%s resulting in " SF_U32 " successful (%s) and " SF_U32 
	   " failed (%s) lookups.\n", prefix,
	   pos, autoPercent(all,pos).trim().c_str(),
	   neg, autoPercent(all,neg).trim().c_str() );
}

void
showStats( FILE* out, const char* prefix,
	   const char* cache, DNSCache* dns, IRRCache* irr,
	   double looptime, double startup, MyUInt32 lineno )
{
  double runtime = now();
  fprintf( out, "%s# STATISTICS FOR \"%s\"\n", prefix, cache );
  fprintf( out, "%sanalysis started at %s\n", prefix, 
	   sftime(startup).c_str() );
  fprintf( out, "%sparsing finished at %s\n", prefix, 
	   sftime(startup+looptime).c_str() );
  fprintf( out, "%sresults printed at %s\n", prefix, 
	   sftime(runtime).c_str() );

  runtime -= startup;
  fprintf( out, "%s%.1f s spent in analyser\n", prefix, runtime );
  fprintf( out, "%s%.1f s spent in parser loop\n",
	   prefix, looptime );
  fprintf( out, "%s" SF_U32 " lines processed (%.1f lps)\n", 
	   prefix, lineno, lineno / looptime );
  
  if ( dns ) cacheStats( out, prefix, "DNS", dns->size(), dns );
  if ( irr ) cacheStats( out, prefix, "IRR", irr->size(), irr );
  fputc( '\n', out );
}

// ----------------------------------------------------------------------

inline
void
myflush( FILE* fp )
{
  if ( fp ) fflush(fp);
}

void
printResults( FILE* text, FILE* dbase, const char* cache,
	      DNSCache* dns, IRRCache* irr, const Counters& counters,
	      double looptime, double startup, MyUInt32 lineno )
  // purpose: print results
  // paramtr: text (IO): file to put textual tabular results into 
  //          dbase (IO): file to put database results into, may be null
  //          cache (IN): (virtual) name to use for output
  //          dns (IO): DNS query and cache
  //          irr (IO): IRR query and cache
  //          counters (IN): current value of last log file processing
  //          looptime (IN): time spent parsing the log file
  //          startup (IN): start time of seafood
  //          lineno (IN): number of lines processed.
  // precondition: text is always a valid fp, even /dev/null...
{
  StringStringMap clientmap; // to hold address translations

  // determine timestamp to log with
  // determine offset UTC and local time for the start time
  time_t offset = gmtOffset(counters.startTime);

  // shift the local start time into UTC, divide by the daily interval
  // and do the Pascal equivalent of round(); cut off any excess seconds.
  double sn = floor((counters.startTime + offset) / globals.dailyInterval + 0.5);

  // Shift back to UTC
  time_t ts = (time_t) (sn * globals.dailyInterval - offset);
  // POSTCONDITION: The localized timestamp is now divisible by interval i1

  // intro
  fputs( "# title...\n", stderr );
  showTitle( text, cache, counters.startTime, counters.finalTime );
  if ( dbase ) {
    fprintf( dbase, "stamp1 %s " _TS " " _TS " %+d " _TS " %+d "
	     SF_U32 " " SF_U32 " " SF_U32 "\n", cache, ts,
	     counters.startTime, gmtOffset(counters.startTime),
	     counters.finalTime, gmtOffset(counters.finalTime),
	     counters.finalTime - counters.startTime, globals.dailyInterval,
	     ::version );
  }
  fflush(text);
  myflush(dbase);

  // overview
  fputs( "# overview...\n", stderr );
  showOverview( text, counters );
  if ( dbase ) dumpOverview( dbase, ts, counters );
  fflush(text);
  myflush(dbase);

  // internal TCP objects
  fputs( "# internal...\n", stderr );
  showInternal( text, dns, counters, 
		globals.tableSize[Global::S_INT], clientmap );
#ifdef ONE_INTERNAL_TABLE
  if ( dbase ) dumpInternal( dbase, dns, ts, counters, 
			     false, globals.tableSize[Global::S_INT] );
#else
  if ( dbase ) dumpInternal( dbase, ts, counters, false );
#endif
  fflush(text);
  myflush(dbase);

  // hierarchy info
  fputs( "# hierarchy...\n", stderr );
  showHierarchy( text, dns, counters, clientmap );
  if ( dbase ) dumpHierarchy( dbase, dns, ts, counters, clientmap );
  fflush(text);
  myflush(dbase);

  // methods
  fputs( "# methods and schemes\n", stderr );
  bothMethods( text, dbase, ts, counters );
  bothSchemes( text, dbase, ts, counters );
  fflush(text);
  myflush(dbase);

  // suffix
  fputs( "# suffices...\n", stderr );
  bothSuffices( text, dbase, ts, counters );
  fflush(text);
  myflush(dbase);

  // top-level domains
  fputs( "# tlds...\n", stderr );
  bothTLD( text, dbase, ts, counters, globals.tableSize[Global::S_TLD], 0 );
  fflush(text);
  myflush(dbase);

  // 2nd-level domains
  fputs( "# 2lds...\n", stderr );
  bothSLD( text, dbase, ts, counters, globals.tableSize[Global::S_2LD], 0 );
  fflush(text);
  myflush(dbase);

  // media types
  fputs( "# mime...\n", stderr );
  showMediatypes( text, counters );
  if ( dbase ) dumpMediatypes( dbase, ts, counters );
  fflush(text);
  myflush(dbase);

  // show port statistics
  fputs( "# ports...\n", stderr );
  showPorts( text, counters );
  if ( dbase ) dumpPorts( dbase, ts, counters );
  fflush(text);
  myflush(dbase);

  if ( dns && irr ) {
    // show directs
    fputs( "# asn...\n", stderr );
    bothASN( text, dbase, ts, dns, irr, 
	     counters, globals.tableSize[Global::S_ASN], 0 );
    fflush(text);
    myflush(dbase);
  }

  // show clients
  fputs( "# clients...\n", stderr );
  bothUDPClients( text, dbase, ts, dns, counters, 
		  globals.tableSize[Global::S_UDP],
		  globals.tableSize[Global::S_MR_UDP], clientmap );
  fflush(text);
  myflush(dbase);
  bothINTClients( text, dbase, ts, dns, counters, 
		  globals.tableSize[Global::S_INT],
		  globals.tableSize[Global::S_MR_INT],
		  clientmap );
  fflush(text);
  myflush(dbase);
  bothTCPClients( text, dbase, ts, dns, counters, 
		  globals.tableSize[Global::S_TCP], 
		  globals.tableSize[Global::S_MR_TCP], 
		  clientmap );
  fflush(text);
  myflush(dbase);

  // show peak intervals
  fputs( "# peaks...\n", stderr );
  showPeaks( text, counters );
  if ( dbase ) dumpPeaks( cache, dbase, ts, counters );
  fflush(text);
  myflush(dbase);

  // show distributions
  if ( globals.showDistributions ) {
    fputs( "# distributions\n", stderr );
    showDistribution( text, counters );
    if ( dbase ) dumpDistribution( dbase, ts, counters );
    fflush(text);
    myflush(dbase);
  }

  // statistics about the log file analysis
  fputs( "# stats...\n", stderr );
  if ( looptime < 1E-4 ) looptime = 1E-4;
  showStats( text, "", cache, dns, irr, looptime, startup, lineno );
  if ( dbase ) 
    showStats( dbase, "# ", cache, dns, irr, looptime, startup, lineno );
  fflush(text);
  myflush(dbase);
}
