//
// $Id: counters.cc,v 1.5 2000/08/10 12:40:08 voeckler Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    counters.cc
//          Thu Aug 05 1999
//
// (c) 1999 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: counters.cc,v $
// Revision 1.5  2000/08/10 12:40:08  voeckler
// added counters for the TCP internal request TCP status (HME).
//
// Revision 1.4  2000/07/27 07:14:23  voeckler
// added suffix counter support, and all internal object counters.
//
// Revision 1.3  1999/10/29 14:01:54  voeckler
// added time stamps (FIXME: this is not perfect).
//
// Revision 1.2  1999/08/25 21:15:06  voeckler
// added distribution count to counters.
//
// Revision 1.1  1999/08/05 21:02:33  voeckler
// Initial revision
//
//
#if defined(__GNUC__) || defined(__GNUG__)
#pragma implementation
#endif

#include <assert.h>
#include "counters.hh"

static const char* RCS_ID =
"$Id: counters.cc,v 1.5 2000/08/10 12:40:08 voeckler Exp $";

Distribution::Distribution()
{
  memset( timeDist, 0, sizeof(timeDist) );
  memset( sizeDist, 0, sizeof(sizeDist) );
  for ( int t=0; t<32; ++t )
    memset( timeSizeDist[t], 0, sizeof(timeSizeDist[t]) );
}



Counters::Counters()
  :nMethod( LogLine::mtable.distinct()+1 ),
   nStatus( LogLine::stable.distinct()+1 ),
   nHier( LogLine::htable.distinct()+1 ),
   nScheme( LogLine::schemes.distinct()+1 ),
   nSuffix( LogLine::suffices.distinct()+1 ),
   nMedia( LogLine::mediatypes.distinct()+1 ),
   nSubtype( new MyUInt32[nMedia] ),
   startTime(C_U32(0)),finalTime(C_U32(0))
{
#if 0
  char major[32];
  char minor[64];
  for ( int i=0; i<nMedia; ++i ) {
    if ( (nSubtype[i] = LogLine::subtypes[i].distinct() ) ) ++nSubtype[i];
    LogLine::mediatypes.reverse(major,sizeof(major),i);
    for ( int j=0; j<nSubtype[i]; ++j ) {
      LogLine::subtypes[i].reverse(minor,sizeof(minor),j);
      fprintf( stderr, "> %s/%s\n", major, minor );
    }
  }
#else
  for ( size_t i=0; i<nMedia; ++i ) 
    if ( (nSubtype[i] = LogLine::subtypes[i].distinct() ) ) ++nSubtype[i];    
#endif

  methods = new Counter[ nMethod ];
  hit_methods = new Counter[ nMethod ];

  udp_hit_status = new Counter[ nStatus ];
  udp_miss_status = new Counter[ nStatus ];

  int_hit_status = new Counter[ nStatus ];
  int_miss_status = new Counter[ nStatus ];
  int_none_status = new Counter[ nStatus ];

  tcp_scheme = new Counter[ nScheme ];
  tcp_suffix = new Counter[ nSuffix ];
  tcp_mime = new Counter[ nMedia ];

  tcp_submime = new CounterPtr[ nMedia ];
  tcp_hit_submime = new CounterPtr[ nMedia ];
  for ( size_t i=0; i<nMedia; i++ ) {
    tcp_submime[i] = nSubtype[i] ? new Counter[ nSubtype[i] ] : 0;
    tcp_hit_submime[i] = nSubtype[i] ? new Counter[ nSubtype[i] ] : 0;
  }

  tcp_ports = new Counter[65];
  tcp_hit_hier = new Counter[ nHier ];
  tcp_hit_status =  new Counter[ nStatus ];
  tcp_hit_scheme = new Counter[ nScheme ];
  tcp_hit_suffix = new Counter[ nSuffix ];
  tcp_hit_mime = new Counter[ nMedia ];

  tcp_miss_none_status =  new Counter[ nStatus ];
  tcp_miss_status =  new Counter[ nStatus ];

  hier_direct_method = new Counter[ nHier ];
  hier_peer_method = new Counter[ nHier ];
  hier_peer_status = new CountMap[ nHier ];
  hier_parent_method = new Counter[ nHier ];
}

Counters::~Counters()
{
  delete[] methods;
  delete[] hit_methods;

  delete[] udp_hit_status;
  delete[] udp_miss_status;

  delete[] int_hit_status;
  delete[] int_miss_status;
  delete[] int_none_status;

  delete[] tcp_scheme;
  delete[] tcp_suffix;
  delete[] tcp_mime;

  for ( size_t i=0; i<nMedia; ++i ) {
    delete[] tcp_hit_submime[i];
    delete[] tcp_submime[i];
  }
  delete[] tcp_hit_submime;
  delete[] tcp_submime;
  delete[] tcp_ports;

  delete[] tcp_hit_hier;
  delete[] tcp_hit_status;
  delete[] tcp_hit_scheme;
  delete[] tcp_hit_suffix;
  delete[] tcp_hit_mime;

  delete[] tcp_miss_none_status;
  delete[] tcp_miss_status;

  delete[] hier_direct_method;
  delete[] hier_peer_method;
  delete[] hier_peer_status;
  delete[] hier_parent_method;

  delete[] nSubtype;
}
