//
// $Id: network.cc,v 1.3 1999/09/02 19:38:11 voeckler Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    network.cc
//          Mon Aug 30 1999
//
// (c) 1999 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: network.cc,v $
// Revision 1.3  1999/09/02 19:38:11  voeckler
// changed code to determine endianess during runtime.
//
// Revision 1.2  1999/09/02 14:04:24  voeckler
// some byte order fixes for SGI.
//
// Revision 1.1  1999/09/02 10:11:57  voeckler
// Initial revision
//

#if defined(__GNUC__) || defined(__GNUG__)
#pragma implementation
#endif

#include <stdlib.h>
#include "network.hh"
#include "dnsitem.hh"

const MyUInt32 Netmask::cidrtable[2][33] =
{
  { // little endian
    0x00000000,0x00000080,0x000000c0,0x000000e0,
    0x000000f0,0x000000f8,0x000000fc,0x000000fe,
    0x000000ff,0x000080ff,0x0000c0ff,0x0000e0ff,
    0x0000f0ff,0x0000f8ff,0x0000fcff,0x0000feff,
    0x0000ffff,0x0080ffff,0x00c0ffff,0x00e0ffff,
    0x00f0ffff,0x00f8ffff,0x00fcffff,0x00feffff,
    0x00ffffff,0x80ffffff,0xc0ffffff,0xe0ffffff,
    0xf0ffffff,0xf8ffffff,0xfcffffff,0xfeffffff,
    0xffffffff
  },
  { // big endian
    0x00000000,0x80000000,0xc0000000,0xe0000000,
    0xf0000000,0xf8000000,0xfc000000,0xfe000000,
    0xff000000,0xff800000,0xffc00000,0xffe00000,
    0xfff00000,0xfff80000,0xfffc0000,0xfffe0000,
    0xffff0000,0xffff8000,0xffffc000,0xffffe000,
    0xfffff000,0xfffff800,0xfffffc00,0xfffffe00,
    0xffffff00,0xffffff80,0xffffffc0,0xffffffe0,
    0xfffffff0,0xfffffff8,0xfffffffc,0xfffffffe,
    0xffffffff
  }
};

Netmask::Netmask()
{
  // do not use stack, use data segment
  static const MyUInt32 l = 0x12345678; 
  MyUInt08* s = (MyUInt08*) &l;

  if ( s[0] == 0x12 && s[1] == 0x34 && s[2] == 0x56 && s[3] == 0x78 ) {
    fputs( "# machine is big endian\n", stderr );
    current = cidrtable[1]; // big endian
  } else if ( s[0] == 0x78 && s[1] == 0x56 && s[2] == 0x34 && s[3] == 0x12 ) {
    fputs( "# machine is little endian\n", stderr );
    current = cidrtable[0]; // lil endian
  } else {
    fputs( "unknown kind of endianess, aborting!\n", stderr );
    exit(1);
  }
}

const Netmask Network::cidrmask; // call default ctor

Network::Network( const String& s )
{
  char temp[48];
  memset( temp, 0, sizeof(temp) );
  strncpy( temp, s.c_str(), sizeof(temp)-1 );
  char* p = strchr( temp, '/' );
  if ( p ) {
    *p++ = '\0';
    network = inet_addr(temp);
    if ( strchr( p, '.' ) == 0 ) netmask = cidrmask[ atoi(p) ];
    else netmask = inet_addr(p);
  } else {
    // assume host address
    network = inet_addr(temp);
    netmask = C_U32(-1);
  }
  network &= netmask;
}

String
Network::toString() const
{
  String result( DNSItem::ntoa(network) );
  int cidr = cidrmask.find(netmask);

  if ( cidr == -1 ) {
    // irregular mask, use dotted quad mask
    return ( result + "/" + DNSItem::ntoa(netmask) );
  } else {
    // regular mask, use CIDR syntax
    char temp[32];
    sprintf( temp, "/%d", cidr );
    return ( result + temp );
  }
}

