//
// $Id: generic.cc,v 1.3 2000/08/10 12:52:46 voeckler Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    generic.cc
//          Thu Jul 27 2000
//
// (c) 2000 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: generic.cc,v $
// Revision 1.3  2000/08/10 12:52:46  voeckler
// added minimum request option to table dumps, added HME count dumps to the
// generics.
//
// Revision 1.2  2000/08/07 11:52:01  cached
// removed default parameter in implementation module.
//
// Revision 1.1  2000/07/29 22:14:15  voeckler
// Initial revision
//
//
#if defined(__GNUC__) || defined(__GNUG__)
#pragma implementation
#endif

#include "generic.hh"
#include "tools.hh"

static const char* RCS_ID =
"$Id: generic.cc,v 1.3 2000/08/10 12:52:46 voeckler Exp $";

const CountMap _noHits;
String str_other( "<%d more>" );

CountMap
distinct( const CountMap& src, const StringStringMap& xlate )
  // purpose: translate count map with external lookup - make distinct!
  // paramtr: src (IN): count map to make distinct.
  //          xlate (IN): translation for src keys.
  // returns: map containing translated keys and sums.
  // remarks: this helps against multi-homed hosts etc.
{
  CountMap result;
  for ( CountMap::Iterator i( src ); i.avail(); i++ ) {
    String key( xlate.exists(i.key()) ? xlate[i.key()] : i.key() );
    result[key] += i.value();
  }
  return result;
}

void
dumpGeneric( FILE* out, const char* prefix, const time_t stamp,
	     const BasicTrie* trie, 
	     const Counter* count,
	     const Counter* hit_count )
  // purpose: print database dump file in *unsorted* order
  // paramtr: out (IO): destination to format results into
  //          prefix (IN): table key for dump
  //          stamp (IN): beautified time stamp to protocol
  //          trie (IN): pointer to used trie method
  //          count (IN): array of counters to display
  //          hit_count (IN): 0, if there are not HITs to show
  // remarks: there is no "number" limit, as in the map function, because
  //          the tries are always rather limited in size.
{
  char symbol[128];
  bool withHits = (hit_count != 0);
  size_t size = trie->distinct()+1; // include zeroth element!

  for ( MyUInt32 i=0; i<size; ++i ) {
    if ( count[i].reqs() ) {
      symbol[0] = '\0';
      trie->reverse( symbol, sizeof(symbol), i );
      fprintf( out, "%s " _TS " %s" _DB, 
	       prefix, stamp, symbol, _dump(count[i]) );
      if ( withHits ) fprintf( out, _DB, _dump(hit_count[i]) );
      fputc( '\n', out );
    }
  }
}

void
dumpGeneric( FILE* out, const char* prefix, time_t stamp,
	     const size_t number, const size_t min_reqs,
	     const size_t* index,
	     const NullLookup* lookup,
	     const CountMap&   count,
	     const CountMap&   hit_count )
  // purpose: print database dump file in optionally sorted order
  // paramtr: out (IO): destination to format results into
  //          prefix (IN): table key for dump
  //          stamp (IN): beautified time stamp to protocol
  //          number (IN): maximum nr of result lines, 0 for unlimited
  //          index (IN): sorted array of indices, NULL for unsorted order
  //          lookup (IN): object to map reverse lookups on keys 
  //          count (IN): array of counters to display
  //          hit_count (IN): 0, if there are not HITs to show
{
  bool withHits = ( &hit_count != &_noHits );
  bool sorted = ( index != 0 );
  size_t size = count.size();

  // create dummy index, if there is none
  if ( ! sorted ) {
    index = (size_t*) new size_t[size];
    for ( size_t i = 0; i<size; ++i ) 
      ((size_t*) index)[i] = i;
  }

  Counter leftover;
  Counter lhitover;
  MyUInt32 n = C_U32(0);
  for ( size_t m,i=m=0; i<count.size(); ++i ) {
    String key( count.key(index[i]) );
    if ( (number == 0 || number > m) && count[index[i]].reqs() > min_reqs ) {
      // show result line
      String output( lookup->lookup(key) );

      fprintf( out, "%s " _TS " %s" _DB, 
	       prefix, stamp, output.c_str(), _dump(count[index[i]]) );
      if ( withHits ) fprintf( out, _DB, _dump(hit_count[key]) );
      fputc( '\n', out );
      m++;
    } else {
      // just add results internally
      leftover += count[index[i]];
      if ( withHits ) lhitover += hit_count[key];
      n++;
    }
  }
  if ( ! sorted ) delete[] index;

  // tail
  if ( n ) {
    fprintf( out, "%s " _TS " more[" SF_U32 "] " _DB, 
	     prefix, stamp, n, _dump(leftover) );
    if ( withHits ) fprintf( out, _DB, _dump(lhitover) );
    fputc( '\n', out );
  }
}

void
dumpGeneric( FILE* out, const char* prefix, time_t stamp,
	     const size_t number, const size_t min_reqs,
	     const size_t* index,
	     const NullLookup* lookup,
	     const CountMap&   count,
	     const CountMap&   hit_count,
	     const CountMap&   miss_count,
	     const CountMap&   none_count )
  // purpose: print database dump file in optionally sorted order
  // paramtr: out (IO): destination to format results into
  //          prefix (IN): table key for dump
  //          stamp (IN): beautified time stamp to protocol
  //          number (IN): maximum nr of result lines, 0 for unlimited
  //          index (IN): sorted array of indices, NULL for unsorted order
  //          lookup (IN): object to map reverse lookups on keys 
  //          count (IN): array of counters to display
  //          hit_count (IN): 0, if there are not HITs to show
  //          miss_count (IN): number of MISSes
  //          none_count (IN): number of NONE. 
  //                           hit_count + miss_count + none_count = count
{
  bool sorted = ( index != 0 );
  size_t size = count.size();

  // create dummy index, if there is none
  if ( ! sorted ) {
    index = (size_t*) new size_t[size];
    for ( size_t i = 0; i<size; ++i ) 
      ((size_t*) index)[i] = i;
  }

  Counter leftover;
  Counter lhitover;
  Counter lnoneover;
  Counter lmissover;
  MyUInt32 n = C_U32(0);
  for ( size_t m,i=m=0; i<count.size(); ++i ) {
    String key( count.key(index[i]) );
    if ( ( number == 0 || number > m ) && count[index[i]].reqs() > min_reqs ) {
      // show result line
      String output( lookup->lookup(key) );

      fprintf( out, "%s " _TS " %s" _DB _DB _DB _DB "\n", 
	       prefix, stamp, output.c_str(), 
	       _dump(count[index[i]]),
	       _dump(hit_count[key]),
	       _dump(miss_count[key]),
	       _dump(none_count[key]) );
      m++;
    } else {
      // just add results internally
      leftover += count[index[i]];
      lhitover += hit_count[key];
      lmissover += miss_count[key];
      lnoneover += none_count[key];
      n++;
    }
  }
  if ( ! sorted ) delete[] index;

  // tail
  if ( n )
    fprintf( out, "%s " _TS " more[" SF_U32 "] " _DB _DB _DB _DB "\n", 
	     prefix, stamp, n, 
	     _dump(leftover),
	     _dump(lhitover),
	     _dump(lmissover),
	     _dump(lnoneover) );
}

// -------------------------------------------------------------------

size_t* 
showGeneric( FILE* out, const char* title, size_t length,
	     bool useRate, bool byByte,
	     const BasicTrie* trie, 
	     const Counter* count,
	     const Counter  base_count,
	     const Counter* hit_count, 
	     const Counter  base_compare,
	     const Counter  hit_compare,
	     bool returnIndex )
  // paramtr: out (IO): destination to format results into
  //          title (IN): table title
  //          length (IN): size of first column
  //          useRate (IN): globals.preferDatarate
  //          byByte (IN): false -> sort by req; true -> sort by volume
  //          trie (IN): pointer to used trie method
  //          count (IN): array of counters to display
  //          hit_count (IN): 0, if there are not HITs to show
  //          base_count (IN): count of TCP or UDP or INT to compare with
  //          base_compare (IN): to compare sums against for discrepancies
  //          hit_compare (IN): to compare hit sums against for discrep.
  //          returnIndex (IN): true: return index, false: kill index + ret. 0
  // returns: pointer to array of indices sorted according to "byByte".
  // remarks: there is no "number" limit, as in the map function, because
  //          the tries are always rather limited in size.
{
  char symbol[80];
  Counter thit, temp;
  bool withHits = (hit_count != 0);
  size_t size = trie->distinct()+1; // include zeroth element!

  // head
  fputstr( out, valueHead( title, length, useRate, withHits ).c_str() );
  fputstr( out, valueTail( length, withHits ).c_str() );

  // body
  size_t* index = byByte ? indexBySize(count,size) : indexByReqs(count,size);
  for ( MyUInt32 i=0; i<size; ++i ) {
    if ( count[index[i]].reqs() ) {
      symbol[0] = '\0';
      trie->reverse( symbol, sizeof(symbol), index[i] );
      fprintf( out, "%*s %s\n", -length, symbol,
	       withHits ?
	       valueBody( count[index[i]],
			  base_count,
			  hit_count[index[i]], useRate ).c_str() :
	       valueBody( count[index[i]],
			  base_count, useRate ).c_str() );
      temp += count[index[i]];
      if ( withHits ) thit += hit_count[index[i]];
    }
  }
  if ( returnIndex == false ) {
    delete[] index;
    index = 0;
  }

  // tail
  fputstr( out, valueTail( length, withHits ).c_str() );
  fprintf( out, "%*s %s\n", -length, "SUM", 
	   withHits ? 
	   valueBody( temp, base_count, thit, useRate ).c_str() :
	   valueBody( temp, base_count, useRate ).c_str() );

  // post-tail
  if ( temp != base_compare || 
       withHits && thit != hit_compare ) 
    fprintf( out, "%*s %s\n", -length, "SHOULD-BE", 
	     withHits ?
	     valueBody( base_compare,
			base_count,
			hit_compare, useRate ).c_str() :
	     valueBody( base_compare,
			base_count, useRate ).c_str() );
  fputc( '\n', out );
  return index;
}



size_t*
showGeneric( FILE* out, const char* title, size_t length,
	     bool useRate, bool byByte, const size_t number,
	     const size_t min_reqs,
	     const NullLookup* lookup,
	     const CountMap&   count,
	     const Counter     base_count,
	     const CountMap&   hit_count, 
	     const Counter     base_compare,
	     const Counter     hit_compare,
	     bool  returnIndex )
  // paramtr: out (IO): destination to format results into
  //          title (IN): table title
  //          length (IN): size of first column
  //          useRate (IN): globals.preferDatarate
  //          byByte (IN): false -> sort by req; true -> sort by volume
  //          number (IN): maximum nr of result lines, 0 for unlimited
  //          count (IN): array of counters to display
  //          hit_count (IN): 0, if there are not HITs to show
  //          base_count (IN): count of TCP or UDP or INT to compare with
  //          base_compare (IN): to compare sums against for discrepancies
  //          hit_compare (IN): to compare hit sums against for discrep.
  //          returnIndex (IN): true: return index, false: kill index + ret. 0
  // returns: pointer to array of indices sorted according to "byByte".
{
  Counter thit, temp, leftover, lhitover;
  MyUInt32 n = C_U32(0);
  bool withHits = ( &hit_count != &_noHits );

  // head
  fputstr( out, valueHead( title, length, useRate, withHits ).c_str() );
  fputstr( out, valueTail( length, withHits ).c_str() );

  // body
  size_t* index = byByte ? indexBySize(count) : indexByReqs(count);
  for ( size_t m,i=m=0; i<count.size(); ++i ) {
    String key( count.key(index[i]) );
    if ( ( number == 0 || number > m ) && count[index[i]].reqs() > min_reqs ) {
      // show result line
      String output( lookup->lookup(key).substring(0,length) );
      fprintf( out, "%*s %s\n", -length, output.c_str(),
	       withHits ?
	       valueBody( count[index[i]],
			  base_count,
			  hit_count[key], useRate ).c_str() :
	       valueBody( count[index[i]],
			  base_count, useRate ).c_str() );
      m++;
    } else {
      // just add results internally
      leftover += count[index[i]];
      if ( withHits ) lhitover += hit_count[key];
      n++;
    }
    temp += count[index[i]];
    if ( withHits ) thit += hit_count[key];
  }
  if ( returnIndex == false ) {
    delete[] index;
    index = 0;
  }

  // pre-tail
  if ( n ) {
    char here[16];
    sprintf( here, str_other.c_str(), n );
    fprintf( out, "%*s %s\n", -length, here, 
	     withHits ?
	     valueBody( leftover, base_count, lhitover, useRate ).c_str() :
	     valueBody( leftover, base_count, useRate ).c_str() );
  }

  // tail
  fputstr( out, valueTail( length, withHits ).c_str() );
  fprintf( out, "%*s %s\n", -length, "SUM", 
	   withHits ? 
	   valueBody( temp, base_count, thit, useRate ).c_str() :
	   valueBody( temp, base_count, useRate ).c_str() );

  // post-tail
  if ( temp != base_compare || 
       withHits && thit != hit_compare ) 
    fprintf( out, "%*s %s\n", -length, "SHOULD-BE", 
	     withHits ?
	     valueBody( base_compare,
			base_count,
			hit_compare, useRate ).c_str() :
	     valueBody( base_compare,
			base_count, useRate ).c_str() );
  fputc( '\n', out );
  return index;
}

size_t*
showGeneric( FILE* out, const char* title, size_t length,
	     bool useRate, bool byByte, const size_t number,
	     const size_t min_reqs,
	     const NullLookup* lookup,
	     const CountMap&   count,
	     const Counter     base_count,
	     const CountMap&   hit_count, 
	     const CountMap&   miss_count,
	     const CountMap&   none_count,
	     const Counter     base_compare,
	     const Counter     hit_compare,
	     const Counter     miss_compare,
	     const Counter     none_compare,
	     bool  returnIndex )
  // paramtr: out (IO): destination to format results into
  //          title (IN): table title
  //          length (IN): size of first column
  //          useRate (IN): globals.preferDatarate
  //          byByte (IN): false -> sort by req; true -> sort by volume
  //          number (IN): maximum nr of result lines, 0 for unlimited
  //          count (IN): array of counters to display
  //          hit_count (IN): number of HITs
  //          miss_count (IN): number of MISSes
  //          none_count (IN): number of NONE. 
  //                           hit_count + miss_count + none_count = count
  //          base_count (IN): count of TCP or UDP or INT to compare with
  //          base_compare (IN): to compare sums against for discrepancies
  //          hit_compare (IN): to compare hit sums against for discrep.
  //          miss_compare (IN): to compare miss sums against for discrep.
  //          none_compare (IN): to compare none sums against for discrep.
  //          returnIndex (IN): true: return index, false: kill index + ret. 0
  // returns: pointer to array of indices sorted according to "byByte".
{
  Counter  temp,  leftover;
  Counter  thit,  lhitover;
  Counter tmiss, lmissover;
  Counter tnone, lnoneover;
  MyUInt32 n = C_U32(0);

  // head
  fputstr( out, valueHead( title, length, useRate, true ).substitute("HIT","HME",true).c_str() );
  fputstr( out, valueTail( length, true ).c_str() );

  // body
  size_t* index = byByte ? indexBySize(count) : indexByReqs(count);
  for ( size_t m,i=m=0; i<count.size(); ++i ) {
    String key( count.key(index[i]) );
    if ( ( number == 0 || number > m ) && count[index[i]].reqs() > min_reqs ) {
      // show result line
      String output( lookup->lookup(key).substring(0,length) );
      fprintf( out, "%*s %s\n", -length, output.c_str(),
	       valueBody( count[index[i]],
			  base_count,
			  hit_count[key], useRate ).c_str() );
      if ( miss_count[key].reqs() )
	fprintf( out, " %*s %s\n", -(length+44-1), "MISS",
		 valueBody( miss_count[key],
			    count[index[i]],
			    useRate ).c_str() );
      if ( none_count[key].reqs() )
	fprintf( out, " %*s %s\n", -(length+44-1), "NONE",
		 valueBody( none_count[key], 
			    count[index[i]], 
			    useRate ).c_str() );
      m++;
    } else {
      // just add results internally
      leftover += count[index[i]];
      lhitover += hit_count[key];
      lmissover += miss_count[key];
      lnoneover += none_count[key];
      n++;
    }
    temp += count[index[i]];
    thit += hit_count[key];
    tmiss += miss_count[key];
    tnone += none_count[key];
  }
  if ( returnIndex == false ) {
    delete[] index;
    index = 0;
  }

  // pre-tail
  if ( n ) {
    char here[80];
    sprintf( here, str_other.c_str(), n );
    fprintf( out, "%*s %s\n", -length, here, 
	     valueBody( leftover, base_count, lhitover, useRate ).c_str() );
    if ( lmissover.reqs() )
      fprintf( out, " %*s %s\n", -(length+44-1), "MISS",
	       valueBody( lmissover, base_count, useRate ).c_str() );
    if ( lnoneover.reqs() )
      fprintf( out, " %*s %s\n", -(length+44-1), "NONE", 
	       valueBody( lnoneover, base_count, useRate).c_str() );
  }

  // tail
  fputstr( out, valueTail( length, true ).c_str() );
  fprintf( out, "%*s %s\n", -length, "SUM", 
	   valueBody( temp, base_count, thit, useRate ).c_str() );
  if ( tmiss.reqs() )
    fprintf( out, " %*s %s\n", -(length+44-1), "MISS-SUM", 
	     valueBody( tmiss, base_count, useRate ).c_str() );
  if ( tnone.reqs() )
    fprintf( out, " %*s %s\n", -(length+44-1), "NONE-SUM", 
	     valueBody( tnone, base_count, useRate ).c_str() );

  // post-tail
  if (  temp != base_compare ||  thit != hit_compare ||
       tnone != none_compare || tmiss != miss_compare ) {
    fprintf( out, "%*s %s\n", -length, "SHOULD-BE", 
	     valueBody( base_compare, 
			base_count, 
			hit_compare, useRate ).c_str() );
    fprintf( out, " %*s %s\n", -(length+44-1), "SHOULD-MISS", 
	     valueBody(miss_compare, base_count, useRate).c_str() );
    fprintf( out, " %*s %s\n", -(length+44-1), "SHOULD-NONE", 
	     valueBody(none_compare, base_count, useRate).c_str() );
  }

  fputc( '\n', out );
  return index;
}
