//
// $Id: primetab.cc,v 1.4 2000/06/30 13:08:51 voeckler Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    primetab.cc
//          Wed Aug 12 1997
//
// (c) 1997 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: primetab.cc,v $
// Revision 1.4  2000/06/30 13:08:51  voeckler
// added small value to tables in order to be more memory efficient for
// triple recursive maps, e.g. a map of a map of a map.
//
// Revision 1.3  1999/08/05 21:18:31  voeckler
// changes from size_t to MyUInt32.
//
// Revision 1.2  1998/07/02 09:42:41  voeckler
// changed from HashIndex to size_t, changed spacing from pi to 10.
//
// Revision 1.1  1997/08/18 11:45:58  voeckler
// Initial revision
//

#if defined(__GNUC__) || defined(__GNUG__)
#pragma implementation
#endif

#include "primetab.hh"

// const int SIZE;

const MyUInt32 primes[SIZE] = {
  // constants of useful prime numbers.
  C_U32(11),
  C_U32(103), 
  C_U32(1009), 
  C_U32(10009), 
  C_U32(100019), 
  C_U32(1000033), 
  C_U32(10000079), 
  C_U32(100000037) 
};

const MyUInt32 fillup[SIZE] = {
  // 20*pi % of the above stated numbers, threshold for invoking rehash.
  // make sure these are prime numbers, too. Abused for double hashing.
  C_U32(7),
  C_U32(61),
  C_U32(631),
  C_U32(6287),
  C_U32(62827),
  C_U32(628319),
  C_U32(6283223),
  C_U32(62831869) 
};
