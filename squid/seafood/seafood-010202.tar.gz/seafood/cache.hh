//
// $Id: cache.hh,v 1.4 1999/09/02 10:19:45 voeckler Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    cache.hh
//          Thu Aug 05 1999
//
// (c) 1999 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: cache.hh,v $
// Revision 1.4  1999/09/02 10:19:45  voeckler
// added late HIT constant, added method to increment a counter.
//
// Revision 1.3  1999/08/20 12:15:55  voeckler
// left-over bug fixes from NDBM removal. Now includes iostream, as the
// textual database file needs to be streamed.
//
// Revision 1.2  1999/08/15 22:30:40  voeckler
// extended statistics.
//
// Revision 1.1  1999/08/05 21:00:36  voeckler
// Initial revision
//
//
#ifndef _CACHE_HH
#define _CACHE_HH

#if defined(__GNUC__) || defined(__GNUG__)
#pragma interface
#endif

#include "typedefs.h"
#include <iostream.h>

class BaseCache {
public:
  enum CacheRequest { C_ALL, C_HIT, C_LATE, 
		      C_MISS, C_TTL, C_POS, C_NEG, C_END };

  inline BaseCache( MyUInt32 posTTL = 3600 * 24 * 30,
		    MyUInt32 negTTL = 3600 * 24 * 7 )
    :positiveTTL(posTTL),negativeTTL(negTTL)
  {
    memset( requests, 0, sizeof(MyUInt32) * C_END );
  }

  inline MyUInt32 request( CacheRequest what ) const
  {
    if ( what >= C_ALL && what < C_END ) return requests[what];
    else return C_U32(0);
  }

  inline MyUInt32 incr( CacheRequest what )
  {
    if ( what >= C_ALL && what < C_END ) return ++requests[what];
    else return C_U32(0);
  }

protected:
  MyUInt32  positiveTTL;
  MyUInt32  negativeTTL;

#ifndef HAS_MUTABLE
#define mutable
#endif // HAS_MUTABLE

  mutable MyUInt32 requests[C_END];

private:
  // disallow
  BaseCache( const BaseCache& );
  BaseCache& operator=( const BaseCache& );
};

#endif // _CACHE_HH
