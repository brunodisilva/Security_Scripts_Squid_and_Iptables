//
// $Id: gdbm.hh,v 1.1 1999/10/29 13:57:22 voeckler Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    gdbm.hh
//          Sun Sep 12 1999
//
// (c) 1999 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: gdbm.hh,v $
// Revision 1.1  1999/10/29 13:57:22  voeckler
// Initial revision
//
//
#ifndef _GDBM_HH
#define _GDBM_HH

#if defined(__GNUC__) || defined(__GNUG__)
#pragma interface
#endif

#include <stdlib.h>
#include <gdbm.h>
#include "string.hh"

class GDBMIterator;

class GDBM {
public:
  GDBM( const char* fn, bool readOnly = false, bool fastMode = true );
  GDBM( const String& s, bool readOnly = false, bool fastMode = true );
  ~GDBM();

  class Iterator;
  friend Iterator;
  
  bool exists( const String& key ) const;
  // purpose: check for existence of key w/o allocating memory for it
  // paramtr: key (IN): key to check for
  // results: true: key was in database, false: key was *not* in database

  String fetch( const String& key ) const;
  // purpose: obtain the value for a key
  // paramtr: key (IN): key to fetch from database
  // returns: value fetched from database, or empty string, if key not found
  inline String operator[]( const String& key ) const
    { return fetch(key); }

  bool insert( const String& key, String value, bool replace = true );
  // purpose: insert a new value or overwrite an existing value
  // paramtr: key (IN): key to associate with
  //          value (IN): value to store
  //          replace (IN): true: overwrite existing values,
  //                        false: do not overwrite existing values
  // returns: true, if key was inserted into database,
  //          false, if no key was inserted (e.g. key exists && ! replace )

  bool erase( const String& key );
  // purpose: remove a key/value pair from the database
  // paramtr: key (IN): key to remove with its value
  // returns: true, if the delete was successful

  bool setFastMode( bool fastMode = true );
  inline void sync( void ) const
    { gdbm_sync(database); }

  String errmsg( void ) const;
  String version( void ) const;

protected:
  char*       filename;
  GDBM_FILE   database;

private:
  GDBM();
  GDBM( const GDBM& );
  GDBM& operator=( const GDBM& );
};

class GDBM::Iterator {
public:
  inline Iterator( const GDBM& dbase )
    :db(dbase.database)
  { cursor = gdbm_firstkey(db); }
  inline ~Iterator()
  { if ( cursor.dptr != 0 ) free((void*) cursor.dptr ); }
  inline bool avail() const
  { return (cursor.dptr != 0); }
  inline void* operator++( int )
  { 
    if ( cursor.dptr != 0 ) {
      datum next = gdbm_nextkey( db, cursor );
      free((void*) cursor.dptr );
      cursor = next;
    }
    return (void*) cursor.dptr;
  }
  inline void rewind()
  { 
    datum next = gdbm_firstkey(db);
    if ( cursor.dptr != 0 )
      free((void*) cursor.dptr );
    cursor = next;
  }

  inline String key() const
  { return String(cursor.dptr,cursor.dsize); }
  inline String value()
  {
    datum value = gdbm_fetch( db, cursor );
    String result;
    if ( value.dptr != 0 ) {
      result = String(value.dptr,value.dsize);
      free((void*)value.dptr);
    }
    return result;
  }
protected:
  GDBM_FILE db;
  datum cursor;
};

#endif // _GDBM_HH

