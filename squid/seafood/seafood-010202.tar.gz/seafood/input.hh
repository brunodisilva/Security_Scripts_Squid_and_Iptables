//
// $Id: input.hh,v 1.9 1999/08/23 12:43:39 voeckler Exp voeckler $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    input.hh
//          Sat Jul  4 1998
//
// (c) 1998 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: input.hh,v $
// Revision 1.9  1999/08/23 12:43:39  voeckler
// removed spelling bug.
//
// Revision 1.8  1999/08/20 22:44:52  voeckler
// move PlainInput d'tor into the implementation file.
//
// Revision 1.7  1999/08/18 11:12:52  voeckler
// extended gzip input and bzip2 input to use their respective low-level
// interface. Also added a filter input method for multi processor
// machines (currently experimental).
//
// Revision 1.6  1999/08/15 22:26:56  voeckler
// added prefill buffer possibility to PlainText class, so that
// any pre-read content must not be re-read.
//
// Revision 1.5  1999/08/08 09:07:42  voeckler
// added compile-time configurable libz and libbz2 support.
//
// Revision 1.4  1999/08/05 21:11:33  voeckler
// reworked number parsing methods to be more efficient. Added new methods
// for the MyXIntXX types. Improved PlainInput parsing. Added bzip2 input.
//
// Revision 1.3  1998/08/06 20:02:50  voeckler
// major performance issue improvements, restructuring.
//
// Revision 1.2  1998/07/23 18:14:41  voeckler
// replaced rational() with an improved scanner.
//
// Revision 1.1  1998/07/05 15:37:24  voeckler
// Initial revision
//
//
#ifndef _INPUT_HH
#define _INPUT_HH

#if defined(__GNUC__) || defined(__GNUG__)
#pragma interface
#endif

#include <sys/types.h>
#include "typedefs.h"

class BaseInput {
  // Class to define the interface for easy access of scanners
  // in other classes. This effectively separates input actions from
  // interpretation.
public:
  BaseInput():lineno(1) { }
  // purpose: default ctor

  virtual ~BaseInput() { /* empty on purpose */ }
  // purpose: dtor

  virtual bool eoln() { int ch=peek(); return (ch=='\n'||ch<0); }
  // purpose: determine end of file condition
  // returns: true, if current position is at EOLN '\n' (or EOF, or error)
  
  virtual bool eof() = 0;
  // purpose: determine end of file condition
  // returns: true, if logical eof (or error) is reached, false otherwise

  virtual int peek() = 0;
  // purpose: obtain the next character to be returned, w/o getting it.
  //          actually handles the read() calls, too.
  // returns: next character, or -1 for error, or -2 for EOF.

  virtual int get() = 0;
  // purpose: return next character from input
  // returns: next character, or -1 for error, or -2 for EOF.

  //
  // --- implemented functions based on get() and peek() ---
  //
  virtual int integer( MyUInt64& number );
  // purpose: reads an integer from the input
  // paramtr: number (OUT): \s*[0-9]* from current position; 0 for text
  // returns: number of characters viewed, not including LWS, may be 0
  // warning: based on get() and peek()

  virtual int integer( MySInt64& number );
  // purpose: reads an integer from the input
  // paramtr: number (OUT): \s*[0-9]* from current position; 0 for text
  // returns: number of characters viewed, not including LWS, may be 0
  // warning: based on get() and peek()

  virtual int integer( MyUInt32& number );
  // purpose: reads an integer from the input
  // paramtr: number (OUT): \s*[0-9]* from current position; 0 for text
  // returns: number of characters viewed, not including LWS, may be 0
  // warning: based on get() and peek()

  virtual int integer( MySInt32& number );
  // purpose: reads an integer from the input
  // paramtr: number (OUT): \s*[0-9]* from current position; 0 for text
  // returns: number of characters viewed, not including LWS, may be 0
  // warning: based on get() and peek()

  virtual int rational( double& stamp );
  // purpose: reads a Squid UTC timestamp.millis from the input
  // paramtr: stamp (OUT): \s*[+-]?(\d+)|(\d*[.,]\d+), may be 0.0
  // returns: number of characters viewed, not including LWS, may be 0
  // warning: this is *not* be the complete C float set.
  // warning: based on get() and peek()
  
  virtual int get( char* destination, size_t maxsize );
  // purpose: read a string with maximum length into a buffer
  // paramtr: destination (OUT): area to write string into
  //          maxsize (IN): maximum size of previous area
  // returns: number of characters transferred, may be 0
  // warning: based on get() and peek()
  // additnl: destination[0] is guaranteed to be 0 for return value 0.

  virtual void skiptolws();
  // purpose: skip forward to next linear whitespace [ \t]
  
  virtual void skiplws();
  // purpose: skip forward during linear whitespaces [ \t]

  virtual void skippasteoln();
  // purpose: skip forward *over* the next '\n'

  unsigned long lineno;
  // purpose: current line number
};



class PlainInput : public BaseInput {
  // implements the interface of BaseInput for plain text files.
public:
  PlainInput( int _fd, size_t buffersize, 
	      const char* prefill = 0, size_t presize = 0 );
  // purpose: ctor
  // paramtr: _fd (IN): file opened for reading
  //          buffersize (IN): size of input buffer to allocate
  //          prefill (IN): some first bytes in input buffer
  //          presize (IN): size of prefill buffer (0=unused)
  // condit.: presize <= buffersize 

  virtual ~PlainInput();
  // purpose: dtor

  virtual bool eof();
  // purpose: determine end of file condition
  // returns: true, if logical eof is reached, false otherwise
  
  virtual int peek();
  // purpose: obtain the next character to be returned, w/o getting it.
  //          actually handles the read() calls, too.
  // returns: next character, or -1 for error, or -2 for EOF.

  virtual int get() 
  // purpose: return next character from input
  // returns: next character, or -1 for error, or -2 for EOF.
  {
#if 0    
    int result;
    if ( (result=peek()) >= 0 ) start++;
    return result;
#else
    if ( rsize <= 0 ) return ((-2)-rsize);
    if ( start >= end ) peek();
    return *start++;
#endif    
  }
  
  virtual int get( char* destination, size_t maxsize );
  // purpose: read a string with maximum length into a buffer
  // paramtr: destination (OUT): area to write string into
  //          maxsize (IN): maximum size of previous area
  // returns: number of characters transferred, may be 0
  //          destination[0] is guaranteed to be 0 for return value 0.
  // this is a slightly more efficient refinement

  virtual void skiptolws();
  // purpose: skip forward to next linear whitespace [ \t]
  // this is a slightly more efficient refinement
  
  virtual void skiplws();
  // purpose: skip forward during linear whitespaces [ \t]
  // this is a slightly more efficient refinement

  virtual void skippasteoln();
  // purpose: skip forward *over* the next '\n'
  // sidekck: increments line number lineno and updates lstart.

  virtual int integer( MyUInt64& number );
  // purpose: reads an integer from the input
  // paramtr: number (OUT): \s*[0-9]* from current position; 0 for text
  // returns: number of characters viewed, not including LWS, may be 0
  // this is a slightly more efficient refinement

  virtual int integer( MySInt64& number );
  // purpose: reads an integer from the input
  // paramtr: number (OUT): \s*[+-]?[0-9]* from current position; 0 for text
  // returns: number of characters viewed, not including LWS, may be 0
  // this is a slightly more efficient refinement

  virtual int integer( MyUInt32& number );
  // purpose: reads an integer from the input
  // paramtr: number (OUT): \s*[0-9]* from current position; 0 for text
  // returns: number of characters viewed, not including LWS, may be 0
  // this is a slightly more efficient refinement

  virtual int integer( MySInt32& number );
  // purpose: reads an integer from the input
  // paramtr: number (OUT): \s*[+-]?[0-9]* from current position; 0 for text
  // returns: number of characters viewed, not including LWS, may be 0
  // this is a slightly more efficient refinement

  typedef unsigned char uchar;

  virtual int position() const;
  // purpose: return position from start of line
  // warning: unreliable for very long lines

protected:
  const int    fd;      // file descriptor, opened for input
  const size_t bsize;   // buffer size, needed for read() call
  int          rsize;   // return value of last read() call.
  uchar* const buffer;  // input buffer to read() into,
  uchar*       start;   // pointer into currently examined position (cursor)
  uchar*       end;     // buffer+buffersize, first past the end
  uchar*       lstart;  // position of line start
};

#ifdef USE_LIBZ

// libz-1.0.8 for example
extern "C" {
#ifndef EXPORT
#define EXPORT
#endif 
#ifndef EXPORTVA
#define EXPORTVA
#endif
#include <zlib.h>
}

class GZipInput : public PlainInput {
  // implements the interface of BaseInput for gzipped text files.
public:
  GZipInput( int _fd, size_t buffersize,
	      const char* prefill = 0, size_t presize = 0 );
  // purpose: ctor
  // paramtr: _fd (IN): file opened for reading
  //          buffersize (IN): size of input buffer to allocate
  //          prefill (IN): some first bytes in input buffer
  //          presize (IN): size of prefill buffer (0=unused)
  // condit.: presize <= buffersize 

  virtual ~GZipInput();
  // purpose: dtor
  
  virtual int peek();
  // purpose: obtain the next character to be returned, w/o getting it.
  //          actually handles the read() calls, too.
  // returns: next character, or -1 for error, or -2 for EOF.

protected:
  MyUInt32  crc;
  int       result;
  MyUInt08* zbuffer;
  z_stream  gzip;

  enum GzipFlags { 
    ASCII_FLAG=0x01,      /* bit 0 set: file probably ascii text */
    HEAD_CRC=0x02,        /* bit 1 set: header CRC present */
    EXTRA_FIELD=0x04,     /* bit 2 set: extra field present */
    ORIG_NAME=0x08,       /* bit 3 set: original file name present */
    COMMENT=0x10,         /* bit 4 set: file comment present */
    RESERVED=0xE0         /* bits 5..7: reserved */
  };

  int _eat();
  int _checkHeader();

  ssize_t read( int _fd, MyUInt08* _buffer, size_t _size );
  // purpose: system read function, so peek() needn't be overwritten
  // returns: see read(2)
};

#endif // USE_LIBZ


#ifdef USE_LIBBZ2

// bzip2-0.9.0c for example
#include <stdio.h> // needed by bzlib.h
extern "C" {
#include <bzlib.h>
}

class BZip2Input : public PlainInput {
  // implements the interface of BaseInput for bzip2ed text files.
public:
  BZip2Input( int _fd, size_t buffersize,
	      const char* prefill = 0, size_t presize = 0 );
  // purpose: ctor
  // paramtr: _fd (IN): file opened for reading
  //          buffersize (IN): size of input buffer to allocate
  //          prefill (IN): some first bytes in input buffer
  //          presize (IN): size of prefill buffer (0=unused)
  // condit.: presize <= buffersize 

  virtual ~BZip2Input();
  // purpose: dtor

  virtual int peek();
  // purpose: obtain the next character to be returned, w/o getting it.
  //          actually handles the read() calls, too.
  // returns: next character, or -1 for error, or -2 for EOF.

protected:
  int          result;
  const size_t zsize;
  char*        zbuffer;
  bz_stream    bzip;

  ssize_t read( int _fd, MyUInt08* _buffer, size_t _size );
  // purpose: system read function, so peek() needn't be overwritten
  // returns: see read(2)
};

#endif // USE_LIBBZ2

class FilterInput : public PlainInput {
  // implements the interface of BaseInput for externally filtered text files.
public:
  FilterInput( int _fd, size_t buffersize, const char* filter = "/bin/cat" );
  // purpose: ctor
  // paramtr: _fd (IN): file opened for reading
  //          buffersize (IN): size of input buffer to allocate

  virtual ~FilterInput();
  // purpose: dtor

protected:
  int   fds[2];
  pid_t pid;
};

#endif // _INPUT_HH
