//
// $Id: dns.hh,v 1.9 1999/10/29 13:50:44 voeckler Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    dns.hh
//          Thu Aug 05 1999
//
// (c) 1999 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: dns.hh,v $
// Revision 1.9  1999/10/29 13:50:44  voeckler
// moved to gdbm cache file format.
//
// Revision 1.8  1999/09/02 10:10:54  voeckler
// removed old (obsolete) interface from class, minor statistics fixes.
//
// Revision 1.7  1999/08/31 08:48:42  voeckler
// new intermediary revision before removing obsolete items.
//
// Revision 1.6  1999/08/27 20:55:51  voeckler
// removed io stream dependencies in favour of standard io, the
// string map iterator is now part of the string map, fixed some
// time() related signedness bug.
//
// Revision 1.5  1999/08/25 21:23:17  voeckler
// made DNSItem a class of its own, since it can be re-used by
// the dns helpers.
//
// Revision 1.4  1999/08/20 22:41:44  voeckler
// added access to the internal map size through the size() method.
//
// Revision 1.3  1999/08/20 12:15:55  voeckler
// left-over bug fixes from NDBM removal. Now includes iostream, as the
// textual database file needs to be streamed.
//
// Revision 1.2  1999/08/15 19:49:59  voeckler
// removed NDBM dependency in favour of a textual database format
// which is (supposed to be) interchangable between different
// platforms.
//
// Revision 1.1  1999/08/05 21:06:01  voeckler
// Initial revision
//
//
#ifndef _DNS_HH
#define _DNS_HH

#if defined(__GNUC__) || defined(__GNUG__)
#pragma interface
#endif

#include "typedefs.h"
#include "string.hh"
#include "strmap.hh"
#include "stringset.hh"
#include "cache.hh"
#include "dnsitem.hh"
#include "dnscopro.hh"
#include "gdbm.hh"

class DNSCache : public BaseCache {
public:
  typedef DNSCoProcess::ItemMap    DNSItemMap;

  DNSCache( size_t nrOfChildren,
	    const char* dnsHelper,
	    const char* cacheFile = "/var/tmp/dns",
	    MyUInt32 posTTL = 3600 * 24 * 30,
	    MyUInt32 negTTL = 3600 * 24 * 7 );
  ~DNSCache();

  DNSItemMap getanybyany( const StringSet& what );
  // purpose: obtain addresses
  // paramtr: what (IN): set of symbolic or numeric strings to look up
  // returns: Map containing all (lower-cased) keys from what

  inline size_t size() const 
    { return count; }

protected:
  const char*  dbfn;
  DNSCoProcess helper;
  GDBM         dbase;
  MyUInt32     count;

private:
  // disallow
  DNSCache( const DNSCache& );
  DNSCache& operator=( const DNSCache& );
};

#endif // _DNS_HH
