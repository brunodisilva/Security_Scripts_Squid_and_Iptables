//
// $Id: global.hh,v 1.13 2000/08/10 12:38:28 voeckler Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    global.hh
//          Thu Aug 05 1999
//
// (c) 1999 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: global.hh,v $
// Revision 1.13  2000/08/10 12:38:28  voeckler
// added report interval lookup_report_interval, added minimum client requests
// client_min_reqs_udp, client_min_reqs_tcp and client_min_reqs_int.
//
// Revision 1.12  2000/07/29 22:13:07  voeckler
// added sortDBaseByByte configuration option, which allows to chose whether
// top-N are either volume-sorted, or request sorted.
//
// Revision 1.11  2000/07/27 07:38:22  voeckler
// created new configuration tags for suffix lists, suffix list implementation,
// internal clients, internal client list length, extendend internal list and
// configurable internal path component prefix.
//
// Revision 1.10  2000/06/09 09:27:17  voeckler
// fixes for FreeBSD 4.0
//
// Revision 1.9  1999/11/29 15:04:17  voeckler
// added separate flag to warn about status codes which are neither TCP nor UDP,
// but which are counted as TCP. Formerly, the unknown status flag was also
// responsible for this.
//
// Revision 1.8  1999/10/29 14:06:57  voeckler
// moved global time stamps to counter local stamps into counters module,
// added UTC offset variable (this is junk!) to be fed from the configuration
// file.
//
// Revision 1.7  1999/09/02 10:17:03  voeckler
// added helper process name and number, fixed method to obtain the
// maximum number of processes possible.
//
// Revision 1.6  1999/08/26 19:41:35  voeckler
// added dnsChildren configuration parameter.
//
// Revision 1.5  1999/08/25 21:16:42  voeckler
// added distribution flag and variable size of large tables to globals.
//
// Revision 1.4  1999/08/22 11:20:49  voeckler
// added flag to indicate a preference of data rates instead of durations.
// added the seconds interval, needed for counters.
//
// Revision 1.3  1999/08/15 22:29:31  voeckler
// fixed interface/implementation mix-up.
//
// Revision 1.2  1999/08/06 08:44:33  voeckler
// added debugging to DNS using the debug level and debug class from global.
//
// Revision 1.1  1999/08/05 21:08:11  voeckler
// Initial revision
//
//
#ifndef _GLOBAL_HH
#define _GLOBAL_HH

#if defined(__GNUC__) || defined(__GNUG__)
#pragma interface
#endif

#include "typedefs.h"
#include <sys/types.h>
#include <sys/time.h>
#include <sys/resource.h>

#if ! defined(RLIMIT_NOFILE) && defined(RLIMIT_OFILE)
#define RLIMIT_NOFILE RLIMIT_OFILE
#endif

class Global {
public:
  enum {
    D_DNS = 0x0001,
    D_IRR = 0x0002,
    D_ALL = 0xFFFF
  };

  Global();
  ~Global();

  bool            noIdent;
  bool		  clientFQDN;
  bool	          preferDatarate;
  bool            showDistributions;
  bool            showExtendedInternal;
  bool	          sortDBaseByByte;

  bool	          warnUnknownMethod;
  bool	          warnUnknownHier;
  bool	          warnUnknownStatus;
  bool		  warnNoneAsTCP;
  bool	          warnUnknownScheme;
  bool	          warnUnknownSuffix;
  bool	          warnUnknownTLD;
  MyUInt08        dnsChildren;
  MyUInt08        irrChildren;

  unsigned short  debugClass;
  unsigned short  debugLevel;
  MyUInt32	  allowedWhiteSpaces;
  MyUInt32	  warnCrashInterval;
  MyUInt32 	  peakInterval;
  MyUInt32        dailyInterval;
  MySInt32        gmtOffset;
  MyUInt32        progressReports;

  MyUInt32	  dnsPositiveTTL;
  MyUInt32	  dnsNegativeTTL;
  MyUInt32	  irrPositiveTTL;
  MyUInt32	  irrNegativeTTL;

  const char*     dnsCacheFile;
  const char*     dnsHelper;

  const char*     irrCacheFile;
  const char*     irrServer;
  const char*     irrHelper;

  const char*     iurlPrefix;

  enum TableSize { S_TLD, S_2LD, S_ASN, S_TCP, S_UDP, S_INT, 
		   S_MR_TCP, S_MR_UDP, S_MR_INT, S_END };
  MyUInt32        tableSize[S_END];

  long           openMax;
  long           childMax;
#ifdef RLIMIT_NOFILE
  struct rlimit  maxOpen;
#endif // RLIMIT_NOFILE
#ifdef RLIMIT_NPROC
  struct rlimit  maxChild;
#endif // RLIMIT_NPROC

  void setChildren( long wanted, MyUInt08& what );
};

extern Global globals;

#endif // _GLOBAL_HH
