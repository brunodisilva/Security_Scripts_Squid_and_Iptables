//
// $Id: dumpdb.cc,v 1.4 2000/07/27 07:37:19 voeckler Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    dbout.cc
//          Thu Sep 16 1999
//
// (c) 1999 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: dumpdb.cc,v $
// Revision 1.4  2000/07/27 07:37:19  voeckler
// reworked to use a FILE* instead of a file name, and to include the
// new internal sections into the database intermediate file.
//
// Revision 1.3  1999/12/24 00:12:52  voeckler
// fixed severe bug in hierarchy output, fixed stamp1 logging to first
// log a beautified stamp - only this will enable last SQL comparisons
// based on the stamp.
//
// Revision 1.2  1999/11/26 10:25:32  voeckler
// Fixed statistics output to match new prototype.
// Fixed flushing for the real output file.
//
// Revision 1.1  1999/10/29 14:12:08  voeckler
// Initial revision
//
//
#if defined(__GNUC__) || defined(__GNUG__)
#pragma implementation
#endif

static const char* RCS_ID =
"$Id: dumpdb.cc,v 1.4 2000/07/27 07:37:19 voeckler Exp $";

#include <stdio.h>
#include "logline.hh"
#include "counter.hh"
#include "counters.hh"
#include "global.hh"
#include "tools.hh"  // indexBy*
#include "output.hh" // clientLookup(),showStats(),hierarchy*Lookup()

#define TS "%ld" 

static
time_t
gmtOffset( time_t utc )
  // purpose: calculate the number of seconds between local time and UTC
  // paramtr: utc (IN): UTC time stamp to calculate the UTC offset for.
  // returns: number of seconds between local time and UTC.
  // warning: Please note that areas with daylight savings have two or
  //          more different values over a year.
{
  // FIXME: localtime() and gmtime() are not reentrant!
  struct tm a, b;
  memcpy( &a, localtime(&utc), sizeof(a) );
  memcpy( &b, gmtime(&utc), sizeof(b) );
  a.tm_isdst = b.tm_isdst = 0;
  return ( mktime(&a) - mktime(&b) );
}

const char*
dump( const Counter& c )
{
  // FIXME: not reentrant!
  static char buffer[256];
  sprintf( buffer, SF_U32 " " SF_U64 " %.3f", 
	   c.reqs(), c.size(), c.time() / 1E3 );
  return buffer;
}

// ------------------------------------------------------------------

static
void
dumpOverview( FILE* out, time_t ts, const Counters& counters )
{
  char s[128];
  size_t size = LogLine::stable.distinct()+1;

  for ( MyUInt32 i=0; i<size; ++i ) {
    LogLine::stable.reverse(s,sizeof(s),i);
    if ( counters.udp_hit_status[i].reqs() ) 
      fprintf( out, "udp hit " TS " %s %s\n", ts, s, 
	       dump(counters.udp_hit_status[i]) );
    if ( counters.udp_miss_status[i].reqs() )
      fprintf( out, "udp miss " TS " %s %s\n", ts, s,
	       dump(counters.udp_miss_status[i]) );
    if ( counters.tcp_hit_status[i].reqs() )
      fprintf( out, "tcp hit " TS " %s %s\n", ts, s,
	       dump(counters.tcp_hit_status[i]) );
    if ( counters.tcp_miss_status[i].reqs() )
      fprintf( out, "tcp miss " TS " %s %s\n", ts, s,
	       dump(counters.tcp_miss_status[i]) );
    if ( counters.tcp_miss_none_status[i].reqs() )
      fprintf( out, "tcp none " TS " %s %s\n", ts, s,
	       dump(counters.tcp_miss_none_status[i]) );
  }
}

static
void
dumpHierarchy( FILE* out, DNSCache* dns, time_t ts, const Counters& counters )
{
  char s[128];
  size_t size = LogLine::htable.distinct()+1;

  StringStringMap map;
  clientLookup( dns, counters.hier_peer_host, map );

  for ( MyUInt32 i=0; i<size; ++i ) {
    LogLine::htable.reverse(s,sizeof(s),i);
    if ( counters.hier_direct_method[i].reqs() ) {
      fprintf( out, "hier direct " TS " %s %s\n", ts, s,
	       dump(counters.hier_direct_method[i]) );
    } else if ( counters.hier_peer_status[i].size() ) {
      for ( CountMap::Iterator j(counters.hier_peer_status[i]); j.avail(); j++ ) {
	if ( counters.hier_parent_method[i].reqs() ) {
	  fprintf( out, "hier parent " TS " %s %s %s\n", ts, s, 
		   map[j.key().lower()].c_str(), dump(j()) );
	} else if ( counters.hier_peer_method[i].reqs() ) {
	  fprintf( out, "hier peer " TS " %s %s %s\n", ts, s, 
		   map[j.key().lower()].c_str(), dump(j()) );
	}
      }
    }
  }
}

#ifdef ONE_INTERNAL_TABLE

static
void
dumpInternal( FILE* out, DNSCache* dns, time_t ts, const Counters& counters,
	      bool byByte, const size_t number )
{
  // combine all INT clients into a map for massive parallel lookups
  StringStringMap map;
  clientLookup( dns, counters.internal_client, map );

  size_t  size1 = counters.internal_host.size();
  size_t* index = byByte ?
    indexBySize( counters.internal_host ) :
    indexByReqs( counters.internal_host );
  for ( size_t i=0; i<size1; ++i ) {
    if ( counters.internal_host[index[i]].reqs() ) {
      String host( counters.internal_host.key(index[i]) );
      size_t  size2 = counters.internal_path[host].size();
      size_t* jndex = byByte ?
	indexBySize( counters.internal_path[host] ) :
	indexByReqs( counters.internal_path[host] );

      for ( size_t j=0; j<size2; ++j ) {
	if ( counters.internal_path[host][jndex[j]].reqs() ) {
	  String key( counters.internal_path[host].key(jndex[j]) );
	  
	  Counter leftover, lhitover;
	  MyUInt32 n, m = n = C_U32(0);
	  size_t  size3 = counters.internal_hpc[host][key].size();
	  size_t* kndex = byByte ? 
	    indexBySize( counters.internal_hpc[host][key] ) : 
	    indexByReqs( counters.internal_hpc[host][key] );
	  for ( size_t k=0; k<size3; ++k ) {
	    if ( counters.internal_hpc[host][key][kndex[k]].reqs() ) {
	      String client( counters.internal_hpc[host][key].key(kndex[k]) );
	      if ( number == 0 || number > ++m ) {
		// ok to dump entry
		fprintf( out, "internal uri " TS " %s%s %s %s ", ts, 
			 host.c_str(), key.c_str(), map[client].c_str(), 
			 dump(counters.internal_hpc[host][key][kndex[k]]) );
		fputs( dump(counters.internal_hit_hpc[host][key][client]), 
		       out );
		fputc( '\n', out );
	      } else {
		++n;
	      }
	    }
	  }
	  delete[] kndex;
	  if ( n ) {
	    // dump leftovers
	    fprintf( out, "internal uri " TS " %s %s more[" SF_U32 "] %s ", 
		     ts, host.c_str(), key.c_str(), n, dump(leftover) );
	    fputs( dump(lhitover), out );
	    fputc( '\n', out );
	  }
	}
      } // foreach j
      delete[] jndex;
    } 
  } // foreach i 
  delete[] index;
}

#else // !ONE_INTERNAL_TABLE

static
void
dumpInternal( FILE* out, time_t ts, const Counters& counters, bool byByte )
{
  size_t  size1 = counters.internal_host.size();
  size_t* index = byByte ?
    indexBySize( counters.internal_host ) :
    indexByReqs( counters.internal_host );
  for ( size_t i=0; i<size1; ++i ) {
    if ( counters.internal_host[index[i]].reqs() ) {
      String host( counters.internal_host.key(index[i]) );
      size_t  size2 = counters.internal_path[host].size();
      size_t* jndex = byByte ?
	indexBySize( counters.internal_path[host] ) :
	indexByReqs( counters.internal_path[host] );

      for ( size_t j=0; j<size2; ++j ) {
	if ( counters.internal_path[host][jndex[j]].reqs() ) {
	  String key( counters.internal_path[host].key(jndex[j]) );
	  fprintf( out, "internal uri " TS " %s %s %s ", ts, 
		   host.c_str(), key.c_str(),
		   dump(counters.internal_path[host][jndex[j]]) );
	  fputs( dump(counters.internal_hit_path[host][key]), out );
	  fputc( '\n', out );
	}
      } // foreach j
      delete[] jndex;
    } 
  } // foreach i 
  delete[] index;
}
#endif // ONE_INTERNAL_TABLE


static
void
dumpMethods( FILE* out, time_t ts, const Counters& counters )
{
  char s[128];
  size_t size = LogLine::mtable.distinct()+1;
  for ( MyUInt32 i=0; i<size; ++i ) 
    if ( counters.methods[i].reqs() ) {
      LogLine::mtable.reverse(s,sizeof(s),i);
      fprintf( out, "method " TS " %s %s ", ts, s, dump(counters.methods[i]) );
      fputs( dump(counters.hit_methods[i]), out );
      fputc( '\n', out );
    }
}

static
void
dumpSchemes( FILE* out, time_t ts, const Counters& counters )
{
  char s[128];
  size_t size = LogLine::schemes.distinct()+1;

  for ( MyUInt32 i=0; i<size; ++i )
    if ( counters.tcp_scheme[i].reqs() ) {
      LogLine::schemes.reverse(s,sizeof(s),i);
      fprintf( out, "scheme " TS " %s %s ", ts, s, dump(counters.tcp_scheme[i]) );
      fputs( dump(counters.tcp_hit_scheme[i]), out );
      fputc( '\n', out );
    }
}

static
void
dumpTLDs( FILE* out, time_t ts, const Counters& counters )
{
  char s[128];
  size_t size = LogLine::domains.distinct()+1;

#if 1
  for ( CountMap::Iterator j(counters.tcp_tld); j.avail(); j++ ) {
    fprintf( out, "tld " TS " %s %s ", ts, j.key().c_str(), dump(j.value()) );
    fputs( dump(counters.tcp_hit_tld[j.key()]), out );
    fputc( '\n', out );
  }
#else
  for ( MyUInt32 i=0; i<size; ++i ) {
    LogLine::domains.reverse(s,sizeof(s),i);
    fprintf( out, "tld " TS " %s %s ", ts, s, dump(counters.tcp_tld[s]) );
    fputs( dump(counters.tcp_hit_tld[s]), out );
    fputc( '\n', out );
  }
#endif
}

static
void
dumpSLDs( FILE* out, time_t ts, const Counters& counters, 
	  bool byByte, const size_t number )
{
  char s[128];
  Counter leftover;
  Counter lhitover;
  MyUInt32 n = C_U32(0);
  size_t* index = byByte ? 
    indexBySize( counters.tcp_sld ) : 
    indexByReqs( counters.tcp_sld );

  for ( size_t i=0; i<counters.tcp_sld.size(); ++i ) {
    String key( counters.tcp_sld.key(index[i]) );
    if ( number == 0 || number > i ) {
      fprintf( out, "sld " TS " %s %s ", ts, key.c_str(), 
	       dump(counters.tcp_sld[index[i]]) );
      fputs( dump(counters.tcp_hit_sld[key]), out );
      fputc( '\n', out );
    } else {
      leftover += counters.tcp_sld[index[i]];
      lhitover += counters.tcp_hit_sld[key];
      n++;
    }
  }
  delete[] index;

  if ( n ) {
    fprintf( out, "sld " TS " more[" SF_U32 "] %s ", ts, n, dump(leftover) );
    fputs( dump(lhitover), out );
    fputc( '\n', out );
  }
}

static
void
dumpMediatypes( FILE* out, time_t ts, const Counters& counters )
{
  char s[128], t[128];
  size_t size = counters.nMedia;
  for ( MyUInt32 i=0; i<size; ++i ) 
    if ( counters.tcp_mime[i].reqs() ) {
      LogLine::mediatypes.reverse(s,sizeof(s),i);
      fprintf( out, "mime " TS " %s/* %s ", ts, s, 
	       dump(counters.tcp_mime[i]) );
      fputs( dump(counters.tcp_hit_mime[i]), out );
      fputc( '\n', out );
      if ( counters.tcp_submime[i] ) {
	size_t subs = counters.nSubtype[i];
	for ( MyUInt32 j=0; j<subs; ++j ) 
	  if ( counters.tcp_submime[i][j].reqs() ) {
	    LogLine::subtypes[i].reverse(t,sizeof(t),j);
	    fprintf( out, "mime " TS " %s/%s %s ", ts, s, t, 
		     dump( counters.tcp_submime[i][j] ) );
	    fputs( dump(counters.tcp_hit_submime[i][j]), out );
	    fputc( '\n', out );
	  }
      }
    }
}

static
void
dumpPorts( FILE* out, time_t ts, const Counters& counters )
{
  char s[128];

  for ( MyUInt32 i=0; i<64; ++i ) {
    if ( counters.tcp_ports[i].reqs() ) {
      fprintf( out, "ports " TS " %5d-%-5d %s\n", ts, i << 10, ((i+1)<<10)-1,
	       dump(counters.tcp_ports[i]) );
    }
  }
  fprintf( out, "ports " TS " %5d-%-5d %s\n", ts, 80, 80, 
	   dump(counters.tcp_ports[64]) );
}


static
void
dumpUDPClients( FILE* out, DNSCache* dns, time_t ts, const Counters& counters,
		bool byByte, const size_t number )
{
  Counter leftover;
  Counter lhitover;
  MyUInt32 n = C_U32(0);

  // combine all UDP clients into a map for massive parallel lookups
  StringStringMap map;
  clientLookup( dns, counters.udp_client, map );

  size_t size = counters.udp_client.size();
  size_t* index = byByte ? 
    indexBySize( counters.udp_client ) :
    indexByReqs( counters.udp_client );

  for ( size_t i=0; i<size; ++i ) {
    if ( counters.udp_client[index[i]].reqs() ) {
      String key( counters.udp_client.key(index[i]) );
      if ( number == 0 || number > i ) {
	fprintf( out, "client udp " TS " %s %s ", ts, 
		 map[key.lower()].c_str(),
		 dump(counters.udp_client[index[i]]) );
	fputs( dump(counters.udp_hit_client[key]), out );
	fputc( '\n', out );
      } else {
	leftover += counters.udp_client[index[i]];
	lhitover += counters.udp_hit_client[key];
	n++;
      }
    }
  }
  delete[] index;

  if ( n ) {
    fprintf( out, "client udp " TS " more[" SF_U32 "] %s ", ts, n,
	     dump(leftover) );
    fputs( dump(lhitover), out );
    fputc( '\n', out );
  }

#if 0 
  for ( CountMap::Iterator j(counters.udp_client); j.avail(); j++ ) {
    fprintf( out, "client udp " TS " %s %s ", ts, 
	     map[j.key().lower()].c_str(),
	     dump(j.value()) );
    fputs( dump(counters.udp_hit_client[j.key()]), out );
    fputc( '\n', out );
  }
#endif
}


#ifndef ONE_INTERNAL_TABLE

static
void
dumpINTClients( FILE* out, DNSCache* dns, time_t ts, const Counters& counters,
		bool byByte, const size_t number )
{
  Counter leftover;
  Counter lhitover;
  MyUInt32 n = C_U32(0);

  // combine all UDP clients into a map for massive parallel lookups
  StringStringMap map;
  clientLookup( dns, counters.internal_client, map );

  size_t size = counters.internal_client.size();
  size_t* index = byByte ? 
    indexBySize( counters.internal_client ) :
    indexByReqs( counters.internal_client );

  for ( size_t i=0; i<size; ++i ) {
    if ( counters.internal_client[index[i]].reqs() ) {
      String key( counters.internal_client.key(index[i]) );
      if ( number == 0 || number > i ) {
	fprintf( out, "client int " TS " %s %s ", ts, 
		 map[key.lower()].c_str(),
		 dump(counters.internal_client[index[i]]) );
	fputs( dump(counters.internal_hit_client[key]), out );
	fputc( '\n', out );
      } else {
	leftover += counters.internal_client[index[i]];
	lhitover += counters.internal_hit_client[key];
	n++;
      }
    }
  }
  delete[] index;

  if ( n ) {
    fprintf( out, "client int " TS " more[" SF_U32 "] %s ", ts, n,
	     dump(leftover) );
    fputs( dump(lhitover), out );
    fputc( '\n', out );
  }
}
#endif // ONE_INTERNAL_TABLE


static
void
dumpTCPClients( FILE* out, DNSCache* dns, time_t ts, const Counters& counters,
		bool byByte, const size_t number )
{
  Counter leftover;
  Counter lhitover;
  Counter lerrover;
  Counter lmissover;
  MyUInt32 n = C_U32(0);

  // combine all TCP clients into a map for massive parallel lookups
  StringStringMap map;
  clientLookup( dns, counters.tcp_client, map );

  size_t size = counters.tcp_client.size();
  size_t* index = byByte ? 
    indexBySize( counters.tcp_client ) :
    indexByReqs( counters.tcp_client );

  for ( size_t i=0; i<size; ++i ) {
    if ( counters.tcp_client[index[i]].reqs() ) {
      String key( counters.tcp_client.key(index[i]) );
      if ( number == 0 || number > i ) {
	fprintf( out, "client tcp " TS " %s %s ", ts, 
		 map[key.lower()].c_str(), 
		 dump(counters.tcp_client[index[i]]) );
	fputs( dump(counters.tcp_hit_client[key]), out );
	fputc( ' ', out );
	fputs( dump(counters.tcp_miss_client[key]), out );
	fputc( ' ', out );
	fputs( dump(counters.tcp_miss_none_client[key]), out );
	fputc( '\n', out );
      } else {
	leftover += counters.tcp_client[index[i]];
	lhitover += counters.tcp_hit_client[key];
	lmissover += counters.tcp_miss_client[key];
	lerrover += counters.tcp_miss_none_client[key];
	n++;
      }
    }
  }
  delete[] index;

  if ( n ) {
    fprintf( out, "client tcp " TS " more[" SF_U32 "] %s ", ts, n,
	     dump(leftover) );
    fputs( dump(lhitover), out );
    fputc( ' ', out );
    fputs( dump(lmissover), out );
    fputc( ' ', out );
    fputs( dump(lerrover), out );
    fputc( '\n', out );
  }
  
#if 0
  for ( CountMap::Iterator j(counters.tcp_client); j.avail(); j++ ) {
    fprintf( out, "client tcp " TS " %s %s ", ts, 
	     map[j.key().lower()].c_str(), dump(j.value()) );
    fputs( dump(counters.tcp_hit_client[j.key()]), out );
    fputc( ' ', out );
    fputs( dump(counters.tcp_miss_client[j.key()]), out );
    fputc( ' ', out );
    fputs( dump(counters.tcp_miss_none_client[j.key()]), out );
    fputc( '\n', out );
  }
#endif
}

static
void
dumpPeaks( const char* cache, FILE* out, time_t ts, const Counters& counters )
{
  for ( MyUInt32 i=counters.startTime / globals.peakInterval;
	i <= counters.finalTime / globals.peakInterval; 
	++i ) {
    time_t then = i * globals.peakInterval;
    fprintf( out, "stamp2 %s " TS " %+d " SF_U32 "\n", cache,
	     then, gmtOffset(then), globals.peakInterval );
    fprintf( out, "peak " TS " %s ", then, dump( counters.peak_udp[i] ) );
    fputc( ' ', out );
    fputs( dump(counters.peak_udp_hit[i]), out );
    fputc( ' ', out );
    fputs( dump(counters.peak_int[i]), out );
    fputc( ' ', out );
    fputs( dump(counters.peak_int_hit[i]), out );
    fputc( ' ', out );
    fputs( dump(counters.peak_tcp[i]), out );
    fputc( ' ', out );
    fputs( dump(counters.peak_tcp_hit[i]), out );
    fputc( ' ', out );
    fputs( dump(counters.peak_hier_direct[i]), out );
    fputc( ' ', out );
    fputs( dump(counters.peak_hier_parent[i]), out );
    fputc( ' ', out );
    fputs( dump(counters.peak_hier_peer[i]), out );
    fputc( '\n', out );
  }
}

static
void
dumpASN( FILE* out, DNSCache* dns, IRRCache* irr, 
	 time_t ts, const Counters& counters,
	 bool byByte, const size_t number )
{
  CountMap asnmap;
  Counter leftover;
  MyUInt32 n = C_U32(0);

  // combine all HIER hosts into a map for massive parallel DNS lookups
  AddressMap addr_map;
  hierarchyHostLookup( dns, counters.hier_direct_host, addr_map );
  // POSTCONDITION: addr_map contains all addresses belonging to the 
  // direct hosts. If the HNo patch was applied, the address conversion
  // will be done without needing to bother DNS (much faster).

  // combine all HIER addresses from HIER hosts for massive parallel IRR
  IRRCache::IRRItemMap dest_map;
  hierarchyASLookup( irr, counters.hier_direct_host, addr_map,
		     dest_map, asnmap );
  // POSTCONDITION: dest_map will contain *hosts* key (not network/CIDR)
  // as dotted quad derived from addr_map which got its hosts from the
  // hier_direct_host map. The value type is the AS#, <NO_AS>, or <NODNS>.
  // It will also contain for the key AS# the description of the AS.
  // asnmap is a count map

  size_t size = asnmap.size();
  size_t* index = byByte ?
    indexBySize( asnmap ) :
    indexByReqs( asnmap );
  for ( size_t i=0; i<size; ++i ) {
    String key(asnmap.key(index[i]));
    if ( number == 0 || number > i ) {
      fprintf( out, "as %7s " TS " \"%s\" %s\n", key.c_str(), ts, 
	       dest_map[key].item.c_str(), dump(asnmap[size_t(index[i])]) );
    } else {
      leftover += asnmap[size_t(index[i])];
      n++;
    }
  }
  delete[] index;

  if ( n ) {
    fprintf( out, "as more " TS " \"" SF_U32 "\" %s\n", ts, n,
	     dump(leftover) );
  }
 
#if 0
  for ( CountMap::Iterator i(asnmap); i.avail(); i++ ) {
    fprintf( out, "as %7s " TS " \"%s\" ", i.key().c_str(), ts, 
	     dest_map[i.key()].item.c_str() );
    fputs( dump(i.value()), out );
    fputc( '\n', out );
  }
#endif
}

static
void
dumpDistribution( FILE* out, time_t ts, const Counters& counters )
{
  static const char* msg[Counters::D_END] = { "hit", "miss", "none" };

  for ( int d=Counters::D_HIT; d<Counters::D_END; ++d ) {

    fprintf( out, "dist size %s " TS "", msg[d], ts );
    for ( int s=0; s<32; ++s ) 
      fprintf( out, " %lu", counters.distribution[d].sizeDist[s] );
    fputc( '\n', out );

    fprintf( out, "dist time %s " TS "", msg[d], ts );
    for ( int t=0; t<32; ++t ) 
      fprintf( out, " %lu", counters.distribution[d].timeDist[t] );
    fputc( '\n', out );

    for ( int s=0; s<32; ++s ) {
      fprintf( out, "dist both[%d] %s " TS "", s, msg[d], ts );
      for ( int t=0; t<32; ++t )
	fprintf( out, " %lu", counters.distribution[d].timeSizeDist[t][s] );
      fputc( '\n', out );
    }
  }
}

void
dumpResults( FILE* out, const char* cache,
	     DNSCache* dns, IRRCache* irr, const Counters& cnt,
	     double looptime, double startup, MyUInt32 lineno )
{
  // determine timestamp to log with
#if 1
  // determine offset UTC and local time for the start time
  time_t offset = gmtOffset(cnt.startTime);

  // shift the local start time into UTC, divide by the daily interval
  // and do the Pascal equivalent of round(); cut off any excess seconds.
  double sn = floor((cnt.startTime + offset) / globals.dailyInterval + 0.5);

  // Shift back to UTC
  time_t ts = (time_t) (sn * globals.dailyInterval - offset);
  // POSTCONDITION: The localized timestamp is now divisible by interval i1

  fprintf( out, "stamp1 %s " TS " " TS " %+d " TS " %+d "
	   SF_U32 " " SF_U32 "\n", cache, ts,
	   cnt.startTime, gmtOffset(cnt.startTime),
	   cnt.finalTime, gmtOffset(cnt.finalTime),
	   cnt.finalTime - cnt.startTime, globals.dailyInterval );
#else
  time_t ts = cnt.startTime;
  fprintf( out, "stamp1 %s " TS " %+d " TS " %+d " SF_U32 " " SF_U32 "\n",
	   cache,
	   cnt.startTime, gmtOffset(cnt.startTime),
	   cnt.finalTime, gmtOffset(cnt.finalTime),
	   cnt.finalTime - cnt.startTime, globals.dailyInterval );
#endif

  // overview
  fputs( "# overview...\n", stderr );
  dumpOverview( out, ts, cnt );
  fflush(out);

  // hierarchy info
  fputs( "# hierarchy...\n", stderr );
  dumpHierarchy( out, dns, ts, cnt );
  fflush(out);

  // show internal including clients
  fputs( "# internal...\n", stderr );
#ifdef ONE_INTERNAL_TABLE
  dumpInternal( out, dns, ts, cnt, false, globals.tableSize[Global::S_INT] );
#else
  dumpInternal( out, ts, cnt, false );
#endif
  fflush(out);

  // methods
  fputs( "# methods...\n", stderr );
  dumpMethods( out, ts, cnt );
  fflush(out);

  // schemes
  fputs( "# schemes...\n", stderr );
  dumpSchemes( out, ts, cnt );
  fflush(out);

  // top-level domains
  fputs( "# tlds...\n", stderr );
  dumpTLDs( out, ts, cnt );
  fflush(out);

  // 2nd-level domains
  fputs( "# slds...\n", stderr );
  dumpSLDs( out, ts, cnt, false, globals.tableSize[Global::S_2LD] );
  fflush(out);

  // media types
  fputs( "# mime...\n", stderr );
  dumpMediatypes( out, ts, cnt );
  fflush(out);

  // show port statistics
  fputs( "# ports...\n", stderr );
  dumpPorts( out, ts, cnt );
  fflush(out);

  // show clients
  fputs( "# clients...\n", stderr );
  dumpUDPClients( out, dns, ts, cnt, false, globals.tableSize[Global::S_UDP] );
  fflush(out);
#ifndef ONE_INTERNAL_TABLE
  dumpINTClients( out, dns, ts, cnt, false, globals.tableSize[Global::S_INT] );
  fflush(out);
#endif
  dumpTCPClients( out, dns, ts, cnt, false, globals.tableSize[Global::S_TCP] );
  fflush(out);

  // show peak intervals
  fputs( "# peaks...\n", stderr );
  dumpPeaks( cache, out, ts, cnt );
  fflush(out);

  if ( dns && irr ) {
    // show directs
    fputs( "# asn...\n", stderr );
    dumpASN( out, dns, irr, ts, cnt, false, globals.tableSize[Global::S_ASN] );
    fflush(out);
  }

  // show distributions
  fputs( "# distributions\n", stderr );
  dumpDistribution( out, ts, cnt );
  fflush(out);

  // statistics about the log file analysis
  fputs( "# stats...\n", stderr );
  if ( looptime < 1E-4 ) looptime = 1E-4;
  showStats( out, "# ", cache, dns, irr, looptime, startup, lineno );
  fflush(out);
}
