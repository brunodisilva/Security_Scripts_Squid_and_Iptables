//
// $Id: tools.hh,v 1.2 1999/08/22 11:52:56 voeckler Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    tools.hh
//          Thu Aug 05 1999
//
// (c) 1999 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: tools.hh,v $
// Revision 1.2  1999/08/22 11:52:56  voeckler
// added functionality to display duration as an alternative
// to data rates.
//
// Revision 1.1  1999/08/05 21:27:42  voeckler
// Initial revision
//
//
#ifndef _TOOLS_HH
#define _TOOLS_HH

#if defined(__GNUC__) || defined(__GNUG__)
#pragma interface
#endif

#include <sys/types.h>
#include "typedefs.h"
#include "string.hh"
#include "counter.hh"
#include "counters.hh"

size_t* indexByReqs( const Counter* array, size_t size );
  // purpose: construct an array of hashvalues for the map in sorted order.
  // paramtr: array (IN): array of counters to generate the index for
  //          size (IN): number of elements in the array.
  // returns: map-sized array with indices, sorted by largest first.
  // warning: you have to delete[] the result yourself!
  // warning: the index is only valid for the array it was generated for.

size_t* indexByReqs( const CountMap& map );
  // purpose: construct an array of hashvalues for the map in sorted order.
  // paramtr: map (IN): map to generate the index for
  // returns: map-sized array with indices, sorted by largest first.
  // warning: you have to delete[] the result yourself!
  // warning: the index is only valid for the map it was generated for,
  // warning: and only as long as the map is not written to.

size_t* indexBySize( const Counter* array, size_t size );
  // purpose: construct an array of hashvalues for the map in sorted order.
  // paramtr: array (IN): array of counters to generate the index for
  //          size (IN): number of elements in the array.
  // returns: map-sized array with indices, sorted by largest first.
  // warning: you have to delete[] the result yourself!
  // warning: the index is only valid for the array it was generated for.

size_t* indexBySize( const CountMap& map );
  // purpose: construct an array of hashvalues for the map in sorted order.
  // paramtr: map (IN): map to generate the index for
  // returns: map-sized array with indices, sorted by largest first.
  // warning: you have to delete[] the result yourself!
  // warning: the index is only valid for the map it was generated for,
  // warning: and only as long as the map is not written to.



extern const char* stdunit;

String
autoSize( double x, double shift = 999.9, int width = 7, 
	  int suffix = 1, const char* unit = stdunit );
  // purpose: auto-format a byte value, by using the correct unit prefix
  // paramtr: x (IN): value to format
  //          shift (IN): threshold to switch to next dimension
  //          width (IN): width of string to return
  //          suffix (IN): width of fractional part of the string
  //          unit (IN): unit of measurement
  // returns: a string formated according to the input

String
autoTime( double x, int width = 9, int suffix = 3 );
  // purpose: auto-format a time value, by using the correct unit suffix
  // paramtr: x (IN): value to format
  //          width (IN): width of string to return
  //          suffix (IN): width of fractional part of the string
  // returns: a string formated according to the input

String
autoPercent( double full, double partial );
  // purpose: format a percentage from absolute values
  // paramtr: full (IN): the sum
  //          partial (IN): the absolute part of the sum
  // returns: formatted string



String valueTail( size_t width, bool withHits );
  // purpose: create a table underliner
  // paramtr: width (IN): maximum allowed size for the changable part
  //          withHits (IN): true: prepare a table with hit partials
  // returns: string containing a table underliner

String valueHead( String a, size_t width, bool useRate, bool withHits );
  // purpose: create a table head
  // paramtr: a (IN): string containing some text for the table head
  //          width (IN): maximum allowed size --> 'a' might be cut
  //          useRate (IN): true: use a data rate instead of duration
  //          withHits (IN): true: prepare a table with hit partials
  // returns: string containing the table head

String valueBody( const Counter& cur, const Counter& all, bool useRate );
  // purpose: create a string containing just the full count.
  // paramtr: cur (IN): the current count 
  //          all (IN): the summary count
  //          useRate (IN): true: use a data rate instead of duration
  // returns: string containing these items

String valueBody( const Counter& cur, const Counter& all, const Counter& hit,
		  bool useRate );
  // purpose: create a string containing the full and hit part.
  // paramtr: cur (IN): the current count 
  //          all (IN): the summary count
  //          hit (IN): the hit part of the full count
  //          useRate (IN): true: use a data rate instead of duration
  // returns: string containing these items

extern String str_numeric; // <numeric>
extern String str_empty;   // <empty>
extern String str_error;   // <error>

void
getDomainFromHost( const char* host, String& tld, String& sld );
  // purpose: extract the top-level and 2nd level domain from a hostname
  // paramtr: host (IN): possible FQDN
  //          tld (OUT): top-level domain or category
  //          sld (OUT): 2nd-level domain or empty string
  // warning: numeric dotted quads and bigints --> tld := ::str_numeric
  //          and sld the class C network

double
now( void );
  // purpose: obtain the current time
  // returns: current time in *SECONDS* since 01.01.1970


#endif // _TOOLS_HH
