//
// $Id: input.cc,v 1.11 2000/07/27 07:33:03 voeckler Exp voeckler $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    input.cc
//          Sat Jul  4 1998
//
// (c) 1998 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: input.cc,v $
// Revision 1.11  2000/07/27 07:33:03  voeckler
// added preprocessor directive USE_NEW_BZIP2_API to make up for
// changes in the BZ2 API.
//
// Revision 1.10  1999/08/23 12:44:01  voeckler
// moved from (safer) execve() to execv() in order to use the
// parent environment in a compatible way -- newer 64 bit libs
// do not allow direct (non-function) access to internals.
//
// Revision 1.9  1999/08/20 22:45:39  voeckler
// moved PlainInput d'tor into the implementation file, fixed bug
// in FilterInput which needed to close the descriptor in order
// to expire the child process. Fixed bug in PlainInput to close
// the FD, if it is available.
//
// Revision 1.8  1999/08/18 11:12:52  voeckler
// extended gzip input and bzip2 input to use their respective low-level
// interface. Also added a filter input method for multi processor
// machines (currently experimental).
//
// Revision 1.7  1999/08/15 22:26:56  voeckler
// added prefill buffer possibility to PlainText class, so that
// any pre-read content must not be re-read.
//
// Revision 1.6  1999/08/08 09:07:42  voeckler
// added compile-time configurable libz and libbz2 support.
//
// Revision 1.5  1999/08/05 21:10:35  voeckler
// reworked number parsing methods to be more efficient. Added new methods
// for the MyXIntXX types. Improved PlainInput parsing. Added bzip2 input.
//
// Revision 1.4  1999/01/18 08:58:53  voeckler
// snapshot.
//
// Revision 1.3  1998/08/06 20:02:50  voeckler
// major performance issue improvements, restructuring.
//
// Revision 1.2  1998/07/23 18:14:41  voeckler
// replaced rational() with an improved scanner.
//
// Revision 1.1  1998/07/05 15:37:24  voeckler
// Initial revision
//
//
#if defined(__GNUC__) || defined(__GNUG__)
#pragma implementation
#endif

#include "input.hh"
#include "ctype.hh"
#include <errno.h>
#include <memory.h>

#include <assert.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <float.h>
#include <sys/wait.h>

static const char* RCS_ID =
"$Id: input.cc,v 1.11 2000/07/27 07:33:03 voeckler Exp voeckler $";

#define SGET \
  int count = 0; \
  bool negate = false; \
  \
  number = 0; \
  skiplws(); \
  int ch = peek(); \
  if ( ch == '+' || ch == '-' ) { \
    negate = ( ch == '-' ); \
    get(); /* advance cursor */ \
    count++; \
  } \
  \
  /* PRECONDITION: chars 0..-2 are not true on ISDIGIT() */ \
  while ( ISDIGIT(ch=peek()) ) { \
    number = number*10 + ( ch - '0' ); \
    count++; \
    get(); \
  } \
  if ( negate ) number = -number; \
  return count; 

#define UGET \
  int ch, count = 0; \
  number = 0ul; \
  skiplws(); \
  /* PRECONDITION: chars 0..-2 are not true on ISDIGIT() */ \
  while ( ISDIGIT(ch=peek()) ) { \
    number = number * 10 + ( ch - '0' ); \
    count++; \
    get(); \
  } \
  return count;

int 
BaseInput::integer( MyUInt64& number )
  // purpose: reads an integer from the input
  // paramtr: number (OUT): \s*[0-9]* from current position; 0 for text
  // returns: number of characters viewed, not including LWS, may be 0
  // warning: based on get() and peek()
{
  UGET
}

int 
BaseInput::integer( MySInt64& number )
  // purpose: reads an integer from the input
  // paramtr: number (OUT): \s*[+-]?[0-9]* from current position; 0 for text
  // returns: number of characters viewed, not including LWS, may be 0
  // warning: based on get() and peek()
{
  SGET
}

int 
BaseInput::integer( MyUInt32& number )
  // purpose: reads an integer from the input
  // paramtr: number (OUT): \s*[0-9]* from current position; 0 for text
  // returns: number of characters viewed, not including LWS, may be 0
  // warning: based on get() and peek()
{
  UGET
}

int 
BaseInput::integer( MySInt32& number )
  // purpose: reads an integer from the input
  // paramtr: number (OUT): \s*[+-]?[0-9]* from current position; 0 for text
  // returns: number of characters viewed, not including LWS, may be 0
  // warning: based on get() and peek()
{
  SGET
}

int
BaseInput::rational( double& stamp )
  // purpose: reads a Squid UTC timestamp.millis from the input
  // paramtr: stamp (OUT): \s*[+-]?(\d+)|(\d*[.,]\d+), may be 0.0
  // returns: number of characters viewed, not including LWS, may be 0
  // warning: this is *not* be the complete C float set.
  // warning: based on get() and peek()
{
  static const double exponent[20] = {
     1E00, 1E-01, 1E-02, 1E-03, 1E-04, 1E-05, 1E-06, 1E-07, 1E-08, 1E-09,
    1E-10, 1E-11, 1E-12, 1E-13, 1E-14, 1E-15, 1E-16, 1E-17, 1E-18, 1E-19
  };

  long prae, post;
  int c1 = integer( prae );
  if ( peek() != '.' ) {
    stamp = prae;
    return c1;
  } else {
    get();
    c1++;
  }

  int c2 = integer( post );
  stamp = prae + post / exponent[c2];
  return c1+c2;
}

int
BaseInput::get( char* destination, size_t maxsize )
  // purpose: read a string with maximum length into a buffer
  // paramtr: destination (OUT): area to write string into
  //          maxsize (IN): maximum size of previous area
  // returns: number of characters transferred, may be 0
  //          destination[0] is guaranteed to be 0 for return value 0.
  // warning: based on get() and peek()
{
  int ch;
  char* s = destination;
  char* e = s + maxsize-1;

  skiplws();
  while ( (ch=peek()) >= 0 && !ISSPACE(ch) && s < e ) *s++ = get();
  *s = 0;
  if ( !ISSPACE(ch) ) skiptolws(); // handle overrun
  return s-destination;
}

void 
BaseInput::skiptolws()
  // purpose: skip forward to next linear whitespace [ \t]
{
  for ( int ch; (ch=peek()) >= 0 && !ISBLANK(ch); ch=get() ) ;
}

void 
BaseInput::skiplws()
  // purpose: skip forward during linear whitespaces [ \t]
{
  for ( int ch; (ch=peek()) > 0 && ISBLANK(ch); ch=get() ) ;
}

void 
BaseInput::skippasteoln()
  // purpose: skip forward *over* the next '\n'
  // sidekck: increments line number lineno.
{
  int ch = get();
  while ( ch > 0 && ch != '\n' ) ch=get();
  if ( ch=='\n' ) lineno++;
}




PlainInput::PlainInput( int _fd, size_t buffersize,
			const char* prefill, size_t presize )
  :fd(_fd),
   bsize(buffersize),
   rsize(presize ? presize : 1),
   buffer(new PlainInput::uchar[bsize])
  // purpose: ctor
  // paramtr: _fd (IN): file opened for reading
  //          buffersize (IN): size of input buffer to allocate
  //          prefill (IN): some first bytes in input buffer
  //          presize (IN): size of prefill buffer (0=unused)
  // condit.: presize <= buffersize 
{
  assert( buffer != 0 );
  lstart = start = end = buffer;

  // buffer prefill
  assert( bsize >= presize );
  if ( prefill && presize ) {
    memmove( buffer, prefill, presize );
    end = buffer + presize;
  }
}

PlainInput::~PlainInput() 
  // purpose: dtor
{ 
  if ( fd != -1 ) close(fd);
  delete[] buffer; 
}

bool
PlainInput::eof()
{
  // if buffers are empty, force reading of next chunk
  if ( start >= end && rsize > 0 ) peek();
  // an error is also an EOF condition...
  return ((start >= end) && (rsize <= 0)); 
}

int
PlainInput::peek()
  // purpose: obtain the next character to be returned, w/o getting it.
  //          actually handles the read() calls, too.
  // returns: next character, or -1 for error, or -2 for EOF.
{
  // don't read if error or EOF
  if ( rsize <= 0 ) return ((-2)-rsize);

  if ( start == end ) {
    do {
      rsize = read( fd, (MyUInt08*) buffer, bsize );
    } while ( rsize == -1 && errno == EINTR );
    
    if ( rsize > 0 ) {
      // position end one past buffer
      start = buffer;
      end = buffer + rsize;
    } else {
      // eof or error
      return ((-2)-rsize);
    }
  }

  return *start;
}
  
int
PlainInput::get( char* destination, size_t maxsize )
  // purpose: read a string with maximum length into a buffer
  // paramtr: destination (OUT): area to write string into
  //          maxsize (IN): maximum size of previous area
  // returns: number of characters transferred, may be 0
  //          destination[0] is guaranteed to be 0 for return value 0.
  // this is a slightly more efficient refinement
{
  int ch;
  char* s = destination;
  char* e = s + maxsize-1;

  // though this looks more complicated, it is actually much faster,
  // since it saves repeated calls to peek().
  skiplws();
  while ( (ch=peek()) >= 0 && !ISSPACE(ch) && s < e ) {
    *s++ = *start++;
    while ( start < end && !ISSPACE(*start) && s < e ) *s++ = *start++;
  }
  *s = 0;
  if ( !ISSPACE(ch) ) skiptolws(); // handle overrun
  return s-destination;
}

void 
PlainInput::skiptolws()
  // purpose: skip forward to next linear whitespace [ \t]
  // this is a slightly more efficient refinement
{
  while ( start < end && !ISSPACE(*start) )
    if ( ++start >= end )
      // peek() will reset 'start', if there is data available
      if ( peek() < 0 ) break;
}

void 
PlainInput::skiplws()
  // purpose: skip forward during linear whitespaces [ \t]
  // this is a slightly more efficient refinement
{
  while ( start < end && ISSPACE(*start) )
    if ( ++start >= end )
      // peek() will reset 'start', if there is data available
      if ( peek() < 0 ) break;
}

void 
PlainInput::skippasteoln()
  // purpose: skip forward *over* the next '\n'
  // sidekck: increments line number lineno and updates lstart.
{
  int ch;

  do {
    ch = *start++;
    if ( start >= end && peek() < 0 ) break;
  } while ( ch != '\n' );

  if ( ch=='\n' ) {
    lineno++;
    lstart = start;
  }
}

int 
PlainInput::position() const
  // purpose: return position from start of line
  // warning: unreliable for very long lines
{
  return ( lstart <= start ? start-lstart : (end-lstart) + (start-buffer) );
}

#undef SGET
#define SGET \
  int count = 0; \
  bool negate = false; \
  \
  number = 0; \
  skiplws(); \
  if ( *start == '+' || *start == '-' ) { \
    negate = ( *start == '-' ); \
    if ( ++start >= end ) peek(); \
    count++; \
  } \
  \
  /* PRECONDITION: chars 0..-2 are not true on ISDIGIT() */ \
  while ( ISDIGIT(peek()) ) { \
    count++; \
    number = number*10 + ( *start++ - '0' ); \
  } \
  \
  if ( negate ) number = -number; \
  return count;

#undef UGET
#define UGET \
  int count = 0; \
  \
  number = 0; \
  skiplws(); \
  /* PRECONDITION: chars 0..-2 are not true on ISDIGIT() */ \
  while ( ISDIGIT(peek()) ) { \
    count++; \
    number = number*10 + ( *start++ - '0' ); \
  } \
  \
  return count;

int 
PlainInput::integer( MyUInt64& number )
  // purpose: reads an integer from the input
  // paramtr: number (OUT): \s*[0-9]* from current position; 0 for text
  // returns: number of characters viewed, not including LWS, may be 0
  // this is a slightly more efficient refinement
{
  UGET
}

int 
PlainInput::integer( MySInt64& number )
  // purpose: reads an integer from the input
  // paramtr: number (OUT): \s*[+-]?[0-9]* from current position; 0 for text
  // returns: number of characters viewed, not including LWS, may be 0
  // this is a slightly more efficient refinement
{
  SGET
}

int 
PlainInput::integer( MyUInt32& number )
  // purpose: reads an integer from the input
  // paramtr: number (OUT): \s*[0-9]* from current position; 0 for text
  // returns: number of characters viewed, not including LWS, may be 0
  // this is a slightly more efficient refinement
{
  UGET
}

int 
PlainInput::integer( MySInt32& number )
  // purpose: reads an integer from the input
  // paramtr: number (OUT): \s*[+-]?[0-9]* from current position; 0 for text
  // returns: number of characters viewed, not including LWS, may be 0
  // this is a slightly more efficient refinement
{
  SGET
}

#ifdef USE_LIBZ

int
GZipInput::_eat()
{
  if ( rsize <= 0 ) return ((-2)-rsize);
  if ( start >= end ) PlainInput::peek();
  return *start++;
}

int
GZipInput::_checkHeader()
{
  int ch;

  if ( _eat() != 0x1F ) return -1;
  if ( _eat() != 0x8B ) return -1;
  if ( _eat() != Z_DEFLATED ) return -2;
  
  MyUInt08 flags = _eat();
  if ( (flags & RESERVED) != 0 ) return -3;

  if ( (ch=_eat()) < 0 ) return -1;
  MyUInt32 mtime = ch;
  if ( (ch=_eat()) < 0 ) return -1;
  mtime |= (ch << 8);
  if ( (ch=_eat()) < 0 ) return -1;
  mtime |= (ch << 16);
  if ( (ch=_eat()) < 0 ) return -1;
  mtime |= (ch << 24);

  if ( _eat() < 0 ) return -1; // extra flags
  if ( _eat() < 0 ) return -1; // os section

  // check and eat extra flags header
  if ( (flags & EXTRA_FIELD) != 0 ) {
    if ( (ch=_eat()) < 0 ) return -1;
    MyUInt32 len = ch;
    if ( (ch=_eat()) < 0 ) return -1;
    len |= (ch << 8);
    while ( len && (ch=_eat()) >= 0 ) --len;
    if ( ch < 0 ) return -1;
  }

  // check for file name flag
  if ( (flags & ORIG_NAME) != 0 ) {
    while ( (ch=_eat()) > 0 ) ;
    if ( ch < 0 ) return -1;
  }

  // check for commentary
  if ( (flags & COMMENT) != 0 ) {
    while ( (ch=_eat()) > 0 ) ;
    if ( ch < 0 ) return -1;
  }

  // check for header CRC
  if ( (flags & HEAD_CRC) != 0 ) {
    if ( _eat() < 0 ) return -1;
    if ( _eat() < 0 ) return -1;
  }

  return 0;
}

GZipInput::GZipInput( int _fd, size_t buffersize, 
		      const char* prefill, size_t presize )
  :PlainInput(_fd,buffersize,prefill,presize),
   crc(crc32(0,0,0)),result(Z_OK)
{
  zbuffer = new MyUInt08[buffersize];
  assert ( zbuffer != 0 );

  // init zlib handle: The negative number is a back-door by which zlib
  // is told *not* to expect any zlib specific headers, because gzip
  // uses a different header structure.
  memset( &gzip, 0, sizeof(gzip) );
  inflateInit2( &gzip, -MAX_WBITS );

  // 
  // PRECONDITION: we temporarily use the PlainInput::peek() method
  // with cursor advancement in the uncompressed buffer in order to 
  // eat up the gzip header.
  //

  // read and skip gzip header portion
  if ( _checkHeader() < 0 ) {
    fputs( "error while reading gzip header\n", stderr );
    if ( rsize > 0 ) rsize = -1; // mark as error
    return;
  }

  // set up first inflation
  if ( end == start ) PlainInput::peek(); // FIXME: case "rsize <= 0"
  memcpy( zbuffer, start, end-start );
  gzip.next_in = zbuffer;
  gzip.avail_in = end-start;
  gzip.next_out = buffer;
  gzip.avail_out = bsize;
  start = end = buffer;

  result = inflate( &gzip, rsize > 0 ? Z_NO_FLUSH : Z_FINISH );
  if ( result != Z_OK && result != Z_STREAM_END ) {
    fprintf( stderr, "first inflation error: %s\n", gzip.msg );
    if ( rsize > 0 ) rsize = -1;
  } else {
    crc = crc32( crc, buffer, bsize - gzip.avail_out );
    end = buffer + (bsize - gzip.avail_out);
  }
}

GZipInput::~GZipInput()
{
  if ( gzip.avail_in >= 8 ) {
    MyUInt08* cursor = gzip.next_in;
    MyUInt32 temp = *cursor++;
    temp |= (*cursor++) << 8;
    temp |= (*cursor++) << 16;
    temp |= (*cursor++) << 24;
    if ( crc != temp )
      fprintf( stderr, "warning, gzip CRC mismatch: 0x%08x != 0x%08x!\n",
	       crc, temp );

    temp = *cursor++;
    temp |= (*cursor++) << 8;
    temp |= (*cursor++) << 16;
    temp |= (*cursor++) << 24;
    if ( gzip.total_out != temp )
      fprintf( stderr, "warning, gzip size mismatch: %lu != %lu!\n",
	       gzip.total_out, temp );
  }

  result = inflateEnd(&gzip);
  delete[] zbuffer;
}

ssize_t
GZipInput::read( int _fd, MyUInt08* _buffer, size_t _size )
  // purpose: system read function, so peek() needn't be overwritten
  // returns: see read(2)
{
  if ( result == Z_STREAM_END ) return 0;

  ssize_t temp = gzip.avail_in;
  if ( gzip.avail_in == 0 ) {
    // need to read another chunk of compressed data
    do {
      temp = ::read( _fd, zbuffer, bsize );
    } while ( temp == -1 && errno == EINTR );
    if ( temp < 0 ) return -1;
    gzip.next_in = zbuffer;
    gzip.avail_in = temp;
  }

  // decompress input
  gzip.next_out = _buffer;
  gzip.avail_out = _size;
  result = inflate( &gzip, temp>0 && result==Z_OK ? Z_NO_FLUSH : Z_FINISH );
  if ( result == Z_OK || result == Z_STREAM_END ) {
    ssize_t retval = bsize - gzip.avail_out;
    crc = crc32( crc, buffer, retval );
    return retval;
  } else {
    // eof or error
    fprintf( stderr, "gzip error: %s\n", gzip.msg );
    return ( temp > 0 ? -1 : 0 );
  }
}

int
GZipInput::peek()
  // purpose: obtain the next character to be returned, w/o getting it.
  //          actually handles the read() calls, too.
  // returns: next character, or -1 for error, or -2 for EOF.
{
  // don't read if error or EOF
  if ( rsize <= 0 ) return ((-2)-rsize);

  if ( start == end ) {
    do {
      rsize = read( fd, (MyUInt08*) buffer, bsize );
    } while ( rsize == -1 && errno == EINTR ||
	      rsize == 0 && result != Z_STREAM_END );
    
    if ( rsize > 0 ) {
      // position end one past buffer
      start = buffer;
      end = buffer + rsize;
    } else {
      // eof or error
      return ((-2)-rsize);
    }
  }

  return *start;
}

#endif // USE_LIBZ

#ifdef USE_LIBBZ2

#ifdef USE_NEW_BZIP2_API
#define bzDecompressInit	BZ2_bzDecompressInit
#define bzDecompress		BZ2_bzDecompress
#define bzDecompressEnd		BZ2_bzDecompressEnd
#endif

BZip2Input::BZip2Input( int _fd, size_t buffersize,
			const char* prefill, size_t presize )
  :PlainInput(_fd,buffersize),
   result(BZ_OK),
   zsize( (1ul << 16) > buffersize ? (1ul << 16) : buffersize ),
   zbuffer( new char[zsize] )
{
  assert ( zbuffer != 0 );

  // init bzlib handle
  memset( &bzip, 0, sizeof(bzip) );
  if ( (result=bzDecompressInit( &bzip, 0, 0 )) != BZ_OK ) {
    fputs( "unable to init bzip2 buffer\n", stderr );
    if ( rsize > 0 ) rsize = -1;
    return;
  }

  // set up first inflation
  start = end = buffer;
  if ( prefill && presize ) {
    assert( presize <= zsize );
    memcpy( zbuffer, prefill, presize );
    bzip.next_in = zbuffer;
    bzip.avail_in = rsize = presize;
    bzip.next_out = (char*) buffer;
    bzip.avail_out = bsize;

    result = bzDecompress( &bzip );
    if ( result >= BZ_OK && result <= BZ_STREAM_END ) {
      end = buffer + (bsize - bzip.avail_out);
    } else {
      fputs( "bzip2 first decompression error.\n", stderr );
      if ( rsize > 0 ) rsize = -1;
    }
  }
}

BZip2Input::~BZip2Input()
{
  bzDecompressEnd( &bzip );
  delete[] zbuffer;
}

ssize_t
BZip2Input::read( int _fd, MyUInt08* _buffer, size_t _size )
  // purpose: system read function, so peek() needn't be overwritten
  // returns: see read(2)
{
  if ( result == BZ_STREAM_END ) return 0;

  ssize_t temp = bzip.avail_in;
  if ( bzip.avail_in == 0 ) {
    // need to read another chunk of compressed data
    do {
      temp = ::read( _fd, zbuffer, zsize );
    } while ( temp == -1 && errno == EINTR );
    if ( temp < 0 ) return -1;
    bzip.next_in = zbuffer;
    bzip.avail_in = temp;
  }

  // decompress input
  bzip.next_out = (char*) _buffer;
  bzip.avail_out = _size;
  result = bzDecompress( &bzip );
  if ( result >= BZ_OK && result <= BZ_STREAM_END ) {
    return bsize - bzip.avail_out;
  } else {
    // eof or error
    fprintf( stderr, "bzip2 decompress error %d\n", result );
    return ( temp > 0 ? -1 : 0 );
  }
}

int
BZip2Input::peek()
  // purpose: obtain the next character to be returned, w/o getting it.
  //          actually handles the read() calls, too.
  // returns: next character, or -1 for error, or -2 for EOF.
{
  // don't read if error or EOF
  if ( rsize <= 0 ) return ((-2)-rsize);

  if ( start == end ) {
    do {
      rsize = read( fd, buffer, bsize );
    } while ( rsize == -1 && errno == EINTR ||
	      rsize == 0 && result != BZ_STREAM_END );
    
    if ( rsize > 0 ) {
      // position end one past buffer
      start = buffer;
      end = buffer + rsize;
    } else {
      // eof or error
      return ((-2)-rsize);
    }
  }

  return ((unsigned char)(*start));
}

#endif // USE_LIBBZ2

FilterInput::FilterInput( int _fd, size_t buffersize, const char* filter )
  :PlainInput(-1,buffersize)
{
  if ( pipe(fds) == -1 ) {
    perror("FilterInput pipe");
    rsize = -1;
    return;
  }

  if ( (pid=fork()) == -1 ) {
    perror( "FilterInput fork" );
    rsize = -1;
    return;
  } else if ( pid == 0 ) {
    // child
    close(fds[0]);
    if ( dup2( _fd, STDIN_FILENO ) == -1 ) {
      perror("dup2 stdin");
      exit(1);
    }
    if ( dup2( fds[1], STDOUT_FILENO ) == -1 ) {
      perror("dup2 stdout");
      exit(1);
    }

    char* const argv[2] = { (char*) filter, 0 };
    execv( filter, argv ); // use parent environment

    // if we return from exec, something is wrong
    fprintf( stderr, "exec(%s): %s\n", filter, strerror(errno) );
    exit(1);
  } else {
    // parent
    close(fds[1]);
    *((int*) &fd) = fds[0];
  }
}

FilterInput::~FilterInput()
{
  int status;
  pid_t result;

  // close file, so the SIGPIPE will terminate child process
  if ( fd != -1 && close(fd) == -1 )
    perror( "warning while closing external filter" );
  else
    *((int*) &fd) = -1;

  // wait for result from child death
  while ( (result=waitpid( pid, &status, 0 )) != pid ) {
    if ( result == -1 ) {
      if ( errno != EINTR ) {
	perror( "waiting for filter to terminate" );
	return;
      }
    } else {
      fputs( "waited for wrong child\n", stderr );
    }
  }

  char line[80];
  if ( WIFEXITED(status) ) {
    sprintf( line, "# process %d reaped, status %d\n", 
	     pid, WEXITSTATUS(status) );
  } else if ( WIFSIGNALED(status) ) {
    sprintf( line, "# process %d died on signal %d", pid, WTERMSIG(status) );
#ifdef WCOREDUMP
    if ( WCOREDUMP(status) ) strcat( line, " (core generated)" );
#endif
    strcat( line, "\n" );
  } else {
    sprintf( line, "# detected dead process %d, status %d\n",
	     pid, status );
  }

  // one atomic write
  write( STDERR_FILENO, line, strlen(line) );
}

