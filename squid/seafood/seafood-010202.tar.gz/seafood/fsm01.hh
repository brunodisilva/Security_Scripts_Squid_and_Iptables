//
// $Id: fsm01.hh,v 1.3 2000/07/27 07:12:20 voeckler Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    fsm01.hh - first finite state machine
//          Thu Aug 05 1999
//
// (c) 1999 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: fsm01.hh,v $
// Revision 1.3  2000/07/27 07:12:20  voeckler
// added code to return the start of the urlpath.
//
// Revision 1.2  1999/08/06 13:07:08  voeckler
// added stats to fsm01 in order to parse "CONNECT some.host:443" correctly.
//
// Revision 1.1  1999/08/05 21:08:11  voeckler
// Initial revision
//
//
#ifndef _FSM01_HH
#define _FSM01_HH

#if defined(__GNUC__) || defined(__GNUG__)
#pragma interface
#endif

#include <sys/types.h>
#include "typedefs.h"

class FSM_01 {
  // class defining a finite state automaton which parses a given 
  // and possibly corrupt URL in order to extract the (1) scheme,
  // the (2) hostname and (3) the port from the URL.
public:
  FSM_01();

  size_t parse( const char* url, char* const out[3], const size_t size[3] );
  // purpose: extract the three items from a URL
  // paramtr: url (IN): the URL, possibly malformed
  //          out (OUT): array of pointers to three char arrays --> content
  //          size (IN): size of each of the out[x] pointers
  // returns: position of start of path components (excluding absolute slash)
  // warning: results may be empty, but not NULL

protected:
  // character classes: '/'=0; EOS '?' '#'=1; ':'=2; '@'=3; alnum=5, else=5
  MyUInt08 cclass[256];
  // see implementation comments
  static int stateTable[6][6];

private:
  // disallow these
  FSM_01( const FSM_01& );
  FSM_01& operator=( const FSM_01& );
};

#endif // _FSM01_HH
