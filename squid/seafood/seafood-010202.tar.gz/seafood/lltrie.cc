//
// $Id: lltrie.cc,v 1.2 2000/07/29 22:10:53 voeckler Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    lltrie.cc
//          Thu Aug 05 1999
//
// (c) 1999 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: lltrie.cc,v $
// Revision 1.2  2000/07/29 22:10:53  voeckler
// adaptation of an interface through an abstract base class.
//
// Revision 1.1  1999/08/05 21:13:12  voeckler
// Initial revision
//
//
#if defined(__GNUC__) || defined(__GNUG__)
#pragma implementation
#endif

#include <assert.h>
#include <string.h>
#include <stdio.h>
#include "lltrie.hh"

static const char* RCS_ID =
"$Id: lltrie.cc,v 1.2 2000/07/29 22:10:53 voeckler Exp $";

LinkedListTrie::SymbolNode::SymbolNode( const SymbolNode& sn )
  :data(sn.data),what(sn.what)
{
  next = sn.next ? new SymbolNode(sn.next) : 0;
  down = sn.down ? new SymbolNode(sn.down) : 0;
}

LinkedListTrie::SymbolNode::SymbolNode( const SymbolNode* sn )
{
  assert ( sn != 0 );

  data = sn->data;
  what = sn->what;
  next = sn->next ? new SymbolNode(sn->next) : 0;
  down = sn->down ? new SymbolNode(sn->down) : 0;
}

LinkedListTrie::SymbolNode::~SymbolNode()
{ 
  if ( down ) delete down;
  if ( next ) delete next;
  down = next = 0;
}

LinkedListTrie::SymbolNode& 
LinkedListTrie::SymbolNode::operator=( const SymbolNode& sn )
{
  if ( &sn != this ) {
    delete down;
    delete next;

    data = sn.data;
    what = sn.what;
    next = sn.next ? new SymbolNode(sn.next) : 0;
    down = sn.down ? new SymbolNode(sn.down) : 0;
  }
  return *this;
}

LinkedListTrie::LinkedListTrie( const LinkedListTrie& llt )
  :_size(llt._size),_distinct(llt._distinct)
{
  _head = llt._head ? new SymbolNode( llt._head ) : 0;
}

LinkedListTrie::LinkedListTrie( const LinkedListTrie* llt )
{
  assert( llt != 0 );

  _size = llt->_size;
  _distinct = llt->_distinct;
  _head = llt->_head ? new SymbolNode( llt->_head ) : 0;
}

LinkedListTrie::~LinkedListTrie()
{
  delete _head;
  _head = 0;
}

#if 0
size_t
LinkedListTrie::distinct() const
{ 
  return _distinct; 
}
#endif

LinkedListTrie& 
LinkedListTrie::operator=( const LinkedListTrie& llt )
  // purpose: assignment operator
{
  if ( &llt != this ) {
    delete _head;
    _head = llt._head ? new SymbolNode( llt._head ) : 0;
    _size = llt._size;
    _distinct = llt._distinct;
  }
  return *this;
}

#include <ctype.h>

void 
LinkedListTrie::SymbolNode::print( FILE* f, int indent ) const
{
  fprintf( f, "(%02lu,%c", data, isprint(what) ? what : '#' );
  if ( down ) down->print( f, indent+1 );
  if ( next ) {
    fputc( '\n', f );
    for ( int n=0; n<indent; n++ ) fputc( '.', f );
    next->print( f, indent );
  }
  fputc( ')', f );
}

bool
LinkedListTrie::insert( const char* name, MyUInt32 value )
  // purpose: insert a new piece into the symbol table
  // paramtr: name (IN): new name to insert into symtab
  //          value (IN): token value to use for default override
  // returns: true, if insertion was successful.
  // warning: double inserts will overwrite the old value
{
  // sanity check
  if ( name==0 ) return false;

  if ( _head == 0 ) _head = new SymbolNode( *name );
  SymbolNode* temp( _head );
  for ( const char* s=name; *s; s++ ) {
    // find right branch to go down on
    while ( temp->what != *s && temp->next ) temp = temp->next;
    if ( temp->what != *s ) {
      // insert a new node into this level
      temp->next = new SymbolNode( *s );
      temp = temp->next;
    }
    // POSTCONDITION: temp points to an inner node where we may go down on

    if ( temp->down == 0 ) {
      // the down pointer is empty. Yes, this will insert '\0'.
      temp->down = new SymbolNode( s[1] );
    }
    temp = temp->down;
  }

  // POSTCONDITION: temp points to a valid element with key character '\0'
  //                where we may safely insert a value.
  temp->data = value;
  _size++;
  if ( ! (value & IS_ALIAS) ) _distinct++;
  return true;
}

MyUInt32
LinkedListTrie::find( const char* name ) const
  // purpose: search the trie for the given word, and return token value
  // paramtr: word (IN): word to search trie for
  // returns: 0 for not found, tokenvalue otherwise
  //          The return value of 0 lets you count the errors, too.
  // warning: PRECONDITION: word must not be null!
{
  SymbolNode* temp( _head );
  for ( const char* s = name; *s; s++ ) {
    while ( temp && temp->what != *s ) temp = temp->next;
    if ( temp == 0 ) return 0; // not found
    else temp = temp->down;
  }
  // POSTCONDITION: temp points to a level, where the '\0' is suspected
  return ( temp ? temp->data : 0 );
}

bool
LinkedListTrie::SymbolNode::exists( MyUInt32 v ) const
{
  if ( (data & 0x1FFFF) == v ) return true;
  else if ( down && down->exists(v) ) return true;

  // regardless of NUL, we need to test neighbours
  if ( next && next->exists(v) ) return true;

  // nothing found here
  return false;
}

bool
LinkedListTrie::SymbolNode::retrieve( char* s, size_t max, 
				      MyUInt32 v, size_t i ) const
  // purpose: traverse trie in order to find value v and store the
  //          characters encountered during descend into a storage.
  // paramtr: s (IO): storage to store parameters into
  //          max (IN): maximum size of the storage
  //          v (IN): value to search for
  //          i (IN): current position to change storage at.
  // returns: true, if value was found, false otherwise.
{
  // safety checks first
  if ( i >= max ) return false;

  // enter character into storage (just in case, even enter '\0').
  s[i] = what;

  if ( (data & 0x1FFFF) == v ) {
    s[i] = '\0';
    return true;
  } else {
    // only for unmatched, we need to test further downward
    if ( down && down->retrieve(s,max,v,i+1) ) return true;
  }

  // regardless of NUL, we need to test neighbours
  if ( next && next->retrieve(s,max,v,i) ) return true;

  // nothing found here
  return false;
}

const char* 
LinkedListTrie::reverse( char* buffer, size_t bsize, MyUInt32 value ) const
  // purpose: find the matching string to a given token value
  // paramtr: buffer (IO): area to store resulting string into
  //          bsize (IN): size of the area to store data into
  //          value (IN): value to look for
  // returns: a pointer to the buffer, which will contain
  //	      "<error>" if the value was not found.
{
  if ( value && _head->retrieve( buffer, bsize, value ) ) return buffer;
  else return strncpy( buffer, "<unknown>", bsize );
}
