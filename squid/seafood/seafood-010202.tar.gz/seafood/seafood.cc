//
// $Id: seafood.cc,v 1.16 2001/02/02 09:36:08 cached Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    seafood.hh
//          Thu Aug 05 1999
//
// (c) 1999 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: seafood.cc,v $
// Revision 1.16  2001/02/02 09:36:08  cached
// changed char* to const char* complaint by Sun's CC.
//
// Revision 1.15  2000/07/29 22:14:15  voeckler
// joined database and textual output, split generic part of output into
// separate file, split main parsing loop from seafood.cc into separate
// file.
//
// Revision 1.14  2000/07/27 07:42:08  voeckler
// added internal object counters and file extension lists.
//
// Revision 1.13  2000/06/09 09:27:17  voeckler
// fixes for FreeBSD 4.0
//
// Revision 1.12  1999/11/29 15:06:16  voeckler
// added options to create both forms of output, textual and db intermediate.
// more extensive logging for unknown hierarchy codes, added flag to warn
// about NONE entries which are counted as TCP entries.
//
// Revision 1.11  1999/10/29 14:13:19  voeckler
// added new -D parameter, moved output into separate modules and control
// functions, added -H parameter for decent names for output, fixed some
// endless loop bug in the whitespace gutting function.
//
// Revision 1.10  1999/09/02 10:22:19  voeckler
// the dns cache is now a pointer and not a reference any longer. Changes
// to the DNS and IRR helper interface due to the use of external helper
// processes. Some wording changes.
//
// Revision 1.9  1999/08/25 21:22:13  voeckler
// added distributions, added more comments, made some tables
// configurable, fixed bug with command line configuration file
// specification.
//
// Revision 1.8  1999/08/23 11:53:03  voeckler
// fixed bug in dns and irr server which resulted in looking up any
// negativly cached entry. Also added some more debug output to the
// cache code.
//
// Revision 1.7  1999/08/20 22:47:19  voeckler
// number of CPUs online is checked, and if two or more, and the
// input file is seekable, a filter input will be used for compressed
// files (speeds things). Now made the DNS cache a pointer, too.
//
// Revision 1.6  1999/08/18 11:12:52  voeckler
// extended gzip input and bzip2 input to use their respective low-level
// interface. Also added a filter input method for multi processor
// machines (currently experimental).
//
// Revision 1.5  1999/08/15 22:26:56  voeckler
// added prefill buffer possibility to PlainText class, so that
// any pre-read content must not be re-read.
//
// Revision 1.4  1999/08/08 09:07:42  voeckler
// added compile-time configurable libz and libbz2 support.
//
// Revision 1.3  1999/08/06 13:07:08  voeckler
// added stats to fsm01 in order to parse "CONNECT some.host:443" correctly.
//
// Revision 1.2  1999/08/05 22:09:30  voeckler
// made the config file location commandline configurable, added a force
// no lookups flag.
//
// Revision 1.1  1999/08/05 21:16:27  voeckler
// Initial revision
//
//
#if defined(__GNUC__) || defined(__GNUG__)
#pragma implementation
#endif

#include <stdio.h>
#include <errno.h>
#include <string.h>

#include <sys/types.h>
#include <sys/time.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <limits.h>
#include <sys/stat.h>
#include <locale.h> // LC_ALL, LC_CTYPE, LANG
#include <time.h> 

#include "typedefs.h"
#include "global.hh"
#include "counter.hh"
#include "ctype.hh"
#include "hash.hh"
#include "string.hh"
#include "input.hh"
#include "logline.hh"
#include "counters.hh"
#include "tools.hh"
#include "parseloop.hh"
#include "output.hh"
#include "dns.hh"

static const char*  RCS_ID =
"$Id: seafood.cc,v 1.16 2001/02/02 09:36:08 cached Exp $";

// global var to communication with flex/bison
int parserErrorSeen;
extern int yyparse();

#ifdef FREEBSD
#include <sys/types.h>
#include <sys/sysctl.h>
#endif

#ifndef NULLDEVICE
#ifdef unix
#define NULLDEVICE "/dev/null"
#else
#define NULLDEVICE "NUL:"
#endif
#endif

inline 
unsigned 
cpus( void )
  // purpose: determine number of CPUs currently online
{
#ifdef FREEBSD
  int mib[2] = { CTL_HW, HW_MODEL };
  int cpus;
  size_t len;
  int result = sysctl( mib, 2, &cpus, &len, NULL, 0 );
  return ( result == -1 ? 1 : cpus );
#else
# if !defined(_SC_NPROCESSORS_ONLN) && defined(_SC_NPROC_ONLN)
# define _SC_NPROCESSORS_ONLN _SC_NPROC_ONLN
# endif
  long result = sysconf(_SC_NPROCESSORS_ONLN);
  return ( result == -1 ? 1 : result );
#endif // FREEBSD
}

char*
knowsAbout( const char* what )
  // purpose: find the absolute path to a given program
{
  // obtain PATH information
  char* path = getenv("PATH");
  if ( path == 0 ) return 0;

  // obtain maximum size of a path information
  char local[4096];
  char* s = path;
  struct stat st;
  while ( s != 0 ) {
    
    char* t = strchr( s, ':' );
    if ( t == 0 ) t = path+strlen(path);

    // create path info
    size_t i = ( size_t(t-s) > sizeof(local)-1 ? sizeof(local)-1 : t-s );
    strncpy( local, s, i );
    local[i] = '\0';
    strncat( local, "/", sizeof(local) );
    strncat( local, what, sizeof(local) );

    if ( stat(local,&st) != -1 && 
	 ((geteuid() == st.st_uid && (st.st_mode & S_IXUSR) > 0 ) ||
	  (getegid() == st.st_gid && (st.st_mode & S_IXGRP) > 0 ) ||
	  (st.st_mode & S_IXOTH) > 0 ) ) return strdup(local);
    s = t+1;
  }

  return 0;
}

static
BaseInput*
obtainFile( const char* fn ) 
  // purpose: check the given file name for being of the 'right' kind
  //          and return either a gunzip or a plain input stream to it.
  // paramtr: fn (IN): file name
  // returns: opened input stream, of NULL in case of error
{
  // try to open the specified file
  int fd = (fn[0]=='-' && fn[1]=='\0') ?
    dup(STDIN_FILENO) :
    open( fn, O_RDONLY | O_NOCTTY );
  if ( fd == -1 ) {
    fprintf( stderr, "open(%s): %s\n", fn, strerror(errno) );
    return 0;
  }
  
  // check for gzipped input by reading a few byte (see: /etc/magic)
  unsigned char test[PIPE_BUF];
  int option;
  do {
    option = read( fd, test, PIPE_BUF );
  } while ( option == -1 && errno == EINTR );

  // see how much we have got, complain bitterly otherwise
  if ( option < 0 ) {
    perror( "read from input" );
    close(fd);
    return 0;
  } else if ( option < 4 ) {
    fputs( "read from input: premature end of input\n", stderr );
    close(fd);
    return 0;
  }

  static const char* unknownFormat = 
    "unknown input format (neither gzip, bzip2 nor plain)\n";
  BaseInput* result = 0;
  if ( ISDIGIT(test[0]) && ISDIGIT(test[1]) && ISDIGIT(test[2]) ) {
    // plain input, we do not need to rewind
    fputs( "# using internal plain input\n", stderr );
    result = new PlainInput( fd, 65520, (const char*) test, option );
  } else if ( cpus() > 1 && lseek( fd, -option, SEEK_CUR ) != -1 ) {
    // There are more than 1 CPU, so use an external program filter to
    // decompress the input. That way, we make use of more than 1 CPU.
    // Especially gzip input will be almost as fast as plain input.
    //    For filter input, we must reset the input stream, but that
    // will fail for pipe input or socket input.
    char* filter = 0;

    if ( (test[0] == 0x1F) && (test[1] == 0x8B) && (test[2] <= 0x08) &&
	 (filter=knowsAbout("gunzip")) != 0 ) {
      // gzip input
      fprintf( stderr, "# using external filter \"%s\"\n", filter );
      result = new FilterInput( fd, 65520, filter );
      free((void*) filter);
    } else if ( (test[0] == 0x42) && (test[1] == 0x5A) && (test[2] == 0x68) &&
		(test[3] >= 0x30) && (filter=knowsAbout("bunzip2")) != 0 ) {
      // bzip2 input
      fprintf( stderr, "# using external filter \"%s\"\n", filter );
      result = new FilterInput( fd, 65520, filter );
      free((void*) filter);
    } else if ( (test[0] == 0x1F) && (test[1] == 0x9D) && (test[2] >= 128) &&
		(filter=knowsAbout("uncompress")) != 0 ) {
      // compressed input
      fprintf( stderr, "# using external filter \"%s\"\n", filter );
      result = new FilterInput( fd, 65520, filter );
      free((void*) filter);
    } else {
      // unknown format
      fputs( unknownFormat, stderr );
    }

#ifdef USE_LIBZ
  } else if ( (test[0] == 0x1F) && (test[1] == 0x8B) && (test[2] <= 0x08) ) {
    // gzip input
    fputs( "# using internal zlib\n", stderr );
    result = new GZipInput( fd, 65520, (const char*) test, option );
#endif // USE_LIBZ
#ifdef USE_LIBBZ2
  } else if ( (test[0] == 0x42) && (test[1] == 0x5A) && (test[2] == 0x68) &&
	      (test[3] >= 0x30) ) {
    // bzip2 input
    fputs( "# using internal bzlib\n", stderr );
    result = new BZip2Input( fd, 65520, (const char*) test, option );
#endif // USE_LIBBZ2
  } else {
    // unknown input format
    fputs( unknownFormat, stderr );
  } // no such input

  return result;
}

// processFile() is now in module parseloop.cc

void
readConfigFile( const char* fn )
{
  extern FILE* yyin;

  fprintf( stderr, "# trying to read \"%s\"\n", fn );
  if ( (yyin=fopen(fn,"r")) != 0 ) {
    yyparse();
    fclose(yyin);
    if ( parserErrorSeen ) {
      fprintf( stderr, "there were errors in the \"%s\" config file, exiting!\n",
	       fn );
      exit(1);
    }
  } else {
    fprintf( stderr, "unable to read config file \"%s\": %s, exiting!\n", 
	     fn, strerror(errno) );
    exit(1);
  }
  fprintf( stderr, "# done reading \"%s\"\n", fn );
}

static
void
helpMe( const char* argv0, const char* rcsid )
{
  // obtain my own basename...
  const char* s = strrchr(argv0,'/');
  if ( s ) ++s;

  printf( "%s\nUsage:\t%s [-N] [-f cfgfile] [-O nr] [-D dbfile] [-o txtfile] \\\n\t[-T title] [-X] file1 [file2 [..]]\n", rcsid, s );
  puts( " fileN\tyou need at least one input file, plain"
#ifdef USE_LIBZ
	"|gzip"
#endif
#ifdef USE_LIBBZ2
	"|bzip2"
#endif
	" format" );
  printf( " -f fn\tUse configuration file fn instead of %s.conf\n", argv0 );
  puts( " -N\tDisable all DNS and IRR lookups regardless of configuration "
	"content" );
  puts( " -O nr\tOutput option: none (0), textual (1), dbase (2), both (3)");
  puts( " -o fn\tPrint textual results into file fn, default is stdout");
  puts( " -D fn\tDump results into file fn for DB post-processing" );
  puts( " -T tl\tUse the title 'tl' in output, default: "
	"basename(file1)" );
  puts( " -X\tToggle showing clients in the internal request paths table.");
  puts( "" );
  exit(1);
}

static
void
parseCommandline( int argc, char* argv[], 
		  char*& configFilename,
		  char*& outputFile,
		  char*& databaseFile,
		  char*& outputTitle,
		  bool& forceDisableLookups,
		  MyUInt08& outputOption )
  // purpose: parse optional arguments from the command line
  // paramtr: argc (IN): see main()
  //          argv (IN): see main()
  //          configFilename (OUT): place of configuration file
  //          outputFile (IO): name of file to use for textual results.
  //          databaseFile (IO): name of file to use for DB intermediate res.
  //          outputTitle (OUT): name of cache or cache group to use
  //          forceDisableLooups (IO): true==disable DNS+IRR 
  //          outputOption (IO): 0=no output 1=human readable on stdout,
  //                             2=db output 3=(1)+(2)
{
  // check for any argument
  if ( argc <= 1 ) helpMe(argv[0],RCS_ID);

  // construct configuration file default name
  configFilename = new char[strlen(argv[0])+6];
  strcpy( configFilename, argv[0] );
  strcat( configFilename, ".conf" );

  // parse options
  struct stat st;
  int option;
  while ( (option = getopt( argc, argv, "D:f:T:NO:o:X?" )) != -1 ) {
    switch ( option ) {
    case 'D':
      if ( databaseFile ) free((void*) databaseFile );
      databaseFile = 0;
      if ( optarg && *optarg ) {
	databaseFile = strdup(optarg);
	outputOption |= 0x02;
      }
      break;
    case 'f':
      if ( stat(optarg,&st) != -1 && 
	   ((geteuid() == st.st_uid && (st.st_mode & S_IRUSR) > 0 ) ||
	    (getegid() == st.st_gid && (st.st_mode & S_IRGRP) > 0 ) ||
	    (st.st_mode & S_IROTH) > 0 ) ) {
	delete[] configFilename;
	configFilename = new char[strlen(optarg)+1];
	strcpy( configFilename, optarg );
      } else {
	fprintf( stderr, "configuration file \"%s\" is invalid!\n", optarg );
	exit(1);
      }
      break;
    case 'T':
      if ( outputTitle ) free((void*) outputTitle );
      outputTitle = 0;
      if ( optarg && *optarg ) outputTitle = strdup(optarg);
      break;
    case 'N':
      forceDisableLookups = true;
      break;
    case 'O':
      outputOption = strtoul( optarg, 0, 0 ) & 0x03;
      break;
    case 'o':
      if ( outputFile ) free((void*) outputFile );
      outputFile = 0;
      if ( optarg && *optarg ) {
	outputFile  = strdup(optarg);
	outputOption |= 0x01;
      }
      break;
    case 'X':
      globals.showExtendedInternal = ! globals.showExtendedInternal;
      break;
    case '?':
    default:
      helpMe(argv[0],RCS_ID);
      break;
    }
  }

  if ( outputTitle == 0 ) {
    // determine output cache name from first basename -- if there is one.
    // otherwise insist on having the output give a (virtual) name
    if ( optind == argc ) {
      fputs( "Sorry, but I need a (possibly virtual) name for the output\n"
	     "Please use the -H option to set such a name.\n", stderr );
      exit(1);
    }

    // determine the basename without suffix
    char* s = strrchr( argv[optind], '/' );
    if ( s == 0 ) s = argv[optind]; 
    else ++s;
    char* t = strchr( s, '.' );
    if ( t == 0 ) t = s + strlen(s);
#if 0
    fprintf( stderr, "# starting in \"%s\", going for %d chars.\n", s, t-s );
    exit(0);
#endif

    // copy the basename into outputTitle
    outputTitle = (char*) malloc( t-s+1 );
    memcpy( outputTitle, s, t-s );
    outputTitle[t-s] = '\0';
  }

  // ascertain that only legal host characters are used,
  // and replace illegal characters with an underscore.
  for ( char* s = outputTitle; s && *s; ++s )
    if ( ! ISHNAME(*s) ) *s = '_';


  // reset output option according to filename availability
  outputOption &= 3;
  if ( (outputOption & 2) > 0 && databaseFile == 0 ) outputOption &= 0xFD;
  if ( (outputOption & 1) > 0 && outputFile == 0 ) outputOption &= 0xFE;
  if ( outputOption == 0 ) {
    fputs( "No ouput files specified, exiting!\n\n", stderr );
    helpMe( argv[0], RCS_ID );
  }
}

static
void
openOutput( FILE*& fp, const char* fn, FILE* alternative = 0 ) 
{
  // open output, thus checking for writability
  if ( alternative && (fn == 0 || *fn == 0 || fn[0] == '-' && fn[1] == '\0') )
    fp = alternative;
  else if ( (fp = fopen( fn, "w" )) == 0 ) {
    fprintf( stderr, "unable to open(%s) for writing: (%d) %s\n",
	     fn, errno, strerror(errno) );
    exit(1);
  }
}

// -------------------------------------------------------------------

int
main( int argc, char* argv[] )
{
  double startup = now();
  double looptime = 0.0;
  MyUInt32 lineno = C_U32(0);

  // just a quick dash into locale settings
  if ( setlocale(LC_ALL,"C") == 0 ) 
    perror( "# unable to set C local environment" );

  // read some basic configuration commands
  bool disableLookups = false;
  MyUInt08 outputOption = 1;
  char* outputFilename = strdup("-");
  char* dbaseFilename = 0;
  char* configFilename = 0;
  char* outputTitle = 0;
  parseCommandline( argc, argv, configFilename, 
		    outputFilename, dbaseFilename, outputTitle, 
		    disableLookups,  outputOption );

  // open output, thus checking for writability first
  FILE* txtout = 0;
  if ( (outputOption & 1) > 0 ) openOutput( txtout, outputFilename, stdout );
  if ( txtout == 0 ) txtout = fopen( NULLDEVICE, "w" );
  FILE* dbout = 0;
  if ( (outputOption & 2) > 0 ) openOutput( dbout, dbaseFilename );

  // read configuration file
  readConfigFile( configFilename );
  delete[] configFilename;

  // force disable lookups, if such was commandline-wanted
  // that will still open the DNS database...
  if ( disableLookups ) {
    globals.clientFQDN = false;
    if ( globals.irrServer ) free((void*) globals.irrServer);
    globals.irrServer = 0;
  }

  // in case of debugging, use slower line buffered output
  if ( globals.debugClass || globals.debugLevel )
    setvbuf( stdout, 0, _IOLBF, 8192 );

  // *AFTER* reading configuration, allocate counters
  Counters counters; // default c'tor

  // try to read DNS cache 
  DNSCache* dns = 0;
  if ( ! disableLookups ) {
    fputs( "# trying to read DNS cache and start DNS co processes...\n",
	   stderr );
    dns = new DNSCache( globals.dnsChildren,
			globals.dnsHelper,
			globals.dnsCacheFile, 
			globals.dnsPositiveTTL, 
			globals.dnsNegativeTTL );
    fprintf( stderr, "# DNS cache contains %lu entries.\n", 
	     dns ? dns->size() : 0 );
  } else {
    fputs( "# no DNS cache required.\n", stderr );
  }

  // establish connection to IRR server
  IRRCache* irr = 0; // IRR connection
  if ( globals.irrServer && ! disableLookups ) {
    fprintf( stderr, "# read IRR cache, start IRR co processes, use server \"%s\".\n", 
	     globals.irrServer );
    irr = new IRRCache( globals.irrChildren,
			globals.irrHelper,
		        globals.irrCacheFile, 
			globals.irrServer,
			globals.irrPositiveTTL, 
			globals.irrNegativeTTL );
    fprintf( stderr, "# IRR cache contains %lu entries.\n", 
	     irr ? irr->size() : 0 );
  } else {
    fputs( "# no IRR services required.\n", stderr );
  }

  // process files
  for ( int filenr=optind; filenr < argc; filenr++ ) {
    BaseInput* in = obtainFile( argv[filenr] );
    if ( in ) { 
      looptime += processFile( in, counters );
      lineno += (in->lineno - 1);
    }
    delete in;
  }

  // show results  
  fputs( "# done processing files\n", stderr );
  printResults( txtout, dbout, outputTitle, dns, irr, 
		counters, looptime, startup, lineno );
  if ( txtout != stdout ) fclose(txtout);
  fclose(dbout);

  // finalize local cache constructs
  if ( dns ) {
    fprintf( stderr, "# dumping DNS cache (%u entries)\n", dns->size() );
    delete dns;
    dns = 0;
  }

  if ( irr ) {
    fprintf( stderr, "# dumping IRR cache (%u entries)\n", irr->size() );
    delete irr;
    irr = 0;
  }

  free((void*) outputFilename );
  fputs( "# DONE!\n", stderr );
  return 0;
}
