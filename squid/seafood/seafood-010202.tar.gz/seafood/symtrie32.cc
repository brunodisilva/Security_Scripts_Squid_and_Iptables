//
// $Id: symtrie32.cc,v 1.2 2000/07/29 22:10:53 voeckler Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    symtrie32.cc
//          Thu Aug 05 1999
//
// (c) 1998 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: symtrie32.cc,v $
// Revision 1.2  2000/07/29 22:10:53  voeckler
// adaptation of an interface through an abstract base class.
//
// Revision 1.1  1999/08/05 21:13:12  voeckler
// Initial revision
//
//
#if defined(__GNUC__) || defined(__GNUG__)
#pragma implementation
#endif

#include <assert.h>
#include <string.h>
#include <stdio.h>
#include "symtrie32.hh"

static const char* RCS_ID =
"$Id: symtrie32.cc,v 1.2 2000/07/29 22:10:53 voeckler Exp $";

const char SymbolTrie32::SymbolNode::xlate[] = 
"@ABCDEFGHIJKLMNOPQRSTUVWXYZ????_";

#if defined(__GNUC__) || defined(__GNUG__)
size_t
SymbolTrie32::distinct() const
{ 
  return _distinct; 
}
#endif

SymbolTrie32::SymbolNode::SymbolNode( MyUInt32 v )
  :data(v)
{ 
  memset( down, 0, sizeof(SymbolNodePtr) * 32 );
}

SymbolTrie32::SymbolNode::SymbolNode( const SymbolNode& sn )
  :data(sn.data)
{ 
  memset( down, 0, sizeof(SymbolNodePtr) * 32 );
  for ( int i=0; i<32; i++ )
    if ( sn.down[i] )
      down[i] = new SymbolNode( *(sn.down[i]) );
}

SymbolTrie32::SymbolNode&
SymbolTrie32::SymbolNode::operator=( const SymbolTrie32::SymbolNode& sn )
{
  if ( &sn != this ) {
    // destruct old value
    for ( int i=0; i<32; i++ )
      if ( down[i] ) delete down[i];

    // deep copy new items
    data = sn.data;
    memset( down, 0, sizeof(SymbolNodePtr) * 32 );
    for ( int i=0; i<32; i++ )
      if ( sn.down[i] )
	down[i] = new SymbolNode( *(sn.down[i]) );
  }
  return *this;
}

SymbolTrie32::SymbolNode::~SymbolNode()
{ 
  for ( int i=0; i<32; i++ )
    if ( down[i] ) delete down[i];
}

SymbolTrie32::~SymbolTrie32()
{
  // empty
}

SymbolTrie32&
SymbolTrie32::operator=( const SymbolTrie32& st )
  // purpose: copy operator
{
  if ( &st != this ) {
    _head = st._head;
    _size = st._size;
    _distinct = st._distinct;
  }
  return *this;
}

#include <ctype.h>

void 
SymbolTrie32::SymbolNode::print( FILE* f, int indent ) const
{
  bool action = false;
  for ( int j=0; j<32; j++ ) {
    if ( action && down[j] ) {
      fputc('\n', f );
      for ( int i=0; i<indent; i++ ) fputc( '.', f );
    }
    if ( down[j] ||  (j==0 && data) ) {
      fprintf( f, "(%02x,%c", data & 0x1FFFF, xlate[j] );
      action = true;
      if ( down[j] ) down[j]->print( f, indent+1 );
      fputc( ')', f );
    }
  }
}

bool
SymbolTrie32::insert( const char* name, MyUInt32 value )
  // purpose: insert a new piece into the symbol table
  // paramtr: name (IN): new name to insert into symtab
  //          value (IN): token value to use for default override
  // returns: true, if insertion was successful.
  // warning: double inserts will overwrite the old value
{
  // sanity check
  if ( name==0 ) return false;
  const char* s=name; 
  while ( *s >= 'A' && *s <= 'Z' || *s == '_' ) s++;
  if ( *s ) {
    fprintf( stderr, "%c (%d) in \"%s\" is invalid for this kind of trie!\n",
	     *s, *s, name );
    return false;
  }

  SymbolNode* temp( &_head );
  for ( s=name; *s; s++ ) {
    char ch = *s & 0x1F;
    if ( temp->down[ch] == 0 )
      temp->down[ch] = new SymbolNode();
    temp = temp->down[ch];
  }

  // POSTCONDITION: temp points to a valid element with key character '\0'
  //                where we may safely insert a value.
  temp->data = value;
  _size++;
  if ( ! (value & IS_ALIAS) ) _distinct++;
  return true;
}

MyUInt32
SymbolTrie32::find( const char* name ) const
  // purpose: search the trie for the given word, and return token value
  // paramtr: word (IN): word to search trie for
  // returns: 0 for not found, tokenvalue otherwise
  //          The return value of 0 lets you count the errors, too.
  // warning: PRECONDITION: word must not be null!
{
  const SymbolNode* temp( &_head );
  for ( const char* s = name; *s && temp; s++ )
    temp = temp->down[ *s & 0x1F ];

  // POSTCONDITION: temp points to a level, where the '\0' is suspected
  return ( temp ? temp->data : 0 );
}

bool
SymbolTrie32::SymbolNode::exists( MyUInt32 v ) const
  // returns: true, if value was found, false otherwise.
{
  if ( (data & 0x1FFFF) == v ) return true;
  else
    for ( int j=1; j<32; j++ )
      if ( down[j] && down[j]->exists(v) ) return true;

  // nothing found here
  return false;
}

bool
SymbolTrie32::SymbolNode::retrieve( char* s, size_t max, 
				    MyUInt32 v, size_t i ) const
  // purpose: traverse trie in order to find value v and store the
  //          characters encountered during descend into a storage.
  // paramtr: s (IO): storage to store parameters into
  //          max (IN): maximum size of the storage
  //          v (IN): value to search for
  //          i (IN): current position to change storage at.
  // returns: true, if value was found, false otherwise.
{

  // safety checks first
  if ( i >= max ) return false;

  if ( (data & 0x1FFFF) == v ) {
    s[i] = '\0';
    return true;
  } else {
    // only for !NUL we need to test further downward
    for ( int j=1; j<32; j++ ) {
      s[i] = xlate[j];
      if ( down[j] && down[j]->retrieve(s,max,v,i+1) ) return true;
    }
  }

  // nothing found here
  return false;
}

const char* 
SymbolTrie32::reverse( char* buffer, size_t bsize, MyUInt32 value ) const
  // purpose: find the matching string to a given token value
  // paramtr: buffer (IO): area to store resulting string into
  //          bsize (IN): size of the area to store data into
  //          value (IN): value to look for
  // returns: a pointer to the buffer, which will contain
  //	      "<error>" if the value was not found.
{
  if ( value && _head.retrieve( buffer, bsize, value ) ) return buffer;
  else return strncpy( buffer, "<unknown>", bsize );
}
