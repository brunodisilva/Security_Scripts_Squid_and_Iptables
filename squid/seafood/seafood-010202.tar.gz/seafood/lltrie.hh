//
// $Id: lltrie.hh,v 1.2 2000/07/29 22:10:53 voeckler Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    lltrie.hh
//          Thu Aug 05 1999
//
// (c) 1999 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: lltrie.hh,v $
// Revision 1.2  2000/07/29 22:10:53  voeckler
// adaptation of an interface through an abstract base class.
//
// Revision 1.1  1999/08/05 21:12:10  voeckler
// Initial revision
//
//
#ifndef _LLTRIE_HH
#define _LLTRIE_HH

#if defined(__GNUC__) || defined(__GNUG__)
#pragma interface
#endif

#include "typedefs.h"
#include "basetrie.hh"

class LinkedListTrie : public BasicTrie {
  // linked list version of a trie. 
  // This class is optimized for fast find() operations.
  // It will do good, if each level does not have more than a few nodes.
  // Insertions and reverse finds are slow and exhaustive.
public:

  class SymbolNode {
    // purpose: node class of the trie
  public:
    typedef SymbolNode* SymbolNodePtr;

    inline SymbolNode( char ch, MyUInt32 v = 0 )
      :next(0),down(0),data(v),what(ch)
      { }
    SymbolNode( const SymbolNode& sn );
    SymbolNode( const SymbolNode* sn );
    ~SymbolNode();
    SymbolNode& operator=( const SymbolNode& sn );

    bool retrieve( char* s, size_t max, MyUInt32 v, size_t i = 0 ) const;
    // purpose: traverse trie in order to find value v and store the
    //          characters encountered during descend into a storage.
    // paramtr: s (IO): storage to store parameters into
    //          max (IN): maximum size of the storage
    //          v (IN): value to search for
    //          i (IN): current position to change storage at.
    // returns: true, if value was found, false otherwise.
  
    bool exists( MyUInt32 v ) const;
    void print( FILE* f, int indent = 0 ) const;

    SymbolNode* next; // next on same level (same char position in word)
    SymbolNode* down; // next on next level (next char position in word)
    MyUInt32    data; // token value
    char        what; // current word character looked at

  private:
    // disallow these
    SymbolNode();
  };

  inline LinkedListTrie()
    :_size(0),_distinct(0),_head(0) { }
  LinkedListTrie( const LinkedListTrie& llt );
  LinkedListTrie( const LinkedListTrie* llt );
  virtual ~LinkedListTrie();
  LinkedListTrie& operator=( const LinkedListTrie& llt );
  // purpose: assignment operator

  virtual size_t size() const { return _size; }
  // returns: number of leafs
  virtual size_t distinct() const { return _distinct; }
  // returns: number of distinct tokens: distinct() <= size()

  virtual 
  bool insert( const char* word, MyUInt32 value );
  // purpose: insert a new piece into the symbol table
  // paramtr: name (IN): new name to insert into symtab
  //          value (IN): token value to use for default override
  // returns: true, if insertion was successful.
  // warning: double inserts will overwrite the old value

  virtual 
  const char* reverse( char* buffer, size_t bsize, MyUInt32 value ) const;
  // purpose: find the matching string to a given token value
  // paramtr: buffer (IO): area to store resulting string into
  //          bsize (IN): size of the area to store data into
  //          value (IN): value to look for
  // returns: a pointer to the buffer, which will contain
  //	      "<error>" if the value was not found.
  
  virtual 
  MyUInt32 find( const char* word ) const;
  // purpose: search the trie for the given word, and return token value
  // paramtr: word (IN): word to search trie for
  // returns: 0 for not found, tokenvalue otherwise
  //          The return value of 0 lets you count the errors, too.
  // warning: PRECONDITION: word must not be null!

  inline void print( FILE* f ) const
    { _head->print(f); fputc('\n',f); }

protected:
  size_t      _size;
  size_t      _distinct;
  SymbolNode* _head;
};

#endif // _LLTRIE_HH
