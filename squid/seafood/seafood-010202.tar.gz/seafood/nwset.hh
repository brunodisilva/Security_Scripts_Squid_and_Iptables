//
// $Id: nwset.hh,v 1.3 2000/08/02 12:27:13 voeckler Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    nwset.hh
//          Tue Aug 31 1999
//
// (c) 1999 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: nwset.hh,v $
// Revision 1.3  2000/08/02 12:27:13  voeckler
// Some fixes in order to be compilable with HAS_HASHSET.
//
// Revision 1.2  1999/11/29 15:09:48  voeckler
// bug fix: Changed network addr. key to broadcast addr. as key.
//
// Revision 1.1  1999/09/02 10:16:20  voeckler
// Initial revision
//
//
#ifndef _NWSET_HH
#define _NWSET_HH

#if defined(__GNUC__) || defined(__GNUG__)
#pragma interface
#endif

#include "network.hh"

#ifndef HAS_HASHSET
#include <set>
#else
#include <hash_set>
#endif

#ifndef HAS_HASHSET
typedef std::set< Network, std::less<Network> > NetworkSet;
#else
struct nwhash {
  // BEWARE: create different entries for "194.64.0.0/24" and "194.64.0.0/16"!
  // It is permissable for hash functions to map different keys to the same
  // value, e.g.: hash(206.161.207.0/24) == hash(206.161.192.0/20)
  inline MyUInt32 operator()(const Network& nw) const
    { return nw.broadcast(); }
};
typedef std::hash_set< Network, nwhash, std::equal_to<Network> > NetworkSet;
#endif

struct FindMatch {
  // struct to use in conjunction with a find_if operation on the nwset.
  // find_if there is a network/netmask pair which matches the given host.
public:
  inline FindMatch( MyUInt32 a )
    :host(a) 
    { }
  inline bool operator()( const Network& nw ) const
    { return nw.match(host); }
private:
  MyUInt32 host;
};

#endif // _NWSET_HH
