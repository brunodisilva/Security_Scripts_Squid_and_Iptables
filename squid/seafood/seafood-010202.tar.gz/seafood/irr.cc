//
// $Id: irr.cc,v 1.12 2000/08/10 12:51:07 voeckler Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    irr.cc
//          Thu Aug 05 1999
//
// (c) 1999 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: irr.cc,v $
// Revision 1.12  2000/08/10 12:51:07  voeckler
// Added more extensive debugging code in the style of dns.cc to irr.cc.
//
// Revision 1.11  1999/11/29 15:10:35  voeckler
// extensive logging for error detection.
//
// Revision 1.10  1999/10/29 13:48:49  voeckler
// moved to gdbm cache file format.
//
// Revision 1.9  1999/09/02 10:08:12  voeckler
// removed obsolete old interface, myriads of fixes for getOriginByAddress(),
// added set of network/netmask pairs for host address look ups.
//
// Revision 1.8  1999/08/31 08:48:42  voeckler
// new intermediary revision before removing obsolete items.
//
// Revision 1.7  1999/08/27 21:51:27  voeckler
// changed String operator() to method c_str() call.
//
// Revision 1.6  1999/08/27 20:57:21  voeckler
// removed io stream in favour of standard io, moved IRRItem into
// a class of its own, fixed signedness problems.
//
// Revision 1.5  1999/08/25 21:27:03  voeckler
// fixed some spelling, removed superflous variable, fixed some
// minor bug.
//
// Revision 1.4  1999/08/23 11:53:03  voeckler
// fixed bug in dns and irr server which resulted in looking up any
// negativly cached entry. Also added some more debug output to the
// cache code.
//
// Revision 1.3  1999/08/20 22:43:15  voeckler
// now expires entries in c'tor.
//
// Revision 1.2  1999/08/15 20:24:33  voeckler
// removed NDBM dependency in favour of a textual database format
// which is (supposed to be) interchangable between different
// platforms.
//
// Revision 1.1  1999/08/05 21:06:01  voeckler
// Initial revision
//
//
#if defined(__GNUC__) || defined(__GNUG__)
#pragma implementation
#endif

#include <assert.h>
#include <sys/types.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>

#include "ctype.hh"
#include "global.hh"
#include "irritem.hh"
#include "irr.hh"
#include "rw.hh"

#include <algorithm>
#include "dnsitem.hh"

static const char* RCS_ID =
"$Id: irr.cc,v 1.12 2000/08/10 12:51:07 voeckler Exp $";

static
char* const*
make( const char* prg, const char* whoisServer, 
      MyUInt32 positive, MyUInt32 negative )
{
  static char pos[16];
  sprintf( pos, SF_U32, positive );
  static char neg[16];
  sprintf( neg, SF_U32, negative );
  static char* const argv[5] = {
    (char*) prg, (char*) whoisServer, pos, neg, (char*) 0 
  };
  return argv;
}

IRRCache::IRRCache( size_t nrOfChildren,
		    const char* irrHelper,
		    const char* cacheFile,
		    const char* whoisServer,
		    MyUInt32 posTTL,
		    MyUInt32 negTTL )
  :BaseCache(posTTL,negTTL),
   dbfn(strdup(cacheFile ? cacheFile : "")),
   helper( nrOfChildren, irrHelper, make(irrHelper,whoisServer,posTTL,negTTL),
	   (globals.debugClass & Global::D_IRR), globals.debugLevel, this ),
   dbase( dbfn, false, false ), // rw, sync
   count(C_U32(0))
{
  StringSet expired;
  time_t now = time(0);

  // do not expire while there is an opened iterator on the database!
  for ( GDBM::Iterator i(dbase); i.avail(); i++ ) {
    ++count;
    if ( (globals.debugClass & Global::D_IRR) && (count & 16383) == 0 ) {
      now = time(0); // refresh time information      
      fprintf( stderr, "# read " SF_U32 " irr cache entries.\n", count );
    }

    String keyString( i.key() );
    IRRItem value( i.value().c_str() );
    if ( value.expires <= now ) expired.insert(keyString);
    else if ( ISDIGIT(keyString[0]) ) networks.insert(Network(keyString));
  }

  for ( StringSet::iterator i=expired.begin(); i!=expired.end(); ++i ) {
    fprintf( stderr, "# removing irr key \"%s\"\n", (*i).c_str() );
    dbase.erase( *i );
    --count;
  }

  if ( (globals.debugClass & Global::D_IRR) )
    fprintf( stderr, "# " SF_U32 " irr cache entries and %u network map entries are usable.\n",
	     count, networks.size() );
}

IRRCache::~IRRCache()
{
  dbase.sync();
  free((void*) dbfn );
}

IRRCache::IRRItemMap 
IRRCache::getOriginByAddress( const StringSet& what )
{
  IRRItemMap result;
  if ( what.size() == 0 ) return result;

  // find all entries we already know about by matching the given
  // host address with the set of networks/netmasks, and 
  // copy all unknown entries for massive parallel querying
  StringSet unknown;
  time_t now = time(0);
  requests[C_ALL] += what.size();
  if ( (globals.debugClass & Global::D_IRR) && globals.debugLevel > 1 )
    fprintf( stderr, "# IRR %d look ups\n", what.size() );
  for ( StringSet::const_iterator i=what.begin(); i != what.end(); ++i ) {
    NetworkSet::iterator where =
      std::find_if( networks.begin(), networks.end(),
		    FindMatch( DNSItem::aton(*i) ) );
    if ( where != networks.end() ) {
      // found a host match in network/netmask pairs
      String key( (*where).toString() );
      IRRItem value( dbase.fetch(key).c_str() );
      if ( value.expires < now ) {
	// ttl will be 0 for non existing item
	if ( value.expires == 0 ) requests[C_MISS]++;
	else requests[C_TTL]++;
	if ( (globals.debugClass & Global::D_IRR) && globals.debugLevel )
	  fprintf( stderr, "# IRR cache %s: %s --> %s\n",
		   value.expires == 0 ? "MISS" : "TIMEOUT",
		   (*i).c_str(), key.c_str() );
	unknown.insert(*i);
      } else {
	requests[C_HIT]++;
	if ( (globals.debugClass & Global::D_IRR) && globals.debugLevel > 2 ) {
	  fprintf( stderr, "# IRR cache HIT: %s --> %s --> %s\n",
		   (*i).c_str(), key.c_str(),
		   value.toString().c_str() );
	}
	result[*i] = value;
      }
    } else {
      // no such host in network/netmask pairs
      requests[C_MISS]++;
      if ( (globals.debugClass & Global::D_IRR) && globals.debugLevel )
	fprintf( stderr, "# IRR cache NW/NM MISS: %s\n", (*i).c_str() );
      unknown.insert(*i);
    }
  }

  // POSTCONDITION: what do we have here:
  // 1) a set "unknown" with host address strings
  // 2) a map "result" with host address string keys and IRRItem values
  // PROBLEM: whois lookups yield network/netmask pairs with AS number

  // if there are any unknown entries, we need to look 'em up (parallel)
  if ( ! unknown.empty() ) {
    NetworkSet localnet;
    IRRItemMap localmap;
    helper.query( unknown, localmap, negativeTTL );
    // POSTCONDITION: the keys of 'local' are network/CIDR pairs

    if ( (globals.debugClass & Global::D_IRR) && globals.debugLevel > 1 )
      fprintf( stderr, "# IRR unknown set=%d, lookup map=%d\n", 
	       unknown.size(), localmap.size() );

    // insert all known networks into a local network/netmask map
    for ( IRRItemMap::Iterator i(localmap); i.avail(); i++ ) {
      String keyString( i.key() );
      if ( (globals.debugClass & Global::D_IRR) && globals.debugLevel > 1 )
	fprintf( stderr, "# IRR localnet insert: %s\n", keyString.c_str() );
      localnet.insert(Network(keyString));
      if ( ! dbase.exists(keyString) ) ++count;
      if ( (globals.debugClass & Global::D_IRR) && globals.debugLevel > 1 )
	fprintf( stderr, "# IRR dbase insert: %s --> %s\n", 
		 keyString.c_str(), i.value().toString().c_str() );
      dbase.insert( keyString, i.value().toString() );
    }

    // now rematch with the help of localnet (smaller --> faster)
    for ( StringSet::iterator i=unknown.begin(); i != unknown.end(); ++i ) {
      NetworkSet::iterator where = 
	std::find_if( localnet.begin(), localnet.end(),
		      FindMatch( DNSItem::aton(*i) ) );

      // if there is a match of the host address with the networks,
      // add to result
      if ( where != localnet.end() ) {
	String key( (*where).toString() );
	IRRItem value = result[*i] = localmap[key];
	requests[ value.empty ? C_NEG : C_POS ]++;
	if ( (globals.debugClass & Global::D_IRR) )
	  fprintf( stderr, "# IRR %stive lookup: %s --> %s --> %s\n", 
		   ( value.empty ? "nega" : "posi" ),
		   (*i).c_str(), key.c_str(),
		   value.toString().c_str() );
      } else {
	IRRItem value;
	requests[C_NEG]++;
	value.expires = time(0) + negativeTTL;
	result[*i] = value;
	if ( (globals.debugClass & Global::D_IRR) )
	  fprintf( stderr, "# IRR negative lookup: %s --> %s\n", 
		   (*i).c_str(), value.toString().c_str() );
      }
    }

    // add network/CIDR to our own cache map for future lookups
    networks.insert( localnet.begin(), localnet.end() );
  }

  return result;
}

IRRCache::IRRItemMap 
IRRCache::getanybyany( const StringSet& what )
{
  IRRItemMap result;
  if ( what.size() == 0 ) return result;

  // find all entries we already know about, and 
  // copy all unknown entries for massive parallel querying
  StringSet unknown;
  time_t now = time(0);
  requests[C_ALL] += what.size();
  if ( (globals.debugClass & Global::D_IRR) && globals.debugLevel > 1 )
    fprintf( stderr, "# IRR %d look ups\n", what.size() );
  for ( StringSet::const_iterator i=what.begin(); i != what.end(); ++i ) {
    IRRItem value( dbase.fetch((*i).trim()).c_str() );
    // POSTCONDITION: ttl will be 0 for non existing item

    if ( value.expires < now ) {
      if ( value.expires == 0 ) requests[C_MISS]++;
      else requests[C_TTL]++;
      if ( (globals.debugClass & Global::D_IRR) && globals.debugLevel ) {
	fprintf( stderr, "# IRR cache %s: %s\n", 
		 value.expires == 0 ? "MISS" : "TIMEOUT", (*i).c_str() );
      }
      unknown.insert(*i);
    } else {
      requests[C_HIT]++;
      if ( (globals.debugClass & Global::D_IRR) && globals.debugLevel ) {
	fprintf( stderr, "# IRR cache HIT: %s --> %s\n", 
		 (*i).c_str(), value.toString().c_str() );
      }
      result[*i] = value;
    }
  }
  
  // if there are any unknown entries, we need to look 'em up (parallel)
  if ( ! unknown.empty() ) {
    IRRItemMap local;
    helper.query( unknown, local, negativeTTL );

    for ( IRRItemMap::Iterator i(local); i.avail(); i++ ) {
      // add findings anyway to our cache
      String keyString( i.key() );
      if ( ISDIGIT(keyString[0]) ) networks.insert(Network(keyString));
      String valueString( i.value().toString() );
      if ( ! dbase.exists( keyString ) ) ++count;
      dbase.insert( keyString, valueString );

#if 0
      // if current answer is part of the search, add to result
      StringSet::iterator j = unknown.find( keyString );
      if ( j != unknown.end() ) 
#endif
	result[ keyString ] = i.value();

      if ( i.value().empty ) {
	requests[C_NEG]++;
	if ( (globals.debugClass & Global::D_IRR) )
	  fprintf( stderr, "# IRR negative lookup: %s\n", 
		   keyString.c_str() );
      } else {
	requests[C_POS]++;
	if ( (globals.debugClass & Global::D_IRR) )
	  fprintf( stderr, "# IRR positive lookup: %s\n", 
		   valueString.c_str() );
      }
    }
  }

  return result;
}

