//
// $Id: ctype.hh,v 1.5 2001/02/02 09:53:37 voeckler Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    ctype.hh
//          Thu Aug 05 1999
//
// (c) 1999 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: ctype.hh,v $
// Revision 1.5  2001/02/02 09:53:37  voeckler
// changed tolower and toupper conversion tables from char to short, because
// the range of -128 to 255 implied a conversion between different char types.
//
// Revision 1.4  1999/08/20 12:13:01  voeckler
// the in-file definition of __USE_GNU caused troubles with glibc-2.1. Now
// moved the definition into the Makefile for Linux systems.
//
// Revision 1.3  1999/08/05 21:04:03  voeckler
// added many new character class detectors, especially the RFC 2396 URI
// syntax for reserved, unreserved, delimiting and unwise characters.
// Also added support for hexdigits, control characters class, and the
// legal hostname character class. Also added uppercase and lowercase
// conversions based on ASCII.
//
//
#ifndef _MY_CTYPE_HH
#define _MY_CTYPE_HH

#ifdef CTYPE_IS_FAST
# include <ctype.h>
# define ISCNTRL(c) iscntrl(c)
# define ISDIGIT(c) isdigit(c)
# define ISSPACE(c) isspace(c)
# if defined(HAS_ISBLANK) && defined(isblank)
#  define ISBLANK(c) isblank(c)
# else
#  define ISBLANK(c) ((c)==' '||(c)=='\t')
# endif // HAS_ISBLANK
#else
# define ISDIGIT(c) CType::digit(c)
# define ISSPACE(c) CType::space(c)
# define ISBLANK(c) CType::blank(c)
# define ISCNTRL(c) CType::cntrl(c)
#endif // CTYPE_IS_FAST

#define ISHNAME(c) CType::hname(c) // correct hostname character [alnum_-.]
#define ISRESVD(c) CType::resvd(c) // RFC 2396 reserved characters [;/?:@&=+$,]
#define ISUNRSV(c) CType::unrsvd(c)// RFC 2396 unres. chars alnum+[-_.!~*'()]
#define ISDELIM(c) CType::delim(c) // RFC 2396 delimiter characters [<>#%"]
#define ISUNWSE(c) CType::unwise(c)// RFC 2396 unwise characters [{}|\^[]`]

#define TOLOWER(c) CType::lower(c)
#define TOUPPER(c) CType::upper(c)

#define UNXDIGIT(c) (ISDIGIT(c) ? c-'0' : CType::upper(c)-'A'+10)

class CType {
  // PRECONDITION on predicates: -128 <= ch <= 255
  // Anything else will (hopefully) produce a core dump.
  // That is for performance reasons! ASCII subset character conversions
public:
#ifndef BIT_CTYPE
  static inline int digit( int ch )
  { return (CType::ctype_table[ch] & (0x001)) != 0; }
  static inline int space( int ch )
  { return (CType::ctype_table[ch] & (0x002)) != 0; }
  static inline int blank( int ch )
  { return (CType::ctype_table[ch] & (0x004)) != 0; }
  static inline int xdigit( int ch )
  { return (CType::ctype_table[ch] & (0x008)) != 0; }
  static inline int cntrl( int ch )
  { return (CType::ctype_table[ch] & (0x010)) != 0; }
  static inline int hname( int ch )
  { return (CType::ctype_table[ch] & (0x020)) != 0; }
  static inline int resvd( int ch )
  { return (CType::ctype_table[ch] & (0x040)) != 0; }
  static inline int unrsvd( int ch )
  { return (CType::ctype_table[ch] & (0x080)) != 0; }
  static inline int delim( int ch )
  { return (CType::ctype_table[ch] & (0x100)) != 0; }
  static inline int unwise( int ch )
  { return (CType::ctype_table[ch] & (0x200)) != 0; }
#else
  static inline int digit( int ch )
  { return CType::ctype_table[ch].digit; }
  static inline int space( int ch )
  { return CType::ctype_table[ch].space; }
  static inline int blank( int ch )
  { return CType::ctype_table[ch].blank; }
  static inline int xdigit( int ch )
  { return CType::ctype_table[ch].xdigit; }
  static inline int cntrl( int ch )
  { return CType::ctype_table[ch].cntrl; }
  static inline int hname( int ch )
  { return CType::ctype_table[ch].hname; }
  static inline int resvd( int ch )
  { return (CType::ctype_table[ch].resvd; }
  static inline int unrsvd( int ch )
  { return (CType::ctype_table[ch].unrsvd; }
  static inline int delim( int ch )
  { return (CType::ctype_table[ch].delim; }
  static inline int unwise( int ch )
  { return (CType::ctype_table[ch].unwise; }
#endif

  static inline int lower( int ch )
  { return CType::lower_table[ch]; }
  static inline int upper( int ch )
  { return CType::upper_table[ch]; }

private:
  static const short  ctype_lower[384];
  static const short* const lower_table;
  static const short  ctype_upper[384];
  static const short* const upper_table;

#ifndef BIT_CTYPE
  static const short  ctype_basic[384];
  static const short* const ctype_table;
#else
  struct Internal {
    unsigned digit:1;
    unsigned space:1;
    unsigned blank:1;
    unsigned xdigit:1;
    unsigned cntrl:1;
    unsigned hname:1;
    unsigned resvd:1;
    unsigned unrsvd:1;
    unsigned delim:1;
    unsigned unwise:1;
  };
  static const Internal  ctype_basic[384];
  static const Internal* ctype_table;

  CType();
  static const CType dummy;
#endif
};

#endif // _MY_CTYPE_HH
