//
// $Id: string.hh,v 1.10 1999/09/02 10:18:38 voeckler Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    string.hh
//          Sat Aug  9 1997
//
// (c) 1997 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
//
// $Log: string.hh,v $
// Revision 1.10  1999/09/02 10:18:38  voeckler
// added an assert() macro to _remove() in favour of just the warning.
// It has been noted that this method will most likely die, if there
// are bugs elsewhere in some container classes containing strings.
//
// Revision 1.9  1999/08/27 21:50:40  voeckler
// replaced operator() with the c_str() method.
//
// Revision 1.8  1999/08/22 11:33:02  voeckler
// added c'tor interface for constructing a string of a repeated
// number of the same character.
//
// Revision 1.7  1999/08/05 21:23:09  voeckler
// size_t --> MyUInt32 changes, slightly more verbose coding,
// added some error mechanism to _remove(), disabled access to
// the lvalue array operator due to being too dangerous
//
// Revision 1.6  1998/07/02 09:39:35  voeckler
// changed string sentinel to singleton use, string internal pointer to
// rep class now set to 0 in dtor in order to yield SEGV for illegal use.
//
// Revision 1.5  1998/06/28 19:46:22  voeckler
// moved string representation to module of its own, now with
// the virtual interface complying to hashes, access to string
// representation now threaded through accessors, added very
// fast method for default ctor via sentinel.
//
// Revision 1.4  1998/06/26 17:44:36  voeckler
// last STL version
//
// Revision 1.3  1998/06/22 12:05:38  voeckler
// bool handling, mutable internal hash cache, inline handling, non-const
// assigment return values, etc.
//
// Revision 1.2  1997/08/18 11:50:11  voeckler
// cosmetical changes for complaining compilers, new ctor for constructing
// string from substrings of charfields, substitutions added (literal and
// regular expression (emacs like)), added upper(), lower() and trim().
//
// Revision 1.1  1997/08/11 10:10:25  voeckler
// Initial revision
//

#ifndef _STRING_HH
#define _STRING_HH

#if defined(__GNUC__) || defined(__GNUG__)
#pragma interface
#endif

#include <assert.h>
#include <stdio.h>
#include <sys/types.h> // size_t
#include <string.h>
#include <strings.h>   // strncasecmp

#include "typedefs.h"
#include "hash.hh"
#include "stringrep.hh"

#ifdef USE_REGSTR
class RegExp;
#endif

class String;



inline int 
compare( const String& a, const char* str, unsigned size, bool cs=true );
inline int
compare( const String& a, const String& b, unsigned size, bool cs=true );
int 
compare( const String& a, const char* str, bool cs=true );
int 
compare( const String& a, const String& b, bool cs=true );

class String : public Hashable {
  // simple string with refcount. All copies are shallow, except clone().
public:
  inline String()
    :string(StringSentinel::instance()) 
    { /* fast */ }
  inline String( unsigned size )
    :string( new StringRep(size) )
    { /* slow */ }  
  inline String( const char* s )
    :string( new StringRep(s) )
    { /* slow */ }
  inline String( size_t count, char prefill )
    :string( new StringRep(count,prefill) )
    { /* slow */ }

  inline String( const String& s ):string( s.string ) { string->increase(); }
  String( const char* str, unsigned size, unsigned start = 0 );
  virtual ~String() { _remove(); string = 0; }

  String& operator=( const String& s );
  String& operator=( const char* str );

  String& operator+=( const String& s );
  String& operator+=( const char* str );

  String operator+( const String& s );
  String operator+( const char* str );
  friend String operator+( const String& s1, const char* s2 );
  friend String operator+( const char* s1, const String s2 );
  // friend String operator+( const char* s1, const char* s2 );

  //
  // Accessors
  //
#if FEELING_FROLICSOME
  inline operator const char*() const { return string->content(); }
#endif
  inline const char* c_str( void ) const { return string->content(); }
  inline unsigned int length( void ) const { return string->length(); }
  inline unsigned int references( void ) const { return string->references(); }
  virtual MyUInt32 hash( void ) const { return string->hash(); }
  
  //
  // character-wise access via index
  //
  inline char operator[]( unsigned i ) const // righthandside
  {
    const char* temp = string->content();
    return ( i >= string->length() ) ? default_char : (char) temp[i];
  }

#if 0
  // extremely dangerous! do not use unless you know how String work!
  inline char& operator[]( unsigned i )      // lefthandside
    // never ever let final NUL be overwritten, or StringSentinel breaks
  { 
    const char* temp = string->content();
    return ( i >= string->length() ) ? default_char : *((char*)(temp + i)); 
  }
#endif

  //
  // searching for something; -1 := no such something
  //
  int index( char ch, unsigned start = 0 ) const;
  int index( const char* s, unsigned start = 0 ) const;
  int index( const String& s, unsigned start = 0 ) const;
  int rindex( char ch ) const;
  int rindex( char ch, unsigned start ) const;

  //
  // extract a string from the current one
  //
  inline String clone( void ) const { return String( string->content() ); }
  String substring( unsigned start ) const;
  String substring( unsigned start, unsigned size ) const;
  friend String substring( const char* s, unsigned start, unsigned size );

  //
  // replace a string with a string to yield a new string (smurfs?)
  //
  String substitute( const String from, const String to, bool global,
		     unsigned start = 0 );
#ifdef USE_REGSTR
  String substitute( RegExp& from, const String to, bool global,
		     unsigned start = 0 );
  // purpose: do a sed like substitution, allow variable delimiters
  // paramtr: from (IN): regular expression, may contain up to 9 () pairs
  //          to (IN): replacement, may contain \1..\9 like in emacs
  //          global (IN): true:=replace every occurence, false:=only first
  //          start (IN): start position
  // returns: new string with substitutions
#endif // USE_REGSTR

  //
  // misc. operations
  //
  String upper( void ) const;
  // purpose: convert to uppercase characters, see toupper()
  // returns: new string consisting of uppercase characters.
  String lower( void ) const;
  // purpose: convert to lowercase characters, see tolower()
  // returns: new string consisting of lowercase characters.
  String trim( void ) const;
  // purpose: trim isspace() characters from front and rear.
  // returns: new string which may be identical to this one, or empty.
  String trim( const char* lws ) const;
  // purpose: trim all characters in lws from front and rear.
  // paramtr: lws (IN): set of characters which are trimmable.
  // returns: new string which may be identical to this one, or empty.
  String trim( const String& lws ) const;
  // purpose: trim all characters in lws from front and rear.
  // paramtr: lws (IN): set of characters which are trimmable.
  // returns: new string which may be identical to this one, or empty.

  //
  // comparison operators
  //
  inline int operator==( const String& s ) const 
  { return compare( *this, s )==0; }
  inline int operator==( const char* s ) const
  { return compare( *this, s )==0; }
  inline int operator!=( const String& s ) const
  { return compare( *this, s )!=0; }
  inline int operator!=( const char* s ) const
  { return compare( *this, s )!=0; }

  inline int operator<=( const String& s ) const 
  { return compare( *this, s )<=0; }
  inline int operator<=( const char* s ) const
  { return compare( *this, s )<=0; }
  inline int operator<( const String& s ) const 
  { return compare( *this, s )<0; }
  inline int operator<( const char* s ) const
  { return compare( *this, s )<0; }
      
  inline int operator>=( const String& s ) const 
  { return compare( *this, s )>=0; }
  inline int operator>=( const char* s ) const
  { return compare( *this, s )>=0; }
  inline int operator>( const String& s ) const 
  { return compare( *this, s )>0; }
  inline int operator>( const char* s ) const
  { return compare( *this, s )>0; }

protected:
  inline String( StringBaseRep* sr ):string(sr) { }
  inline StringBaseRep* internal( void ) const { return string; }
  inline void _remove( void ) 
  { 
#ifndef JUST_WARN
    assert(string != 0);
#else
    if ( string == 0 ) 
      fprintf( stderr, "String::_remove: whoa there (%p)!\n", this );
    else 
#endif // JUST_WARN
      if ( string->decrease() == 0 ) {
	delete string; 
	string = 0;
      }
  }

  // statics
  static char default_char;

private:
  StringBaseRep* string;
};

// comparison functions, don't need to be friends: cs==case-sensitive
extern "C" {
typedef int (*CompFunc)( const char* a, const char* b, size_t );
}

inline
int 
compare( const String& a, const char* str, unsigned size, bool cs )
{ CompFunc comp = cs ? strncmp : strncasecmp;

  if ( str && *str ) return comp( a.c_str(), str, size );
  else return ( *(a.c_str()) ? 1 : 0 );
}

inline
int
compare( const String& a, const String& b, unsigned size, bool cs )
{ CompFunc comp = cs ? strncmp : strncasecmp;

  return comp( a.c_str(), b.c_str(), size );
}

#endif // _STRING_HH
