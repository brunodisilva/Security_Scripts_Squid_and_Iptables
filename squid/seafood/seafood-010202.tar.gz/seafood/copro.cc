//
// $Id: copro.cc,v 1.4 1999/09/03 12:53:51 voeckler Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    copro.cc
//          Tue Aug 26 1999
//
// (c) 1999 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: copro.cc,v $
// Revision 1.4  1999/09/03 12:53:51  voeckler
// fixed some nagging error of passing long* to char*...
//
// Revision 1.3  1999/08/31 08:46:15  voeckler
// new intermediary revision before trying new things. Major changes to
// the co process concept. Now includes the query() method in a template
// class due to many common issues. Further changes are expected in order
// to enhance the efficiency of the queries (saving queries rendered
// redundant by previously received answers within the same run).
//
// Revision 1.2  1999/08/27 20:45:37  voeckler
// made copro the base class for sibling co process helpers.
// Just the ctor and dtor remain to start and kill processes.
//
// Revision 1.1  1999/08/26 19:41:51  voeckler
// Initial revision
//
//
#if defined(__GNUC__) || defined(__GNUG__)
#pragma implementation
#endif

#include "copro.hh"
#include <assert.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <limits.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/socket.h>
#include <stdlib.h>

#ifndef AF_LOCAL
#ifndef AF_UNIX
#error "Sorry, I need either AF_LOCAL or AF_UNIX to be defined"
#endif // AF_UNIX
#define AF_LOCAL AF_UNIX
#endif

static const char* RCS_ID =
"$Id: copro.cc,v 1.4 1999/09/03 12:53:51 voeckler Exp $";

const short CoProcess::POLLREAD = ( POLLIN | POLLHUP | POLLERR );

CoProcess::CoProcess( size_t n, const char* prg, char* const argv[] )
  :number(n),nargs(0),child( new pid_t[n] ),descriptor( new int[n] )
{
  assert( child != 0 );
  assert( descriptor != 0 );
  assert( prg != 0 );
  assert( (programme = strdup(prg)) != 0 );

  for ( char* const* s = argv; s && *s; ++s ) ++nargs;
  if ( nargs == 0 ) {
    // insert program name as argv[0] according to Unix conventions
    arguments = new CharP[2];
    arguments[0] = strdup(prg);
  } else {
    arguments = new CharP[nargs+1];
    for ( size_t i=0; i<nargs; ++i ) 
      arguments[i] = strdup(argv[i]);
  }
  arguments[nargs] = 0;

  // become process group leader, so we can signal with a negative...
  if ( setpgid(0,0) == -1 ) {
    perror( "cannot become process group leader" );
    abort();
  }

  for ( size_t i=0; i<n; ++i ) {
    if ( startChild(i) == pid_t(-1) ) {
      fprintf( stderr, "while starting child %d: %s\n", i, strerror(errno) );
      if ( descriptor[i] != -1 ) close(descriptor[i]);
    }
  }
}

CoProcess::~CoProcess()
{
  for ( int i=nargs-1; i>=0; --i )
    free((void*) arguments[i]);
  delete[] arguments;
  free((void*) programme);

  // it is more efficient to first close all descriptors, and
  // then wait for all the children to exit.
  for ( size_t i=0; i<number; ++i )
    if ( descriptor[i] != -1 ) close(descriptor[i]);

  for ( size_t i=0; i<number; ++i ) {
    int status;
    if ( child[i] == 0 ) continue;
    else kill( child[i], SIGTERM );
    while ( waitpid( child[i], &status, 0 ) != child[i] ) ;
    child[i] = 0;
  }
}

pid_t
CoProcess::stopChild( int i )
  // purpose: close IPC socket, signal TERM and reap child
  // paramtr: i (IN): the logical child number [0..nargs[
  // returns: the PID of the terminated child, or 0, if the child was 
  //          already dead.
  // warning: may change descriptor[i] and child[i].
{
  pid_t pid = child[i];
  if ( descriptor[i] != -1 ) {
    close(descriptor[i]);
    descriptor[i] = -1;
  }

  if ( pid ) {
    int status;
    kill( pid, SIGTERM );
    while ( waitpid( pid, &status, 0 ) != pid ) ;
    child[i] = 0;
  }

  return pid;
}

pid_t
CoProcess::startChild( int i )
  // purpose: open IPC socket, start subprocess and connect FDs 
  // paramtr: i (IN): the logical child number [0..nargs[
  // returns: the PID of the started child, or -1 in case of error
  // warning: changes descriptor[i] and child[i].
{
  descriptor[i] = -1;
  child[i] = 0;

  int fds[2];
  if ( socketpair( AF_LOCAL, SOCK_STREAM, 0, fds ) == -1 ) return -1;

#ifndef PIPE_BUF
#define PIPE_BUF 512
#endif

  long size = fpathconf(fds[0],_PC_PIPE_BUF);
  if ( size < PIPE_BUF ) size = PIPE_BUF;
  // any errors setting the socket size are non-lethal
  setsockopt( fds[0], SOL_SOCKET, SO_RCVBUF, (char*) &size, sizeof(size) );
  setsockopt( fds[1], SOL_SOCKET, SO_RCVBUF, (char*) &size, sizeof(size) );
  setsockopt( fds[0], SOL_SOCKET, SO_SNDBUF, (char*) &size, sizeof(size) );
  setsockopt( fds[1], SOL_SOCKET, SO_SNDBUF, (char*) &size, sizeof(size) );
    
  // spawn child
  pid_t pid;
  if ( (pid = fork()) == -1 ) {
    return -1;
  } else if ( pid == 0 ) {
    // child
    close(fds[0]);
    if ( dup2( fds[1], STDIN_FILENO ) == -1 ) {
      perror( "dup2(STDIN)" );
      exit(1);
    }
    if ( dup2( fds[1], STDOUT_FILENO ) == -1 ) {
      perror( "dup2(STDOUT)" );
      exit(1);
    }
    execv( programme, arguments );
    // the two lines below should not be reached
    perror( "execv" );
    exit(1);
  } else {
    // parent
    close(fds[1]);
    descriptor[i] = fds[0];
    child[i] = pid;
  }
  return pid;
}

void
CoProcess::showPollFD( FILE* out, const PollFD* fds )
{
  bool temp = false;
#ifdef _REENTRANT
  flockfile(out);
#endif

  fputs( "# FD=(", out );
  for ( size_t j=0; j<number; ++j ) {
    if ( temp ) fputc(' ', out );
    fprintf( out, "%02x:%02x", j, fds[j].revents );
    temp = true;
  }
  fputs( ")\n", out );

#ifdef _REENTRANT
  funlockfile(out);
#endif
}
