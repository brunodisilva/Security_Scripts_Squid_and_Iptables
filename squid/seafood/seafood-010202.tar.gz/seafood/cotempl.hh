//
// $Id: cotempl.hh,v 1.2 2000/08/10 12:52:00 voeckler Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    cotempl.hh
//          Tue Aug 31 1999
//
// (c) 1999 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: cotempl.hh,v $
// Revision 1.2  2000/08/10 12:52:00  voeckler
// added progress report to parallel querying instances.
//
// Revision 1.1  1999/09/02 10:15:26  voeckler
// Initial revision
//
//
#ifndef _COTEMPL_HH
#define _COTEMPL_HH

#if defined(__GNUC__) || defined(__GNUG__)
#pragma interface
#endif

#include "global.hh"
#include "cache.hh"
#include "copro.hh"
#include <errno.h>
#include <time.h>

template <class Item>
class CoProTemplate : public CoProcess {
  // this class is derived of the base class CoProcess, so that the
  // virtually same operation can be coded using template, but the
  // actions independent of the template parameter are more efficiently
  // coded in a common base class.
public:
  typedef StringMap<Item,false> ItemMap;

  inline CoProTemplate( size_t n, const char* prg, char* const argv[],
			bool debugClass, short debugLevel,
			const BaseCache* cache )
    :CoProcess(n,prg,argv),debug(debugClass),level(debugLevel),base(cache)
    { }
  virtual ~CoProTemplate() { }

  virtual void addToMap( ItemMap& map, const String& key, Item& value ) = 0;
  // purpose: map[key] = value -- let the derivative tweak the key/value
  // paramtr: map (IO): map to insert into
  //          key (IN): key of item to add
  //          value (IN): value to add - must not be const
  // attent.: it is legal for the derivative class to add a different key

  virtual bool isKnown( const ItemMap& map, const String& key ) = 0;
  // purpose: map.exists(key) -- let the derivate check different keys
  // paramtr: map (IN): map to check for the key
  //          key (IN): key to check for
  // returns: true, if the key was found.
  // attent.: The key need *not* necessarily be in the map

  void query( const StringSet& v, ItemMap& map, MyUInt32 negativeTTL );
  // purpose: look up all items
  // paramtr: v (IN): set containing all item to make a look up.
  //          map (IO): result map, should be empty at call.
  //          negativeTTL (IN): for failed queries, TTL for empty items.

protected:
  ssize_t obtainResult( int j, String& key, Item& value ) const;
  // purpose: read a result, which is actually two read operations
  // paramtr: j (IN): index into internal FD table and for logging purposes
  //          key (IO): the key (query) will be returned by the helpers
  //          value (IO): the value (response) is the answer.
  // results: in analogy to the read() system call...
  // warning: if the result < 1, key and value are not defined...

  bool   debug;
  short  level;
  const BaseCache* base;

private:
  // render inaccessible
  CoProTemplate();
  CoProTemplate( const CoProTemplate& );
  CoProTemplate& operator=( const CoProTemplate& );
};

// -------------------------------------------------------------------

template <class Item>
ssize_t
CoProTemplate<Item>::obtainResult( int j, String& key, Item& value ) const
  // purpose: read a result, which is actually two read operations
  // paramtr: j (IN): index into internal FD table and for logging purposes
  //          key (IO): the key (query) will be returned by the helpers
  //          value (IO): the value (response) is the answer.
  // results: in analogy to the read() system call...
  // warning: if the result < 1, key and value are not defined...
{
  size_t size = 0;
  char buffer[16384];
  key = String();
  value.clear();

  // obtain size of answer first. The size has a fixed format "0xNNNN "
  memset( buffer, 0, sizeof(buffer) );
  ssize_t rsize = read( descriptor[j], buffer, 7 ); 
  if ( rsize <= 0 ) {
    return rsize;
  } else if ( rsize != 7 ) {
  size_err:
    fprintf( stderr, "# strange length (%d):", rsize );
    for ( int i=0; i<rsize; ++i ) fprintf( stderr, " %02x", buffer[i] );
    fputc( '\n', stderr );
    errno = ENOMSG;
    return -1;
  } else {
    size = strtoul( buffer, 0, 0 );
    if ( size == 0 ) goto size_err;
  }

  // read data
  rsize = readn( descriptor[j], buffer, Minimum(size,sizeof(buffer)-1) );
  if ( rsize == ssize_t(size) ) {
    if ( debug && level > 1 )
      fprintf( stderr, "<%02x< %s", j, buffer );
    char* s = strchr( buffer, ' ' );
    if ( s != 0 ) {
      *s++ = '\0';
      value = Item(s);
      key = String(buffer);
    } else {
      fputs( "# invalid input format\n", stderr );
    }
  } else {
    fprintf( stderr, "# reading %02x returned %d\n", j, rsize );
  }
  return rsize;
}

template <class Item>
void
CoProTemplate<Item>::query( const StringSet& v, 
			    ItemMap& map, 
			    MyUInt32 negativeTTL )
  // purpose: look up all items
  // paramtr: v (IN): set containing all item to make a look up.
  //          map (IO): result map, should be empty at call.
  //          negativeTTL (IN): for failed queries, TTL for empty items.
{
  size_t answers = 0;
  map.clear();

  // create struct pollfd handles
  PollFD* fds = new PollFD[number];
  memset( fds, 0, sizeof(PollFD) * number );
  for ( size_t i=0; i<number; ++i ) {
    fds[i].fd = descriptor[i];
    fds[i].events = POLLIN | POLLOUT;
  }

  // create some statistical input, allow for 2 messages total, one
  // message in the queue and one message actually being worked on.
  size_t* input = new size_t[number];
  size_t* output = new size_t[number];
  memset( input, 0, sizeof(size_t) * number );
  memset( output, 0, sizeof(size_t) * number );

  // start loop
  StringSet::const_iterator i = v.begin();
  bool cleanup = true;
  int countdown = 6;
  time_t this_time, last_time, start_time = time(&last_time);
  while ( answers < v.size() ) {
    // remove all writable flags, if there are no new queries.
    if ( cleanup && i == v.end() ) {
      if ( debug && level )
	fputs( "# done writing to helpers\n", stderr );
      cleanup = false;
      for ( size_t k=0; k<number; ++k ) fds[k].events &= ~POLLOUT;
    }

    errno = 0;
    int result = poll( fds, number, 10000 );
    if ( debug && level )
      fprintf( stderr, "# result=%u, answers=%u, unknown=%u, poll()=%d, errno=%d\n",
	       map.size(), answers, v.size(), result, errno );

    // some more debug output for the impatient...
    if ( globals.progressReports &&
	 difftime( time(&this_time), last_time ) > globals.progressReports ) {
      last_time = this_time;
      char when[32];
      if ( answers ) {
	int eta = (int) 
	  (difftime(last_time,start_time) * (v.size()/double(answers) - 1.0));
	sprintf( when, "%d:%02d:%02d", eta/3600, (eta%3600)/60, eta%60 );
      } else {
	strcpy( when, "unknown" );
      }
      fprintf( stderr, "# lookup %.1f%% done, ETA %s\n",
	       (100.0 * answers) / v.size(), when );
    }

    if ( result == -1 ) {
      // poll() error
      if ( errno == EINTR ) continue;
      else perror("poll");
    } else if ( result== 0 ) {
      // poll() timeout
      --countdown;
      if ( countdown == 0 ) break;
      else fprintf( stderr, "# countdown T-%d: %u answers missing\n", 
		    countdown*10, v.size() - answers );
    } else {
      // poll() regular result
      countdown = 6; // reset countdown after successful poll()

      if ( debug && level > 2 ) 
	showPollFD( stderr, fds );

      for ( size_t j=0; j<number; ++j ) {
	// check, if we can write something
	if ( i != v.end() && ( fds[j].revents & POLLOUT ) ) {
	  ++output[j];
	  char buffer[128];
	  sprintf( buffer, "%s\n", (*i).c_str() );
	  if ( debug && level > 1 )
	    fprintf( stderr, ">%02x> %s", j, buffer );
	  writen( descriptor[j], buffer, strlen(buffer) );
	  ++i;

	  // save some lookups, if there are intermediate results
	  // which already answer an upcoming query
	  while ( i != v.end() && isKnown(map,*i) ) {
	    ((BaseCache*) base)->incr(BaseCache::C_LATE);
	    if ( debug ) fputs( "# sneak *match* saved a lookup\n", stderr );
	    ++i;
	    ++answers;
	  }
#if 0
#define BUFFERED_RQ 4
	  if ( output[j]-input[j] > BUFFERED_RQ )
#endif
	    fds[j].events &= ~POLLOUT;
	}
	// check, if we should read something
	if ( (fds[j].revents & POLLREAD) ) {
	  ++input[j];
	  String key;
	  Item value;
	  switch ( obtainResult( j, key, value ) ) {
	  case -1: // error
	    fprintf( stderr, "!%02x! error: %s\n", j, strerror(errno) );
	    break;
	  case 0: // EOF
	    fds[j].events = 0;
	    fprintf( stderr, "!%02x! child closed, trying to restart\n", j );
	    if ( restartChild(j) == pid_t(-1) ) {
	      fprintf( stderr, "!%02x! unable to restart child: %s\n",
		       j, strerror(errno) );
	    } else {
	      fds[j].fd = descriptor[j];
	      fds[j].events = POLLIN;
	      if ( i != v.end() ) fds[j].events |= POLLOUT;
	    }
	    break;
	  default: // regular result
	    ++answers;
	    if ( key.length() ) addToMap( map, key, value );
	    break;
	  }
	  if ( i != v.end() )
#if 0
	    if ( output[j]-input[j] <= BUFFERED_RQ )
#endif
	      fds[j].events |= POLLOUT;
	}
      }
    }
  }
  if ( ! countdown ) fputs( "# warning: countdown expired.\n", stderr );
  delete[] fds;
  delete[] input;

  if ( debug ) {       
    // show some usage statistics, just a bar graph for each co processor.
    size_t max = 0;
    for ( size_t i=0; i<number; ++i ) 
      if ( max < output[i] ) max = output[i];
    int intlog = (int) ceil(log(max) / M_LN10 );
    for ( size_t i=0; i<number; ++i ) {
      fprintf( stderr, "# %02x %*u: ", i, intlog, output[i] );
      for ( size_t j=0; j < (output[i]<<6)/max; ++j ) fputc( '#', stderr );
      fputc('\n', stderr );
    }
  }
  delete[] output;

  if ( answers < v.size() ) {
    // we missed out on some answers, set them to be negative lookups
    time_t ttl = time(0) + negativeTTL;
    for ( i = v.begin(); i != v.end(); ++i )
      if ( ! isKnown(map,*i) ) {
	Item j;
	j.expires = ttl;
	addToMap( map, *i, j );
	fprintf( stderr, "# missing key %s, setting to %s\n",
		 (*i).c_str(), j.toString().c_str() );
      }
  }
}

#endif // _COTEMPL_HH
