//
// $Id: typedefs.h,v 1.1 1999/08/05 21:27:42 voeckler Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    typedefs.hh
//          Thu Jul 22 1999
//
// (c) 1999 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: typedefs.h,v $
// Revision 1.1  1999/08/05 21:27:42  voeckler
// Initial revision
//
//
#ifndef _MY_TYPEDEFS_HH
#define _MY_TYPEDEFS_HH

#if defined(__GNUC__) || defined(__GNUG__)
#pragma interface
#else
#ifndef HAS_BOOL
# define HAS_BOOL
typedef int bool;
# define false 0
# define true  1
#endif // BOOL
#endif // GCC

#if defined(CRAY) || defined(_CRAY)
// CRAY environment (46/64 bit): There is no 16 Bit type on Crays !!!

typedef   signed char  MySInt08;
typedef unsigned char  MyUInt08;
typedef   signed short MySInt32;
typedef unsigned short MyUInt32;
typedef   signed long  MySInt64;
typedef unsigned long  MyUInt64;

// numerical constants
#define C_S08(c) c
#define C_U08(c) c
#define C_S32(c) c ## h
#define C_U32(c) c ## hu
#define C_S64(c) c ## l
#define C_U64(c) c ## lu

// string format macros with width
#define SF_wS08(width) "%" #width "c"
#define SF_wU08(width) "%" #width "c"
#define SF_wS32(width) "%" #width "hd"
#define SF_wU32(width) "%" #width "hu"
#define SF_wS64(width) "%" #width "ld"
#define SF_wU64(width) "%" #width "lu"

// simple string format
#define SF_S08 "%c"
#define SF_U08 "%c"
#define SF_S32 "%hd"
#define SF_U32 "%hu"
#define SF_S64 "%ld"
#define SF_U64 "%lu"

#elif LONGSIZE==64 || defined(_LP64) || _MIPS_SZLONG==64
// standard 64 Bit LP64 environment (e.g. Solaris 7, Irix 6.5)

typedef   signed  char MySInt08;
typedef unsigned  char MyUInt08;
typedef   signed short MySInt16;
typedef unsigned short MyUInt16;
typedef   signed   int MySInt32;
typedef unsigned   int MyUInt32;
typedef   signed  long MySInt64;
typedef unsigned  long MyUInt64;

// numerical constants
#define C_S08(c) c
#define C_U08(c) c
#define C_S16(c) c ## h
#define C_U16(c) c ## hu
#define C_S32(c) c 
#define C_U32(c) c ## u
#define C_S64(c) c ## l
#define C_U64(c) c ## lu

// string format macros with width
#define SF_wS08(width) "%" #width "c"
#define SF_wU08(width) "%" #width "c"
#define SF_wS16(width) "%" #width "hd"
#define SF_wU16(width) "%" #width "hu"
#define SF_wS32(width) "%" #width "d"
#define SF_wU32(width) "%" #width "u"
#define SF_wS64(width) "%" #width "ld"
#define SF_wU64(width) "%" #width "lu"

// simple string format
#define SF_S08 "%c"
#define SF_U08 "%c"
#define SF_S16 "%hd"
#define SF_U16 "%hu"
#define SF_S32 "%d"
#define SF_U32 "%u"
#define SF_S64 "%ld"
#define SF_U64 "%lu"

#else 
// standard 32 bit environment

typedef   signed  char MySInt08;
typedef unsigned  char MyUInt08;
typedef   signed short MySInt16;
typedef unsigned short MyUInt16;
typedef   signed  long MySInt32;
typedef unsigned  long MyUInt32;
typedef   signed  long long MySInt64;
typedef unsigned  long long MyUInt64;

// numerical constants
#define C_S08(c) c
#define C_U08(c) c
#define C_S16(c) c ## h
#define C_U16(c) c ## hu
#define C_S32(c) c ## l
#define C_U32(c) c ## lu
#define C_S64(c) c ## ll
#define C_U64(c) c ## llu

// string format macros with width
#define SF_wS08(width) "%" #width "c"
#define SF_wU08(width) "%" #width "c"
#define SF_wS16(width) "%" #width "hd"
#define SF_wU16(width) "%" #width "hu"
#define SF_wS32(width) "%" #width "ld"
#define SF_wU32(width) "%" #width "lu"
#define SF_wS64(width) "%" #width "lld"
#define SF_wU64(width) "%" #width "llu"

// simple string format
#define SF_S08 "%c"
#define SF_U08 "%c"
#define SF_S16 "%hd"
#define SF_U16 "%hu"
#define SF_S32 "%ld"
#define SF_U32 "%lu"
#define SF_S64 "%lld"
#define SF_U64 "%llu"

#endif // LONGSIZE



enum Flags {
  IS_TCP     = C_U32(0x8000000),
  IS_UDP     = C_U32(0x4000000),
  IS_NONE    = C_U32(0x2000000),
  IS_HIT     = C_U32(0x1000000),
  IS_MISS    = C_U32(0x0800000),
  IS_DIRECT  = C_U32(0x0400000),
  IS_PARENT  = C_U32(0x0200000),
  IS_PEER    = C_U32(0x0100000),

  IS_TIMEOUT = C_U32(0x0080000), // TIMEOUT_* hierarchy prefix

  IS_ALIAS   = C_U32(0x0010000)
};

#endif // _MY_TYPEDEFS_HH
