//
// $Id: logline.cc,v 1.3 2000/07/27 07:13:15 voeckler Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    logline.cc
//          Sun Jul 18 1999
//
// (c) 1998,99 Lehrgebiet Rechnernetze und Verteilte Systeme
//             Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: logline.cc,v $
// Revision 1.3  2000/07/27 07:13:15  voeckler
// added trie for file extensions (suffix).
//
// Revision 1.2  1999/08/27 20:49:56  voeckler
// fixed some signedness troubles.
//
// Revision 1.1  1999/08/05 21:15:59  voeckler
// Initial revision
//
//
#if defined(__GNUC__) || defined(__GNUG__)
#pragma implementation
#endif

#include <stdlib.h>
#include "logline.hh"
#include "ctype.hh"
#include "global.hh"

static const char* RCS_ID =
"$Id: logline.cc,v 1.3 2000/07/27 07:13:15 voeckler Exp $";

SymbolTrie32 LogLine::mtable;
SymbolTrie32 LogLine::htable;
SymbolTrie32 LogLine::stable;
LinkedListTrie  LogLine::mediatypes;
LinkedListTrie  LogLine::schemes;
LinkedListTrie* LogLine::subtypes = 0;
SymbolTrie128 LogLine::domains;
SymbolTrie128 LogLine::suffices;

int 
LogLine::parseMediaType( BaseInput* in )
  // purpose: obtain media type information
  // paramtr: in (IO): stream to read from
  // returns: number of characters read, may return 0 to signal an error.
  // warning: changes i'var _mediatype
{
  char temp[256], major[32], minor[128];
  in->skiplws();
  int count = in->get( temp, 256 );

  int j, i=0;
  while ( temp[i] && temp[i] != '/' && size_t(i) < sizeof(major)-1 ) {
    major[i] = TOLOWER(temp[i]);
    ++i;
  }

  // finalize string
  major[i++] = '\0';
  for ( j=0; size_t(i) < sizeof(temp)-1 && size_t(j) < sizeof(minor)-1; ) 
    if ( (minor[j++] = TOLOWER(temp[i++])) == 0 ) break;
  minor[j++] = '\0';

  // after finishing copying, run check (less cpu cache reloads)
  _mediasubtype = (_mediatype = mediatypes.find(major)) ? 
    subtypes[_mediatype & 0xFFFF].find(minor) : 
    C_U32(0);

#if 0
  fprintf( stderr, "> \"%s\" / \"%s\" --> " SF_U32 "/" SF_U32 "\n", 
	   major, minor, _mediatype, _mediasubtype );
#endif

  return count;
}

int
LogLine::parseMethod( BaseInput* in )
  // purpose: parse the 6th column of the squid input file, the HTTP method.
  // paramtr: in (IO): pointer to input stream to get chars from
  // returns: number of characters read
  // warning: changes instance variable _method, check for ERROR
{
  char temp[16];
  in->skiplws();
  int count = in->get( temp, 16 );

  if ( (_method = mtable.find(temp)) == 0 && globals.warnUnknownMethod )
    fprintf( stderr, "%lu: unknown method \"%s\"\n", in->lineno, temp );
  return count;
}

int
LogLine::parseHierarchy( BaseInput* in )
  // purpose: obtain hierarchy information and split into three parts
  // paramtr: in (IO): stream to read from
  // returns: number of characters read, may return 0 to signal an error.
  // warning: changes i'vars _hierarchy, _timeout and _hierhost,
  // warning: _hierhost will be empty, if no dash was found in string
{
  char* s;
  char temp[256];

  // read input
  int count = in->get( temp, sizeof(temp) );

  // extract hierarchy host
  if ( (s = strchr( temp, '/' )) != 0 ) {
    *s++ = '\0';
    strncpy( _hierhost, s, sizeof(_hierhost) );
  } else {
    *_hierhost = '\0';
  }
    
  // convert hierarchy tag
  if ( (_hierarchy = htable.find( temp )) == 0 && globals.warnUnknownHier )
    fprintf( stderr, "%lu: unknown hierarchy tag \"%s\"\n", in->lineno, temp );
  return count;
}

int
LogLine::parseStatus( BaseInput* in )
  // purpose: read status column and split into message and HTTP reply
  // paramtr: in (IO): pointer to input stream to read from
  // returns: number of characters read, may return 0 to signal an error.
  // warning: changes instance variables _status and _statuscode,
  // warning: _statuscode will be -1, if no dash was found in string
{
  char* s;
  char temp[128];

  int count = in->get( temp, sizeof(temp) );
  if ( (s = strchr( temp, '/' )) != 0 ) {
    *s++ = '\0';
    _statuscode = strtol(s,0,10);
  } else {
    _statuscode = -1;
  }

  // try to match the status code
  if ( (_status = stable.find( temp )) == 0 && globals.warnUnknownStatus )
    fprintf( stderr, "%lu: unknown status tag \"%s\"\n", in->lineno, temp );
  return count;
}

void 
LogLine::dump( FILE* out, int amount, const char* prefix )
  // purpose: dump contents of instance variables
  // paramtr: out (IO): stream to dump contents onto
  //          amount (IN): number of columns which were correctly parsed
  //          prefix (IN): prepend each new line with this message
  // returns: -
{
  char temp[64];

#ifdef _REENTRANT
  flockfile(out);
#endif

  if ( amount > 0 ) 
    fprintf( out, "%s timestamp=" SF_U32, prefix, _stamp );
  if ( amount > 1 )
    fprintf( out, ", duration=" SF_S32, _duration );
  if ( amount > 2 )
    fprintf( out, ", client=\"%s\"", _requester );

  if ( amount > 3 )
    fprintf( out, "\n%s status=\"%s/" SF_S32 "\"", 
	     prefix, stable.reverse(temp,sizeof(temp),_status & 0xFFFF), _statuscode );
  if ( amount > 4 )
    fprintf( out, ", size=" SF_U64, _size );

  if ( amount > 5 )
    fprintf( out, ", method=\"%s\"", 
	     mtable.reverse(temp,sizeof(temp),_method & 0xFFFF) );

  if ( amount > 6 )
    fprintf( out, "\n%s url=\"%s\"", prefix, _url );

  if ( amount > 7 )
    fprintf( out, "\n%s ident=\"%s\"", prefix, _ident );
  if ( amount > 8 )
    fprintf( out, ", hier=\"%s%s/%s\"", 
	     _timeout ? "TIMEOUT_" : "", 
	     htable.reverse(temp,sizeof(temp),_hierarchy & 0xFFFF),
	     _hierhost );
  if ( amount > 9 )
    fprintf( out, ", mime=\"%s\"", 
	     mediatypes.reverse(temp,sizeof(temp),_mediatype & 0xFFFF) );

  fputc( '\n', out );
#ifdef _REENTRANT
  funlockfile(out);
#endif
}
