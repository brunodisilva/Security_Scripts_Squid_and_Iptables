//
// $Id: dnsitem.hh,v 1.3 1999/09/01 22:03:50 voeckler Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    dnsitem.hh
//          Tue Aug 24 1999
//
// (c) 1999 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: dnsitem.hh,v $
// Revision 1.3  1999/09/01 22:03:50  voeckler
// added static address conversion methods, changed string
// conversion format from unsigned long to dotted quad.
//
// Revision 1.2  1999/08/27 20:51:32  voeckler
// removed dependency on io stream in favour of 'classic' approaches,
// now is a sibling of the base class BaseItem.
//
// Revision 1.1  1999/08/25 21:25:05  voeckler
// Initial revision
//
//
#ifndef _DNSITEM_HH
#define _DNSITEM_HH

#if defined(__GNUC__) || defined(__GNUG__)
#pragma interface
#endif

#include "typedefs.h"
#include "baseitem.hh"
#include "string.hh"

class DNSItem : public BaseItem {
public:
  inline DNSItem()
    :BaseItem(0,true),n_aliases(0),n_addresses(0)
    { }
  DNSItem( time_t expiry, struct hostent* h );
  DNSItem( const DNSItem& dns );
  DNSItem& operator=( const DNSItem& dns );
  bool operator==( const DNSItem& dns );
  bool operator!=( const DNSItem& dns );
  ~DNSItem();
  void clear();
  
  String toString( void ) const;
  DNSItem( const char* s );
  
  static String ntoa( MyUInt32 address );
  static MyUInt32 aton( const String& address );
  
  size_t    n_aliases;
  size_t    n_addresses;
  String*   aliases;
  MyUInt32* addresses;
  String    fqdn;
};

#endif // _DNSITEM_HH
