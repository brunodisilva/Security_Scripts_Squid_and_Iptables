//
// psymtab.cc
//

#include <assert.h>
#include <string.h>
#include "psymtab.hh"

static const char* RCS_ID =
"$Id$";

PrefixedSymbolTable::PrefixedItem::PrefixedItem( const char* s, bool here,
						 MyUInt32 multi )
  :direct(here)
{
  if ( here ) {
    // no symbol table, use this node directly
    assert( prefix = new char[ strlen(s)+1 ] );
    strcpy( (char*) prefix, s );
    dvalue = multi;
  } else {
    assert( (prefix = new char[ multi+1 ]) );
    strncpy( (char*) prefix, s, multi );
    *((char*) prefix+multi) = '\0';
  }
}
 
PrefixedSymbolTable::PrefixedItem::~PrefixedItem()
{
  delete[] prefix;
}



PrefixedSymbolTable::PrefixedSymbolTable( MyUInt32 plength )
  :prefixlength(plength),tokencounter(1)
{
  heads = new PrefixedItemPtr[ 'Z' - 'A' + 1 ];
  memset( heads, 0, sizeof(PrefixedItemPtr) * ( 'Z' - 'A' + 1 ) );
}

PrefixedSymbolTable::~PrefixedSymbolTable()
{
  for ( char ch=0; ch <= 'Z'-'A'; ch++ )
    if ( heads[ch] ) delete heads[ch];

  delete[] heads;
}

bool 
PrefixedSymbolTable::insert( const char* name, MyUInt32 value )
{
  // sanity check
  if ( name==0 || *name < 'A' || *name > 'Z' || prefixlength > strlen(name) )
    return false;

  char ch( *name - 'A' );
  if ( strlen(name) <= prefixlength ) {
    // direct node, use pvalue
    if ( heads[ch] ) return false; // direct values cannot be appended

    if ( value == 0 ) value = tokencounter++;
    else tokencounter++;
    heads[ch] = new PrefixedItem( name, true, value );
    return true;
  } else {
    // indirect node, go via symbol
    if ( heads[ch] == 0 ) {
      // initial element
      heads[ch] = new PrefixedItem( name, false, prefixlength );
    } else {
      // append to list, if correct prefix
      if ( strncmp( heads[ch]->prefix, name, prefixlength ) ) return false;
    }

    if ( value == 0 ) value = tokencounter++;
    else tokencounter++;
    return heads[ch]->symbol.insert( name + prefixlength, value );
  }
}
  
const char* 
PrefixedSymbolTable::reverse( MyUInt32 value )
  // returns: "<error>" for not found, pointer into symbol table otherwise
{
  value &= C_U32( 0xFFFF );
  for ( char ch=0; ch<='Z'-'A'; ch++ )
    if ( heads[ch] ) {
      const char* s = heads[ch]->symbol.reverse(value);
      if ( s != SymbolTable::error ) return s;
    }
  return SymbolTable::error;
}
