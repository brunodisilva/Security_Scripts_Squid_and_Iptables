#!/usr/bin/perl
require 5.003;
use strict;

use Socket;
#use Getopt::Std;
$main::DEBUG = 1;
#
# ---------------------------------------------------------- sub functions
#
sub getasbyhost ($) {
    # purpose: obtain AS number of route, if known to IRR
    my (undef,$result) = getorbyrt( shift );
    $result || '<n.a.>';
}

sub getdescrbyas ($) {
    # purpose: obtain complete info about AS by referencing with ASnr
    my ($asnum,$source,$descr) = getasbyor( shift );
    $descr->[0] || '';
}

sub incr (\@) {
    # purpose: increment the usual triple of the argument
    # paramtr: @counter: reference to a counter
    $_[0][0]++;
    $_[0][1] += $main::size;
    $_[0][2] += $main::duration;
}
#
# ---------------------------------------------------------- global vars
#
my @log;
my ($log_status_result,$log_status_code,$log_client,$log_hier);
my (@url,$url_scheme,$url_host,$url_tld);
my ($squid_internal_flag,$squid_internal_count);
my ($log_hier_method, $log_hier_host);
my $lineno = 0;

my $as_number;
my $tcp_hit_host_reqs;
my $tcp_hit_tld_reqs;
my $time_begin;
my $time_end;

my @hier;
my @hier_direct;
my @hier_parent;
my @hier_peer;
my @sum;
my @tcp;
my @tcp_hit;
my @tcp_miss_none;
my @tcp_miss;
my @udp;
my @udp_hit;
my @udp_miss;

my %hier_direct;
my %hier_direct_as;
my %hier_parent_host;
my %hier_parent_method;
my %hier_parent_status;
my %hier_peer_host;
my %hier_peer_method;
my %hier_peer_status;
my %method;
my %tcp_client;
my %tcp_hit_client;
my %tcp_hit_status;
my %tcp_hit_mime;
my %tcp_hit_scheme;
my %tcp_host;
my %tcp_mime;
my %tcp_miss_client;
my %tcp_miss_status;
my %tcp_miss_none_client;
my %tcp_miss_none_status;
my %tcp_scheme;
my %tcp_tld;
my %udp_client;
my %udp_hit_status;
my %udp_hit_client;
my %udp_miss_status;

#
# ---------------------------------------------------------- start of prg
#

#
# ---------------------------------------------------------- main loop
#
my $start = time;
while ( <> ) {
    # print some info about where we are within the file
    warn "# $lineno lines processed.\n"
	if ( (++$lineno & 4095) == 0 );

    # split one line into contents
    chomp;
    undef $squid_internal_flag;
    @log = split / +/;

    # if there is anything in $log_leftover, do complain.
    # Alternatively, the squid.conf:uri_whitespace was set to "allow"
    if ( @log != 10 ) {
	warn "$lineno: unable to parse line, skipping:\n$_\n";
	next;
    }

    # process 4th column
    ($log_status_result,$log_status_code) = split(/\//,$log[3]);
    if ( $log_status_code < 0 || $log_status_code > 600 ) {
	warn "$lineno: illegal HTTP code $log_status_code, skipping:\n $_\n";
	next;
    }

    # obtains scheme and hostname from URL, taken from calamaris-2.27
    ($url_scheme,$url_host) = (@url = split(/[\/\\]/o,$log[6]))[0,2];
    if ( @url <= 1 ) {
	$url_scheme = $url_host = $url_tld = '<error>';
    } else {
	# sometimes, CONNECT https: instances are strange...
	unless ( defined $url_host ) {
	    warn "# $lineno: strange URL, continuing:\n# \"$log[6]\"\n";
	    $url_host = $url_scheme;
	    $url_scheme = '<secure>';
	}

	# extract the pure hostname information
	$url_host =~ s#^.*@##o;
	$url_host =~ s#[:\?].*$##o;
	$url_host = lc($url_host);

	# squid internal objects
	$squid_internal_flag = ++$squid_internal_count 
	    if ( $url[3] =~ /^squid\-internal\-(static|dynamic)$/ );

	# more hosts translations
	if ( $url_host =~ /^(([0-9]{1,3}\.){3})[0-9]{1,3}$/o ) {
	    # dotted quad numerical ip address
	    $url_host = $1 . '*';
	    $url_tld  = '<dotted_quad>';
	} elsif ( $url_host =~ /^[0-9]+$/ ) {
	    # single number 32 bit sex site BSD resolver address
	    $url_host = '<numeric>';
	    $url_tld  = '<numeric_ip>';
	} elsif ( $url_host =~ /^(?:.*\.(?:[^\.]+\.)?)?([^\.]+\.([^\.]+))\.?$/o ) {
	    # regular symbolic host name - we only look at 2nd level domains!
	    $url_tld  = '*.' . $2;
	    $url_host = '*.' . $1;
	} elsif ( $url_host =~ /([!a-z0-9\.\-]|\.\.)/o ) {
	    # no dots or double dot
	    $url_host = $url_tld = $url_scheme = '<error>';
	} else {
	    # whatever is left over here
	    print STDERR "# $lineno: using URL host \"$url_host\"\n";
	    $url_tld = $url_host;
	}
    }

    # process 9th column
    ($log_hier_method,$log_hier_host) = (split /\//, $log[8])[0,1];
    
    $log[9] = '<unknown>'
	if ( $log[9] eq undef || $log[9] eq '-' );
    $log[9] = lc($log[9]);
    $log[9] = $url_host = $url_tld = $url_scheme = '<error>' 
	if ( $log_status_code >= 400 && $log_status_code < 600 );

    # time stamp processing
    $time_begin = $log[0] if $log[0] < $time_begin;
    $time_end = $log[0] if $log[0] > $time_end;

    # ---------- start of sums section
    ($main::duration,$main::size) = @log[1,4];

    # do some sums
    incr( @sum );
    incr( @{$method{$log[5]}} );

    if ( $log[5] eq 'ICP_QUERY' || $log_status_result =~ /^ICP/o ) {
	# UDP counts
	incr( @udp );
	incr( @{$udp_client{$log[2]}} );

	if ( $log_status_result =~ /^(?:IC|UD)P_HIT/o ) {
	    # UDP HIT
	    incr( @udp_hit );
	    incr( @{$udp_hit_client{$log[2]}} );
	    incr( @{$udp_hit_status{$log_status_result}} );
	} else {
	    # UDP MISS
	    incr( @udp_miss );
	    # incr( @{$udp_miss_client{$log[2]}} );
	    incr( @{$udp_miss_status{$log_status_result}} );
	}
    } else {
	# TCP counts
	incr( @tcp );
	incr( @{$tcp_client{$log[2]}} );
	incr( @{$tcp_host{$url_host}} );
	incr( @{$tcp_tld{$url_tld}} );
	incr( @{$tcp_scheme{$url_scheme}} );
	incr( @{$tcp_mime{$log[9]}} );
	
	if ( $log_status_result =~ /^TCP_\w*HIT/o ) {
	    # any TCP HIT
	    incr( @tcp_hit );
	    incr( @{$tcp_hit_status{$log_status_result}} );
	    incr( @{$tcp_hit_client{$log[2]}} );

	    # TCP HIT counter
	    $tcp_hit_host_reqs++;
	    $tcp_hit_tld_reqs++;
	    $tcp_hit_mime{$log[9]}++;
	    $tcp_hit_scheme{$url_scheme}++;
	} elsif ( $log_hier_method =~ /NONE|^\-$/ ||
		  substr($log_status_result,0,4) eq 'ERR_' ) {
	    # any kind of type NONE TCP MISS
	    incr( @tcp_miss_none );
	    incr( @{$tcp_miss_none_status{$log_status_result}} );
	    incr( @{$tcp_miss_none_client{$log[2]}} );
	} else {
	    # any other type of TCP MISS which is not NONE or ERR
	    incr( @tcp_miss );
	    incr( @{$tcp_miss_status{$log_status_result}} );
	    incr( @{$tcp_miss_client{$log[2]}} );
	}
	 
	if ( $log_hier_method !~ /NONE|^\-$/o ) {
	    # any kind of TCP with attached hierarchy code
	    incr( @hier );
	    if ( index($log_hier_method, 'DIRECT' ) >= 0 ||
 		 index($log_hier_method, 'SOURCE_FASTEST' ) >= 0 ) {
		# DIRECT traffic, the most costly traffic
		incr( @hier_direct );
		incr( @{$hier_direct{$log_hier_method}} );

		# prepare for AS extension
		# it is easier to do the AS lookups after parsing, so we
		# accumulate a little more information than strictly 
		# necessary here.
		incr( @{$hier_direct_as{$log_hier_host}} );
	    } elsif ( $log_hier_method =~ /CARP/o ||
		      $log_hier_method =~ /(?:CACHE_DIGEST|NEIGHBOR|PARENT|SIBLING)_\w*HIT/o ) {
		# PEER HIT
		incr( @hier_peer );
		incr( @{$hier_peer_method{$log_hier_method}} );
		incr( @{$hier_peer_host{$log_hier_host}} );
		incr( @{$hier_peer_status{$log_hier_host}{$log_hier_method}});

	    } elsif ( index($log_hier_method,'PARENT_MISS') >= 0 ||
 		      $log_hier_method =~ /(?:CLOSEST|DEFAULT|FIRST_UP|PASSTHROUGH|ROUNDROBIN|SINGLE)_PARENT/ ) {
		# any parent relationship beside the previous ones
		incr( @hier_parent );
		incr( @{$hier_parent_method{$log_hier_method}} );
		incr( @{$hier_parent_host{$log_hier_host}} );
		incr( @{$hier_parent_status{$log_hier_host}{$log_hier_method}} );
	    } else {
		warn "$lineno: unknown hierarchy tag, not counting: \"$log[8]\"\n";
	    }
	} # !NONE
    } # TCP
}
warn "# done processing.\n";

# performance evaluation
$start = (time - $start) || 1;
#
# ---------------------------------------------------------- output processing
#
print "# processing statistics\n";
print "duration : $start s\n";
print "log lines: $lineno\n";
printf("  valid  : %lu, size=%.1f MB, duration=%.1f days\n", 
       $sum[0], $sum[1] / 1048576.0, $sum[2] / 86400000.0 );
print "speed    : ", int($lineno / $start), " lps\n\n";
