#include <stdio.h>
#include "typedefs.h"
#include "ptrvec.hh"

struct Asdf {
  Asdf( int n = 0 ):x(n) { }
  int x;
};

typedef PointerVector<Asdf> IntPtrVec;

int
main( void )
{
  char ch = 'Z';
  IntPtrVec ipv;

  while ( ! feof(stdin) ) {
    int n;
    scanf( "%d\n", &n );
    fprintf( stderr, "# read %d from input\n", n );
    ipv.insert( ch--, new Asdf(n) );
  }

  for ( ch='A'; ch<='Z'; ch++ ) {
    Asdf* temp = ipv.at( MyUInt08(ch) );
    if ( temp ) printf( "%c --> %d\n", ch, temp->x );
  }
  return 0;
}
