//
// symtab.hh
//
#ifndef _SYMTAB_HH
#define _SYMTAB_HH

#if defined(__GNUC__) || defined(__GNUG__)
#pragma interface
#endif

#include "typedefs.h"

class SymbolTable {
public:
  SymbolTable();
  ~SymbolTable();

  bool insert( const char* name, MyUInt32 value = C_U32(0) );
  // purpose: insert a new piece into the symbol table
  // paramtr: name (IN): new name to insert into symtab
  //          value (IN): token value to use for default override
  // returns: true, if insertion was successful.

  MyUInt32 find( const char* name );
  // returns: 0 for not found, tokenvalue [1..tokencounter) otherwise
  //          The return value of 0 lets you count the errors, too.
  // warning: precondition is 'name' != NULL !!!

  const char* reverse( MyUInt32 value );
  // returns: "<error>" for not found, pointer into symbol table otherwise
  inline MyUInt32 size() const 
    { return tokencounter; }

  // what reverse returns for not found
  static const char* error;

protected:
  class SymbolItem {
  public:
    SymbolItem( const char* s, MyUInt32 v, SymbolItem* n = 0 );
    ~SymbolItem();
    
    SymbolItem* next;
    MyUInt32    value;
    const char* name;
  };
  
  typedef SymbolItem* SymbolItemPtr;
  
  MyUInt32     tokencounter;
  SymbolItem** heads;

private:
  // disallow copy ctor, assignments
  SymbolTable( const SymbolTable& );
  SymbolTable& operator=( const SymbolTable& );
};

#endif // _SYMTAB_HH
