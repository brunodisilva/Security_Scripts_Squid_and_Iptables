//
// psymtab.hh
//
#ifndef _PSYMTAB_HH
#define _PSYMTAB_HH

#if defined(__GNUC__) || defined(__GNUG__)
#pragma interface
#endif

#include "typedefs.h"
#include "symtab.hh"
#include <stdio.h>

class PrefixedSymbolTable {
public:
  PrefixedSymbolTable( MyUInt32 plength );
  ~PrefixedSymbolTable();

  bool insert( const char* name, MyUInt32 value = 0 );
  const char* reverse( MyUInt32 value );
  // returns: "<error>" for not found, pointer into symbol table otherwise

  inline MyUInt32 find( const char* name )
    // returns: 0 for not found, tokenvalue [1..tokencounter) otherwise
    //          The return value of 0 lets you count the errors, too.
    // warning: precondition is 'name' != NULL !!!
  {
    char ch( *name - 'A' );
    return (( heads[ch] &&
	      strncmp( name, heads[ch]->prefix, prefixlength ) == 0 ) ?
	    (heads[ch]->direct ? 
	     heads[ch]->dvalue : 
	     heads[ch]->symbol.find( name + prefixlength )) :
	    0);
  }
  inline MyUInt32 size() const 
    { return tokencounter; }

protected:
  class PrefixedItem {
  public:
    PrefixedItem( const char* s, bool here, MyUInt32 multi );
    ~PrefixedItem();

    bool         direct; // true: symbol table not used
    const char*  prefix;
    MyUInt32     dvalue; // token value for direct accesses
    SymbolTable  symbol; // table w/o prefixes
  };

  typedef PrefixedItem* PrefixedItemPtr;

  const MyUInt32 prefixlength;
  MyUInt32       tokencounter;
  PrefixedItem** heads;

private:
  // disallow default ctor, copy ctor, assignments
  PrefixedSymbolTable();
  PrefixedSymbolTable( const PrefixedSymbolTable& );
  PrefixedSymbolTable& operator=( const PrefixedSymbolTable& );
};

#endif // _PSYMTAB_HH
