//
// $Id: dnscopro.hh,v 1.1 1999/08/27 20:55:00 voeckler Exp voeckler $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    dnscopro.hh
//          Fri Aug 27 1999
//
// (c) 1999 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: dnscopro.hh,v $
// Revision 1.1  1999/08/27 20:55:00  voeckler
// Initial revision
//
//
#ifndef _DNSCOPRO_HH
#define _DNSCOPRO_HH

#if defined(__GNUC__) || defined(__GNUG__)
#pragma interface
#endif

#include "copro.hh"
#include "dnsitem.hh"

class dnsAdd {
  typedef StringMap<DNSItem,false> DNSItemMap;
  dnsAdd( DNSItemMap& map, const String& key, DNSItem& value )
    {
      map[key] = value; // always add what was asked for!
      if ( value.fqdn.length() && value.fqdn != key ) 
	map[value.fqdn] = value;
      for ( size_t k=0; k<value.n_aliases; ++k )
	if ( value.aliases[k] != key ) map[value.aliases[k]] = value;
      for ( size_t k=0; k<value.n_addresses; ++k ) {
	String ip( DNSItem::ntoa(value.addresses[k]) );
	if ( ip != key ) map[ip] = value;
      }
    } 
};

typedef CoProTemplate< DNSItem, dnsAdd > DNSCoProcess;

#endif // _DNSCOPRO_HH
