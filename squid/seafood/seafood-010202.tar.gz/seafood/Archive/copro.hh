//
// $Id: copro.hh,v 1.2 1999/08/27 20:45:37 voeckler Exp voeckler $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    copro.hh
//          Tue Aug 26 1999
//
// (c) 1999 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: copro.hh,v $
// Revision 1.2  1999/08/27 20:45:37  voeckler
// made copro the base class for sibling co process helpers.
// Just the ctor and dtor remain to start and kill processes.
//
// Revision 1.1  1999/08/26 19:41:51  voeckler
// Initial revision
//
//
#ifndef _COPRO_HH
#define _COPRO_HH

#if defined(__GNUC__) || defined(__GNUG__)
#pragma interface
#endif

#include <sys/types.h>
#include <errno.h>
#include <stdio.h>
#include <math.h>

#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>
#include <poll.h>

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "copro.hh"
#include "ctype.hh"
#include "string.hh"
#include "strmap.hh"
#include "rw.hh"

#ifndef HAS_HASHSET
#include <set>
#else
#include <hash_set>
#endif

class CoProcess {
  // spawn N co-processes PRG with the given ARGV, connect with their
  // stdin and stdout via a local stream socket (bi-directional connection)
  // and afterwards clean them up again, too.
  //
  // child classes are expected to implement meaningful methods using the
  // the co processes. Children should prefer poll() over select(), though
  // select() is more portable to strange platforms.
public:
  CoProcess( size_t n, const char* prg, char* const argv[] );
  ~CoProcess();

  pid_t startChild( int i );
  // purpose: open IPC socket, start subprocess and connect FDs 
  // paramtr: i (IN): the logical child number [0..nargs[
  // returns: the PID of the started child, or -1 in case of error
  // warning: changes descriptor[i] and child[i].

  pid_t stopChild( int i );
  // purpose: close IPC socket, signal TERM and reap child
  // paramtr: i (IN): the logical child number [0..nargs[
  // returns: the PID of the terminated child, or 0, if the child was 
  //          already dead.
  // warning: may change descriptor[i] and child[i].

  pid_t restartChild( int i )
    { stopChild(i); return startChild(i); }
  
protected:
  size_t number;
  size_t nargs;
  pid_t* child;
  int*   descriptor;
  char*  programme;
  char** arguments;

  typedef char* CharP;
  typedef struct pollfd PollFD;

  static const short POLLREAD;
  void showPollFD( FILE* out, const PollFD* fds );
  inline const size_t Minimum( const size_t a, const size_t b ) const
    {
#ifdef __GNUG__
      return a <? b;
#else
      return a < b ? a : b;
#endif
    }

private:
  // render inaccessible
  CoProcess();
  CoProcess( const CoProcess& );
  CoProcess& operator=( const CoProcess& );
};

// -------------------------------------------------------------------

template <class Item>
class defaultAdd {
  typedef StringMap<Item,false> ItemMap;
  defaultAdd( ItemMap& map, const String& key, Item& value )
    { map[key] = value; }
};

template <class Item, class addToMap = defaultAdd<Item> >
class CoProTemplate : public CoProcess {
  // this class is derived of the base class CoProcess, so that the
  // virtually same operation can be coded using template, but the
  // actions independent of the template parameter are more efficiently
  // coded in a common base class.
public:
  typedef StringMap<Item,false> ItemMap;

#ifndef HAS_HASHSET
  typedef std::less<String> ltstr;
  typedef std::set< String, ltstr > StringSet;
#else
  struct strhash {
    inline MyUInt32 operator()(const String& s) const
    { return s.hash(); }
  };
  typedef std::hash_set< String, strhash, std::equal_to<String> > StringSet;
#endif

  inline CoProTemplate( size_t n, const char* prg, char* const argv[] )
    :CoProcess(n,prg,argv) 
    { }
  inline ~CoProTemplate()
    { }

  void query( const StringSet& v, ItemMap& map, MyUInt32 negativeTTL );

protected:
  ssize_t obtainResult( int j, String& key, Item& value ) const;

private:
  // render inaccessible
  CoProTemplate();
  CoProTemplate( const CoProTemplate& );
  CoProTemplate& operator=( const CoProTemplate& );
};

// -------------------------------------------------------------------

template <class Item, class addToMap>
ssize_t
CoProTemplate<Item,addToMap>::obtainResult( int j, 
					    String& key, 
					    Item& value ) const
{
  size_t size = 0;
  char buffer[16384];
  key = String();
  value.clear();

  // obtain size of answer first. The size has a fixed format "0xNNNN "
  memset( buffer, 0, sizeof(buffer) );
  ssize_t rsize = read( descriptor[j], buffer, 7 ); 
  if ( rsize <= 0 ) {
    return rsize;
  } else if ( rsize != 7 ) {
  size_err:
    fprintf( stderr, "# strange length (%d):", rsize );
    for ( int i=0; i<rsize; ++i ) fprintf( stderr, " %02x", buffer[i] );
    fputc( '\n', stderr );
    errno = ENOMSG;
    return -1;
  } else {
    size = strtoul( buffer, 0, 0 );
    if ( size == 0 ) goto size_err;
  }

  // read data
  rsize = readn( descriptor[j], buffer, Minimum(size,sizeof(buffer)-1) );
  if ( rsize == ssize_t(size) ) {
    fprintf( stderr, "<%02x< %s", j, buffer );
    char* s = strchr( buffer, ' ' );
    if ( s != 0 ) {
      *s++ = '\0';
      value = Item(s);
      key = String(buffer);
    } else {
      fputs( "# invalid input format\n", stderr );
    }
  } else {
    fprintf( stderr, "# reading %02x returned %d\n", j, rsize );
  }
  return rsize;
}

template <class Item, class addToMap>
void
CoProTemplate<Item,addToMap>::query( const StringSet& v, 
				     ItemMap& map, 
				     MyUInt32 negativeTTL )
{
  size_t answers = 0;
  map.clear();

  // create struct pollfd handles
  PollFD* fds = new PollFD[number];
  memset( fds, 0, sizeof(PollFD) * number );
  for ( size_t i=0; i<number; ++i ) {
    fds[i].fd = descriptor[i];
    fds[i].events = POLLIN | POLLOUT;
  }

  // create some statistical input, allow for 2 messages total, one
  // message in the queue and one message actually being worked on.
  size_t* input = new size_t[number];
  size_t* output = new size_t[number];
  memset( input, 0, sizeof(size_t) * number );
  memset( output, 0, sizeof(size_t) * number );

  // start loop
  StringSet::const_iterator i = v.begin();
  bool cleanup = true;
  int countdown = 9;
  while ( answers < v.size() ) {
    // remove all writable flags, if there are no new queries.
    if ( cleanup && i == v.end() ) {
      fputs( "# done writing\n", stderr );
      cleanup = false;
      for ( size_t i=0; i<number; ++i ) fds[i].events &= ~POLLOUT;
    }

    int result = poll( fds, number, 10000 );
    fprintf( stderr, "# map=%u, a=%u, v=%u, poll()=%d, errno=%d\n",
	     map.size(), answers, v.size(), result, errno );
    if ( result == -1 ) {
      if ( errno == EINTR ) continue;
      else perror("poll");
    } else if ( result== 0 ) {
      fprintf( stderr, "# %u queries to go\n", v.size() - answers );
      if ( --countdown == 0 ) break;
    } else {
      countdown = 9; // reset countdown after successful poll()
#if 0
      showPollFD( fds, number );
#endif

      for ( size_t j=0; j<number; ++j ) {
	// check, if we can write something
	if ( i != v.end() && ( fds[j].revents & POLLOUT ) ) {
	  ++output[j];
	  char buffer[8192];
	  sprintf( buffer, "%s\n", (*i).c_str() );
	  fprintf( stderr, ">%02x> %s", j, buffer );
	  writen( descriptor[j], buffer, strlen(buffer) );
	  ++i;
#if 0
#define BUFFERED_RQ 4
	  if ( output[j]-input[j] > BUFFERED_RQ )
#endif
	    fds[j].events &= ~POLLOUT;
	}
	// check, if we should read something
	if ( (fds[j].revents & POLLREAD) ) {
	  ++input[j];
	  String key;
	  Item value;
	  switch ( obtainResult( j, key, value ) ) {
	  case -1: // error
	    fprintf( stderr, "!%02x! error: %s\n", j, strerror(errno) );
	    break;
	  case 0: // EOF
	    fds[j].events = 0;
	    fprintf( stderr, "!%02x! child closed, trying to restart\n", j );
	    if ( restartChild(j) == pid_t(-1) ) {
	      fprintf( stderr, "!%02x! unable to restart child: %s\n",
		       j, strerror(errno) );
	    } else {
	      fds[j].fd = descriptor[j];
	      fds[j].events = POLLIN;
	      if ( i != v.end() ) fds[j].events |= POLLOUT;
	    }
	    break;
	  default: // regular result
	    ++answers;
	    if ( key.length() ) 
	      addToMap( map, key, value );
	    break;
	  }
	  if ( i != v.end() )
#if 0
	    if ( output[j]-input[j] <= BUFFERED_RQ )
#endif
	      fds[j].events |= POLLOUT;
	}
      }
    }
  }
  if ( ! countdown ) fputs( "# warning: countdown has expired.\n", stderr );
  delete[] fds;
  delete[] input;

  size_t max = 0;
  for ( size_t i=0; i<number; ++i ) 
    if ( max < output[i] ) max = output[i];
  int intlog = (int) ceil(log(max) / M_LN10 );
  for ( size_t i=0; i<number; ++i ) {
    fprintf( stderr, "# %02x %*u: ", i, intlog, output[i] );
    for ( size_t j=0; j < (65*output[i])/max; ++j ) fputc( '#', stderr );
    fputc('\n', stderr );
  }
  delete[] output;

  if ( answers < v.size() ) {
    // we missed out on some answers, set them to be negative lookups
    time_t ttl = time(0) + negativeTTL;
    for ( i = v.begin(); i != v.end(); ++i )
      if ( ! map.exists(*i) ) {
	Item v;
	v.expires = ttl;
	map[*i] = v;
      }
  }
}

#endif // _COPRO_HH
