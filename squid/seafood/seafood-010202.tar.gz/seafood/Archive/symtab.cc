//
// symtab.cc
//

#include <assert.h>
#include <string.h>
#include "symtab.hh"

static const char* RCS_ID =
"$Id$";

const char* SymbolTable::error = "<error>";

SymbolTable::SymbolItem::SymbolItem( const char* s, 
				     MyUInt32 v, 
				     SymbolItem* n )
  :next(n),value(v)
{
  assert( (name = new char[strlen(s)+1]) );
  strcpy( (char*) name, s );
}

SymbolTable::SymbolItem::~SymbolItem()
{ 
  delete next;
  delete[] name; 
}



SymbolTable::SymbolTable()
  :tokencounter(1)
{
  heads = new SymbolItemPtr[ 'Z' - 'A' + 1 ];
  memset( heads, 0, sizeof(SymbolItemPtr) * ( 'Z' - 'A' + 1 ) );
}

SymbolTable::~SymbolTable()
{
  for ( char ch=0; ch <= 'Z'-'A'; ch++ )
    if ( heads[ch] ) delete heads[ch];
  delete[] heads;
}

bool
SymbolTable::insert( const char* name, MyUInt32 value )
  // purpose: insert a new piece into the symbol table
  // paramtr: name (IN): new name to insert into symtab
  //          value (IN): token value to use for default override
  // returns: true, if insertion was successful.
{
  // sanity check
  if ( name==0 || *name < 'A' || *name > 'Z' ) return false;
  if ( value == C_U32(0) ) value = tokencounter++;
  else tokencounter++;

  char ch( *name - 'A' );
  if ( heads[ch] == 0 ) {
    // initial element to list
    heads[ch] = new SymbolItem(name,value);
  } else {
    // append to list
    SymbolItemPtr temp = heads[ch];
    while ( temp->next ) {
      temp = temp->next;
    }
    temp->next = new SymbolItem(name,value);
  }
  return true;
}

MyUInt32
SymbolTable::find( const char* name )
  // returns: 0 for not found, tokenvalue [1..tokencounter) otherwise
  //          The return value of 0 lets you count the errors, too.
  // warning: precondition is 'name' != NULL !!!
{
  char ch( *name - 'A' );
  if ( ch >= 0 && ch <= 'Z'-'A' && heads[ch] ) {
    // check the rest
    SymbolItemPtr temp = heads[ch];
    while ( temp ) {
      if ( strcmp( temp->name, name ) == 0 ) return temp->value;
      temp = temp->next;
    }
  }
  return 0;
}

const char* 
SymbolTable::reverse( MyUInt32 value )
  // returns: "<error>" for not found, pointer into symbol table otherwise
{
  for ( char ch='A'-'A'; ch<='Z'-'A'; ch++ ) {
    if ( heads[ch] ) {
      SymbolItemPtr temp = heads[ch];
      while ( temp ) {
	if ( temp->value == value ) return temp->name;
	temp = temp->next;
      }
    }
  }
  return error;
}
