#include <ctype.h>
#include <sys/types.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>

int
main( int argc, char* argv[] ) 
{
  struct in_addr ip;
  struct hostent* h;
  int i;

  for ( i=1; i<argc; ++i ) {
    if ( isdigit(argv[i][0]) ) {
      if ( (ip.s_addr=inet_addr(argv[i])) == INADDR_NONE ) {
	printf( "illegal argument %s\n", argv[i] );
	continue;
      } else
	h = gethostbyaddr( &ip, sizeof(ip), AF_INET );
    } else {
      h = gethostbyname( argv[i] );
    }

    if ( h && strstr( h->h_name, "in-addr.arpa" ) == 0 ) {
      for ( char** p=h->h_addr_list; *p; ++p ) {
	memcpy( &ip.s_addr, *p, sizeof(ip) );
	printf( "%-15s %s", inet_ntoa(ip), h->h_name );
	for ( char** o=h->h_aliases; *o; ++o )
	  printf( " %s", *o );
	fputc( '\n', stdout );
      }
    }
  }

  return 0;
}
