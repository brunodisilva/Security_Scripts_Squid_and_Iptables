//
// token.hh
//
#ifndef _TOKEN_HH
#define _TOKEN_HH

#if defined(__GNUC__) || defined(__GNUG__)
#pragma interface
#endif

enum {
  TF_TCP  = 0x01u, 
  TF_UDP  = 0x02u,
  TF_NONE = 0x04u,

  TF_DIRECT = 0x08u,
  TF_PARENT = 0x10u,
  TF_PEER   = 0x20u,

  TF_HIT  = 0x40u,
  TF_MISS = 0x80u,

  TF_ALIAS = 0x100u
};

struct Token {
  inline Token( unsigned tc = 0, unsigned tv = 0, unsigned tf = 0 )
    :tvalue(tv),tclass(tc),tflags(tf)
  { }

  inline bool operator==( const Token& t ) const
  { return (tvalue == t.tvalue && tclass == t.tclass ); }
  inline bool operator!=( const Token& t ) const
  { return (tvalue != t.tvalue || tclass != t.tclass ); }

  unsigned tvalue:16;
  unsigned tclass:7;
  unsigned tflags:9;
};

#endif // _TOKEN_HH
