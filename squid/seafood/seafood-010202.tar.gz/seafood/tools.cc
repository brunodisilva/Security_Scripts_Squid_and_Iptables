//
// $Id: tools.cc,v 1.4 2001/02/02 08:51:09 voeckler Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    tools.cc
//          Thu Aug 05 1999
//
// (c) 1999 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: tools.cc,v $
// Revision 1.4  2001/02/02 08:51:09  voeckler
// Fixed char* to const char* complaints by Sun CC.
//
// Revision 1.3  1999/09/01 21:59:57  voeckler
// adaption to the new strmap iterator.
//
// Revision 1.2  1999/08/22 11:52:56  voeckler
// added functionality to display duration as an alternative
// to data rates.
//
// Revision 1.1  1999/08/05 21:27:42  voeckler
// Initial revision
//
//

#if defined(__GNUC__) || defined(__GNUG__)
#pragma implementation
#endif

#include <sys/types.h>
#include <sys/time.h>
#include <assert.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "ctype.hh"
#include "tools.hh"

static const char* RCS_ID =
"$Id: tools.cc,v 1.4 2001/02/02 08:51:09 voeckler Exp $";

const char* stdunit = "B";

static
void
mySwap( size_t* result, int a, int b )
{
  size_t temp = result[a];
  result[a] = result[b];
  result[b] = temp;
}

static
void
qsortByReqs( const Counter* array, size_t* result, int left, int right )
{
  if ( left >= right ) return;
  mySwap( result, left, (left+right) / 2 );
  int last = left;
  for ( int i=left+1; i<=right; i++ )
    if ( array[result[left]].reqs() < array[result[i]].reqs() )
      mySwap( result, ++last, i );
  mySwap( result, left, last );
  qsortByReqs( array, result, left, last-1 );
  qsortByReqs( array, result, last+1, right );
}

size_t* 
indexByReqs( const Counter* array, size_t size )
  // purpose: construct an array of hashvalues for the map in sorted order.
  // paramtr: array (IN): array of counters to generate the index for
  //          size (IN): number of elements in the array.
  // returns: map-sized array with indices, sorted by largest first.
  // warning: you have to delete[] the result yourself!
  // warning: the index is only valid for the array it was generated for.
{
  size_t* result = new size_t[ size ];
  for ( size_t n=0; n<size; n++ ) result[n] = n;
  qsortByReqs( array, result, 0, size-1 );
  return result;
}

static
void
qsortByReqs( const CountMap& array, size_t* result, int left, int right )
{
  if ( left >= right ) return;
  mySwap( result, left, (left+right) / 2 );
  int last = left;
  for ( int i=left+1; i<=right; i++ )
    if ( array[result[left]].reqs() < array[result[i]].reqs() )
      mySwap( result, ++last, i );
  mySwap( result, left, last );
  qsortByReqs( array, result, left, last-1 );
  qsortByReqs( array, result, last+1, right );
}

size_t*
indexByReqs( const CountMap& map )
  // purpose: construct an array of hashvalues for the map in sorted order.
  // paramtr: map (IN): map to generate the index for
  // returns: map-sized array with indices, sorted by largest first.
  // warning: you have to delete[] the result yourself!
  // warning: the index is only valid for the map it was generated for,
  // warning: and only as long as the map is not written to.
{
  size_t n = 0;
  size_t size = map.size();
  size_t* result = new size_t[ size ];
  for ( CountMap::Iterator i(map); i.avail() && n<size; i++ )
    result[n++] = i.indexOf();
  qsortByReqs( map, result, 0, size-1 );
  return result;
}

static
void
qsortBySize( const Counter* array, size_t* result, int left, int right )
{
  if ( left >= right ) return;
  mySwap( result, left, (left+right) / 2 );
  int last = left;
  for ( int i=left+1; i<=right; i++ )
    if ( array[result[left]].size() < array[result[i]].size() )
      mySwap( result, ++last, i );
  mySwap( result, left, last );
  qsortBySize( array, result, left, last-1 );
  qsortBySize( array, result, last+1, right );
}

size_t* 
indexBySize( const Counter* array, size_t size )
  // purpose: construct an array of hashvalues for the map in sorted order.
  // paramtr: array (IN): array of counters to generate the index for
  //          size (IN): number of elements in the array.
  // returns: map-sized array with indices, sorted by largest first.
  // warning: you have to delete[] the result yourself!
  // warning: the index is only valid for the array it was generated for.
{
  size_t* result = new size_t[ size ];
  for ( size_t n=0; n<size; n++ ) result[n] = n;
  qsortBySize( array, result, 0, size-1 );
  return result;
}

static
void
qsortBySize( const CountMap& array, size_t* result, int left, int right )
{
  if ( left >= right ) return;
  mySwap( result, left, (left+right) / 2 );
  int last = left;
  for ( int i=left+1; i<=right; i++ )
    if ( array[result[left]].size() < array[result[i]].size() )
      mySwap( result, ++last, i );
  mySwap( result, left, last );
  qsortBySize( array, result, left, last-1 );
  qsortBySize( array, result, last+1, right );
}

size_t*
indexBySize( const CountMap& map )
  // purpose: construct an array of hashvalues for the map in sorted order.
  // paramtr: map (IN): map to generate the index for
  // returns: map-sized array with indices, sorted by largest first.
  // warning: you have to delete[] the result yourself!
  // warning: the index is only valid for the map it was generated for,
  // warning: and only as long as the map is not written to.
{
  size_t n = 0;
  size_t size = map.size();
  size_t* result = new size_t[ size ];
  for ( CountMap::Iterator i(map); i.avail() && n<size; i++ )
    result[n++] = i.indexOf();
  qsortBySize( map, result, 0, size-1 );
  return result;
}

//
// -------------------------------------------------------------------
//

String
autoSize( double x, double shift, int width, int suffix, const char* unit )
  // purpose: auto-format a byte value, by using the correct unit prefix
  // paramtr: x (IN): value to format
  //          shift (IN): threshold to switch to next dimension
  //          width (IN): width of string to return
  //          suffix (IN): width of fractional part of the string
  //          unit (IN): unit of measurement
  // returns: a string formated according to the input
{
  static const char suffices[] = " KMGT";
  char temp[128];

  int s = 0;
  while ( x > shift && s < 4 ) {
    x /= 1024.0;
    s++;
  }
  sprintf( temp, "%*.*f %c%s", width, suffix, x, suffices[s], unit );
  return String(temp);
}

String
autoTime( double x, int width, int suffix )
  // purpose: auto-format a time value, by using the correct unit suffix
  // paramtr: x (IN): value to format
  //          width (IN): width of string to return
  //          suffix (IN): width of fractional part of the string
  // returns: a string formated according to the input
{
  static const char* units[] = { "ms", " s", " h", " d", " y" };
  static double factors[] = { 1000.0, 3600.0, 24.0, 365.2564 };
  static double wrapper[] = { 1000.0, 1000.0, 100.0, 365.2564 };
  char temp[128];

  int s = 0;
  while ( x > wrapper[s] && s < 3 ) {
    x /= factors[s];
    s++;
  }
  sprintf( temp, "%*.*f %s", width, suffix, x, units[s] );
  return String(temp);
}

String
autoBps( double v, double t )
  // purpose: convert size and duration into a speed
  // paramtr: v (IN): size in byte
  //          t (IN): time in milliseconds
  // returns: string with speed in bit-per-second
{
  return ( autoSize( t < 1E-3 ? 0.0 : (8000.0* v) / t, 999.9, 7, 1, "bps" ) );
}

String
autoPercent( double full, double partial )
  // purpose: format a percentage from absolute values
  // paramtr: full (IN): the sum
  //          partial (IN): the absolute part of the sum
  // returns: formatted string
{
  char temp[128];
  double q = full < 1 ?
    (partial < 1 ? 0.0 : 100.0) :
    (partial * 100.0) / full;

  if ( q > 99.9 ) strcpy( temp, "  100%" );
  else sprintf( temp, " %4.1f%%", q );
  return String(temp);
}

//
// -------------------------------------------------------------------
//

String
valueTail( size_t width, bool withHits )
  // purpose: create a table underliner
  // paramtr: width (IN): maximum allowed size for the changable part
  //          withHits (IN): true: prepare a table with hit partials
  // returns: string containing a table underliner
{
  String result( width, '-' );

  //          1234567890%%%%%%abcdefg xB%%%%%%abcdefg xbps
  result += " ---------- ----- --------- ----- -----------";
  if ( withHits ) 
    //         1234567890 xxxx%1234567 xB xxxx%1234567 xbps
    result += " --------- ----- --------- ----- -----------";
    
  return result;
}

String
valueHead( String a, size_t width, bool useRate, bool withHits )
  // purpose: create a table head
  // paramtr: a (IN): string containing some text for the table head
  //          width (IN): maximum allowed size --> 'a' might be cut
  //          useRate (IN): true: use a data rate instead of duration
  //          withHits (IN): true: prepare a table with hit partials
  // returns: string containing the table head
{
  String result( a.substring(0,width) );
  while ( result.length() <= width ) result += " ";

  //         1234567890%%%%%%abcdefg xB%%%%%%abcdefg xbps
  result += "  requests  req% volume     vol%   ";
  result += ( useRate ? "data-rate" : " duration" );
  if ( withHits ) {                  // duration 
    //         1234567890 xxxx%1234567 xB xxxx%1234567 xbps
    result += "  HIT-req. HITr%  HIT-vol. HITv%   ";
    result += ( useRate ? "data-rate" : " duration" );
  }

  return result;
}

String
valueBody( const Counter& cur, const Counter& all, bool useRate )
  // purpose: create a string containing just the full count.
  // paramtr: cur (IN): the current count 
  //          all (IN): the summary count
  // returns: string containing these items
{
  char buf[128];
  sprintf( buf, SF_wU32(10), cur.reqs() );
  String result( buf + 
		 autoPercent( all.reqs(), cur.reqs() ) +
		 autoSize(cur.size()) +
		 autoPercent( all.size(), cur.size() ) );
  if ( useRate ) 
    result += autoBps(cur.size(),cur.time());
  else
    result += autoTime(cur.time());

  return result;
}

String
valueBody( const Counter& cur, const Counter& all, const Counter& hit,
	   bool useRate )
  // purpose: create a string containing the full and hit part.
  // paramtr: cur (IN): the current count 
  //          all (IN): the summary count
  //          hit (IN): the hit part of the full count
  // returns: string containing these items
{
  char buf[128];
  String result( valueBody(cur,all,useRate) );

  sprintf( buf, SF_wU32(10), hit.reqs() );
  result += buf;
  result += autoPercent( cur.reqs(), hit.reqs() );
  result += autoSize( hit.size() );
  result += autoPercent( cur.size(), hit.size() );
  if ( useRate ) 
    result += autoBps( hit.size(), hit.time() );
  else
    result += autoTime( hit.time() );

  return result;
}

//
// -------------------------------------------------------------------
//

String str_numeric( "<numeric>" );
String str_empty( "<empty>" );
String str_error( "<error>" );

void
getDomainFromHost( const char* host, String& tld, String& sld )
  // purpose: extract the top-level and 2nd level domain from a hostname
  // paramtr: host (IN): possible FQDN
  //          tld (OUT): top-level domain or category
  //          sld (OUT): 2nd-level domain or empty string
  // warning: numeric dotted quads and bigints --> tld := ::str_numeric
  //          and sld the class C network
{
  if ( ISDIGIT(*host) ) {
    // some kind of numeric 
    struct in_addr ip;
    ip.s_addr = htonl(IN_CLASSC_NET & ntohl(inet_addr(host)));
    sld = String(inet_ntoa(ip)); // FIXME: not thread-safe
    tld = ::str_numeric;
  } else {
    // regular or irregular symbolic host
    const char* s = strrchr( host, '.' );
    if ( s == 0 ) {
      // error or localhost
      sld = ::str_empty;
      if ( strcmp( host, "localhost" ) == 0 ) tld = String(host);
      else tld = ::str_error;
    } else {
      // regular symbolic host, s points to last dot
      tld = String(s+1);
      s--;
      while ( s>host && *s != '.' ) s--;
      sld = String( *s == '.' ? s+1 : s );
    }
  }
} 

double
now( void )
  // purpose: obtain the current time
  // returns: current time in *SECONDS* since 01.01.1970
{
  struct timeval tv;
  int timeout = 10;
  while ( gettimeofday( &tv, NULL ) == -1 && timeout > 0 ) timeout--;
  return timeout ? ( tv.tv_sec + tv.tv_usec * 1E-6 ) : 0.0;
}
