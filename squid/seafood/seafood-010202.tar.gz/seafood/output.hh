//
// $Id: output.hh,v 1.8 2000/07/29 22:14:15 voeckler Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    output.hh
//          Thu Aug 05 1999
//
// (c) 1999 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: output.hh,v $
// Revision 1.8  2000/07/29 22:14:15  voeckler
// joined database and textual output, split generic part of output into
// separate file, split main parsing loop from seafood.cc into separate
// file.
//
// Revision 1.7  2000/07/27 07:36:21  voeckler
// reworked to create new sections for internal code, and updated the API
// to write into a FILE* of its own instead of stdout.
//
// Revision 1.6  1999/11/29 15:11:18  voeckler
// added new parameter to statistics output, in order to print statistics
// as comments into the database intermediate file.
//
// Revision 1.5  1999/10/29 14:03:33  voeckler
// removed module private function definitions from the interface file, added
// definitions with a more global scope to the interface.
//
// Revision 1.4  1999/09/01 21:59:24  voeckler
// cache data structures are pointers.
//
// Revision 1.3  1999/08/25 21:13:37  voeckler
// added distribution tables to output.
//
// Revision 1.2  1999/08/20 22:43:50  voeckler
// made dns cache a pointer. now prints full statistics of the
// irr and dns cache, if they are available.
//
// Revision 1.1  1999/08/05 21:17:11  voeckler
// Initial revision
//
//
#ifndef _OUTPUT_HH
#define _OUTPUT_HH

#if defined(__GNUC__) || defined(__GNUG__)
#pragma interface
#endif

#include <stdio.h>
#include <time.h>
#include "typedefs.h"
#include "counter.hh"
#include "counters.hh"
#include "dns.hh"
#include "irr.hh"

enum Selector {
  // currently unused, later for selection of output
  BY_NONE=0,
  BY_REQS=1,
  BY_SIZE=2,
  BY_BOTH=3
};

extern const String no_dns;
extern const String no_irr;
typedef StringMap<MyUInt32,true> AddressMap;

void
printResults( FILE* text, FILE* dbase, const char* cache,
	      DNSCache* dns, IRRCache* irr, const Counters& counters,
	      double looptime, double startup, MyUInt32 lineno );
  // purpose: print results
  // paramtr: out (IO): file to put results into 
  //          cache (IN): (virtual) name to use for output
  //          dns (IO): DNS query and cache
  //          irr (IO): IRR query and cache
  //          counters (IN): current value of last log file processing
  //          looptime (IN): time spent parsing the log file
  //          startup (IN): start time of seafood
  //          lineno (IN): number of lines processed.


#endif // _OUTPUT_HH
