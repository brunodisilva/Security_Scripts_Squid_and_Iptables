//
// $Id: dnsitem.cc,v 1.3 1999/09/01 22:03:50 voeckler Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    dnsitem.cc
//          Tue Aug 24 1999
//
// (c) 1999 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: dnsitem.cc,v $
// Revision 1.3  1999/09/01 22:03:50  voeckler
// added static address conversion methods, changed string
// conversion format from unsigned long to dotted quad.
//
// Revision 1.2  1999/08/27 20:51:32  voeckler
// removed dependency on io stream in favour of 'classic' approaches,
// now is a sibling of the base class BaseItem.
//
// Revision 1.1  1999/08/25 21:25:05  voeckler
// Initial revision
//
//
#if defined(__GNUC__) || defined(__GNUG__)
#pragma implementation
#endif

#include <assert.h>
#include <sys/types.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>
#include <fcntl.h>
#include <string.h>

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>

#include "ctype.hh"
#include "dnsitem.hh"

static const char* RCS_ID =
"$Id: dnsitem.cc,v 1.3 1999/09/01 22:03:50 voeckler Exp $";

DNSItem::DNSItem( time_t expiry, struct hostent* h )
  :BaseItem(expiry,(h==0)),n_aliases(0),n_addresses(0)
{
  if ( h ) {
    size_t n = 0;
    for ( char** p=h->h_aliases; *p; p++ ) n_aliases++;
    aliases = new String[n_aliases];
    for ( char** p=h->h_aliases; *p; p++ ) 
      aliases[n++] = String(*p).lower();
    
    n = 0;
    for ( char** p=h->h_addr_list; *p; p++ ) n_addresses++;
    addresses = new MyUInt32[n_addresses];
    for ( char** p=h->h_addr_list; *p; p++ )
      addresses[n++] = *((MyUInt32*) *p);

    fqdn = String(h->h_name).lower();
  }
}

DNSItem::DNSItem( const DNSItem& dns )
  :BaseItem(dns.expires,dns.empty),
   n_aliases(dns.n_aliases),n_addresses(dns.n_addresses)
{
  if ( ! empty ) {
    aliases = new String[n_aliases];
    addresses = new MyUInt32[n_addresses];
    for ( size_t i=0; i<n_aliases; i++ ) 
      aliases[i] = dns.aliases[i];
    for ( size_t i=0; i<n_addresses; i++ ) 
      addresses[i] = dns.addresses[i];
    fqdn = dns.fqdn;
  }
}

void
DNSItem::clear()
{
  if ( ! empty ) {
    delete[] aliases;
    delete[] addresses;
  }
  empty = true;
  expires = n_aliases = n_addresses = C_U32(0);
}

DNSItem::~DNSItem()
{
  clear();
}

DNSItem& 
DNSItem::operator=( const DNSItem& dns )
{
  if ( &dns != this ) {
    clear();
    expires = dns.expires;
    if ( ! (empty = dns.empty) ) {
      aliases = new String[ (n_aliases = dns.n_aliases) ];
      addresses = new MyUInt32[ (n_addresses = dns.n_addresses) ];
      for ( size_t i=0; i<n_aliases; i++ ) aliases[i] = dns.aliases[i];
      for ( size_t i=0; i<n_addresses; i++ ) addresses[i] = dns.addresses[i];
      fqdn = dns.fqdn;
    }
  }
  return *this;
}

bool 
DNSItem::operator==( const DNSItem& dns )
{
  if ( empty ) {
    // a is empty
    return dns.empty;
  } else {
    // a has some value
    if ( dns.empty ) return false;
    else return fqdn == dns.fqdn;
  }
}

bool 
DNSItem::operator!=( const DNSItem& dns )
{
  if ( empty ) {
    // a is empty
    return !dns.empty;
  } else {
    // a has some value
    if ( dns.empty ) return true;
    else return fqdn != dns.fqdn;
  }
}

String 
DNSItem::toString( void ) const
{
  char temp[32];
  sprintf( temp, "(%lu", expires );

  String result(temp);
  if ( ! empty ) {
    result += ";" + fqdn;
    if ( n_aliases == 0 ) result += ";0";
    else {
      sprintf( temp, ";%u:", n_aliases );
      result += temp;
      for ( size_t n=0; n < n_aliases; ++n ) {
	result += aliases[n];
	if ( n_aliases - n > 1 ) result += ",";
      }
    }
    if ( n_addresses == 0 ) result += ";0";
    else {
      sprintf( temp, ";%u:", n_addresses );
      result += temp;
      for ( size_t n=0; n < n_addresses; ++n ) {
	result += DNSItem::ntoa(addresses[n]);
	if ( n_addresses - n > 1 ) result += ",";
      }
    }
  }
  result += ")";
  return result;
}

inline
MyUInt32
number( const char*& s )
{
  MyUInt32 result = 0;
  while ( ISDIGIT(*s) ) {
    result = 10*result + ( *s - '0' );
    s++;
  }
  return result;
}

inline
MyUInt32
address( const char*& s )
{
  const char* t = s;
  while ( ISDIGIT(*s) || *s == '.' ) ++s;
  return DNSItem::aton(String(t,s-t));
}

inline
String
hostname( const char*& s )
{
  const char* t = s;
  while ( ISHNAME(*s) ) ++s;
  return String(t,s-t);
}

DNSItem::DNSItem( const char* s )
  :BaseItem(0,true),n_aliases(0),n_addresses(0)
{
  assert( s != 0 );
  while ( ISSPACE(*s) ) ++s;
  
  if ( *s == '(' ) {
    ++s; // skip '('
    expires = number(s);
    if ( *s == ';' ) {
      empty = false;

      ++s; // skip ';'
      fqdn = hostname( s );

      ++s; // skip ';'
      n_aliases = number(s);
      if ( *s == ':' ) ++s; // skip ':' (old format)
      if ( n_aliases != 0 ) {
	aliases = new String[n_aliases];
	for ( size_t n=0; *s && n < n_aliases; ++n ) {
	  aliases[n] = hostname( s );
	  if ( *s == ',' ) ++s; // skip ','
	}
      } else 
	aliases = 0;

      ++s; // skip ';'

      n_addresses = number(s);
      if ( *s == ':' ) ++s; // skip ':' (old format)
      if ( n_addresses != 0 ) {
	addresses = new MyUInt32[n_addresses];
	for ( size_t n=0; *s && n < n_addresses; ++n ) {
	  addresses[n] = address(s);
	  if ( *s == ',' ) ++s; // skip ','
	}
      } else
	addresses = 0;
    } else if ( *s == ')' ) {
      empty = true;
    }
  }
}

String
DNSItem::ntoa( MyUInt32 address )
{
  struct in_addr ip;
  ip.s_addr = address;
  return String( inet_ntoa(ip) );
}

MyUInt32
DNSItem::aton( const String& address )
{
  return inet_addr( address.c_str() );
}
