//
// $Id: dns.cc,v 1.12 1999/10/29 13:50:44 voeckler Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    dns.cc
//          Thu Aug 05 1999
//
// (c) 1999 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: dns.cc,v $
// Revision 1.12  1999/10/29 13:50:44  voeckler
// moved to gdbm cache file format.
//
// Revision 1.11  1999/09/02 10:10:54  voeckler
// removed old (obsolete) interface from class, minor statistics fixes.
//
// Revision 1.10  1999/08/31 08:48:42  voeckler
// new intermediary revision before removing obsolete items.
//
// Revision 1.9  1999/08/27 21:51:27  voeckler
// changed String operator() to method c_str() call.
//
// Revision 1.8  1999/08/27 20:55:51  voeckler
// removed io stream dependencies in favour of standard io, the
// string map iterator is now part of the string map, fixed some
// time() related signedness bug.
//
// Revision 1.7  1999/08/25 21:24:16  voeckler
// made DNSItem a class of its own, so it can be re-used by the
// dns helper programs. Also fixed some minor lookup bugs.
//
// Revision 1.6  1999/08/23 11:53:03  voeckler
// fixed bug in dns and irr server which resulted in looking up any
// negativly cached entry. Also added some more debug output to the
// cache code.
//
// Revision 1.5  1999/08/20 22:42:35  voeckler
// clarified a few things, now expires entries in c'tor, fixed
// bug when reading names without aliases.
//
// Revision 1.4  1999/08/20 12:17:16  voeckler
// left-over bug fixes from NDBM removal. Now includes iostream, as the
// textual database file needs to be streamed.
//
// Revision 1.3  1999/08/15 19:49:59  voeckler
// removed NDBM dependency in favour of a textual database format
// which is (supposed to be) interchangable between different
// platforms.
//
// Revision 1.2  1999/08/06 08:44:33  voeckler
// added debugging to DNS using the debug level and debug class from global.
//
// Revision 1.1  1999/08/05 21:06:01  voeckler
// Initial revision
//
//
#if defined(__GNUC__) || defined(__GNUG__)
#pragma implementation
#endif

#include <assert.h>
#include <sys/types.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>
#include <fcntl.h>
#include <string.h>

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>

#include "global.hh"
#include "ctype.hh"
#include "dns.hh"

static const char* RCS_ID =
"$Id: dns.cc,v 1.12 1999/10/29 13:50:44 voeckler Exp $";

static
char* const*
make( const char* prg, MyUInt32 positive, MyUInt32 negative )
{
  static char pos[16];
  sprintf( pos, SF_U32, positive );
  static char neg[16];
  sprintf( neg, SF_U32, negative );
  static char* const argv[4] = { (char*) prg, pos, neg, (char*) 0 };
  return argv;
}

DNSCache::DNSCache( size_t nrOfChildren,
		    const char* dnsHelper,
		    const char* cacheFile,
		    MyUInt32 posTTL,
		    MyUInt32 negTTL )
  :BaseCache(posTTL,negTTL),
   dbfn(strdup(cacheFile ? cacheFile : "")),
   helper( nrOfChildren, dnsHelper, make(dnsHelper,posTTL,negTTL),
	   (globals.debugClass & Global::D_DNS), globals.debugLevel, this ),
   dbase( dbfn, false, false ), // rw, sync
   count(C_U32(0))
{
  StringSet expired;
  time_t now = time(0);

  // do not expire while there is an opened iterator on the database!
  for ( GDBM::Iterator i(dbase); i.avail(); i++ ) {
    ++count;
    if ( (globals.debugClass & Global::D_DNS) && (count & 16383) == 0 ) {
      now = time(0); // refresh time information
      fprintf( stderr, "# read " SF_U32 " dns cache entries.\n", count );
    }

    DNSItem value( i.value().c_str() );
    if ( value.expires <= now ) expired.insert(i.key());
  }

  for ( StringSet::iterator i=expired.begin(); i!=expired.end(); ++i ) {
    fprintf( stderr, "# removing dns key \"%s\"\n", (*i).c_str() );
    dbase.erase( *i );
    --count;
  }

  if ( (globals.debugClass & Global::D_DNS) ) 
    fprintf( stderr, "# " SF_U32 " dns cache entries are usable.\n", count );
}

DNSCache::~DNSCache()
{
  dbase.sync();
  free((void*) dbfn );
}

DNSCache::DNSItemMap 
DNSCache::getanybyany( const StringSet& what )
  // purpose: obtain addresses
  // paramtr: what (IN): set of symbolic or numeric strings to look up
  // returns: Map containing all (lower-cased) keys from what
{
  DNSItemMap result;
  if ( what.size() == 0 ) return result;

  // find all entries we already know about, and 
  // copy all unknown entries for massive parallel querying
  StringSet unknown;
  time_t now = time(0);
  for ( StringSet::const_iterator i=what.begin(); i != what.end(); ++i ) {
    requests[C_ALL]++;
    String key( (*i).lower() );
    DNSItem value( dbase.fetch(key).c_str() );
    // POSTCONDITION: ttl will be 0 for non existing item

    if ( value.expires < now ) {
      if ( value.empty ) requests[C_MISS]++;
      else requests[C_TTL]++;
      unknown.insert(key);
    } else {
      requests[C_HIT]++;
      if ( (globals.debugClass & Global::D_DNS) && globals.debugLevel ) {
	fprintf( stderr, "# DNS cache HIT: %s\n", value.toString().c_str() );
      }
      result[key] = value;
    }
  }
  
  // if there are any unknown entries, we need to look 'em up (parallel)
  if ( ! unknown.empty() ) {
    DNSItemMap local;
    helper.query( unknown, local, negativeTTL );

    for ( DNSItemMap::Iterator i(local); i.avail(); i++ ) {
      // add findings anyway to our cache
      String keyString( i.key() );
      String valueString( i.value().toString() );
      if ( ! dbase.exists( keyString ) ) ++count;
      dbase.insert( keyString, valueString );

      // if current answer is part of the search, add to result
      StringSet::iterator j = unknown.find( keyString );
      if ( j != unknown.end() ) {
	result[ keyString ] = i.value();
	if ( i.value().empty ) requests[C_NEG]++;
	else requests[C_POS]++;
      }

      if ( i.value().empty ) {
	if ( (globals.debugClass & Global::D_DNS) )
	  fprintf( stderr, "# DNS negative lookup: %s\n", 
		   keyString.c_str() );
      } else {
	if ( (globals.debugClass & Global::D_DNS) )
	  fprintf( stderr, "# DNS positive lookup: %s\n", 
		   valueString.c_str() );
      }

    }
  }

  return result;
}
