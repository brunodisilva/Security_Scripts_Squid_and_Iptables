//
// $Id: copro.hh,v 1.7 2001/02/02 10:33:58 voeckler Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    copro.hh
//          Tue Aug 26 1999
//
// (c) 1999 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: copro.hh,v $
// Revision 1.7  2001/02/02 10:33:58  voeckler
// separated Minimum() into template and inline of its own.
//
// Revision 1.6  1999/10/29 13:58:27  voeckler
// added typedef for StringStringMap.
//
// Revision 1.5  1999/09/02 10:14:57  voeckler
// moved template class into a file of its own due to SGI compiler weirdness.
//
// Revision 1.4  1999/08/31 09:53:27  voeckler
// managed to derive a concrete class from a template base.
//
// Revision 1.3  1999/08/31 08:46:15  voeckler
// new intermediary revision before trying new things. Major changes to
// the co process concept. Now includes the query() method in a template
// class due to many common issues. Further changes are expected in order
// to enhance the efficiency of the queries (saving queries rendered
// redundant by previously received answers within the same run).
//
// Revision 1.2  1999/08/27 20:45:37  voeckler
// made copro the base class for sibling co process helpers.
// Just the ctor and dtor remain to start and kill processes.
//
// Revision 1.1  1999/08/26 19:41:51  voeckler
// Initial revision
//
//
#ifndef _COPRO_HH
#define _COPRO_HH

#if defined(__GNUC__) || defined(__GNUG__)
#pragma interface
#endif

#include <sys/types.h>
#include <errno.h>
#include <stdio.h>
#include <math.h>

#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>
#include <poll.h>

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "copro.hh"
#include "ctype.hh"
#include "string.hh"
#include "strmap.hh"
#include "stringset.hh"
#include "rw.hh"
#include "minimum.hh"

typedef StringMap< String, false > StringStringMap;

class CoProcess {
  // spawn N co-processes PRG with the given ARGV, connect with their
  // stdin and stdout via a local stream socket (bi-directional connection)
  // and afterwards clean them up again, too.
  //
  // child classes are expected to implement meaningful methods using the
  // the co processes. Children should prefer poll() over select(), though
  // select() is more portable to strange platforms.
public:
  CoProcess( size_t n, const char* prg, char* const argv[] );
  ~CoProcess();

  pid_t startChild( int i );
  // purpose: open IPC socket, start subprocess and connect FDs 
  // paramtr: i (IN): the logical child number [0..nargs[
  // returns: the PID of the started child, or -1 in case of error
  // warning: changes descriptor[i] and child[i].

  pid_t stopChild( int i );
  // purpose: close IPC socket, signal TERM and reap child
  // paramtr: i (IN): the logical child number [0..nargs[
  // returns: the PID of the terminated child, or 0, if the child was 
  //          already dead.
  // warning: may change descriptor[i] and child[i].

  pid_t restartChild( int i )
    { stopChild(i); return startChild(i); }
  
protected:
  size_t number;
  size_t nargs;
  pid_t* child;
  int*   descriptor;
  char*  programme;
  char** arguments;

  typedef char* CharP;
  typedef struct pollfd PollFD;

  static const short POLLREAD;
  void showPollFD( FILE* out, const PollFD* fds );

private:
  // render inaccessible
  CoProcess();
  CoProcess( const CoProcess& );
  CoProcess& operator=( const CoProcess& );
};

#endif // _COPRO_HH
