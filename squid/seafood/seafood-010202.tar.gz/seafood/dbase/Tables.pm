#! /usr/bin/perl
#
# $Id: Tables.pm,v 1.2 2000/08/10 13:24:46 voeckler Exp voeckler $
#
package Tables;
require 5.003;
use strict;

#
# some more definitions
#
@main::tables = 
qw(
   SF_AS
   SF_HIER_DIRECT
   SF_HIER_PEER
   SF_INT_CLIENT
   SF_INTERNAL
   SF_META
   SF_METHOD
   SF_MIME
   SF_PEAK
   SF_SCHEME
   SF_SLD
   SF_STAMP1
   SF_STAMP2
   SF_STATUS
   SF_SUFFIX
   SF_TCP_CLIENT
   SF_TLD
   SF_UDP_CLIENT
);
    
%Tables::jumptable = 
    ( 
      'tcp' => \&insert_tcp,
      'udp' => \&insert_udp,
      'int' => \&insert_int,
      'hier' => \&insert_hier,
      'method' => \&insert_method,
      'internal' => \&insert_internal,
      'scheme' => \&insert_scheme,
      'suffix' => \&insert_suffix,
      'tld' => \&insert_tld,
      'sld' => \&insert_sld,
      'mime' => \&insert_mime,
      'client' => \&insert_client,
#      'dist' => \&insert_dist,
      'as' => \&insert_as
    );

#
# --------------------------------------------------------------- subs
#

sub newinsert ($$$$$) {
    # purpose: insert and/or update date in the database
    # paramtr: $handle (IO): database handle
    #          $table (IN): name of table within database
    #          $insertion_mode (IN): -1=replace, 0=insert, 1=update
    #          \%key (IN): hash of table keys { keyname => keyvalue }
    #          \%value (IN): hash of table values { column => value }
    # insertion_mode 1 and -1 must have the row in existence, 
    # insertion_mode 0 must not have the row in existence.
    my ($handle,$table,$insertion_mode,$key,$value) = @_;
    my ($request,$k,$v);
    
    if ( $insertion_mode == 0 ) {
	# regular insertion
	# precondition: the row must not exists, or insert will fail

	# from the %key map and %value map, construct column assignments
	my (@keylist,@valuelist);
	while (($k,$v) = each %{$key} ) {
	    push @keylist, $k;
	    push @valuelist, $v;
	}
	while (($k,$v) = each %{$value} ) {
	    push @keylist, $k;
	    push @valuelist, $v;
	}

	# construct request for insertion
	$request = "insert into $table (" . join(',',@keylist) . ") ";
	$request .= "values (" . join(',',@valuelist) . ")";
    } elsif ( $insertion_mode == 1 ) {
	# regular update
	# precondition: the row must exists, or insert will fail
	# precondition: the columns must not contain non-numerical values

	$request = "update $table set ";
	my $first;
	# WARNING: This piece relies on the non-key columns all being
	#          of a numerical type!
	while (($k,$v) = each %{$value}) {
	    $request .= ", " if $first;
	    $first=1;
	    $request .= "$k = $k + $v";
	}

	$request .= " where ";
	undef $first;
	while (($k,$v) = each %{$key}) {
	    $request .= " AND " if $first;
	    $first=1;
	    $request .= "$k = $v";
	}
    } elsif ( $insertion_mode == -1 ) {
	# replacement mode
	# precondition: the row must exists, or replace will fail

	$request = "update $table set ";
	my $first;
	# WARNING: This piece relies on the non-key columns all being
	#          of a numerical type!
	while (($k,$v) = each %{$value}) {
	    $request .= ", " if $first;
	    $first=1;
	    $request .= "$k = $v";
	}

	$request .= " where ";
	undef $first;
	while (($k,$v) = each %{$key}) {
	    $request .= " AND " if $first;
	    $first=1;
	    $request .= "$k = $v";
	}
    } else {
	# error
	die "illegal insertion_mode=$insertion_mode";
    }

    warn "# trying $request\n" if $main::DEBUG > 1;
    $Tables::stmt = $request;
    my $query = $handle->prepare($request) ||
	die "table->prepare($request): ", $handle->errstr;
    my $retval = $query->execute ||
	die "table->execute: ", $handle->errstr;
    $retval = $query->finish ||
	die "table->finish: ", $handle->errstr;
    undef $Tables::stmt;
    1;
}

#
# --------------------------------------------------------------- subs
#

sub insert_stamp1 {
    # purpose: insert first line, and return the $tsid for this file...
    # paramtr: $handle (IO): database connection handle
    #          $tsid (IN): relevent time stamp
    #          $update (IN): 0=insert, 1=update
    #          @args (IN): arguments to the stamp1 input
    my ($handle,$tsid,$update,$cache,$first,$start,$soff,
	$final,$foff,$iv_real,$iv_conf,$version) = @_;

    # insert new values into db, replace existing time stamps
    newinsert( $handle, 'sf_stamp1', $update ? -1 : 0,
	       { I1ID => $tsid, CACHE => "\'$cache\'", 
		 FIRST => $first },
	       { BEGIN_TS => $start, BOFF => $soff + 0, 
		 FINAL => $final, FOFF => $foff + 0,
		 IV_REAL => $iv_real, IV_CONF => $iv_conf,
	         VERSION => 0+$version } 
	       );
}

sub insert_stamp2 {
    # purpose: insert first line, and return the $tsid for this file...
    # paramtr: $handle (IO): database connection handle
    #          $tsid (IN): relevent time stamp
    #          $update (IN): 0=insert, 1=update
    #          @args (IN): arguments to the stamp2 input
    my ($handle,$tsid,$update,$cache,$first,$soff,$iv_conf,$version) = @_;

    # insert new values into db, replace existing time stamps
    newinsert( $handle, 'sf_stamp2', $update ? -1 : 0,
	       { I2ID => $tsid, CACHE => "\'$cache\'", 
		 FIRST => $first },
	       { SOFF => $soff + 0, IV_CONF => $iv_conf,
	         VERSION => $version + 0 } 
	       );
}

#
# purpose: jumptable destinations, inserting new values into a table
# paramtr: $handle (IN): generic database handle/connection
#          $stamp (IN): time stamp (either stamp1 or stamp2)
#          $update (IN): 0=insert, 1=update
#          @_ (IN): further arguments, usually contains another key
# returns: result of insertion attempt
#

sub insert_udp {
    # remove 2nd timestamp
    my ($handle,$tsid,$update,$what,undef,$status,$r,$s,$t) = @_;

    # insert new values into db
    newinsert( $handle, "sf_status", $update,
	       { I1ID => $tsid, STATUS => "\'$status\'",
		 HMN_FLAG => "\'" . uc(substr($what,0,1)) . "\'" },
	       { IS_TCP => "\'0\'", R => $r, S => $s, T => $t }
	       );		       
}

sub insert_tcp {
    # remove 2nd timestamp
    my ($handle,$tsid,$update,$what,undef,$status,$r,$s,$t) = @_;

    # insert new values into db
    newinsert( $handle, "sf_status", $update,
	       { I1ID => $tsid, STATUS => "\'$status\'", 
		 HMN_FLAG => "\'" . uc(substr($what,0,1)) . "\'" },
	       { IS_TCP => "\'1\'", R => $r, S => $s, T => $t }
	       );
}

sub insert_int {
    # remove 2nd timestamp
    my ($handle,$tsid,$update,$what,undef,$status,$r,$s,$t) = @_;

    # insert new values into db
    newinsert( $handle, "sf_status", $update,
	       { I1ID => $tsid, STATUS => "\'$status\'", 
		 HMN_FLAG => "\'" . uc(substr($what,0,1)) . "\'" },
	       { IS_TCP => "\'2\'", R => $r, S => $s, T => $t }
	       );
}

sub insert_hier {
    # remove 2nd timestamp
    my ($handle,$tsid,$update,$what,undef,$peercode,@args) = @_;

    # insert new values into db
    if ( $what eq 'direct' ) {
        newinsert( $handle, "sf_hier_direct", $update, 
		   { I1ID => $tsid, CODE => "\'$peercode\'" },
		   { R => $args[0], S => $args[1], T => $args[2] }
		   );
    } else {
        newinsert( $handle, "sf_hier_peer", $update, 
		   { I1ID => $tsid, CODE => "\'$peercode\'",
		     HOST => "\'$args[0]\'" },
		   { IS_PARENT => (( $what eq 'parent' ) ? "\'1\'" : "\'0\'"),
		     R => $args[1], S => $args[2], T => $args[3] }
		   );
    }
}

sub insert_method  {
    # remove 2nd timestamp
    my ($handle,$tsid,$update,undef,$method,$r,$s,$t,$hitr,$hits,$hitt) = @_;

    # insert new values into db
    newinsert( $handle, 'sf_method', $update, 
	       { I1ID => $tsid, METHOD => "\'$method\'" },
	       { R => $r, S => $s, T => $t,
		 HITR => $hitr, HITS => $hits, HITT => $hitt }
	       );
}

sub insert_internal  {
    # remove 2nd timestamp
    my ($handle,$tsid,$update,undef,undef,$host,$path,
	$r,$s,$t,$hitr,$hits,$hitt) = @_;

    # insert new values into db
    newinsert( $handle, 'sf_internal', $update, 
	       { I1ID => $tsid, URI => "\'$host\'", PATH => "\'$path\'" },
	       { R => $r, S => $s, T => $t,
		 HITR => $hitr, HITS => $hits, HITT => $hitt }
	       );
}

sub insert_scheme {
    # remove 2nd timestamp
    my ($handle,$tsid,$update,undef,$scheme,$r,$s,$t,$hitr,$hits,$hitt) = @_;

    # insert new values into db
    newinsert( $handle, 'sf_scheme', $update, 
	       { I1ID => $tsid, SCHEME => "\'$scheme\'" },
	       { R => $r, S => $s, T => $t,
		 HITR => $hitr, HITS => $hits, HITT => $hitt }
	       );
}

sub insert_suffix {
    # remove 2nd timestamp
    my ($handle,$tsid,$update,undef,$suffix,$r,$s,$t,$hitr,$hits,$hitt) = @_;

    # insert new values into db
    newinsert( $handle, 'sf_suffix', $update, 
	       { I1ID => $tsid, SUFFIX => "\'$suffix\'" },
	       { R => $r, S => $s, T => $t,
		 HITR => $hitr, HITS => $hits, HITT => $hitt }
	       );
}

sub insert_tld {
    # remove 2nd timestamp
    my ($handle,$tsid,$update,undef,$tld,$r,$s,$t,$hitr,$hits,$hitt) = @_;

    # insert new values into db
    newinsert( $handle, 'sf_tld', $update, 
	       { I1ID => $tsid, TLD => "\'$tld\'" },
	       { R => $r, S => $s, T => $t,
		 HITR => $hitr, HITS => $hits, HITT => $hitt }
	       );
}

sub insert_sld {
    # remove 2nd timestamp
    my ($handle,$tsid,$update,undef,$sld,$r,$s,$t,$hitr,$hits,$hitt) = @_;

    # insert new values into db
    newinsert( $handle, 'sf_sld', $update, 
	       { I1ID => $tsid, SLD => "\'$sld\'" },
	       { R => $r, S => $s, T => $t,
		 HITR => $hitr, HITS => $hits, HITT => $hitt }
	       );
}

sub insert_mime {
    # remove 2nd timestamp
    my ($handle,$tsid,$update,undef,$mimetype,$r,$s,$t,$hitr,$hits,$hitt) = @_;

    # insert new values into db
    newinsert( $handle, 'sf_mime', $update, 
	       { I1ID => $tsid, TYPE => "\'$mimetype\'" },
	       { R => $r, S => $s, T => $t,
		 HITR => $hitr, HITS => $hits, HITT => $hitt }
	       );
}

sub insert_client {
    # remove 2nd timestamp
    my ($handle,$tsid,$update,$what,undef,$host,$r,$s,$t,$hitr,$hits,$hitt,@args) = @_;

    if ( $what eq 'udp' || $what eq 'int' ) {
        newinsert( $handle, "sf_${what}_client", $update,
		   { I1ID => $tsid, HOST => "\'$host\'" },
		   { R => $r, S => $s, T => $t,
		     HITR => $hitr, HITS => $hits, HITT => $hitt }
		   );
    } elsif ( $what eq 'tcp' ) {
        newinsert( $handle, "sf_${what}_client", $update,
		   { I1ID => $tsid, HOST => "\'$host\'" },
		   { R => $r, S => $s, T => $t,
		     HITR => $hitr, HITS => $hits, HITT => $hitt,
		     MISSR=>$args[0], MISSS=>$args[1], MISST=>$args[2],
		     ERRR=>$args[3], ERRS=>$args[4], ERRT=>$args[5] }
		   );
    }
}

sub insert_as {
    my ($handle,$tsid,$update,undef,$asn,@args) = @_;

    # find stop of description string, which is enclosed in quotes
    my $temp = join(' ',@args);
    my $last = rindex( $temp, '"' );
    my $desc = substr( $temp, 0, rindex($temp,'"')+1, '' );
    @args = split ' ', $temp;
    $desc = join("\'\'",split("\'",$desc))
	if ( index($desc,"\'") != -1 ); # ' --> ''
    $desc =~ s/^"/'/; # '"
    $desc =~ s/"$/'/; # '"
    if ( substr($asn,0,4) eq 'more' ) {
	$desc = "'$asn'";
	$asn = 'more';
    }

    newinsert( $handle, 'sf_as', $update,
	       { I1ID => $tsid, ASN => "\'$asn\'" },
	       { DESCR => $desc, R => $args[0],
		 S => $args[1], T => $args[2] } 
	       );
}

sub insert_peak {
    my ($handle,$tsid,$update,undef,@args) = @_;

    # insert new values into db
    newinsert( $handle, 'sf_peak', $update, 
	       { I2ID => $tsid },
	       { UDP_R => $args[0], UDP_S => $args[1], 
		 UDP_T => $args[2], UDP_HIT_R => $args[3],
		 UDP_HIT_S => $args[4], UDP_HIT_T => $args[5],

	         INT_R => $args[6], INT_S => $args[7], 
		 INT_T => $args[8], INT_HIT_R => $args[9],
		 INT_HIT_S => $args[10], INT_HIT_T => $args[11],
		 
		 TCP_R => $args[12], TCP_S => $args[13],
		 TCP_T => $args[14], TCP_HIT_R => $args[15],
		 TCP_HIT_S => $args[16], TCP_HIT_T => $args[17],
		 
		 DIRECT_R => $args[18], DIRECT_S => $args[19], 
		 DIRECT_T => $args[20],

		 PARENT_R => $args[21], PARENT_S => $args[22], 
		 PARENT_T => $args[23],

		 PEER_R => $args[24], PEER_S => $args[25], 
		 PEER_T => $args[26] }
	       );
}

#sub insert_dist {
#    my ($handle,$tsid,$update,$type1,$hmn,undef,@args) = @_;
#    # only insert aggregates
#    if ( $type1 eq 'time' || $type1 eq 'size' ) {
#	
#    }
#}

# success
1;
