create table remove 
  as select i1id from sf_stamp1
  where first >= 972770400;

delete from SF_AS where i1id in ( select * from remove );
delete from SF_HIER_DIRECT where i1id in ( select * from remove );
delete from SF_HIER_PEER where i1id in ( select * from remove );
delete from SF_INTERNAL where i1id in ( select * from remove );
delete from SF_INT_CLIENT where i1id in ( select * from remove );
delete from SF_METHOD where i1id in ( select * from remove );
delete from SF_MIME where i1id in ( select * from remove );
delete from SF_SCHEME where i1id in ( select * from remove );
delete from SF_SLD where i1id in ( select * from remove );
delete from SF_STATUS where i1id in ( select * from remove );
delete from SF_SUFFIX where i1id in ( select * from remove );
delete from SF_TCP_CLIENT where i1id in ( select * from remove );
delete from SF_TLD where i1id in ( select * from remove );
delete from SF_UDP_CLIENT where i1id in ( select * from remove );
delete from SF_STAMP1 where i1id in ( select * from remove );

drop table remove;

create table remove
  as select i2id from sf_stamp2
  where first >= 972770400;

delete from SF_PEAK where i2id in ( select * from remove );
delete from SF_STAMP2 where i2id in ( select * from remove );

drop table remove;

