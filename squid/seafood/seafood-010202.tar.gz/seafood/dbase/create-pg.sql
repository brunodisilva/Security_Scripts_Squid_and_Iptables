-- ============================================================
--   Database name:  MODEL_6
--   DBMS name:      PostGres 6.5.*
--   Created on:     28.10.99  17:32
-- ============================================================

-- ============================================================
--   Table: SF_META
-- ============================================================
create table SF_META
(
    TSID1      int4               not null,
    TSID2      int4               not null
);


insert into SF_META values
(
    0,
    0
);

-- ============================================================
--   Table: SF_STAMP1
-- ============================================================
create table SF_STAMP1
(
    I1ID       int4            not null,
    CACHE      varchar(48)     not null,
    FIRST      int4	       not null,
    BEGIN_TS   int4
        default 0,
    BOFF       int4
        default 0,
    FINAL      int4
        default 0,
    FOFF       int4
        default 0,
    IV_REAL    int4
        default 0,
    IV_CONF    int4
        default 86400,
    VERSION    int4
	default 0,
    constraint pk_sf_stamp1 primary key (I1ID),
    constraint ak_sf_stamp1 unique (CACHE, FIRST)
);

-- ============================================================
--   Table: SF_STAMP2
-- ============================================================
create table SF_STAMP2
(
    I2ID       int4               not null,
    CACHE      varchar(48)        not null,
    FIRST      int4               not null,
    SOFF       int4
        default 0,
    IV_CONF    int4
        default 3600,
    VERSION    int4
	default 0,
    constraint pk_sf_stamp2 primary key (I2ID),
    constraint ak_sf_stamp2 unique (CACHE, FIRST)
);

-- ============================================================
--   Table: SF_STATUS
-- ============================================================
create table SF_STATUS
(
    I1ID       int4               not null,
    STATUS     varchar(32)        not null,
    HMN_FLAG   char               not null,
    IS_TCP     char
	default '0' not null,
    R          int4
        default 0,
    S          int8
        default 0,
    T          float8
        default 0,
    constraint pk_sf_status primary key (I1ID, STATUS, HMN_FLAG, IS_TCP),
    constraint fk_sf_status foreign key (I1ID) references SF_STAMP1 (I1ID)
);

-- ============================================================
--   Table: SF_HIER_PEER
-- ============================================================
create table SF_HIER_PEER
(
    I1ID       int4               not null,
    CODE       varchar(32)        not null,
    HOST       varchar(64)        not null,
    IS_PARENT  CHAR
        default '0',
    R          int4
        default 0,
    S          int8
        default 0,
    T          float8
        default 0,
    constraint pk_sf_hier_peer primary key (I1ID, CODE, HOST),
    constraint fk_sf_hier_peer foreign key (I1ID) references SF_STAMP1 (I1ID)
);

-- ============================================================
--   Table: SF_HIER_DIRECT
-- ============================================================
create table SF_HIER_DIRECT
(
    I1ID       int4               not null,
    CODE       varchar(32)        not null,
    R          int4
        default 0,
    S          int8
        default 0,
    T          float8
        default 0,
    constraint pk_sf_hier_direct primary key (I1ID, CODE),
    constraint fk_sf_hier_direct foreign key (I1ID) references SF_STAMP1 (I1ID)
);

-- ============================================================
--   Table: SF_INTERNAL
-- ===========================================================
create table SF_INTERNAL
(
    I1ID       int4                not null,
    URI        varchar(64)           not null,
    PATH       varchar(64)           not null,
    R          int4
        default 0,
    S          int8
        default 0,
    T          float8
        default 0,
    HITR       int4
        default 0,
    HITS       int8
        default 0,
    HITT       float8
        default 0,
    constraint pk_sf_internal primary key (I1ID, URI, PATH),
    constraint fk_sf_internal foreign key (I1ID) references SF_STAMP1 (I1ID)
);

-- ============================================================
--   Table: SF_METHOD
-- ============================================================
create table SF_METHOD
(
    I1ID       int4               not null,
    METHOD     varchar(20)           not null,
    R          int4
        default 0,
    S          int8
        default 0,
    T          float8
        default 0,
    HITR       int4
        default 0,
    HITS       int8
        default 0,
    HITT       float8
        default 0,
    constraint pk_sf_method primary key (I1ID, METHOD),
    constraint fk_sf_method foreign key (I1ID) references SF_STAMP1 (I1ID)
);

-- ============================================================
--   Table: SF_SCHEME
-- ============================================================
create table SF_SCHEME
(
    I1ID       int4               not null,
    SCHEME     varchar(20)           not null,
    R          int4
        default 0,
    S          int8
        default 0,
    T          float8
        default 0,
    HITR       int4
        default 0,
    HITS       int8
        default 0,
    HITT       float8
        default 0,
    constraint pk_sf_scheme primary key (I1ID, SCHEME),
    constraint fk_sf_scheme foreign key (I1ID) references SF_STAMP1 (I1ID)
);

-- ============================================================
--   Table: SF_SUFFIX
-- ============================================================
create table SF_SUFFIX
(
    I1ID       int4               not null,
    SUFFIX     varchar(20)           not null,
    R          int4
        default 0,
    S          int8
        default 0,
    T          float8
        default 0,
    HITR       int4
        default 0,
    HITS       int8
        default 0,
    HITT       float8
        default 0,
    constraint pk_sf_suffix primary key (I1ID, SUFFIX),
    constraint fk_sf_suffix foreign key (I1ID) references SF_STAMP1 (I1ID)
);

-- ============================================================
--   Table: SF_TLD
-- ============================================================
create table SF_TLD
(
    I1ID       int4               not null,
    TLD        varchar(10)        not null,
    R          int4
        default 0,
    S          int8
        default 0,
    T          float8
        default 0,
    HITR       int4
        default 0,
    HITS       int8
        default 0,
    HITT       float8
        default 0,
    constraint pk_sf_tld primary key (I1ID, TLD),
    constraint fk_sf_tld foreign key (I1ID) references SF_STAMP1 (I1ID)
);

-- ============================================================
--   Table: SF_SLD
-- ============================================================
create table SF_SLD
(
    I1ID       int4               not null,
    SLD        varchar(64)        not null,
    R          int4
        default 0,
    S          int8
        default 0,
    T          float8
        default 0,
    HITR       int4
        default 0,
    HITS       int8
        default 0,
    HITT       float8
        default 0,
    constraint pk_sf_sld primary key (I1ID, SLD),
    constraint fk_sf_sld foreign key (I1ID) references SF_STAMP1 (I1ID)
);

-- ============================================================
--   Table: SF_MIME
-- ============================================================
create table SF_MIME
(
    I1ID       int4               not null,
    TYPE       varchar(64)        not null,
    R          int4
        default 0,
    S          int8
        default 0,
    T          float8
        default 0,
    HITR       int4
        default 0,
    HITS       int8
        default 0,
    HITT       float8
        default 0,
    constraint pk_sf_mime primary key (I1ID, TYPE),
    constraint fk_sf_mime foreign key (I1ID) references SF_STAMP1 (I1ID)
);

-- ============================================================
--   Table: SF_UDP_CLIENT
-- ============================================================
create table SF_UDP_CLIENT
(
    I1ID       int4               not null,
    HOST       varchar(128)       not null,
    R          int4
        default 0,
    S          int8
        default 0,
    T          float8
        default 0,
    HITR       int4
        default 0,
    HITS       int8
        default 0,
    HITT       float8
        default 0,
    constraint pk_sf_udp_client primary key (I1ID, HOST),
    constraint fk_sf_udp_client foreign key (I1ID) references SF_STAMP1 (I1ID)
);

-- ============================================================
--   Table: SF_INT_CLIENT
-- ============================================================
create table SF_INT_CLIENT
(
    I1ID       int4               not null,
    HOST       varchar(128)       not null,
    R          int4
        default 0,
    S          int8
        default 0,
    T          float8
        default 0,
    HITR       int4
        default 0,
    HITS       int8
        default 0,
    HITT       float8
        default 0,
    constraint pk_sf_int_client primary key (I1ID, HOST),
    constraint fk_sf_int_client foreign key (I1ID) references SF_STAMP1 (I1ID)
);

-- ============================================================
--   Table: SF_TCP_CLIENT
-- ============================================================
create table SF_TCP_CLIENT
(
    I1ID       int4               not null,
    HOST       varchar(128)       not null,
    R          int4
        default 0,
    S          int8
        default 0,
    T          float8
        default 0,
    HITR       int4
        default 0,
    HITS       int8
        default 0,
    HITT       float8
        default 0,
    MISSR      int4
        default 0,
    MISSS      int8
        default 0,
    MISST      float8
        default 0,
    ERRR       int4
        default 0,
    ERRS       int8
        default 0,
    ERRT       float8
        default 0,
    constraint pk_sf_tcp_client primary key (I1ID, HOST),
    constraint fk_sf_tcp_client foreign key (I1ID) references SF_STAMP1 (I1ID)
);

-- ============================================================
--   Table: SF_AS
-- ============================================================
create table SF_AS
(
    I1ID       int4               not null,
    ASN        char(7)            not null,
    DESCR      varchar(128)
        default '',
    R          int4
        default 0,
    S          int8
        default 0,
    T          float8
        default 0,
    constraint pk_sf_as primary key (I1ID, ASN),
    constraint fk_sf_as foreign key (I1ID) references SF_STAMP1 (I1ID)
);

-- ============================================================
--   Table: SF_PEAK
-- ============================================================
create table SF_PEAK
(
    I2ID       int4               not null,
    UDP_R      int4
        default 0,
    UDP_S      int8
        default 0,
    UDP_T      float8
        default 0,
    UDP_HIT_R  int4
        default 0,
    UDP_HIT_S  int8
        default 0,
    UDP_HIT_T  float8
        default 0,
    INT_R      int4
        default 0,
    INT_S      int8
        default 0,
    INT_T      float8
        default 0,
    INT_HIT_R  int4
        default 0,
    INT_HIT_S  int8
        default 0,
    INT_HIT_T  float8
        default 0,
    TCP_R      int4
        default 0,
    TCP_S      int8
        default 0,
    TCP_T      float8
        default 0,
    TCP_HIT_R  int4
        default 0,
    TCP_HIT_S  int8
        default 0,
    TCP_HIT_T  float8
        default 0,
    PEER_R     int4
        default 0,
    PEER_S     int8
        default 0,
    PEER_T     float8
        default 0,
    PARENT_R   int4
        default 0,
    PARENT_S   int8
        default 0,
    PARENT_T   float8
        default 0,
    DIRECT_R   int4
        default 0,
    DIRECT_S   int8
        default 0,
    DIRECT_T   float8
        default 0,
    constraint pk_sf_peak primary key (I2ID),
    constraint fk_sf_peak foreign key (I2ID) references SF_STAMP2 (I2ID)
);

-- ============================================================
-- ACLs
-- ============================================================
-- Sorry, grant in PostGreSQL is not perfect, granting select to
-- anybody will remove the altering ability for the owner...
-- grant select on sf_meta to public;
-- grant select on sf_stamp1 to public;
-- grant select on sf_stamp2 to public;
-- grant select on sf_status to public;
-- grant select on sf_hier_peer to public;
-- grant select on sf_hier_direct to public;
-- grant select on sf_internal to public;
-- grant select on sf_method to public;
-- grant select on sf_scheme to public;
-- grant select on sf_tld to public;
-- grant select on sf_sld to public;
-- grant select on sf_mime to public;
-- grant select on sf_udp_client to public;
-- grant select on sf_int_client to public;
-- grant select on sf_tcp_client to public;
-- grant select on sf_as to public;
-- grant select on sf_peak to public;

