-- ============================================================
--   Database name:  MODEL_6                                   
--   DBMS name:      ANSI Level 2                              
--   Created on:     28.10.99  17:32                           
-- ============================================================

-- ============================================================
--   Table: SF_META                                            
-- ============================================================
create table SF_META
(
    TSID1      INTEGER               not null,
    TSID2      INTEGER               not null
);

insert into SF_META values 
(
    0,
    0
);

-- ============================================================
--   Table: SF_STAMP1                                          
-- ============================================================
create table SF_STAMP1
(
    I1ID       INTEGER               not null,
    CACHE      VARCHAR(48)           not null,
    FIRST      NUMERIC(10)           not null,
    START      NUMERIC(10)
        default 0,
    SOFF       NUMERIC(5)                    
        default 0,
    LAST       NUMERIC(10)                   
        default 0,
    FOFF       NUMERIC(5)                    
        default 0,
    IV_REAL    NUMERIC(8)                    
        default 0,
    IV_CONF    NUMERIC(8)                    
        default 86400,
    primary key (I1ID),
    unique (CACHE, FIRST)
);

-- ============================================================
--   Table: SF_STAMP2                                          
-- ============================================================
create table SF_STAMP2
(
    I2ID       INTEGER               not null,
    CACHE      VARCHAR(48)           not null,
    FIRST      NUMERIC(10)           not null,
    SOFF       NUMERIC(5)                    
        default 0,
    IV_CONF    NUMERIC(8)                    
        default 3600,
    primary key (I2ID),
    unique (CACHE, FIRST)
);

-- ============================================================
--   Table: SF_UDP_MISS                                        
-- ============================================================
create table SF_UDP_MISS
(
    I1ID       INTEGER               not null,
    STATUS     VARCHAR(20)           not null,
    R          NUMERIC(16)                   
        default 0,
    S          NUMERIC(24)                   
        default 0,
    T          NUMERIC(12,3)                 
        default 0,
    primary key (I1ID, STATUS)
);

-- ============================================================
--   Table: SF_UDP_HIT                                         
-- ============================================================
create table SF_UDP_HIT
(
    I1ID       INTEGER               not null,
    STATUS     VARCHAR(20)           not null,
    R          NUMERIC(16)                   
        default 0,
    S          NUMERIC(24)                   
        default 0,
    T          NUMERIC(12,3)                 
        default 0,
    primary key (I1ID, STATUS)
);

-- ============================================================
--   Table: SF_TCP_MISS                                        
-- ============================================================
create table SF_TCP_MISS
(
    I1ID       INTEGER               not null,
    STATUS     VARCHAR(20)           not null,
    R          NUMERIC(16)                   
        default 0,
    S          NUMERIC(24)                   
        default 0,
    T          NUMERIC(12,3)                 
        default 0,
    primary key (I1ID, STATUS)
);

-- ============================================================
--   Table: SF_TCP_HIT                                         
-- ============================================================
create table SF_TCP_HIT
(
    I1ID       INTEGER               not null,
    STATUS     VARCHAR(20)           not null,
    R          NUMERIC(16)                   
        default 0,
    S          NUMERIC(24)                   
        default 0,
    T          NUMERIC(12,3)                 
        default 0,
    primary key (I1ID, STATUS)
);

-- ============================================================
--   Table: SF_TCP_NONE                                        
-- ============================================================
create table SF_TCP_NONE
(
    I1ID       INTEGER               not null,
    STATUS     VARCHAR(20)           not null,
    R          NUMERIC(16)                   
        default 0,
    S          NUMERIC(24)                   
        default 0,
    T          NUMERIC(12,3)                 
        default 0,
    primary key (I1ID, STATUS)
);

-- ============================================================
--   Table: SF_HIER_PEER                                       
-- ============================================================
create table SF_HIER_PEER
(
    I1ID       INTEGER               not null,
    CODE       VARCHAR(32)           not null,
    HOST       VARCHAR(64)           not null,
    R          NUMERIC(16)                   
        default 0,
    S          NUMERIC(24)                   
        default 0,
    T          NUMERIC(12,3)                 
        default 0,
    primary key (I1ID, CODE, HOST)
);

-- ============================================================
--   Table: SF_HIER_PARENT                                     
-- ============================================================
create table SF_HIER_PARENT
(
    I1ID       INTEGER               not null,
    CODE       VARCHAR(32)           not null,
    HOST       VARCHAR(64)           not null,
    R          NUMERIC(16)                   
        default 0,
    S          NUMERIC(24)                   
        default 0,
    T          NUMERIC(12,3)                 
        default 0,
    primary key (I1ID, CODE, HOST)
);

-- ============================================================
--   Table: SF_METHOD                                          
-- ============================================================
create table SF_METHOD
(
    I1ID       INTEGER               not null,
    METHOD     VARCHAR(20)           not null,
    R          NUMERIC(16)                   
        default 0,
    S          NUMERIC(24)                   
        default 0,
    T          NUMERIC(12,3)                 
        default 0,
    HITR       NUMERIC(16)                   
        default 0,
    HITS       NUMERIC(24)                   
        default 0,
    HITT       NUMERIC(12,3)                 
        default 0,
    primary key (I1ID, METHOD)
);

-- ============================================================
--   Table: SF_SCHEME                                          
-- ============================================================
create table SF_SCHEME
(
    I1ID       INTEGER               not null,
    SCHEME     VARCHAR(20)           not null,
    R          NUMERIC(16)                   
        default 0,
    S          NUMERIC(24)                   
        default 0,
    T          NUMERIC(12,3)                 
        default 0,
    HITR       NUMERIC(16)                   
        default 0,
    HITS       NUMERIC(24)                   
        default 0,
    HITT       NUMERIC(12,3)                 
        default 0,
    primary key (I1ID, SCHEME)
);

-- ============================================================
--   Table: SF_TLD                                             
-- ============================================================
create table SF_TLD
(
    I1ID       INTEGER               not null,
    TLD        VARCHAR(10)           not null,
    R          NUMERIC(16)                   
        default 0,
    S          NUMERIC(24)                   
        default 0,
    T          NUMERIC(12,3)                 
        default 0,
    HITR       NUMERIC(16)                   
        default 0,
    HITS       NUMERIC(24)                   
        default 0,
    HITT       NUMERIC(12,3)                 
        default 0,
    primary key (I1ID, TLD)
);

-- ============================================================
--   Table: SF_SLD                                             
-- ============================================================
create table SF_SLD
(
    I1ID       INTEGER               not null,
    SLD        VARCHAR(64)           not null,
    R          NUMERIC(16)                   
        default 0,
    S          NUMERIC(24)                   
        default 0,
    T          NUMERIC(12,3)                 
        default 0,
    HITR       NUMERIC(16)                   
        default 0,
    HITS       NUMERIC(24)                   
        default 0,
    HITT       NUMERIC(12,3)                 
        default 0,
    primary key (I1ID, SLD)
);

-- ============================================================
--   Table: SF_MIME                                            
-- ============================================================
create table SF_MIME
(
    I1ID       INTEGER               not null,
    TYPE       VARCHAR(64)           not null,
    R          NUMERIC(16)                   
        default 0,
    S          NUMERIC(24)                   
        default 0,
    T          NUMERIC(12,3)                 
        default 0,
    HITR       NUMERIC(16)                   
        default 0,
    HITS       NUMERIC(24)                   
        default 0,
    HITT       NUMERIC(12,3)                 
        default 0,
    primary key (I1ID, TYPE)
);

-- ============================================================
--   Table: SF_UDP_CLIENT                                      
-- ============================================================
create table SF_UDP_CLIENT
(
    I1ID       INTEGER               not null,
    HOST       VARCHAR(128)          not null,
    R          NUMERIC(16)                   
        default 0,
    S          NUMERIC(24)                   
        default 0,
    T          NUMERIC(12,3)                 
        default 0,
    HITR       NUMERIC(16)                   
        default 0,
    HITS       NUMERIC(24)                   
        default 0,
    HITT       NUMERIC(12,3)                 
        default 0,
    primary key (I1ID, HOST)
);

-- ============================================================
--   Table: SF_TCP_CLIENT                                      
-- ============================================================
create table SF_TCP_CLIENT
(
    I1ID       INTEGER               not null,
    HOST       VARCHAR(128)          not null,
    R          NUMERIC(16)                   
        default 0,
    S          NUMERIC(24)                   
        default 0,
    T          NUMERIC(12,3)                 
        default 0,
    HITR       NUMERIC(16)                   
        default 0,
    HITS       NUMERIC(24)                   
        default 0,
    HITT       NUMERIC(12,3)                 
        default 0,
    MISSR      NUMERIC(16)                   
        default 0,
    MISSS      NUMERIC(24)                   
        default 0,
    MISST      NUMERIC(12,3)                 
        default 0,
    ERRR       NUMERIC(16)                   
        default 0,
    ERRS       NUMERIC(24)                   
        default 0,
    ERRT       NUMERIC(12,3)                 
        default 0,
    primary key (I1ID, HOST)
);

-- ============================================================
--   Table: SF_AS                                              
-- ============================================================
create table SF_AS
(
    I1ID       INTEGER               not null,
    ASN        CHAR(7)               not null,
    DESCR      VARCHAR(128)                  
        default '',
    R          NUMERIC(16)                   
        default 0,
    S          NUMERIC(24)                   
        default 0,
    T          NUMERIC(12,3)                 
        default 0,
    primary key (I1ID, ASN)
);

-- ============================================================
--   Table: SF_PEAK                                            
-- ============================================================
create table SF_PEAK
(
    I2ID       INTEGER               not null,
    UDP_R      NUMERIC(16)                   
        default 0,
    UDP_S      NUMERIC(24)                   
        default 0,
    UDP_T      NUMERIC(12,3)                 
        default 0,
    UDP_HIT_R  NUMERIC(16)                   
        default 0,
    UDP_HIT_S  NUMERIC(24)                   
        default 0,
    UDP_HIT_T  NUMERIC(12,3)                 
        default 0,
    TCP_R      NUMERIC(16)                   
        default 0,
    TCP_S      NUMERIC(24)                   
        default 0,
    TCP_T      NUMERIC(12,3)                 
        default 0,
    TCP_HIT_R  NUMERIC(16)                   
        default 0,
    TCP_HIT_S  NUMERIC(24)                   
        default 0,
    TCP_HIT_T  NUMERIC(12,3)                 
        default 0,
    PEER_R     NUMERIC(16)                   
        default 0,
    PEER_S     NUMERIC(24)                   
        default 0,
    PEER_T     NUMERIC(12,3)                 
        default 0,
    PARENT_R   NUMERIC(16)                   
        default 0,
    PARENT_S   NUMERIC(24)                   
        default 0,
    PARENT_T   NUMERIC(12,3)                 
        default 0,
    DIRECT_R   NUMERIC(16)                   
        default 0,
    DIRECT_S   NUMERIC(24)                   
        default 0,
    DIRECT_T   NUMERIC(12,3)                 
        default 0,
    primary key (I2ID)
);

-- ============================================================
--   Table: SF_HIER_DIRECT                                     
-- ============================================================
create table SF_HIER_DIRECT
(
    I1ID       INTEGER               not null,
    CODE       VARCHAR(32)           not null,
    R          NUMERIC(16)                   
        default 0,
    S          NUMERIC(24)                   
        default 0,
    T          NUMERIC(12,3)                 
        default 0,
    primary key (I1ID, CODE)
);

alter table SF_UDP_MISS
    add foreign key  (I1ID)
       references SF_STAMP1 (I1ID);

alter table SF_UDP_HIT
    add foreign key  (I1ID)
       references SF_STAMP1 (I1ID);

alter table SF_TCP_MISS
    add foreign key  (I1ID)
       references SF_STAMP1 (I1ID);

alter table SF_TCP_HIT
    add foreign key  (I1ID)
       references SF_STAMP1 (I1ID);

alter table SF_TCP_NONE
    add foreign key  (I1ID)
       references SF_STAMP1 (I1ID);

alter table SF_HIER_PEER
    add foreign key  (I1ID)
       references SF_STAMP1 (I1ID);

alter table SF_HIER_PARENT
    add foreign key  (I1ID)
       references SF_STAMP1 (I1ID);

alter table SF_METHOD
    add foreign key  (I1ID)
       references SF_STAMP1 (I1ID);

alter table SF_SCHEME
    add foreign key  (I1ID)
       references SF_STAMP1 (I1ID);

alter table SF_TLD
    add foreign key  (I1ID)
       references SF_STAMP1 (I1ID);

alter table SF_SLD
    add foreign key  (I1ID)
       references SF_STAMP1 (I1ID);

alter table SF_MIME
    add foreign key  (I1ID)
       references SF_STAMP1 (I1ID);

alter table SF_UDP_CLIENT
    add foreign key  (I1ID)
       references SF_STAMP1 (I1ID);

alter table SF_TCP_CLIENT
    add foreign key  (I1ID)
       references SF_STAMP1 (I1ID);

alter table SF_AS
    add foreign key  (I1ID)
       references SF_STAMP1 (I1ID);

alter table SF_PEAK
    add foreign key  (I2ID)
       references SF_STAMP2 (I2ID);

alter table SF_HIER_DIRECT
    add foreign key  (I1ID)
       references SF_STAMP1 (I1ID);

