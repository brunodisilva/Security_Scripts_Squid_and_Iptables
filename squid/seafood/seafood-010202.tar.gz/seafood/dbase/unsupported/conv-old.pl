#! /usr/bin/perl -i.bak -p
#
# use this script to convert pre-xmas'99 database intermediate files into 
# the new format without needing to rerun seafood on the input.
require 5.003;
use strict;
use POSIX;

if ( /^stamp1/ ) {
    chomp;
    my @x = split;
    my $off = $x[3] + 0;
    $main::old = $x[2];
    $main::ts = floor(($x[2]+$off)/$x[7]+0.5)*$x[7] - $off;
    splice( @x, 2, 0, $main::ts );
    $_ = join(' ',@x) . "\n";
} elsif ( ! /^stamp2/ && ! /^peak/ ) {
    s/$main::old/$main::ts/;
}
