#! /usr/bin/perl
require 5.005;
use strict;

my %f1 = ( B => 1, kB => 1024, KB => 1024, MB => 1048576, GB => 1073741824 );
my %f2 = ( ms => 0.001, s => 1.0, h => 3600.0, d => 86400.0 );
my ($host,%keep);
foreach my $fn ( @ARGV ) {
    if ( open( IN, "<$fn" ) ) {
	$/="";			# paragraph mode
	while ( <IN> ) {
	    next unless /^\# HIERARCHY BY HOST/;
	    undef $host;
	    undef %keep;
	    foreach ( split("\n",$_) ) {
		next if /^\# HIER/;
		next if /^-------/;
		next if /^DIRECT to/;
		next if /^SUM    /;
		my @x = split;
		if ( /^[a-z]/ ) {
		    $host = $x[0];
		} elsif ( /^ / ) {
		    my @x = split;
		    # requests
		    $keep{$host}{$x[0]}[0] = $x[1];
		    # estimate size
		    $keep{$host}{$x[0]}[1] = $x[3] * $f1{$x[4]};
		    # estimate duration
		    $keep{$host}{$x[0]}[2] = $x[6] * $f2{$x[7]};
		} else {
		    warn "$fn-$.: $_\n";
		}
	    }
	}
	close(IN);

#	foreach my $host ( keys %keep ) {
#	    foreach my $code ( keys %{$keep{$host}} ) {
#		printf "$host $code %d %.0f %.3f\n", @{$keep{$host}{$code}};
#	    }
#	}

	open( GET, "<../DB/$fn" ) || next;
	open( PUT, ">../DB/$fn.new" ) || next;
	$/="\n";
	while ( <GET> ) {
	    if ( /^hier p/ ) {
		chomp;
		my @x = split;
		$x[5] = $keep{$x[4]}{$x[3]}[0];
		$x[6] = sprintf "%.0f", $keep{$x[4]}{$x[3]}[1];
		$x[7] = sprintf "%.3f", $keep{$x[4]}{$x[3]}[2];
		$_ = join(' ',@x) . "\n";
	    } 
	    print PUT $_;
	}
	close(PUT);
	close(GET);
    } else {
	warn "open($fn): $!\n";
    }
}
