-- ============================================================
--   Database name:  MODEL_6                                   
--   DBMS name:      INFORMIX SQL 7.1                          
--   Created on:     28.10.99  17:14                           
-- ============================================================

-- ============================================================
--   Table: SF_META                                            
-- ============================================================
create table SF_META
(
    TSID1      INTEGER                not null,
    TSID2      INTEGER                not null
);

insert into SF_META values 
(
    0,
    0
);

-- ============================================================
--   Table: SF_STAMP1                                          
-- ============================================================
create table SF_STAMP1
(
    I1ID       INTEGER                not null,
    CACHE      VARCHAR(48)            not null,
    FIRST      NUMERIC(10)            not null,
    START      NUMERIC(10)            default 0         ,
    SOFF       NUMERIC(5)             default 0         ,
    LAST       NUMERIC(10)            default 0         ,
    FOFF       NUMERIC(5)             default 0         ,
    IV_REAL    NUMERIC(8)             default 0         ,
    IV_CONF    NUMERIC(8)             default 86400     ,
    primary key (I1ID) constraint PK_SF_STAMP1,
    unique (CACHE, FIRST) constraint AK_AK_STAMP1_01_SF
);

-- ============================================================
--   Table: SF_STAMP2                                          
-- ============================================================
create table SF_STAMP2
(
    I2ID       INTEGER                not null,
    CACHE      VARCHAR(48)            not null,
    FIRST      NUMERIC(10)            not null,
    SOFF       NUMERIC(5)             default 0         ,
    IV_CONF    NUMERIC(8)             default 3600         ,
    primary key (I2ID) constraint PK_SF_STAMP2,
    unique (CACHE, FIRST) constraint AK_AK_STAMP1_012_S
);

-- ============================================================
--   Table: SF_UDP_MISS                                        
-- ============================================================
create table SF_UDP_MISS
(
    I1ID       INTEGER                not null,
    STATUS     VARCHAR(20)            not null,
    R          NUMERIC(16)            default 0         ,
    S          NUMERIC(24)            default 0         ,
    T          NUMERIC(12,3)          default 0         ,
    primary key (I1ID, STATUS) constraint PK_SF_UDP_MISS
);

-- ============================================================
--   Table: SF_UDP_HIT                                         
-- ============================================================
create table SF_UDP_HIT
(
    I1ID       INTEGER                not null,
    STATUS     VARCHAR(20)            not null,
    R          NUMERIC(16)            default 0         ,
    S          NUMERIC(24)            default 0         ,
    T          NUMERIC(12,3)          default 0         ,
    primary key (I1ID, STATUS) constraint PK_SF_UDP_HIT
);

-- ============================================================
--   Table: SF_TCP_MISS                                        
-- ============================================================
create table SF_TCP_MISS
(
    I1ID       INTEGER                not null,
    STATUS     VARCHAR(20)            not null,
    R          NUMERIC(16)            default 0         ,
    S          NUMERIC(24)            default 0         ,
    T          NUMERIC(12,3)          default 0         ,
    primary key (I1ID, STATUS) constraint PK_SF_TCP_MISS
);

-- ============================================================
--   Table: SF_TCP_HIT                                         
-- ============================================================
create table SF_TCP_HIT
(
    I1ID       INTEGER                not null,
    STATUS     VARCHAR(20)            not null,
    R          NUMERIC(16)            default 0         ,
    S          NUMERIC(24)            default 0         ,
    T          NUMERIC(12,3)          default 0         ,
    primary key (I1ID, STATUS) constraint PK_SF_TCP_HIT
);

-- ============================================================
--   Table: SF_TCP_NONE                                        
-- ============================================================
create table SF_TCP_NONE
(
    I1ID       INTEGER                not null,
    STATUS     VARCHAR(20)            not null,
    R          NUMERIC(16)            default 0         ,
    S          NUMERIC(24)            default 0         ,
    T          NUMERIC(12,3)          default 0         ,
    primary key (I1ID, STATUS) constraint PK_SF_TCP_NONE
);

-- ============================================================
--   Table: SF_HIER_PEER                                       
-- ============================================================
create table SF_HIER_PEER
(
    I1ID       INTEGER                not null,
    CODE       VARCHAR(32)            not null,
    HOST       VARCHAR(64)            not null,
    R          NUMERIC(16)            default 0         ,
    S          NUMERIC(24)            default 0         ,
    T          NUMERIC(12,3)          default 0         ,
    primary key (I1ID, CODE, HOST) constraint PK_SF_HIER_PEER
);

-- ============================================================
--   Table: SF_HIER_PARENT                                     
-- ============================================================
create table SF_HIER_PARENT
(
    I1ID       INTEGER                not null,
    CODE       VARCHAR(32)            not null,
    HOST       VARCHAR(64)            not null,
    R          NUMERIC(16)            default 0         ,
    S          NUMERIC(24)            default 0         ,
    T          NUMERIC(12,3)          default 0         ,
    primary key (I1ID, CODE, HOST) constraint PK_SF_HIER_PARENT
);

-- ============================================================
--   Table: SF_METHOD                                          
-- ============================================================
create table SF_METHOD
(
    I1ID       INTEGER                not null,
    METHOD     VARCHAR(20)            not null,
    R          NUMERIC(16)            default 0         ,
    S          NUMERIC(24)            default 0         ,
    T          NUMERIC(12,3)          default 0         ,
    HITR       NUMERIC(16)            default 0         ,
    HITS       NUMERIC(24)            default 0         ,
    HITT       NUMERIC(12,3)          default 0         ,
    primary key (I1ID, METHOD) constraint PK_SF_METHOD
);

-- ============================================================
--   Table: SF_SCHEME                                          
-- ============================================================
create table SF_SCHEME
(
    I1ID       INTEGER                not null,
    SCHEME     VARCHAR(20)            not null,
    R          NUMERIC(16)            default 0         ,
    S          NUMERIC(24)            default 0         ,
    T          NUMERIC(12,3)          default 0         ,
    HITR       NUMERIC(16)            default 0         ,
    HITS       NUMERIC(24)            default 0         ,
    HITT       NUMERIC(12,3)          default 0         ,
    primary key (I1ID, SCHEME) constraint PK_SF_SCHEME
);

-- ============================================================
--   Table: SF_TLD                                             
-- ============================================================
create table SF_TLD
(
    I1ID       INTEGER                not null,
    TLD        VARCHAR(10)            not null,
    R          NUMERIC(16)            default 0         ,
    S          NUMERIC(24)            default 0         ,
    T          NUMERIC(12,3)          default 0         ,
    HITR       NUMERIC(16)            default 0         ,
    HITS       NUMERIC(24)            default 0         ,
    HITT       NUMERIC(12,3)          default 0         ,
    primary key (I1ID, TLD) constraint PK_SF_TLD
);

-- ============================================================
--   Table: SF_SLD                                             
-- ============================================================
create table SF_SLD
(
    I1ID       INTEGER                not null,
    SLD        VARCHAR(64)            not null,
    R          NUMERIC(16)            default 0         ,
    S          NUMERIC(24)            default 0         ,
    T          NUMERIC(12,3)          default 0         ,
    HITR       NUMERIC(16)            default 0         ,
    HITS       NUMERIC(24)            default 0         ,
    HITT       NUMERIC(12,3)          default 0         ,
    primary key (I1ID, SLD) constraint PK_SF_SLD
);

-- ============================================================
--   Table: SF_MIME                                            
-- ============================================================
create table SF_MIME
(
    I1ID       INTEGER                not null,
    TYPE       VARCHAR(64)            not null,
    R          NUMERIC(16)            default 0         ,
    S          NUMERIC(24)            default 0         ,
    T          NUMERIC(12,3)          default 0         ,
    HITR       NUMERIC(16)            default 0         ,
    HITS       NUMERIC(24)            default 0         ,
    HITT       NUMERIC(12,3)          default 0         ,
    primary key (I1ID, TYPE) constraint PK_SF_MIME
);

-- ============================================================
--   Table: SF_UDP_CLIENT                                      
-- ============================================================
create table SF_UDP_CLIENT
(
    I1ID       INTEGER                not null,
    HOST       VARCHAR(128)           not null,
    R          NUMERIC(16)            default 0         ,
    S          NUMERIC(24)            default 0         ,
    T          NUMERIC(12,3)          default 0         ,
    HITR       NUMERIC(16)            default 0         ,
    HITS       NUMERIC(24)            default 0         ,
    HITT       NUMERIC(12,3)          default 0         ,
    primary key (I1ID, HOST) constraint PK_SF_UDP_CLIENT
);

-- ============================================================
--   Table: SF_TCP_CLIENT                                      
-- ============================================================
create table SF_TCP_CLIENT
(
    I1ID       INTEGER                not null,
    HOST       VARCHAR(128)           not null,
    R          NUMERIC(16)            default 0         ,
    S          NUMERIC(24)            default 0         ,
    T          NUMERIC(12,3)          default 0         ,
    HITR       NUMERIC(16)            default 0         ,
    HITS       NUMERIC(24)            default 0         ,
    HITT       NUMERIC(12,3)          default 0         ,
    MISSR      NUMERIC(16)            default 0         ,
    MISSS      NUMERIC(24)            default 0         ,
    MISST      NUMERIC(12,3)          default 0         ,
    ERRR       NUMERIC(16)            default 0         ,
    ERRS       NUMERIC(24)            default 0         ,
    ERRT       NUMERIC(12,3)          default 0         ,
    primary key (I1ID, HOST) constraint PK_SF_TCP_CLIENT
);

-- ============================================================
--   Table: SF_AS                                              
-- ============================================================
create table SF_AS
(
    I1ID       INTEGER                not null,
    ASN        CHAR(7)                not null,
    DESCR      VARCHAR(128)           default "''"         ,
    R          NUMERIC(16)            default 0         ,
    S          NUMERIC(24)            default 0         ,
    T          NUMERIC(12,3)          default 0         ,
    primary key (I1ID, ASN) constraint PK_SF_AS
);

-- ============================================================
--   Table: SF_PEAK                                            
-- ============================================================
create table SF_PEAK
(
    I2ID       INTEGER                not null,
    UDP_R      NUMERIC(16)            default 0         ,
    UDP_S      NUMERIC(24)            default 0         ,
    UDP_T      NUMERIC(12,3)          default 0         ,
    UDP_HIT_R  NUMERIC(16)            default 0         ,
    UDP_HIT_S  NUMERIC(24)            default 0         ,
    UDP_HIT_T  NUMERIC(12,3)          default 0         ,
    TCP_R      NUMERIC(16)            default 0         ,
    TCP_S      NUMERIC(24)            default 0         ,
    TCP_T      NUMERIC(12,3)          default 0         ,
    TCP_HIT_R  NUMERIC(16)            default 0         ,
    TCP_HIT_S  NUMERIC(24)            default 0         ,
    TCP_HIT_T  NUMERIC(12,3)          default 0         ,
    PEER_R     NUMERIC(16)            default 0         ,
    PEER_S     NUMERIC(24)            default 0         ,
    PEER_T     NUMERIC(12,3)          default 0         ,
    PARENT_R   NUMERIC(16)            default 0         ,
    PARENT_S   NUMERIC(24)            default 0         ,
    PARENT_T   NUMERIC(12,3)          default 0         ,
    DIRECT_R   NUMERIC(16)            default 0         ,
    DIRECT_S   NUMERIC(24)            default 0         ,
    DIRECT_T   NUMERIC(12,3)          default 0         ,
    primary key (I2ID) constraint PK_SF_PEAK
);

-- ============================================================
--   Table: SF_HIER_DIRECT                                     
-- ============================================================
create table SF_HIER_DIRECT
(
    I1ID       INTEGER                not null,
    CODE       VARCHAR(32)            not null,
    R          NUMERIC(16)            default 0         ,
    S          NUMERIC(24)            default 0         ,
    T          NUMERIC(12,3)          default 0         ,
    primary key (I1ID, CODE) constraint PK_SF_HIER_DIRECT
);

alter table SF_UDP_MISS
    add constraint (foreign key  (I1ID)
       references SF_STAMP1 (I1ID) constraint FK_SF_UDP_M_REF_69);

alter table SF_UDP_HIT
    add constraint (foreign key  (I1ID)
       references SF_STAMP1 (I1ID) constraint FK_SF_UDP_H_REF_68);

alter table SF_TCP_MISS
    add constraint (foreign key  (I1ID)
       references SF_STAMP1 (I1ID) constraint FK_SF_TCP_M_REF_68);

alter table SF_TCP_HIT
    add constraint (foreign key  (I1ID)
       references SF_STAMP1 (I1ID) constraint FK_SF_TCP_H_REF_68);

alter table SF_TCP_NONE
    add constraint (foreign key  (I1ID)
       references SF_STAMP1 (I1ID) constraint FK_SF_TCP_N_REF_67);

alter table SF_HIER_PEER
    add constraint (foreign key  (I1ID)
       references SF_STAMP1 (I1ID) constraint FK_SF_HIER__REF_64);

alter table SF_HIER_PARENT
    add constraint (foreign key  (I1ID)
       references SF_STAMP1 (I1ID) constraint FK_SF_HIER__REF_64);

alter table SF_METHOD
    add constraint (foreign key  (I1ID)
       references SF_STAMP1 (I1ID) constraint FK_SF_METHO_REF_65);

alter table SF_SCHEME
    add constraint (foreign key  (I1ID)
       references SF_STAMP1 (I1ID) constraint FK_SF_SCHEM_REF_65);

alter table SF_TLD
    add constraint (foreign key  (I1ID)
       references SF_STAMP1 (I1ID) constraint FK_SF_TLD_REF_661_);

alter table SF_SLD
    add constraint (foreign key  (I1ID)
       references SF_STAMP1 (I1ID) constraint FK_SF_SLD_REF_664_);

alter table SF_MIME
    add constraint (foreign key  (I1ID)
       references SF_STAMP1 (I1ID) constraint FK_SF_MIME_REF_667);

alter table SF_UDP_CLIENT
    add constraint (foreign key  (I1ID)
       references SF_STAMP1 (I1ID) constraint FK_SF_UDP_C_REF_67);

alter table SF_TCP_CLIENT
    add constraint (foreign key  (I1ID)
       references SF_STAMP1 (I1ID) constraint FK_SF_TCP_C_REF_67);

alter table SF_AS
    add constraint (foreign key  (I1ID)
       references SF_STAMP1 (I1ID) constraint FK_SF_AS_REF_670_S);

alter table SF_PEAK
    add constraint (foreign key  (I2ID)
       references SF_STAMP2 (I2ID) constraint FK_SF_PEAK_REF_694);

alter table SF_HIER_DIRECT
    add constraint (foreign key  (I1ID)
       references SF_STAMP1 (I1ID) constraint FK_SF_HIER__REF_70);

