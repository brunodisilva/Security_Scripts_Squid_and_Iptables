create table SF_META
(
    TSID1      INTEGER               not null,
    TSID2      INTEGER               not null
);

insert into SF_META values 
(
    0,
    0
);

create table SF_STAMP1
(
    I1ID       INTEGER               not null,
    CACHE      VARCHAR(48)           not null,
    FIRST      NUMERIC(10)           not null,
    START      NUMERIC(10)
        default 0,
    SOFF       NUMERIC(5)                    
        default 0,
    LAST       NUMERIC(10)                   
        default 0,
    FOFF       NUMERIC(5)                    
        default 0,
    IV_REAL    NUMERIC(8)                    
        default 0,
    IV_CONF    NUMERIC(8)                    
        default 86400,
    primary key (I1ID),
    unique (CACHE, FIRST)
);

create table SF_STAMP2
(
    I2ID       INTEGER               not null,
    CACHE      VARCHAR(48)           not null,
    FIRST      NUMERIC(10)           not null,
    SOFF       NUMERIC(5)                    
        default 0,
    IV_CONF    NUMERIC(8)                    
        default 3600,
    primary key (I2ID),
    unique (CACHE, FIRST)
);

create table SF_UDP_MISS
(
    I1ID       INTEGER               not null,
    STATUS     VARCHAR(20)           not null,
    R          NUMERIC(16)                   
        default 0,
    S          NUMERIC(24)                   
        default 0,
    T          NUMERIC(12,3)                 
        default 0,
    primary key (I1ID, STATUS),
    foreign key  (I1ID)
       references SF_STAMP1 (I1ID)
);

create table SF_UDP_HIT
(
    I1ID       INTEGER               not null,
    STATUS     VARCHAR(20)           not null,
    R          NUMERIC(16)                   
        default 0,
    S          NUMERIC(24)                   
        default 0,
    T          NUMERIC(12,3)                 
        default 0,
    primary key (I1ID, STATUS),
    foreign key  (I1ID)
       references SF_STAMP1 (I1ID)
);

create table SF_TCP_MISS
(
    I1ID       INTEGER               not null,
    STATUS     VARCHAR(20)           not null,
    R          NUMERIC(16)                   
        default 0,
    S          NUMERIC(24)                   
        default 0,
    T          NUMERIC(12,3)                 
        default 0,
    primary key (I1ID, STATUS),
    foreign key  (I1ID)
       references SF_STAMP1 (I1ID)
);

create table SF_TCP_HIT
(
    I1ID       INTEGER               not null,
    STATUS     VARCHAR(20)           not null,
    R          NUMERIC(16)                   
        default 0,
    S          NUMERIC(24)                   
        default 0,
    T          NUMERIC(12,3)                 
        default 0,
    primary key (I1ID, STATUS),
    foreign key  (I1ID)
       references SF_STAMP1 (I1ID)
);

create table SF_TCP_NONE
(
    I1ID       INTEGER               not null,
    STATUS     VARCHAR(20)           not null,
    R          NUMERIC(16)                   
        default 0,
    S          NUMERIC(24)                   
        default 0,
    T          NUMERIC(12,3)                 
        default 0,
    primary key (I1ID, STATUS),
    foreign key  (I1ID)
       references SF_STAMP1 (I1ID)
);

create table SF_HIER_PEER
(
    I1ID       INTEGER               not null,
    CODE       VARCHAR(32)           not null,
    HOST       VARCHAR(64)           not null,
    R          NUMERIC(16)                   
        default 0,
    S          NUMERIC(24)                   
        default 0,
    T          NUMERIC(12,3)                 
        default 0,
    primary key (I1ID, CODE, HOST),
    foreign key  (I1ID)
       references SF_STAMP1 (I1ID)
);

create table SF_HIER_PARENT
(
    I1ID       INTEGER               not null,
    CODE       VARCHAR(32)           not null,
    HOST       VARCHAR(64)           not null,
    R          NUMERIC(16)                   
        default 0,
    S          NUMERIC(24)                   
        default 0,
    T          NUMERIC(12,3)                 
        default 0,
    primary key (I1ID, CODE, HOST),
    foreign key  (I1ID)
       references SF_STAMP1 (I1ID)
);

create table SF_METHOD
(
    I1ID       INTEGER               not null,
    METHOD     VARCHAR(20)           not null,
    R          NUMERIC(16)                   
        default 0,
    S          NUMERIC(24)                   
        default 0,
    T          NUMERIC(12,3)                 
        default 0,
    HITR       NUMERIC(16)                   
        default 0,
    HITS       NUMERIC(24)                   
        default 0,
    HITT       NUMERIC(12,3)                 
        default 0,
    primary key (I1ID, METHOD),
    foreign key  (I1ID)
       references SF_STAMP1 (I1ID)
);

create table SF_SCHEME
(
    I1ID       INTEGER               not null,
    SCHEME     VARCHAR(20)           not null,
    R          NUMERIC(16)                   
        default 0,
    S          NUMERIC(24)                   
        default 0,
    T          NUMERIC(12,3)                 
        default 0,
    HITR       NUMERIC(16)                   
        default 0,
    HITS       NUMERIC(24)                   
        default 0,
    HITT       NUMERIC(12,3)                 
        default 0,
    primary key (I1ID, SCHEME),
    foreign key  (I1ID)
       references SF_STAMP1 (I1ID)
);

create table SF_TLD
(
    I1ID       INTEGER               not null,
    TLD        VARCHAR(10)           not null,
    R          NUMERIC(16)                   
        default 0,
    S          NUMERIC(24)                   
        default 0,
    T          NUMERIC(12,3)                 
        default 0,
    HITR       NUMERIC(16)                   
        default 0,
    HITS       NUMERIC(24)                   
        default 0,
    HITT       NUMERIC(12,3)                 
        default 0,
    primary key (I1ID, TLD),
    foreign key  (I1ID)
       references SF_STAMP1 (I1ID)
);

create table SF_SLD
(
    I1ID       INTEGER               not null,
    SLD        VARCHAR(64)           not null,
    R          NUMERIC(16)                   
        default 0,
    S          NUMERIC(24)                   
        default 0,
    T          NUMERIC(12,3)                 
        default 0,
    HITR       NUMERIC(16)                   
        default 0,
    HITS       NUMERIC(24)                   
        default 0,
    HITT       NUMERIC(12,3)                 
        default 0,
    primary key (I1ID, SLD),
    foreign key  (I1ID)
       references SF_STAMP1 (I1ID)
);

create table SF_MIME
(
    I1ID       INTEGER               not null,
    TYPE       VARCHAR(64)           not null,
    R          NUMERIC(16)                   
        default 0,
    S          NUMERIC(24)                   
        default 0,
    T          NUMERIC(12,3)                 
        default 0,
    HITR       NUMERIC(16)                   
        default 0,
    HITS       NUMERIC(24)                   
        default 0,
    HITT       NUMERIC(12,3)                 
        default 0,
    primary key (I1ID, TYPE),
    foreign key  (I1ID)
       references SF_STAMP1 (I1ID)
);

create table SF_UDP_CLIENT
(
    I1ID       INTEGER               not null,
    HOST       VARCHAR(128)          not null,
    R          NUMERIC(16)                   
        default 0,
    S          NUMERIC(24)                   
        default 0,
    T          NUMERIC(12,3)                 
        default 0,
    HITR       NUMERIC(16)                   
        default 0,
    HITS       NUMERIC(24)                   
        default 0,
    HITT       NUMERIC(12,3)                 
        default 0,
    primary key (I1ID, HOST),
    foreign key  (I1ID)
       references SF_STAMP1 (I1ID)
);

create table SF_TCP_CLIENT
(
    I1ID       INTEGER               not null,
    HOST       VARCHAR(128)          not null,
    R          NUMERIC(16)                   
        default 0,
    S          NUMERIC(24)                   
        default 0,
    T          NUMERIC(12,3)                 
        default 0,
    HITR       NUMERIC(16)                   
        default 0,
    HITS       NUMERIC(24)                   
        default 0,
    HITT       NUMERIC(12,3)                 
        default 0,
    MISSR      NUMERIC(16)                   
        default 0,
    MISSS      NUMERIC(24)                   
        default 0,
    MISST      NUMERIC(12,3)                 
        default 0,
    ERRR       NUMERIC(16)                   
        default 0,
    ERRS       NUMERIC(24)                   
        default 0,
    ERRT       NUMERIC(12,3)                 
        default 0,
    primary key (I1ID, HOST),
    foreign key  (I1ID)
       references SF_STAMP1 (I1ID)
);

create table SF_AS
(
    I1ID       INTEGER               not null,
    ASN        CHAR(7)               not null,
    DESCR      VARCHAR(128)                  
        default '',
    R          NUMERIC(16)                   
        default 0,
    S          NUMERIC(24)                   
        default 0,
    T          NUMERIC(12,3)                 
        default 0,
    primary key (I1ID, ASN),
    foreign key  (I1ID)
       references SF_STAMP1 (I1ID)
);

create table SF_PEAK
(
    I2ID       INTEGER               not null,
    UDP_R      NUMERIC(16)                   
        default 0,
    UDP_S      NUMERIC(24)                   
        default 0,
    UDP_T      NUMERIC(12,3)                 
        default 0,
    UDP_HIT_R  NUMERIC(16)                   
        default 0,
    UDP_HIT_S  NUMERIC(24)                   
        default 0,
    UDP_HIT_T  NUMERIC(12,3)                 
        default 0,
    TCP_R      NUMERIC(16)                   
        default 0,
    TCP_S      NUMERIC(24)                   
        default 0,
    TCP_T      NUMERIC(12,3)                 
        default 0,
    TCP_HIT_R  NUMERIC(16)                   
        default 0,
    TCP_HIT_S  NUMERIC(24)                   
        default 0,
    TCP_HIT_T  NUMERIC(12,3)                 
        default 0,
    PEER_R     NUMERIC(16)                   
        default 0,
    PEER_S     NUMERIC(24)                   
        default 0,
    PEER_T     NUMERIC(12,3)                 
        default 0,
    PARENT_R   NUMERIC(16)                   
        default 0,
    PARENT_S   NUMERIC(24)                   
        default 0,
    PARENT_T   NUMERIC(12,3)                 
        default 0,
    DIRECT_R   NUMERIC(16)                   
        default 0,
    DIRECT_S   NUMERIC(24)                   
        default 0,
    DIRECT_T   NUMERIC(12,3)                 
        default 0,
    primary key (I2ID),
    foreign key  (I2ID)
       references SF_STAMP2 (I2ID)
);

create table SF_HIER_DIRECT
(
    I1ID       INTEGER               not null,
    CODE       VARCHAR(32)           not null,
    R          NUMERIC(16)                   
        default 0,
    S          NUMERIC(24)                   
        default 0,
    T          NUMERIC(12,3)                 
        default 0,
    primary key (I1ID, CODE),
    foreign key  (I1ID)
       references SF_STAMP1 (I1ID)
);

