-- ============================================================
--   Database name:  MODEL_6                                   
--   DBMS name:      INFORMIX SQL 7.1                          
--   Created on:     28.10.99  17:14                           
-- ============================================================

drop table SF_HIER_DIRECT;
drop table SF_PEAK;
drop table SF_AS;
drop table SF_TCP_CLIENT;
drop table SF_UDP_CLIENT;
drop table SF_MIME;
drop table SF_SLD;
drop table SF_TLD;
drop table SF_SCHEME;
drop table SF_METHOD;
drop table SF_HIER_PARENT;
drop table SF_HIER_PEER;
drop table SF_TCP_NONE;
drop table SF_TCP_HIT;
drop table SF_TCP_MISS;
drop table SF_UDP_HIT;
drop table SF_UDP_MISS;
drop table SF_STAMP2;
drop table SF_STAMP1;
drop table SF_META;
