-- ============================================================
--   Database name:  MODEL_6                                   
--   DBMS name:      ANSI Level 2                              
--   Created on:     28.10.99  17:32                           
-- ============================================================

drop table SF_HIER_DIRECT cascade;
drop table SF_PEAK cascade;
drop table SF_AS cascade;
drop table SF_TCP_CLIENT cascade;
drop table SF_UDP_CLIENT cascade;
drop table SF_MIME cascade;
drop table SF_SLD cascade;
drop table SF_TLD cascade;
drop table SF_SCHEME cascade;
drop table SF_METHOD cascade;
drop table SF_HIER_PARENT cascade;
drop table SF_HIER_PEER cascade;
drop table SF_TCP_NONE cascade;
drop table SF_TCP_HIT cascade;
drop table SF_TCP_MISS cascade;
drop table SF_UDP_HIT cascade;
drop table SF_UDP_MISS cascade;
drop table SF_STAMP2 cascade;
drop table SF_STAMP1 cascade;
drop table SF_META cascade;
