-- ============================================================
--   Database name:  MODEL_2
--   DBMS name:      ORACLE Version 7.3
--   Created on:     25.10.99  10:47
-- ============================================================

drop table SF_META cascade constraints
/

drop table SF_HIER_DIRECT cascade constraints
/

drop table SF_PEAK cascade constraints
/

drop table SF_AS cascade constraints
/

drop table SF_TCP_CLIENT cascade constraints
/

drop table SF_INT_CLIENT cascade constraints
/

drop table SF_UDP_CLIENT cascade constraints
/

drop table SF_MIME cascade constraints
/

drop table SF_SLD cascade constraints
/

drop table SF_TLD cascade constraints
/

drop table SF_SUFFIX cascade constraints
/

drop table SF_SCHEME cascade constraints
/

drop table SF_METHOD cascade constraints
/

drop table SF_INTERNAL cascade constraints
/

drop table SF_HIER_PEER cascade constraints
/

drop table SF_STATUS cascade constraints
/

drop table SF_STAMP2 cascade constraints
/

drop table SF_STAMP1 cascade constraints
/
