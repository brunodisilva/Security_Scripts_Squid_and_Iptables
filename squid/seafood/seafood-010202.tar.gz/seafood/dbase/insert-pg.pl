#! /usr/bin/perl
#
# $Id: insert-pg.pl,v 1.1 2000/08/10 13:24:46 voeckler Exp voeckler $
#
require 5.005;
use strict;

use File::Basename;
use lib dirname($0);
use Tables;
use DBI;

#
# some global variables, adjust according to your needs:
#
# $dbhost: the FQDN of the host where the database server resides.
# $dbname: the name of the database driver you are using.
# $dbuser: the username of the login account to the database
# $dbpass: the password for the login onto the database
# $dborg: The organization as needed for DBase authentication
my ($dbhost,$dbname,$dbuser,$dbpass,$dborg);
$dbhost = `hostname` ne "xxgrafzahl\n" ? 'localhost' : 'champux.sean.de';
$dbname = $dbuser = $ENV{LOGNAME};
$dbpass = undef;
$dborg = "dbi:Pg:dbname=$dbuser\@$dbhost:5432";
warn "# starting\n";

# connect to your database
$main::DEBUG=15;
print STDERR "# trying to connect to DB\n";
$main::handle = DBI->connect( $dborg, $dbuser, $dbpass,
			    { RaiseError => 1, AutoCommit => 0 } ) || 
    die "can\'t connect: $DBI::errstr\n";

#
# some error handling in order to roll back mistaken insertions
#
BEGIN {
    $main::skip = -1;
}

$main::skip = 0;
$SIG{INT} = sub { exit(1); };

END {
    if ( $main::skip == 0 ) {
	print STDERR "# last attempt was\n$Tables::stmt\n"
	    if $Tables::stmt;
	$main::handle->rollback();
    }
}

#
# --------------------------------------------------------------- subs
#

sub check_tables ($) {
    # purpose: check for presence of necessary tables in the database
    # paramtr: $handle (IN): query handle for the database
    # returns: dies on missing tables, or returns 1 for success.
    my $handle = shift;
    my $q = "select tablename from pg_tables where tableowner = \'$dbuser\'";
    my $qh = $handle->prepare( $q ) ||
	die "request failure: $DBI::errstr\n";
    my $rc = $qh->execute || die "not ok: $DBI::errstr\n";

    my (%table,@row);
    while ( (@row = $qh->fetchrow_array) ) {
	warn "# found [", join( ':', @row ), "]\n" if ( $main::DEBUG );
	$table{uc($row[0])}++;
    }

    my $table;
    foreach $table ( @main::tables ) {
	if ( $table{$table} != 1 ) {
	    die "Table $table is missing in the database. It seems as if\n" . 
		"the DB creation script was not run. Please create the\n" . 
		"necessary tables and rerun $0.\n";
	}
    }
    1;
}

sub new_timestamp ($$$$\$) {
    # purpose: check for existing entry and generate a new (unique) tsid
    # paramtr: $nr (IN): stamp number
    #          $handle (IN): database handle
    #          $chost (IN): name of (virtual) cache (group)
    #          $stamp (IN): time stamp as reported by seafood
    #          $insertion_mode (IO): reference to insertion mode
    # returns: timestamp id, new or existing, check $insertion_mode
    my ($nr,$handle,$chost,$stamp,$insertion_mode) = @_;
    my @row;

    # check, if the data was already submitted into the database
    my $ch = $handle->prepare( "select I${nr}ID from sf_stamp$nr where " .
			       "cache = \'$chost\' and first = $stamp " ) ||
	die "newstamp->prepare: $DBI::errstr";
    $ch->execute() ||
	die "newstamp->execute: $DBI::errstr";
    @row = $ch->fetchrow_array;
    $ch->finish() ||
	die "newstamp->finish: $DBI::errstr";
    if ( defined $row[0] ) {
	warn "WARNING: SF_STAMP${nr}($stamp,$chost) already in database!\n";
	$$insertion_mode = 1;
	return $row[0];
    } else {
	warn "RETURNING to insertion mode\n" 
	    if ( $$insertion_mode == 1 );
	$$insertion_mode = 0;
    }

    # update time stamp
    my $uh = $handle->prepare( "update sf_meta set TSID$nr = TSID$nr + 1" ) || 
	die "newstamp->prepare: $DBI::errstr";
    $uh->execute() ||
	die "newstamp->update: $DBI::errstr";
    $uh->finish;

    # select last time stamps
    my $qh = $handle->prepare( "select tsid$nr from sf_meta" ) ||
	die "tsid->prepare($DBI::errstr)";
    $qh->execute() || 
	die "tsid->execute($DBI::errstr)";
    @row = $qh->fetchrow_array;
    $qh->finish;

    # print STDERR "# new stamp$nr ID is $row[0]\n";
    $row[0];
}

#
# --------------------------------------------------------------- main
#

print STDERR "# trying to verify tables.\n";
check_tables($main::handle);

# insertion mode for long and short intervals
my $tsid1_mode = 0;
my $tsid2_mode = 0;

print STDERR "# reading input\n";
my (@x,$skip,$key,$lastkey,$tsid1,$tsid2);
while ( <> ) {
    next if /^#/;
    chomp;
    @x = split/ +/;
    $key = lc(shift @x);
    die "illegal key, check the input" unless defined $key;

    # just a short debug output, report each key once, if possible.
    if ( $lastkey ne $key ) {
	print STDERR "# $key...\n" if ( $main::DEBUG );
	$lastkey = $key;
    }

    # the time stamps and peaks need special handling, 
    # the rest will be done via a jumptable approach.
    if ( $key eq 'stamp1' ) {
	if ( $x[1] == 0 || $x[2] == 0 ) {
	    warn "illegal I1 timestamp, entering skipmode\n";
	    $skip=1;
	    next;
	} elsif ( $skip ) {
	    warn "leaving skipmode\n";
	    $skip=0;
	}
	$tsid1 = new_timestamp( 1, $main::handle, $x[0], $x[1], $tsid1_mode );
	&Tables::insert_stamp1( $main::handle, $tsid1, $tsid1_mode, @x );
    } elsif ( $key eq 'stamp2' ) {
	if ( $x[1] == 0 ) {
	    warn "illegal I2 timestamp, entering skipmode\n";
	    $skip=1;
	    next;
	} elsif ( $skip ) {
	    warn "leaving skipmode\n";
	    $skip=0;
	}
	$tsid2 = new_timestamp( 2, $main::handle, $x[0], $x[1], $tsid2_mode );
	&Tables::insert_stamp2( $main::handle, $tsid2, $tsid2_mode, @x );
    } elsif ( $skip ) {
	next;
    } elsif ( $key eq 'peak' ) {
	&Tables::insert_peak( $main::handle, $tsid2, $tsid2_mode, @x );
    } else {
	my $callref = $Tables::jumptable{$key};
	&{$callref}( $main::handle, $tsid1, $tsid1_mode, @x )
	    if ( defined $callref );
    }
}

$main::handle->commit() ||
    die "commit: $DBI::errstr\n";
$main::handle->disconnect() ||
    die "disconnect: $DBI::errstr\n";
$main::skip = 1;
print "SUCCESS!\n";
