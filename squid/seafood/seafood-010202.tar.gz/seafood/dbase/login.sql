define _editor = emacs
set pagesize 24
set pause 'Taste'
set pause on
