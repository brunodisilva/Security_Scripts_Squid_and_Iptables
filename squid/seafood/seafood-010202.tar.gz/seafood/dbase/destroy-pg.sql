-- ============================================================
--   Database name:  MODEL_6
--   Created on:     28.10.99  17:32
-- ============================================================

drop index pk_sf_peak;
drop table SF_PEAK;

drop index pk_sf_as;
drop table SF_AS;

drop index pk_sf_tcp_client;
drop table SF_TCP_CLIENT;

drop index pk_sf_udp_client;
drop table SF_UDP_CLIENT;

drop index pk_sf_int_client;
drop table SF_INT_CLIENT;

drop index pk_sf_mime;
drop table SF_MIME;

drop index pk_sf_sld;
drop table SF_SLD;

drop index pk_sf_tld;
drop table SF_TLD;

drop index pk_sf_suffix;
drop table SF_SUFFIX;

drop index pk_sf_scheme;
drop table SF_SCHEME;

drop index pk_sf_method;
drop table SF_METHOD;

drop index pk_sf_internal;
drop table SF_INTERNAL;

drop index pk_sf_hier_direct;
drop table SF_HIER_DIRECT;

drop index pk_sf_hier_peer;
drop table SF_HIER_PEER;

drop index pk_sf_tcp;
drop table SF_TCP;

drop index pk_sf_status;
drop table SF_STATUS;

drop index ak_sf_stamp2;
drop index pk_sf_stamp2;
drop table SF_STAMP2;

drop index ak_sf_stamp1;
drop index pk_sf_stamp1;
drop table SF_STAMP1;
drop table SF_META;
