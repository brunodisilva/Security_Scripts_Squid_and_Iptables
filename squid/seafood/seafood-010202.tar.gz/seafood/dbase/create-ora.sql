-- ============================================================
--   Database name:  MODEL_2
--   DBMS name:      ORACLE Version 7.3
--   Created on:     25.10.99  10:47
-- ============================================================

-- ============================================================
--   Table: SF_META
-- ============================================================
create table SF_META
(
    TSID1      INTEGER                not null,
    TSID2      INTEGER                not null
)
/

insert into SF_META values ( 0, 0 );

-- ============================================================
--   Table: SF_STAMP1
-- ============================================================
create table SF_STAMP1
(
    I1ID       INTEGER                not null,
    CACHE      VARCHAR2(48)           not null,
    FIRST      NUMBER(10)             not null,
    BEGIN_TS   NUMBER(10)             default 0 null,
    BOFF       NUMBER(5)              default 0 null,
    FINAL      NUMBER(10)             default 0 null,
    FOFF       NUMBER(5)              default 0 null,
    IV_REAL    NUMBER(8)              default 0 null,
    IV_CONF    NUMBER(8)              default 86400 null,
    VERSION    INTEGER                default 0 null,
    constraint PK_SF_STAMP1 primary key (I1ID),
    constraint UK_SF_STAMP1 unique (CACHE, FIRST)
)
/

-- ============================================================
--   Table: SF_STAMP2
-- ============================================================
create table SF_STAMP2
(
    I2ID       INTEGER                not null,
    CACHE      VARCHAR2(48)           not null,
    FIRST      NUMBER(10)             not null,
    SOFF       NUMBER(5)              default 0 null,
    IV_CONF    NUMBER(8)              default 3600 null,
    VERSION    INTEGER                default 0 null,
    constraint PK_SF_STAMP2 primary key (I2ID),
    constraint UK_SF_STAMP2 unique (CACHE, FIRST)
)
/

-- ============================================================
--   Table: SF_STATUS
-- ============================================================
create table SF_STATUS
(
    I1ID       INTEGER                not null,
    STATUS     VARCHAR2(32)           not null,
    HMN_FLAG   CHAR		      not null,
    IS_TCP     CHAR                   default '0' not null,
    R          NUMBER(16)             default 0 null,
    S          NUMBER(24)             default 0 null,
    T          NUMBER(12,3)           default 0 null,
    constraint PK_SF_STATUS primary key (I1ID, STATUS, HMN_FLAG, IS_TCP),
    constraint FK_SF_STATUS foreign key (I1ID) references SF_STAMP1 (I1ID)
)
/

-- ============================================================
--   Table: SF_HIER_PEER
-- ============================================================
create table SF_HIER_PEER
(
    I1ID       INTEGER                not null,
    CODE       VARCHAR2(32)           not null,
    HOST       VARCHAR2(64)           not null,
    IS_PARENT  CHAR                   default '0' null,
    R          NUMBER(16)             default 0 null,
    S          NUMBER(24)             default 0 null,
    T          NUMBER(12,3)           default 0 null,
    constraint PK_SF_HIER_PEER primary key (I1ID, CODE, HOST),
    constraint FK_SF_HIER_PEER foreign key (I1ID) references SF_STAMP1 (I1ID)
)
/

-- ============================================================
--   Table: SF_METHOD
-- ============================================================
create table SF_METHOD
(
    I1ID       INTEGER                not null,
    METHOD     VARCHAR2(20)           not null,
    R          NUMBER(16)             default 0 null,
    S          NUMBER(24)             default 0 null,
    T          NUMBER(12,3)           default 0 null,
    HITR       NUMBER(16)             default 0 null,
    HITS       NUMBER(24)             default 0 null,
    HITT       NUMBER(12,3)           default 0 null,
    constraint PK_SF_METHOD primary key (I1ID, METHOD),
    constraint FK_SF_METHOD foreign key (I1ID) references SF_STAMP1 (I1ID)
)
/

-- ============================================================
--   Table: SF_SCHEME
-- ============================================================
create table SF_SCHEME
(
    I1ID       INTEGER                not null,
    SCHEME     VARCHAR2(20)           not null,
    R          NUMBER(16)             default 0 null,
    S          NUMBER(24)             default 0 null,
    T          NUMBER(12,3)           default 0 null,
    HITR       NUMBER(16)             default 0 null,
    HITS       NUMBER(24)             default 0 null,
    HITT       NUMBER(12,3)           default 0 null,
    constraint PK_SF_SCHEME primary key (I1ID, SCHEME),
    constraint FK_SF_SCHEME foreign key (I1ID) references SF_STAMP1 (I1ID)
)
/

-- ============================================================
--   Table: SF_SUFFIX
-- ============================================================
create table SF_SUFFIX
(
    I1ID       INTEGER                not null,
    SUFFIX     VARCHAR2(20)           not null,
    R          NUMBER(16)             default 0 null,
    S          NUMBER(24)             default 0 null,
    T          NUMBER(12,3)           default 0 null,
    HITR       NUMBER(16)             default 0 null,
    HITS       NUMBER(24)             default 0 null,
    HITT       NUMBER(12,3)           default 0 null,
    constraint PK_SF_SUFFIX primary key (I1ID, SUFFIX),
    constraint FK_SF_SUFFIX foreign key (I1ID) references SF_STAMP1 (I1ID)
)
/

-- ============================================================
--   Table: SF_TLD
-- ============================================================
create table SF_TLD
(
    I1ID       INTEGER                not null,
    TLD        VARCHAR2(10)           not null,
    R          NUMBER(16)             default 0 null,
    S          NUMBER(24)             default 0 null,
    T          NUMBER(12,3)           default 0 null,
    HITR       NUMBER(16)             default 0 null,
    HITS       NUMBER(24)             default 0 null,
    HITT       NUMBER(12,3)           default 0 null,
    constraint PK_SF_TLD primary key (I1ID, TLD),
    constraint FK_SF_TLD foreign key (I1ID) references SF_STAMP1 (I1ID)
)
/

-- ============================================================
--   Table: SF_SLD
-- ============================================================
create table SF_SLD
(
    I1ID       INTEGER                not null,
    SLD        VARCHAR2(64)           not null,
    R          NUMBER(16)             default 0 null,
    S          NUMBER(24)             default 0 null,
    T          NUMBER(12,3)           default 0 null,
    HITR       NUMBER(16)             default 0 null,
    HITS       NUMBER(24)             default 0 null,
    HITT       NUMBER(12,3)           default 0 null,
    constraint PK_SF_SLD primary key (I1ID, SLD),
    constraint FK_SF_SLD foreign key (I1ID) references SF_STAMP1 (I1ID)
)
/

-- ============================================================
--   Table: SF_MIME
-- ============================================================
create table SF_MIME
(
    I1ID       INTEGER                not null,
    TYPE       VARCHAR2(64)           not null,
    R          NUMBER(16)             default 0 null,
    S          NUMBER(24)             default 0 null,
    T          NUMBER(12,3)           default 0 null,
    HITR       NUMBER(16)             default 0 null,
    HITS       NUMBER(24)             default 0 null,
    HITT       NUMBER(12,3)           default 0 null,
    constraint PK_SF_MIME primary key (I1ID, TYPE),
    constraint FK_SF_MIME foreign key (I1ID) references SF_STAMP1 (I1ID)
)
/

-- ============================================================
--   Table: SF_UDP_CLIENT
-- ============================================================
create table SF_UDP_CLIENT
(
    I1ID       INTEGER                not null,
    HOST       VARCHAR2(128)          not null,
    R          NUMBER(16)             default 0 null,
    S          NUMBER(24)             default 0 null,
    T          NUMBER(12,3)           default 0 null,
    HITR       NUMBER(16)             default 0 null,
    HITS       NUMBER(24)             default 0 null,
    HITT       NUMBER(12,3)           default 0 null,
    constraint PK_SF_UDP_CLIENT primary key (I1ID, HOST),
    constraint FK_SF_UDP_CLIENT foreign key (I1ID) references SF_STAMP1 (I1ID)
)
/

-- ============================================================
--   Table: SF_INT_CLIENT
-- ============================================================
create table SF_INT_CLIENT
(
    I1ID       INTEGER                not null,
    HOST       VARCHAR2(128)          not null,
    R          NUMBER(16)             default 0 null,
    S          NUMBER(24)             default 0 null,
    T          NUMBER(12,3)           default 0 null,
    HITR       NUMBER(16)             default 0 null,
    HITS       NUMBER(24)             default 0 null,
    HITT       NUMBER(12,3)           default 0 null,
    constraint PK_SF_INT_CLIENT primary key (I1ID, HOST),
    constraint FK_SF_INT_CLIENT foreign key (I1ID) references SF_STAMP1 (I1ID)
)
/

-- ============================================================
--   Table: SF_TCP_CLIENT
-- ============================================================
create table SF_TCP_CLIENT
(
    I1ID       INTEGER                not null,
    HOST       VARCHAR2(128)          not null,
    R          NUMBER(16)             default 0 null,
    S          NUMBER(24)             default 0 null,
    T          NUMBER(12,3)           default 0 null,
    HITR       NUMBER(16)             default 0 null,
    HITS       NUMBER(24)             default 0 null,
    HITT       NUMBER(12,3)           default 0 null,
    MISSR      NUMBER(16)             default 0 null,
    MISSS      NUMBER(24)             default 0 null,
    MISST      NUMBER(12,3)           default 0 null,
    ERRR       NUMBER(16)             default 0 null,
    ERRS       NUMBER(24)             default 0 null,
    ERRT       NUMBER(12,3)           default 0 null,
    constraint PK_SF_TCP_CLIENT primary key (I1ID, HOST),
    constraint FK_SF_TCP_CLIENT foreign key (I1ID) references SF_STAMP1 (I1ID)
)
/

-- ============================================================
--   Table: SF_AS
-- ============================================================
create table SF_AS
(
    I1ID       INTEGER                not null,
    ASN        CHAR(7)                not null,
    DESCR      VARCHAR2(128)          default '' null,
    R          NUMBER(16)             default 0 null,
    S          NUMBER(24)             default 0 null,
    T          NUMBER(12,3)           default 0 null,
    constraint PK_SF_AS primary key (I1ID, ASN),
    constraint FK_SF_AS foreign key (I1ID) references SF_STAMP1 (I1ID)
)
/

-- ============================================================
--   Table: SF_PEAK
-- ============================================================
create table SF_PEAK
(
    I2ID       INTEGER                not null,
    UDP_R      NUMBER(16)             default 0 null,
    UDP_S      NUMBER(24)             default 0 null,
    UDP_T      NUMBER(12,3)           default 0 null,
    UDP_HIT_R  NUMBER(16)             default 0 null,
    UDP_HIT_S  NUMBER(24)             default 0 null,
    UDP_HIT_T  NUMBER(12,3)           default 0 null,
    INT_R      NUMBER(16)             default 0 null,
    INT_S      NUMBER(24)             default 0 null,
    INT_T      NUMBER(12,3)           default 0 null,
    INT_HIT_R  NUMBER(16)             default 0 null,
    INT_HIT_S  NUMBER(24)             default 0 null,
    INT_HIT_T  NUMBER(12,3)           default 0 null,
    TCP_R      NUMBER(16)             default 0 null,
    TCP_S      NUMBER(24)             default 0 null,
    TCP_T      NUMBER(12,3)           default 0 null,
    TCP_HIT_R  NUMBER(16)             default 0 null,
    TCP_HIT_S  NUMBER(24)             default 0 null,
    TCP_HIT_T  NUMBER(12,3)           default 0 null,
    PEER_R     NUMBER(16)             default 0 null,
    PEER_S     NUMBER(24)             default 0 null,
    PEER_T     NUMBER(12,3)           default 0 null,
    PARENT_R   NUMBER(16)             default 0 null,
    PARENT_S   NUMBER(24)             default 0 null,
    PARENT_T   NUMBER(12,3)           default 0 null,
    DIRECT_R   NUMBER(16)             default 0 null,
    DIRECT_S   NUMBER(24)             default 0 null,
    DIRECT_T   NUMBER(12,3)           default 0 null,
    constraint PK_SF_PEAK primary key (I2ID),
    constraint FK_SF_PEAK foreign key (I2ID) references SF_STAMP2 (I2ID)
)
/

-- ============================================================
--   Table: SF_HIER_DIRECT
-- ============================================================
create table SF_HIER_DIRECT
(
    I1ID       INTEGER                not null,
    CODE       VARCHAR2(32)           not null,
    R          NUMBER(16)             default 0 null,
    S          NUMBER(24)             default 0 null,
    T          NUMBER(12,3)           default 0 null,
    constraint PK_SF_HIER_DIRECT primary key (I1ID, CODE),
    constraint FK_SF_HIER_DIRECT foreign key (I1ID) references SF_STAMP1 (I1ID)
)
/

-- ============================================================
--   Table: SF_INTERNAL
-- ===========================================================
create table SF_INTERNAL
(
    I1ID       INTEGER                not null,
    URI        VARCHAR2(64)           not null,
    PATH       VARCHAR2(64)           not null,
    R          NUMBER(16)             default 0 null,
    S          NUMBER(24)             default 0 null,
    T          NUMBER(12,3)           default 0 null,
    HITR       NUMBER(16)             default 0 null,
    HITS       NUMBER(24)             default 0 null,
    HITT       NUMBER(12,3)           default 0 null,
    constraint PK_SF_INTERNAL primary key (I1ID, URI, PATH),
    constraint FK_SF_INTERNAL foreign key (I1ID) references SF_STAMP1 (I1ID)
)
/

-- ============================================================
-- ACLs
-- ============================================================
grant select on sf_meta to public;
grant select on sf_stamp1 to public;
grant select on sf_stamp2 to public;
grant select on sf_status to public;
grant select on sf_hier_peer to public;
grant select on sf_hier_direct to public;
grant select on sf_internal to public;
grant select on sf_method to public;
grant select on sf_scheme to public;
grant select on sf_tld to public;
grant select on sf_sld to public;
grant select on sf_mime to public;
grant select on sf_udp_client to public;
grant select on sf_int_client to public;
grant select on sf_tcp_client to public;
grant select on sf_as to public;
grant select on sf_peak to public;
