//
// $Id: irr.hh,v 1.8 1999/10/29 13:48:49 voeckler Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    irr.hh
//          Thu Aug 05 1999
//
// (c) 1999 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: irr.hh,v $
// Revision 1.8  1999/10/29 13:48:49  voeckler
// moved to gdbm cache file format.
//
// Revision 1.7  1999/09/02 10:08:12  voeckler
// removed obsolete old interface, myriads of fixes for getOriginByAddress(),
// added set of network/netmask pairs for host address look ups.
//
// Revision 1.6  1999/08/31 08:48:42  voeckler
// new intermediary revision before removing obsolete items.
//
// Revision 1.5  1999/08/27 20:57:21  voeckler
// removed io stream in favour of standard io, moved IRRItem into
// a class of its own, fixed signedness problems.
//
// Revision 1.4  1999/08/20 22:41:44  voeckler
// added access to the internal map size through the size() method.
//
// Revision 1.3  1999/08/20 12:15:55  voeckler
// left-over bug fixes from NDBM removal. Now includes iostream, as the
// textual database file needs to be streamed.
//
// Revision 1.2  1999/08/15 20:24:33  voeckler
// removed NDBM dependency in favour of a textual database format
// which is (supposed to be) interchangable between different
// platforms.
//
// Revision 1.1  1999/08/05 21:06:01  voeckler
// Initial revision
//
//
#ifndef _IRR_HH
#define _IRR_HH

#if defined(__GNUC__) || defined(__GNUG__)
#pragma interface
#endif

#include "typedefs.h"
#include "string.hh"
#include "strmap.hh"
#include "stringset.hh"
#include "cache.hh"
#include "irritem.hh"
#include "irrcopro.hh"
#include "gdbm.hh"

#include "network.hh"
#include "nwset.hh"

class IRRCache : public BaseCache {
public:
  typedef IRRCoProcess::ItemMap    IRRItemMap;

  IRRCache( size_t nrOfChildren,
	    const char* irrHelper,
	    const char* cacheFile = "/var/tmp/irr",
	    const char* whoisServer = "whois.ra.net",
	    MyUInt32 posTTL = 3600 * 24 * 30,
	    MyUInt32 negTTL = 3600 * 24 * 7 );
  ~IRRCache();

  IRRItemMap getanybyany( const StringSet& what );
  IRRItemMap getOriginByAddress( const StringSet& what );

  inline size_t size() const
    { return count; }

protected:
  const char*  dbfn;
  IRRCoProcess helper;
  GDBM         dbase;
  MyUInt32     count;
  NetworkSet   networks;

private:
  // disallow
  IRRCache( const IRRCache& );
  IRRCache& operator=( const IRRCache& );
};

#endif // _IRR_HH
