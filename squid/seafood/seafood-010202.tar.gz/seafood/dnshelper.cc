//
// $Id: dnshelper.cc,v 1.6 2000/06/09 09:27:17 voeckler Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    dnshelper.cc
//          Tue Aug 24 1999
//
// (c) 1999 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: dnshelper.cc,v $
// Revision 1.6  2000/06/09 09:27:17  voeckler
// fixes for FreeBSD 4.0
//
// Revision 1.5  1999/09/01 22:00:33  voeckler
// fixed some spelling mistakes.
//
// Revision 1.4  1999/08/27 21:51:27  voeckler
// changed String operator() to method c_str() call.
//
// Revision 1.3  1999/08/27 20:44:33  voeckler
// removed io stream dependencies, rewrote to use unified io.
//
// Revision 1.2  1999/08/26 20:05:10  voeckler
// removed dependency on class Global in favour of command line parameters.
// added some IRIX specific things, though those should rather be compiler
// dependent.
//
// Revision 1.1  1999/08/25 21:25:37  voeckler
// Initial revision
//
//
#if defined(__GNUC__) || defined(__GNUG__)
#pragma implementation
#endif

#define _XPG4_2 1 // for Solaris, to use void* instead of char*

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <time.h>
#include <sys/uio.h>

#include "typedefs.h"
#include "ctype.hh"
#include "string.hh"
#include "dnsitem.hh"
#include "rw.hh"

DNSItem
lookup( const String& request, size_t positiveTTL, size_t negativeTTL )
{
  time_t now = time(0);
  struct hostent* h = 0;
  MyUInt32 address =
    ISDIGIT(request[0]) ? inet_addr(request.c_str()) : C_U32(-1);

  if ( address != C_U32(-1) ) {
    h = gethostbyaddr( (char*) &address, sizeof(MyUInt32), AF_INET );
  } else {
    h=gethostbyname(request.c_str());
  }

  if ( h == 0 ) return DNSItem( now + negativeTTL, 0 );
  else return DNSItem( now + positiveTTL, h );
}

inline
void
fill( struct iovec& v, const void* base, size_t size )
{
#ifdef FREEBSD
  v.iov_base = (char*) base;
#else
  v.iov_base = (void*) base;
#endif
  v.iov_len = size;
}

int
main( int argc, char* argv[] )
{
  struct iovec output[5];
  fill( output[2], " ", 1 );
  fill( output[4], "\n", 1 );

  char request[256];
  memset( request, 0, sizeof(request) );

  size_t positiveTTL = 2592000;
  size_t negativeTTL = 604800;
  switch ( argc ) {
  case 3:
    negativeTTL = strtoul( argv[2], 0, 0 );
  case 2:
    positiveTTL = strtoul( argv[1], 0, 0 );
  case 1:
    if ( positiveTTL && negativeTTL ) break;
  default:
    fprintf( stderr, "Usage: %s [posTTL [negTTL]]\n", argv[0] );
    return 1;
  }

  while ( fgets( request, sizeof(request), stdin ) != 0 ) {
    String s( String(request).trim() );
    if ( s.length() == 0 || s[0] == '#' ) {
      if ( write( STDOUT_FILENO, "\n", 1 ) < 1 ) return 1;
    } else {
      if ( s.length() < 2 || ! ISHNAME(s[0]) ) {
	// illegal hostname
	fprintf( stderr, "# weird line: %s", request );
	if ( write( STDOUT_FILENO, "\n", 1 ) < 1 ) return 1;
	continue;
      }

      String result( lookup( s, positiveTTL, negativeTTL ).toString() );
      size_t size = s.length() + 1 + result.length() + 1;

      char sizebuf[16];
      sprintf( sizebuf, "0x%04x ", size );
      fill( output[0], sizebuf, strlen(sizebuf) );
      fill( output[1], s.c_str(), s.length() );
      fill( output[3], result.c_str(), result.length() );

      // try atomic write
      writev( STDOUT_FILENO, output, 5 );
    }
  }
  return 0;
}
