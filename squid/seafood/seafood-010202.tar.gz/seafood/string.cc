//
// $Id: string.cc,v 1.12 2001/02/02 10:33:58 voeckler Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    string.cc
//          Sat Aug  9 1997
//
// (c) 1997 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: string.cc,v $
// Revision 1.12  2001/02/02 10:33:58  voeckler
// separated Minimum() into template and inline of its own.
//
// Revision 1.11  2001/02/02 08:50:11  voeckler
// Fixed char* to const char* complaints from Sun CC.
//
// Revision 1.10  1999/08/27 21:50:40  voeckler
// replaced operator() with the c_str() method.
//
// Revision 1.9  1999/08/22 11:33:02  voeckler
// added c'tor interface for constructing a string of a repeated
// number of the same character.
//
// Revision 1.8  1999/08/05 21:24:26  voeckler
// minor changes, mostly cosmetic.
//
// Revision 1.7  1999/01/18 08:58:57  voeckler
// snapshot.
//
// Revision 1.6  1998/07/23 18:27:01  voeckler
// modified for own ctype use.
//
// Revision 1.5  1998/07/02 09:40:53  voeckler
// defchar is now default_char, and sentinel supplies its own singleton if.
//
// Revision 1.4  1998/06/28 19:46:22  voeckler
// moved string representation to module of its own, now with
// the virtual interface complying to hashes, access to string
// representation now threaded through accessors, added very
// fast method for default ctor via sentinel.
//
// Revision 1.3  1998/06/22 12:05:38  voeckler
// bool handling, mutable internal hash cache, inline handling, non-const
// assigment return values, etc.
//
// Revision 1.2  1997/08/18 11:50:11  voeckler
// cosmetical changes for complaining compilers, new ctor for constructing
// string from substrings of charfields, substitutions added (literal and
// regular expression (emacs like)), added upper(), lower() and trim().
//
// Revision 1.1  1997/08/11 10:10:25  voeckler
// Initial revision
//

#if defined(__GNUC__) || defined(__GNUG__)
#pragma implementation
#endif

#include <memory.h>
#include <string.h>
#include "ctype.hh"  // isXxxx(), toXXXXX()
#include "string.hh"
#include "minimum.hh"

#ifdef USE_REGSTR
#include "regstr.hh"
#endif // USE_REGSTR

#if defined(AIX) || defined(SINIXY)
extern "C" {
int strncasecmp( const char*, const char*, size_t );
}
#endif // old BSD compatibility function

static const char* RCS_ID = 
"$Id: string.cc,v 1.12 2001/02/02 10:33:58 voeckler Exp $";

char String::default_char = 0; // default character for index operations

String::String( const char* str, unsigned size, unsigned start )
  :string(0)
{
  unsigned length = str ? strlen(str) : 0;

  if ( length && size && start<=length ) {
    if ( size+start > length ) size = length-start;
    StringRep* temp = new StringRep(size);
    memmove( (void*) temp->string, str+start, size );
    string = temp;
  } else {
    string = new StringRep(); // default constructor for illegal values
  }
}

String& 
String::operator=( const char* str )
{
  _remove();
  string = new StringRep(str);
  return *this;
}

String& 
String::operator=( const String& s )
{
  if ( this != &s ) {
    _remove();
    string = s.string;
    string->increase();
  }
  return *this;
}
 
String& 
String::operator+=( const char* str )
{
  if ( str && *str ) {
    unsigned second = strlen(str);
    StringRep* temp = new StringRep( string->length() + second );

    memmove( (void*) temp->string, string->content(), string->length()+1 );
    memmove( (void*) (temp->string + string->length()), str, second+1 );
    _remove();
    string = temp;
  }
  return *this;
}

String& 
String::operator+=( const String& s )
{
  unsigned second = s.string->length();
  if ( second ) {
    StringRep* temp = new StringRep( string->length() + second );

    memmove( (void*) temp->string, string->content(), string->length()+1 );
    memmove( (void*) (temp->string + string->length()), s.c_str(), second+1 );
    _remove();
    string = temp;
  }
  return *this;
}

String
String::operator+( const String& s ) 
{
  StringRep* temp = new StringRep( this->length() + s.string->length() );
  memmove( (void*) temp->string, string->content(), string->length()+1 );
  memmove( (void*) (temp->string + string->length()), 
	   s.c_str(), s.string->length()+1 );

  return String(temp);
}

String
String::operator+( const char* str )
{
  if ( str && *str ) {
    unsigned second = str ? strlen(str) : 0;
    StringRep* temp = new StringRep( string->length() + second );

    memmove( (void*) temp->string, string->content(), string->length()+1 );
    memmove( (void*) (temp->string + string->length()), str, second+1 );

    return String(temp);  // protected construction 
  } else {
    return String(*this); // copy construction
  }
}

String
operator+( const String& s1, const char* s2 )
{
  if ( s2 && *s2 ) {
    unsigned second = s2 ? strlen(s2) : 0;
    StringRep* temp = new StringRep( s1.length() + second );
    memmove( (void*) temp->string, s1.c_str(), s1.length()+1 );
    if ( second ) memmove( (void*)( temp->string+s1.length()), s2, second+1 );
    
    return String(temp); // protected construction
  } else {
    return String(s1);   // shallow copy construction
  }
}
 
String
operator+( const char* s1, const String s2 )
{
  if ( s1 && *s1 ) {
    unsigned first  = s1 ? strlen(s1) : 0;
    StringRep* temp = new StringRep( first + s2.length() );
    if ( first ) memmove( (void*) temp->string, s1, first );
    memmove( (void*) (temp->string+first), s2.c_str(), s2.length() );

    return String(temp); // protected construction
  } else {
    return String(s2);   // shallow copy construction 
  }
}

#if 0
String
operator+( const char* s1, const char* s2 )
{
  unsigned first  = s1 ? strlen(s1) : 0;
  unsigned second = s2 ? strlen(s2) : 0;
  StringRep* temp = new StringRep( first + second );
  if ( first ) memmove( (void*) temp->string, s1, first );
  if ( second ) memmove( (void*)( temp->string + first), s2, second );
  *(((char*) temp->string) + first + second) = '\0';
  return String(temp); // protected construction
}
#endif




int 
String::index( char ch, unsigned start ) const
{
  if ( start > string->length() ) return -1;
  const char* temp = strchr( string->content()+start, ch );
  return ( temp ) ? temp - string->content() : -1 ;
}

int 
String::index( const char* s, unsigned start ) const
{
  if ( s && *s ) {
    unsigned len = strlen(s);
    if ( start > string->length() || string->length() == 0 ||
	 start + len > string->length() ) return -1;
    // FIXME: t-search (search.*) should be faster than strstr()!
    const char* temp = strstr( string->content()+start, s );
    return ( temp ) ? temp - string->content() : -1;
  } else 
    return -1;
}

int 
String::index( const String& s, unsigned start ) const
{
  if ( start >= string->length() ||
       s.string->length() == 0 || string->length() == 0 ||
       start + s.string->length() > string->length() ) return -1;
  // FIXME: t-search (search.*) should be faster than strstr()!
  const char* temp = strstr( (string->content() + start), s.c_str() );
  return ( temp ) ? temp - string->content() : -1;
}

int
String::rindex( char ch ) const
{
  const char* temp = strrchr( string->content(), ch );
  return ( temp ) ? temp - string->content() : -1;
}

int 
String::rindex( char ch, unsigned start ) const
{
  const char* temp = string->content();
  if ( start >= string->length() ) return -1;
  for ( register const char* ptr = temp + start; ptr >= temp; ptr-- )
    if ( *ptr == ch ) return ptr - temp;
  return -1;
}

String 
String::substring( unsigned start ) const
{
  if ( start == 0 ) return String(*this); // shallow copy
  else if ( start >= string->length() ) return String();
  else return String( string->content() + start );
}

String 
String::substring( unsigned start, unsigned size ) const
{
  if ( start == 0 && size >= string->length() ) return String(*this);
  else if ( start >= string->length() ) return String();
  else {
    StringRep* temp = new StringRep(size);
    strncpy( (char*) temp->string, string->content() + start, size );
    return String(temp);
  }
}

String
substring( const char* s, unsigned start, unsigned size )
{
  StringRep* result = new StringRep( size );
  memcpy( (void*) result->string, s+start, size );
  *(((char*) result->string) + size) = '\0';
  return String(result);
}

String
String::substitute( const String from, const String to, bool global, 
		    unsigned start )
{
  int i;
  String result( substring(0,start) );

  while ( (i=index(from,start)) >= 0 ) {
    result += substring( start, i-start ) + to;
    start = i + from.length();
    if ( ! global ) break;
  }
  if ( start < length() ) result += substring( start );
  return result;
}

#ifdef USE_REGSTR

String
String::substitute( RegExp& from, const String to, bool global,
		    unsigned start )
  // purpose: do a sed like substitution, allow variable delimiters
  // paramtr: from (IN): regular expression, may contain up to 9 () pairs
  //          to (IN): replacement, may contain \1..\9 like in emacs
  //          global (IN): true:=replace every occurence, false:=only first
  // returns: new string with substitutions
{
  String temp;
  Matches sub;
  String result( substring(0,start) );
  String local("\\\\");
  int i = 0;

  do {
    // match re and all subexpressions
    int nr = from.gmatch( sub, *this, start );
    if ( nr < 0 ) break;

    // find start of main expression
    i = index( sub[0], start );

    // replace \0 with complete expression, \1..\9 with subexpressions
    // basically, this is a tiny fsm!
    temp = substring( start, i-start ) + to;
    unsigned size = i-start;
    int state = 0;
    for ( unsigned j=size; j<to.length()+size; j++ ) {
      if ( state == 0 ) {
	if ( '\\' == temp[j] ) state++;
      } else {
#if 0
	local[1] = temp[j];
#else
	*((char*) (local() + 1)) = temp[j];
#endif
	if ( '\\' == temp[j] ) {
	  temp = temp.substitute( local, "\\", false, j-1 );
	  j--;
	} else if ( ISDIGIT(temp[j]) ) {
	  int digit = temp[j] - '0';
	  temp = temp.substitute( local, sub[digit], false, j-1 );
	  j = sub[digit].length() - 1;
	}
	state = 0;
      }
    }

    // continue normally...
    result += temp;
    start = i + sub[0].length();
  } while ( global && from.lastStatus()==0 && i >= 0 );

  if ( start < length() ) result += substring( start );
  return result;
}

#endif // USE_REGSTR

int
compare( const String& a, const char* str, bool cs )
{
  unsigned second = str ? strlen(str) : 0;
  if ( a.length() == second ) return compare( a, str, a.length(), cs );
  else return ( a.length() < second ) ? -1 : 1;
}

int 
compare( const String& a, const String& b, bool cs )
{
  if ( a.length() == b.length() ) return compare( a, b, a.length(), cs );
  else return ( a.length() < b.length() ) ? -1 : 1;
}

String
String::upper( void ) const
  // purpose: convert to uppercase characters, see toupper()
  // returns: new string consisting of uppercase characters.
{
  StringRep* temp = new StringRep( string->length() );
  const char* src = string->content();
  char* dst = (char*) temp->string;
  while ( *src ) *dst++ = TOUPPER(*src++);
  return String(temp);
}

String
String::lower( void ) const
  // purpose: convert to lowercase characters, see tolower()
  // returns: new string consisting of lowercase characters.
{
  StringRep* temp = new StringRep( string->length() );
  const char* src = string->content();
  char* dst = (char*) temp->string;
  while ( *src ) *dst++ = TOLOWER(*src++);
  return String(temp);
}

String
String::trim( void ) const
  // purpose: trim isspace() characters from front and rear.
  // returns: new string which may be identical to this one, or empty.
{
  const char* start = string->content();
  const char* final = start + string->length() - 1;
  while ( start <= final && ISSPACE(*start) ) start++;
  while ( final >= start && ISSPACE(*final) ) final--;
  return (final>=start) ? String( start, final-start+1 ) : String();
}

inline
bool
belongs( char ch, const char* lws )
{ return ( (strchr(lws,ch) != NULL) ); }

String
String::trim( const char* lws ) const
  // purpose: trim all characters in lws from front and rear.
  // paramtr: lws (IN): set of characters which are trimmable.
  // returns: new string which may be identical to this one, or empty.
{
  const char* start = string->content();
  const char* final = start + string->length() - 1;
  while ( start <= final && belongs(*start,lws) ) start++;
  while ( final >= start && belongs(*final,lws) ) final--;
  return (final>=start) ? String( start, final-start+1 ) : String();
}

String
String::trim( const String& lws ) const
  // purpose: trim all characters in lws from front and rear.
  // paramtr: lws (IN): set of characters which are trimmable.
  // returns: new string which may be identical to this one, or empty.
{
  const char* start = string->content();
  const char* final = start + string->length() - 1;
  while ( start <= final && lws.index(*start)!=-1 ) start++;
  while ( final >= start && lws.index(*final)!=-1 ) final--;
  return (final>=start) ? String( start, final-start+1 ) : String();
}
