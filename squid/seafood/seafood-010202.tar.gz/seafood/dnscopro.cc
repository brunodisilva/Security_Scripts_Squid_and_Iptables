//
// $Id: dnscopro.cc,v 1.3 1999/09/02 10:09:48 voeckler Exp $
//
// Author:  Jens-S. V�ckler <voeckler@rvs.uni-hannover.de>
//
// File:    dnscopro.cc
//          Fri Aug 27 1999
//
// (c) 1999 Lehrgebiet Rechnernetze und Verteilte Systeme
//          Universit�t Hannover, Germany
//
// Permission to use, copy, modify, distribute, and sell this software
// and its documentation for any purpose is hereby granted without fee,
// provided that (i) the above copyright notices and this permission
// notice appear in all copies of the software and related documentation,
// and (ii) the names of the Lehrgebiet Rechnernetze und Verteilte
// Systeme and the University of Hannover may not be used in any
// advertising or publicity relating to the software without the
// specific, prior written permission of Lehrgebiet Rechnernetze und
// Verteilte Systeme and the University of Hannover.
//
// THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
// EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
// WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
//
// IN NO EVENT SHALL THE LEHRGEBIET RECHNERNETZE UND VERTEILTE SYSTEME OR
// THE UNIVERSITY OF HANNOVER BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT
// ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY,
// ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
// SOFTWARE.
//
// $Log: dnscopro.cc,v $
// Revision 1.3  1999/09/02 10:09:48  voeckler
// added debug and statistics interface to ctor, added virtual functions to
// be used by the querying method.
//
// Revision 1.2  1999/08/31 09:53:27  voeckler
// managed to derive a concrete class from a template base.
//
// Revision 1.1  1999/08/27 20:55:00  voeckler
// Initial revision
//
//
#if defined(__GNUC__) || defined(__GNUG__)
#pragma implementation
#endif

#include "dnscopro.hh"

static const char* RCS_ID =
"$Id: dnscopro.cc,v 1.3 1999/09/02 10:09:48 voeckler Exp $";

DNSCoProcess::~DNSCoProcess()
  // move into .o file to make compiler happy (create a vtable)
{
  // empty
}

void 
DNSCoProcess::addToMap( DNSItemMap& map, const String& key, DNSItem& value )
  // purpose: add fqdn, all aliases and all addresses to the map, not just key
  // paramtr: map (IO): map to insert into
  //          key (IN): key of item to add
  //          value (IN): value to add - must not be const
{
  map[key] = value; // always add what was asked for!
  if ( value.fqdn.length() && value.fqdn != key ) 
    map[value.fqdn] = value;
  for ( size_t k=0; k<value.n_aliases; ++k )
    if ( value.aliases[k] != key ) map[value.aliases[k]] = value;
  for ( size_t k=0; k<value.n_addresses; ++k ) {
    String ip( DNSItem::ntoa(value.addresses[k]) );
    if ( ip != key ) map[ip] = value;
  }
}

bool
DNSCoProcess::isKnown( const DNSItemMap& map, const String& key )
  // purpose: map.exists(key) -- let the derivate check different keys
  // paramtr: map (IN): map to check for the key
  //          key (IN): key to check for
  // returns: true, if the key was found.
  // attent.: The key must *not* necessarily be in the map
{
#if 0
  static const DNSItem empty;
  return map[key.lower()] != empty;
#else
  return map.exists(key.lower());
#endif
}
