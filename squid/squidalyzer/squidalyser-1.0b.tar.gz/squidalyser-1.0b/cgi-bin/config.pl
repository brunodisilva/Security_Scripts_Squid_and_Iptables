#!/usr/bin/perl

#
#   config.pl, script to configure squidalyser program (http://ababa.org/)
#   Copyright (C) 2001-2002  Simon J Burns.
#
#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#

use lib '/usr/local/squidalyser';

use strict;
use Squidalyser::Template;
use Squidalyser::Config;
use Squidalyser::LanguageLists;
use DBI;
use CGI;

my $query = CGI->new;
$query->import_names('Q');

my $dbh;
my $config = Squidalyser::Config->new(file => '/usr/local/squidalyser/squidalyser.conf');

if ($Q::submit) {
	$dbh = DBI->connect("DBI:mysql:$Q::dbname:$Q::dbhost",$Q::dbuser,$Q::dbpass) or undef;
} elsif ($config->db_ok) {
	$dbh = &dbconnect;
}

$dbh and my $msg = Squidalyser::LanguageLists->new (
	dbh	=> $dbh,
	config	=> $config,
);

my ($title, $message);
if ($dbh) {
	$title = $msg->tran('sq_conf_page'),
	$message = $msg->tran('config_sq'),
} else {
	$title = 'Squidalyser config manager';
	$message = 'Configure squidalyser'
}

my $page = Squidalyser::Template->new (
	title	=> $title,
	heading	=> $title,
	message	=> $message,
	body	=> undef,
	button	=> 'config',
);

if (($dbh) and ($Q::submit eq $msg->tran('save'))) {
	my %params = $query->Vars;
	$config->save($msg, %params);
}

&main_page;
&show_page;

sub main_page {

	my (%timeformat, %chartformat, %incdom, %expire);

	if ($dbh) {
		%timeformat = (
			UK	=> 'dd/mm/yy',
			US	=> 'mm/dd/yy',
		);

		%chartformat = (
			plain	=> $msg->tran('plain'),
			fancy	=> $msg->tran('fancy'),
		);

		%incdom = (
			n	=> $msg->tran('no'),
			y	=> $msg->tran('ntlm_yes'),
		);

		%expire = (
			h	=> $msg->tran('hours'),
			d	=> $msg->tran('days'),
			w	=> $msg->tran('weeks'),
		);
	}

	my $expire_conf = $config->get_expire;
	my ($expire_value, $expire_units);
	if (($dbh) and ($Q::submit eq $msg->tran('save'))) {
		$expire_value = $Q::expire_value;
		$expire_units = $Q::expire_units;
	} else {
		($expire_value, $expire_units) = split(/_/, $expire_conf);
	}

	my $db_ok;
	my @all_languages;
	if ($dbh) {
		$db_ok = '<font color="green">' . $msg->tran('db_cred_ok') . '</font>';
		@all_languages = $config->get_all_languages($dbh);
	} else {
		$db_ok = '<font color="red">Database credentials not OK - try again</font>';
	}

	my ($dbname, $dbhost, $dbuser, $dbpass);

	if (($dbh) and ($Q::submit eq $msg->tran('check'))) {
		$dbname = $Q::dbname;
		$dbhost = $Q::dbhost;
		$dbuser = $Q::dbuser;
		$dbpass = $Q::dbpass;
	} else {
		$dbname = $config->get_dbname;
		$dbhost = $config->get_dbhost;
		$dbuser = $config->get_dbuser;
		$dbpass = $config->get_dbpass;
	}

	my ($db_text, $name_text, $host_text, $user_text, $pass_text, $chacc_text, $chbut_text);

	if ($dbh) {
		$db_text	= $msg->tran('db');
		$name_text	= $msg->tran('name');
		$host_text	= $msg->tran('host');
		$user_text	= $msg->tran('user');
		$pass_text	= $msg->tran('password');
		$chacc_text	= $msg->tran('ch_acc');
		$chbut_text	= $msg->tran('check');
	} else {
		$db_text	= 'Database';
		$name_text	= 'Name';
		$host_text	= 'Host';
		$user_text	= 'User';
		$pass_text	= 'Password';
		$chacc_text	= 'Check access';
		$chbut_text	= 'Check';
	}

	my $html = qq|
		<form method="POST">
		<table border=0 width="100%" cellpadding=5 cellspacing=1>
		<tr>
			<td colspan=2><hr><font size=+1><b>$db_text</b></font><hr></td>
		</tr>
		<tr>
			<td width="40%"><b>$name_text</b></td>
			<td>
				<input type="text" name="dbname" value="$dbname" size=24 maxlength=32>
			</td>
		</tr>
		<tr>
			<td width="40%"><b>$host_text</b></td>
			<td>
				<input type="text" name="dbhost" value="$dbhost" size=24 maxlength=32>
			</td>
		</tr>
		<tr>
			<td width="40%"><b>$user_text</b></td>
			<td>
				<input type="text" name="dbuser" value="$dbuser" size=24 maxlength=32>
			</td>
		</tr>
		<tr>
			<td width="40%"><b>$pass_text</b></td>
			<td>
				<input type="password" name="dbpass" value="$dbpass" size=24 maxlength=32>
			</td>
		</tr>
		<tr>
			<td colspan=2><hr></td>
		</tr>
		<tr>
			<td width="40%"><b>
				$chacc_text<br>$db_ok</b>
			</td>
			<td>
				<input type="submit" name="submit" value="$chbut_text">
			</td>
		</tr>
	|;

	if ($dbh) {
		$html .= qq|
		<p>
		<tr>
			<td colspan=2><hr><font size=+1><b>| .
				$msg->tran('oth_opt')
			. qq|</b></hr></td>
		</tr>
		<tr>
			<td colspan=2><hr></td>
		</tr>
		<tr>
			<td width="40%"><b>| . 
				$msg->tran('sq_log')
			. qq|</b></td>
			<td>
				<input type="text" name="squidlog" value="| . $config->get_squidlog . qq|"
				size=50 maxlength=128>
			</td>
		</tr>
		<tr valign="top">
			<td width="40%"><b>| .
				$msg->tran('expire')
			. qq|</b></td>
			<td>
			<input type="text" name="expire_value" value="$expire_value" size=3 maxlength=4><p>| .
			$query->radio_group(
				-name		=> 'expire_units',
				-values		=> ['h', 'd', 'w'],
				-linebreak	=>'true',
				-labels		=> \%expire,
				-default	=> $expire_units,
			)
			. qq|</td>
		</tr>
		<tr valign="top">
			<td width="40%"><b>| .
				$msg->tran('time_form')
			. qq|</b></td>
			<td>| .
			$query->radio_group(
				-name		=> 'timeformat',
				-values		=> ['UK', 'US'],
				-linebreak	=>'true',
				-labels		=> \%timeformat,
				-default	=> $config->get_timeformat,
			)
			. qq|</td>
		</tr>
		<tr valign="top">
			<td width="40%"><b>| .
				$msg->tran('ch_form')
			. qq|</b></td>
			<td>| .
			$query->radio_group(
				-name		=> 'chartformat',
				-values		=> ['plain', 'fancy'],
				-linebreak	=>'true',
				-labels		=> \%chartformat,
				-default	=> $config->get_chartformat,
			)
			. qq|</td>
		</tr>
		<tr valign="top">
			<td width="40%"><b>| .
				$msg->tran('inc_dom')
			. qq|</b></td>
			<td>| .
			$query->radio_group(
				-name		=> 'include_domain',
				-values		=> ['n', 'y'],
				-linebreak	=>'true',
				-labels		=> \%incdom,
				-default	=> $config->get_include_domain,
			)
			. qq|</td>
		</tr>
		<tr valign="top">
			<td width="40%"><b>| .
				$msg->tran('lang')
			. qq|</b></td>
			<td>| .
			$query->popup_menu(
				-name		=> 'language',
				-values		=> \@all_languages,
				-linebreak	=>'true',
				-labels		=> \%incdom,
				-default	=> $config->get_language,
			)
			. qq|</td>
		</tr>
		<tr>
			<td colspan=2><hr></td>
		</tr>
		<tr valign="top">
			<td width="40%">

			</td>
			<td>
				<input type="submit" name="submit" value="| . $msg->tran('save') . qq|">&nbsp;
				<input type="reset">
			</td>
		</tr>
		</table>
		</form>|;
	} else {
		$html .= '</table></form>';
	}

	$page->append_to_body($html);
}

sub show_page {
	$page->prepare('/usr/local/squidalyser/template.html');
	$page->show;
}

sub dbconnect {
	my $dbname = $config->get_dbname;
	my $dbhost = $config->get_dbhost;
	my $dbuser = $config->get_dbuser;
	my $dbpass = $config->get_dbpass;
	my $dbh = DBI->connect("DBI:mysql:$dbname:$dbhost",$dbuser,$dbpass) or undef;
	return $dbh;
}

