#!/usr/bin/perl

#
#   squidalyser.pl, program to analyse squid logfiles (http://ababa.org/)
#   Copyright (C) 2001-2002  Simon J Burns.
#
#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#

use lib '/usr/local/squidalyser';

use strict;
use Squidalyser::Template;
use Squidalyser::HTMLControls;
use Squidalyser::ListManager;
use Squidalyser::SQLquery;
use Squidalyser::Config;
use Squidalyser::LanguageLists;
use DBI;
use CGI;

my $sqlquery;

my $query = CGI->new;
$query->import_names('Q');

my $config = Squidalyser::Config->new(file => '/usr/local/squidalyser/squidalyser.conf');
my $dbh = dbconnect();

my $msg = Squidalyser::LanguageLists->new (
	dbh	=> $dbh,
	config	=> $config,
);

my $page = Squidalyser::Template->new (
	title	=> $msg->tran('sq_an_page'),
	heading	=> $msg->tran('sq_an_page'),
	message	=> $msg->tran('an_page_instr'),
	body	=> undef,
	button	=> 'analysis',
);

my $controls = Squidalyser::HTMLControls->new(
	dbhandle	=> $dbh,
	msg		=> $msg,
	user_default	=> $query->param('rfc931'),
	words_default	=> $query->param('words_lists'),
	groups_default	=> $query->param('groups'),
);

my $listmanager = Squidalyser::ListManager->new(
	dbhandle	=> $dbh,
	msg		=> $msg,
);

if ($Q::submit eq $msg->tran('submit_but')) {
	if (($Q::url_limit) and ($Q::url_limit < 7)) { $Q::url_limit = 7 };
	if (($Q::limit) and ($Q::limit < 1)) { $Q::limit = 1 };

	$sqlquery = Squidalyser::SQLquery->new(
		dbhandle	=> $dbh,
		type_of_result	=> $Q::type_of_result,
		substring	=> $Q::substring,
		user_system	=> $Q::user_system,
		limit		=> $Q::limit,
		url_limit	=> $Q::url_limit,
		hilo		=> $Q::hilo,
		form_params	=> $query,
		msg		=> $msg,
	);
	$sqlquery->compose;
	$sqlquery->execute;
}

&main_page;
&show_page;

sub main_page {
	my $type_of_results = $controls->show_type_of_results;
	my $rfc931 = $controls->show_users;

	$listmanager->set_list_type('w');
	my $words_lists = $listmanager->show_lists;

	$listmanager->set_list_type('u');
	my $groups = $listmanager->show_lists;

	my ($hisel, $losel);
	if ($Q::hilo eq 'high') { $hisel = 'checked="yes"' } elsif ($Q::hilo eq 'low') { $losel = 'checked="yes"' };

	my $button_submit = $msg->tran('submit_but');
	my $button_clear = $msg->tran('clr_changes');

	$Q::url_limit ||= 60;

	my $html = qq|
		<form method="POST">
		<table border=0 cellpadding=5 cellspacing=1>
		<tr>
			<td colspan=5><hr></td>
		</tr>
		<tr>
			<td colspan=5><font size=+1><b>| . $msg->tran('users_groups') . qq|</b></font></td>
		</tr>
		<tr valign="top"><td width="30%">| .
				$msg->tran('mult_sel_instr') . '</td><td align="right"><b>' .
				$msg->tran('groups') . '</b></td><td>' .
				$groups . '</td><td align="right"><b>' .
				$msg->tran('users') . '</b></td><td>' .
				$rfc931
		. qq|</td></tr>
		<tr>
			<td colspan=5><hr></td>
		</tr>
		<tr>
			<td colspan=5><font size=+1><b>| . $msg->tran('srch_filt') . qq|</b></font></td>
		</tr>
		<tr><td><b>| .
			$msg->tran('substr') .
			qq|</td>
			<td colspan=4>
			<input type="text" name="substring" size=40 maxlength=150 value="$Q::substring">
			</td>
		</tr>
		<tr><td><b>| .
			$msg->tran('user_syst') .
			qq|</td>
			<td colspan=4>
			<input type="text" name="user_system" size=40 maxlength=150 value="$Q::user_system">
			</td>
		</tr>
		<tr valign="top"><td><b>| .
			$msg->tran('word_list') . '</b><br>' . $msg->tran('mult_sel_comm') .
			qq|</td>
			<td colspan=4>
			$words_lists
			</td>
		</tr>
		<tr>
			<td colspan=5><hr></td>
		</tr>
		<tr>
			<td colspan=5><font size=+1><b>| . $msg->tran('res_fmt') . qq|</b></font></td>
		</tr>
		<tr valign="top"><td><b>| .
			$msg->tran('res_fmt') .
			qq|</td>
			<td colspan=4>
			$type_of_results
			</td>
		</tr>
		<tr>
			<td colspan=5><hr></td>
		</tr>
		<tr>
			<td colspan=5><font size=+1><b>| . $msg->tran('oth_opt') . qq|</b></font></td>
		</tr>
		<tr valign="top">
			<td>|
			. $msg->tran('limit_res') .
			qq|</td>
			<td colspan=4><input type="text" size=5 maxlength=6 name="limit" value="$Q::limit">&nbsp;|
			. $msg->tran('limit_rows') .
			qq|</td>
		</tr>

		<tr valign="top">
			<td>|
			. $msg->tran('graphs_show') .
			'<br><small>'
			. $msg->tran('graphs_show_comm') .
			qq|</small>
			</td>
			<td colspan=5>
				<input type="radio" name="hilo" value="high" $hisel>&nbsp; |
				. $msg->tran('most_act') .
				qq|<br><input type="radio" name="hilo" value="low" $losel>&nbsp;|
				. $msg->tran('least_act') .
			qq|</td>
		</tr>
		<tr valign="top">
			<td>|
			. $msg->tran('trunc_url') .
			qq|</td>
			<td colspan=4><input type="text" size=5 maxlength=6 name="url_limit" value="$Q::url_limit">&nbsp;|
			. $msg->tran('chr') .
			qq|&nbsp;</td>
		</tr>
		<tr>
			<td colspan=5><hr></td>
		</tr>
		<tr valign="top">
			<td>&nbsp;</td>
			<td colspan=4>
				<input type="submit" name="submit" value="$button_submit">&nbsp;
				<input type="submit" name="submit" value="$button_clear">&nbsp;
				<input type="reset">
			</td>
		</tr>
		</table>
		</form>
	|;
	if ($Q::submit eq $msg->tran('submit_but')) {
		$html .= $sqlquery->show_results;
	}
	$page->append_to_body($html);
}

sub show_page {
	# The Template module does some simple substitutions. It's hardly as
	# complex as the Template Toolkit, but more suited to my needs.

	$page->prepare('/usr/local/squidalyser/template.html');
	$page->show;
}

sub dbconnect {
	my $dbname = $config->get_dbname;
	my $dbhost = $config->get_dbhost;
	my $dbuser = $config->get_dbuser;
	my $dbpass = $config->get_dbpass;
	my $dbh = DBI->connect("DBI:mysql:$dbname:$dbhost",$dbuser,$dbpass)
		or die (DBI::errstr);
	return $dbh;
}
