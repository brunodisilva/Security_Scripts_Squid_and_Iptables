#!/usr/bin/perl

use lib '/usr/local/squidalyser';

use strict;
use Squidalyser::Config;
use Squidalyser::LanguageLists;
use DBI;

my $config = Squidalyser::Config->new(file => '/usr/local/squidalyser/squidalyser.conf');
my $dbh = &dbconnect;

my $language = @ARGV[0];
unless ($language) {
	print qq|\nUsage: $0 "language_name"\nNothing done.\n\n|;
	exit;
}

my $language_q = $dbh->quote($language);
my $sth = $dbh->prepare(qq|SELECT id FROM language WHERE name=$language_q|);
$sth->execute or die $dbh->errstr;
my $id = $sth->fetchrow;
$sth->finish;

unless ($id) {
	print qq|\nLanguage "$language" not found.\nNothing done.\n\n|;
	exit;
}

print qq|$language\n|;

$sth = $dbh->prepare(qq|SELECT tag, value FROM message WHERE language_id=$id|);
$sth->execute or die $dbh->errstr;
while (my ($tag, $value) = $sth->fetchrow) {
	print qq|TAG: $tag\tVALUE: $value\n|;
}

sub dbconnect {
	my $dbname = $config->get_dbname;
	my $dbhost = $config->get_dbhost;
	my $dbuser = $config->get_dbuser;
	my $dbpass = $config->get_dbpass;
	my $dbh = DBI->connect("DBI:mysql:$dbname:$dbhost",$dbuser,$dbpass) or die (DBI::errstr);
	return $dbh;
}

