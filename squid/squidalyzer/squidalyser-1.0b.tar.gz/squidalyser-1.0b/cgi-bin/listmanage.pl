#!/usr/bin/perl

#
#   listmanage.pl, script to manage lists in squidalyser (http://ababa.org/)
#   Copyright (C) 2001-2002  Simon J Burns.
#
#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#

use lib '/usr/local/squidalyser';

use strict;
use Squidalyser::Template;
use Squidalyser::HTMLControls;
use Squidalyser::Config;
use Squidalyser::ListManager;
use Squidalyser::LanguageLists;
use DBI;
use CGI;

my $query = CGI->new;
$query->import_names('Q');

my $config = Squidalyser::Config->new(file => '/usr/local/squidalyser/squidalyser.conf');
my $dbh = dbconnect();

my $msg = Squidalyser::LanguageLists->new (
	dbh	=> $dbh,
	config	=> $config,
);

my $listmanager = Squidalyser::ListManager->new(
	dbhandle	=> $dbh,
	msg		=> $msg,
);

$listmanager->set_list_type($Q::t);
$Q::lists_list = $Q::words_list || $Q::groups_list;

my $button;
if ($Q::t eq 'u') { $button = 'users' } else { $button = 'words' };

my $page = Squidalyser::Template->new (
	title	=> $msg->tran('sq_list_page'),
	heading	=> $msg->tran('sq_list_page'),
	message	=> $msg->tran('man_lists'),
	body	=> undef,
	msg	=> $msg,
	button	=> $button,
);

my $controls = Squidalyser::HTMLControls->new(
	dbhandle	=> $dbh,
	msg		=> $msg,
);

if ($Q::submit eq $msg->tran('create')) {
	my $check_name = $listmanager->check_new_list_name($Q::newlist);
	if ($check_name) {
		$page->set_message($check_name);
	} else {
		$listmanager->new_list($Q::newlist);
		$listmanager->set_list_name($Q::newlist);
	}
} elsif ($Q::submit eq $msg->tran('edit')) {
	if ($Q::lists_list) {
		$listmanager->set_list_name($Q::lists_list);
		$page->set_message($msg->tran('edit_list') . ': ' . $Q::lists_list);
	} else {
		$page->set_message($msg->tran('sel_list_edit'));
	}
} elsif ($Q::submit eq $msg->tran('del')) {
	if ($Q::lists_list) {
		$listmanager->delete_list($Q::lists_list);
		$page->set_message($msg->tran('del_list') . ': ' . $Q::lists_list);
	} else {
		$page->set_message($msg->tran('sel_list_del'));
	}
} elsif (($Q::submit eq $msg->tran('add') . ' >') or ($Q::submit eq $msg->tran('add_all') . ' >>')) {
	if ($Q::submit eq $msg->tran('add_all') . ' >>') {
		$listmanager->set_scope('all');
	}

	$listmanager->set_list_name($Q::current_list);

	if (($Q::list_non_members) or ($Q::submit eq $msg->tran('add_all') . ' >>')) {
		$listmanager->add_items_to_list($query->param('list_non_members'));
		$page->set_message($msg->tran('items_added'));
	} else {
		$page->set_message($msg->tran('sel_items_add'));
	}
} elsif (($Q::submit eq '< ' . $msg->tran('remove')) or ($Q::submit eq '<< ' . $msg->tran('rem_all'))) {
	if ($Q::submit eq '< ' . $msg->tran('remove')) {
		$listmanager->set_scope('some');
	}

	$listmanager->set_list_name($Q::current_list);

	if (($Q::list_members) or ($Q::submit eq '<< ' . $msg->tran('rem_all'))) {
		$listmanager->remove_items_from_list($query->param('list_members'));
		$page->set_message($msg->tran('items_rem'));
	} else {
		$page->set_message($msg->tran('sel_items_rem'));
	}
}

&main_page;
&show_page;

sub main_page {
	my $current_list = $listmanager->get_list_name;
	$listmanager->get_list_members($current_list);
	$listmanager->get_list_non_members($current_list);

	$listmanager->set_list_type($Q::t);
	my $list_of_lists = $listmanager->show_lists;
	$list_of_lists =~ s/ MULTIPLE//;

	my $html = qq|
		<form method="POST">
		<table border=0 cellpadding=5 cellspacing=1>
		<tr>
			<td colspan=3><hr><font size=+1><b>| .
				$msg->tran('sel_list')
			. qq|</b></font><hr></td>
		<tr>
		<tr valign="top">
			<td><b>| .
			$msg->tran('create_new_list')
			. qq|</b></td>
			<td>
			<input type="textfield" name="newlist" value="$Q::newlist" size=32 maxlength=32>
			</td>
			<td>
			<input type="submit" name="submit" value="| . $msg->tran('create') . qq|">
			</td>
		</tr>
		<tr valign="top">
			<td><b>| .
			$msg->tran('avail_lists')
			. qq|</b></td>
			<td>
			$list_of_lists
			</td>
			<td>
			<input type="hidden" name="t" value="$Q::t">
			<input type="submit" name="submit" value="| . $msg->tran('edit') . qq|">&nbsp;
			<input type="submit" name="submit" value="| . $msg->tran('del') . qq|">&nbsp;
			</td>
		</tr>
		</table>
		</form>
	|;

	unless (
		($Q::submit eq $msg->tran('del')) or
		($Q::submit eq $msg->tran('create')) or
		(!$Q::submit) or
		(!$listmanager->get_list_name)
	) {

		my $listmembers = $listmanager->show_list_members;
		my $listnonmembers = $listmanager->show_list_non_members;

		my $current_list;
		if (($Q::groups_list) or ($Q::words_list)) {
			$current_list = $Q::groups_list || $Q::words_list;
		} else {
			$current_list = $Q::current_list;
		}

		$html .= qq|
			<p>
			<form method="POST">
			<input type="hidden" name="t" value="$Q::t">
			<table border=0 width="100%" cellpadding=5 cellspacing=1>
		<tr>
			<td colspan=4><hr><font size=+1><b>| .
				$msg->tran('list_edit')
			. qq|</b></font><hr></td>
		<tr>
			<tr valign="top">
			<td width="20%"><b>| .
			$msg->tran('list_editor') . ':</b> ' . $current_list
			. qq|</td>
			<td width="30%">
			$listnonmembers
			</td>
			<td align="center" width="20%">
			<input type="submit" name="submit" value="| . $msg->tran('add') . qq| >"><p>
			<input type="submit" name="submit" value="| . $msg->tran('add_all') . qq| >>"><p>
			<input type="submit" name="submit" value="< | . $msg->tran('remove') . qq|"><p>
			<input type="submit" name="submit" value="<< | . $msg->tran('rem_all') . qq|">
			<input type="hidden" name="current_list" value="$current_list">
			</td>
			<td width="30%">
			$listmembers
			</td>
			</tr>
			</table>
			</form>
		|;
	}

	$page->append_to_body($html);
}

sub show_page {
	$page->prepare('/usr/local/squidalyser/template.html');
	$page->show;
}

sub dbconnect {
	my $dbname = $config->get_dbname;
	my $dbhost = $config->get_dbhost;
	my $dbuser = $config->get_dbuser;
	my $dbpass = $config->get_dbpass;
	my $dbh = DBI->connect("DBI:mysql:$dbname:$dbhost",$dbuser,$dbpass)
		or die (DBI::errstr);
	return $dbh;
}

