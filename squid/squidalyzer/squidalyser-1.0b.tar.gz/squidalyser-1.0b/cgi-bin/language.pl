#!/usr/bin/perl

#
#   language.pl, script to configure squidalyser languages (http://ababa.org/)
#   Copyright (C) 2001-2002  Simon J Burns.
#
#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#

use lib '/usr/local/squidalyser';

use strict;
use Squidalyser::Template;
use Squidalyser::Config;
use Squidalyser::LanguageLists;
use DBI;
use CGI;

my $query = CGI->new;
$query->import_names('Q');

my $config = Squidalyser::Config->new(file => '/usr/local/squidalyser/squidalyser.conf');
my $dbh = &dbconnect;

my $msg = Squidalyser::LanguageLists->new (
	dbh	=> $dbh,
	config	=> $config,
);

my $page = Squidalyser::Template->new (
	title	=> $msg->tran('sq_lang_page'),
	heading	=> $msg->tran('sq_lang_page'),
	message	=> $msg->tran('edit_tags'),
	body	=> undef,
	button	=> 'languages',
);

if ($Q::submit eq $msg->tran('edit')) {
	$msg->set_language($Q::language_list);
} elsif ($Q::submit eq $msg->tran('del')) {
	$msg->delete_language($Q::language_list);
	$msg->set_language('English');
} elsif ($Q::submit eq $msg->tran('add_lang')) {
	$msg->add_language($Q::new_language);
	$msg->set_language($Q::new_language);
} elsif ($Q::submit eq $msg->tran('comm_chg')) {
	$msg->commit_changes($query);
	$msg->set_language($Q::current_language);
} elsif ($Q::submit eq $msg->tran('new_tag')) {
	$msg->set_language($Q::language_list);
	$msg->new_tag($Q::new_tag, $Q::new_tag_value);
}

&main_page;
&show_page;

sub main_page {
	my $languages_menu = $msg->get_languages;
	my $tags = $msg->get_tags;
	my $html = qq|
		<form method="POST">
		<table border=0 width="100%" cellpadding=5 cellspacing=1>
		<tr>
		<td colspan=3>
			<hr>
			<font size=+1>
			<b>| . $msg->tran('lang_sel') . qq|</b>
			</font>
		</td>
		</tr>
		<tr>
		<td width="20%">
			$languages_menu
		</td>
		<td colspan=2>
			<input type="submit" name="submit" value="| . $msg->tran('edit') . qq|">
			&nbsp;
			<input type="submit" name="submit" value="| . $msg->tran('del') . qq|">
		</td>
		</tr>
		<tr>
		<td>
			<input type="text" name="new_language" size=15 maxlength=32>
		</td>
		<td colspan=2>
			<input type="submit" name="submit" value="| . $msg->tran('add_lang') . qq|">
		</td>
		</tr>
		<tr>
		<td colspan=3></td>
		</tr>
		<tr>
		<td colspan=3>
			<hr>
			<font size=+1>
			<b>| . $msg->tran('new_tag') . qq|</b>
			</font>
		</td>
		</tr>
		<tr>
		<td><b>| . $msg->tran('new_tag_name') . qq|</b></td>
		<td>&nbsp;</td>
		<td><b>| . $msg->tran('tag_en_val') . qq|</b></td>
		</tr>
		<tr valign="top">
		<td>
			<input type="text" name="new_tag" size=15 maxlength=32>
		</td>
		<td>
			<input type="submit" name="submit" value="| . $msg->tran('new_tag') . qq|">
		</td>
		<td>
			<textarea cols=50 rows=3 name="new_tag_value"></textarea>
		</td>
		</tr>
		<tr>
		<td colspan=3></td>
		</tr>
		</form>

		<tr>
		<td colspan=3>
			<hr>
			<font size=+1>
			<b>| . $msg->tran('tr_tags') . qq|</b>
			</font>
		</td>
		</tr>
		<form method="POST">
		$tags
		</table>
		</form>
	|;

	$page->append_to_body($html);
}

sub show_page {
	$page->prepare('/usr/local/squidalyser/template.html');
	$page->show;
}

sub dbconnect {
	my $dbname = $config->get_dbname;
	my $dbhost = $config->get_dbhost;
	my $dbuser = $config->get_dbuser;
	my $dbpass = $config->get_dbpass;
	my $dbh = DBI->connect("DBI:mysql:$dbname:$dbhost",$dbuser,$dbpass)
		or die (DBI::errstr);
	return $dbh;
}

