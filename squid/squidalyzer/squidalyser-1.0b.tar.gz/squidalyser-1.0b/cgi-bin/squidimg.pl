#!/usr/bin/perl

#
#   squidimg.pl, script to display graphs in squidalyser (http://ababa.org/)
#   Copyright (C) 2001-2002  Simon J Burns.
#
#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#

use strict;
use CGI qw/:standard/;
use GD::Graph::bars;
use GD::Graph::colour;
use GD::Graph::Data;
use URI::Escape;

my (@labels, @values, $title, $ylabel);

my @data_string = split(/\&/, $ENV{QUERY_STRING});
foreach my $pair (@data_string) {
	my ($label, $value) = split(/=/, $pair);
	$label = uri_unescape($label);
	if ($label eq 'title') {
		$value = uri_unescape($value);
		$title = $value;
	} elsif ($label eq 'ylabel') {
		$value = uri_unescape($value);
		$ylabel = $value;
	} else {
		push @labels, $label;
		push @values, $value;
	}
}

my $data = [
	[ @labels ],
	[ @values ],
];

my $my_graph = GD::Graph::bars->new();

$my_graph->set(
	title		=> $title,
	x_label         => 'Username',
	y_label         => $ylabel,
	bar_spacing     => 8,
	shadow_depth    => 4,
	shadowclr       => 'dred',
	transparent     => 1,
	'3d'		=> 0,
)
or warn $my_graph->error;

my $format = 'png';

print header("image/$format");
binmode STDOUT;
print $my_graph->plot($data)->$format();

exit;
