package Squidalyser::Template;
$VERSION = 0.1;
use strict;
use Carp;

#
#   Template.pm, module to handle squidalyser HTML templates (http://ababa.org/)
#   Copyright (C) 2001-2002  Simon J Burns.
#
#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#


# It ain't complicated, and it ain't pretty, but I feel the world is finally
# ready for yet another template module :^) At least this one is brief...

sub new {
	my ($class, %args) = @_;
	bless {
		_title		=> $args{title},
		_heading	=> $args{heading},
		_message	=> $args{message},
		_body		=> $args{body},
		_button		=> $args{button},
		_text		=> undef,
		_header		=> "Content-type: text/html\n\n",
	}, $class;
}

sub prepare {
	my ($self, $template) = @_;
	local $/;
	open (TEMPLATE, "< $template") or die $!;
	$self->{_text} = <TEMPLATE>;
	close TEMPLATE;

	$self->{_text} =~ s/\%\%title\%\%/$self->{_title}/g;
	$self->{_text} =~ s/\%\%heading\%\%/$self->{_heading}/g;
	$self->{_text} =~ s/\%\%message\%\%/$self->{_message}/g;
	$self->{_text} =~ s/\%\%body\%\%/$self->{_body}/g;

	my $button0 = $self->{_button} . '-0.gif';
	my $button1 = $self->{_button} . '-1.gif';
	$self->{_text} =~ s/$button0/$button1/g;
}

sub show {
	my $self = shift;
	print $self->{_header}, $self->{_text};
}

sub set_body {
	my ($self, $text) = @_;
	$self->{_body} = $text;
	return;
}

sub set_message {
	my ($self, $text) = @_;
	$self->{_message} = $text;
	return;
}

sub append_to_body {
	my ($self, $text) = @_;
	$self->{_body} .= $text;
	return;
}

1;
