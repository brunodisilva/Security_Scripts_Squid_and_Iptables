package Squidalyser::Config;
$VERSION = 0.1;
use strict;
use Carp;

#
#   Config.pm, module to handle squidalyser configuration (http://ababa.org/)
#   Copyright (C) 2001-2002  Simon J Burns.
#
#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#


#
# This module handles reading/writing squidalyser's configuration file.
#

sub new {
	my ($class, %args) = @_;

	open (CONF, "< $args{file}") or die $!;
	my %conf;
	while (my $line = <CONF>) {
		$line =~ /^$/ and next;
		$line =~ /^\#/ and next;
		$line =~ /^(.*?)\s+(.*)$/;
		$conf{$1} = $2;
	}

	bless {

	# _file		The location of the squidalyser.conf file.
	# _dbname	Database name.
	# _dbhost	Database host.
	# _dbuser	Database user with permissions to use the 'squid' DB.
	# _dbpass	The user's password for the DB.
	# _squidlog	The full path to the squid logfile.
	# _expire	Time after which entries in the DB should be expired.
	# _timeformat	UK or US, to determine ambiguous dates.
	# _chartformat	Whether to use plain (HTML) or fancy (GD) format graphs

		_file		=> $args{file},
		_dbname		=> $conf{dbname},
		_dbhost		=> $conf{dbhost},
		_dbuser		=> $conf{dbuser},
		_dbpass		=> $conf{dbpass},
		_squidlog	=> $conf{squidlog},
		_expire		=> $conf{expire},
		_timeformat	=> $conf{timeformat},
		_chartformat	=> $conf{chartformat},
		_language	=> $conf{language},
	}, $class;
}

sub get_dbname {
	my $self = shift;
	return $self->{_dbname};
}

sub get_dbhost {
	my $self = shift;
	return $self->{_dbhost};
}

sub get_dbuser {
	my $self = shift;
	return $self->{_dbuser};
}

sub get_dbpass {
	my $self = shift;
	return $self->{_dbpass};
}

sub get_language {
	my $self = shift;
	return $self->{_language};
}

sub set_language {
	my ($self, $language) = @_;
	$self->{_language} = $language;
}


sub get_squidlog {
	my $self = shift;
	return $self->{_squidlog};
}

sub get_timeformat {
	my $self = shift;
	return $self->{_timeformat};
}

sub get_chartformat {
	my $self = shift;
	return $self->{_chartformat};
}

sub get_expire {
	my $self = shift;
	return $self->{_expire};
}

sub get_include_domain {
	my $self = shift;
	return $self->{_include_domain};
}

sub get_all_languages {
	my ($self, $dbh) = @_;
	my $ary_ref = $dbh->selectcol_arrayref('SELECT DISTINCT(name) FROM language ORDER BY name');
	return @{$ary_ref};
}

sub db_ok {
	my $self = shift;
	my $dbname = $self->get_dbname;
	my $dbhost = $self->get_dbhost;
	my $dbuser = $self->get_dbuser;
	my $dbpass = $self->get_dbpass;
	my $dbh = DBI->connect("DBI:mysql:$dbname:$dbhost",$dbuser,$dbpass) or undef;
	if ($dbh) {
		$dbh->disconnect;
		return 1;
	} else {
		return 0;
	}
}

sub save {
	my ($self, $msg, %params) = @_;
	my $text =
	$msg->tran('conf_dbvalues') .
	"\ndbname $params{dbname}\n" .
	"dbhost $params{dbhost}\n" .
	"dbuser $params{dbuser}\n" .
	"dbpass $params{dbpass}\n" .
	"\n" .
	$msg->tran('conf_squidlog') .
	"\nsquidlog $params{squidlog}" .
	"\n\n" .
	$msg->tran('conf_expire') .
	"\nexpire $params{expire_value}" . '_' . $params{expire_units} .
	"\n\n" .
	$msg->tran('conf_timeformat') .
	"\ntimeformat $params{timeformat}" .
	"\n\n" .
	$msg->tran('conf_chartformat') .
	"\nchartformat $params{chartformat}" .
	"\n\n" .
	$msg->tran('conf_include_domain') .
	"\ninclude_domain $params{include_domain}" .
	"\n\n" .
	$msg->tran('conf_language') .
	"\nlanguage $params{language}";

	$text =~ s/\r//g;

	open (CONF, "> /usr/local/squidalyser/squidalyser.conf") or die $!;
	print CONF $text;
	close CONF;

	return;
}











1;
