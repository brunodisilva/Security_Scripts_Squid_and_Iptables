package Squidalyser::LanguageLists;
$VERSION = 0.1;
use strict;
use Carp;
use CGI;

#
#   LanguageLists.pm, module to handle squidalyser multi-language functions (http://ababa.org/)
#   Copyright (C) 2001-2002  Simon J Burns.
#
#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#


sub new {
	my ($class, %args) = @_;

	bless {
		_dbh		=> $args{dbh},
		_config		=> $args{config},
		_language	=> $args{config}->get_language,
	}, $class;
}

sub set_language {
	my ($self, $language) = @_;
	unless ($language) { $language = $self->{_config}->get_language };
	$self->{_language} = $language;
	return;
}

sub get_languages {
	my $self = shift;
	my $dbh = $self->{_dbh};
	my $query = qq|SELECT DISTINCT(name) FROM language ORDER BY name|;
	my $ary_ref = $dbh->selectcol_arrayref($query);
	my $list = CGI::popup_menu (
		-name           => 'language_list',
		-values         => \@{$ary_ref},
	);
	return $list;
}

sub get_tags {
	my $self = shift;
	my $dbh = $self->{_dbh};
	my $language = $self->{_language};
	my $language_q = $dbh->quote($language);
	my $ary_ref = $dbh->selectcol_arrayref("SELECT id FROM language WHERE name=$language_q");
	my $id = @{$ary_ref}[0];
	unless ($id =~ /\d+/) { return "<tr><td colspan=3>No such language: $language</td></tr>" };

	my $query = qq|SELECT id,tag,value FROM message WHERE language_id=1 ORDER BY tag|;
	my $sth = $dbh->prepare($query);
	$sth->execute or die $dbh->errstr;

	my $html = '<tr><td><b>' . $self->tran('Tag') . '</b></td><td><b>' . $self->tran('orig_eng') . '</b></td><td><b>'
			. $self->tran('disp_lang') . ": $language</b></td></tr><tr><td colspan=3><hr></td></tr>";

	while (my ($tag_id, $tag, $value) = $sth->fetchrow) {
		my $tag_q = $dbh->quote($tag);
		my $ary_ref = $dbh->selectcol_arrayref("SELECT value FROM message WHERE language_id=$id AND tag=$tag_q");
		my $translation = @{$ary_ref}[0];
		$value =~ s/\n/<br>/g;
		$html .= qq|
			<tr valign="top">
				<td>$tag</td>
				<td>$value</td>
				<td><textarea name="$tag" rows=3 cols=50>$translation</textarea></td>
			<tr>
			<tr height=1>
				<td colspan=3><hr></td>
			</tr>
		|;
	}
	$sth->finish;
	$html .= qq|
		<tr><td colspan=3>
		<input type="hidden" name="current_language" value="$language">
		<input type="submit" name="submit" value="| . $self->tran('comm_chg') . qq|">
		</td></tr>
	|;
	return $html;
}

sub commit_changes {
	my ($self, $query) = @_;
	my $dbh = $self->{_dbh};

	my %params = $query->Vars;

	my $language_q = $dbh->quote($params{'current_language'});
	my $ary_ref = $dbh->selectcol_arrayref("SELECT id FROM language WHERE name=$language_q");
	my $id = @{$ary_ref}[0];

	foreach my $key (sort keys %params) {
		next if ($key eq 'submit');
		next if ($key eq 'current_language');
		my $tag_q = $dbh->quote($key);
		my $value_q = $dbh->quote($params{$key});
		$dbh->do(qq|UPDATE message SET value=$value_q WHERE tag=$tag_q AND language_id=$id|);
	}
}

sub add_language {
	my ($self, $language) = @_;
	my $dbh = $self->{_dbh};
	my $language_q = $dbh->quote($language);
	my $ary_ref = $dbh->selectcol_arrayref("SELECT id FROM language WHERE name=$language_q");
	return if (@{$ary_ref}[0] =~ /\d+/);

	$dbh->do(qq|INSERT INTO language VALUES (NULL, $language_q)|);
	$ary_ref = $dbh->selectcol_arrayref("SELECT id FROM language WHERE name=$language_q");
	my $id = @{$ary_ref}[0];

	my $sth = $dbh->prepare("SELECT tag FROM message WHERE language_id=1");
	$sth->execute or die $dbh->errstr;
	while (my $tag = $sth->fetchrow) {
		my $tag_q = $dbh->quote($tag);
		$dbh->do("INSERT INTO message VALUES (NULL, $id, $tag_q, NULL)") or die $dbh->errstr;
	}
	$sth->finish;
}

sub new_tag {
	my ($self, $tag, $value) = @_;
	my $dbh = $self->{_dbh};
	my $tag_q = $dbh->quote($tag);
	my $value_q = $dbh->quote($value);
	my $ary_ref = $dbh->selectcol_arrayref("SELECT id FROM message WHERE value=$tag_q");
	return if (@{$ary_ref}[0] =~ /\d+/);

	my $sth = $dbh->prepare("SELECT id FROM language");
	$sth->execute or die $dbh->errstr;
	while (my $id = $sth->fetchrow) {
		$dbh->do("INSERT INTO message VALUES (NULL, $id, $tag_q, $value_q)") or die $dbh->errstr;
	}
	$sth->finish;
	return;
}

sub delete_language {
	my ($self, $language) = @_;
	return if ($language eq 'English');		# Good ole cultural imperialism :^)
	return if ($language eq $self->{_config}->{_language});

	my $dbh = $self->{_dbh};
	my $language_q = $dbh->quote($language);
	my $ary_ref = $dbh->selectcol_arrayref("SELECT id FROM language WHERE name=$language_q");
	my $id = @{$ary_ref}[0];
	return unless ($id =~ /\d+/);

	$dbh->do("DELETE FROM language WHERE id=$id");
	$dbh->do("DELETE FROM message WHERE language_id=$id");

	return;
}

sub tran {
	my ($self, $tag) = @_;
	my $language = $self->{_config}->{_language};

	my $dbh = $self->{_dbh};
	my $language_q = $dbh->quote($language);
	my $ary_ref = $dbh->selectcol_arrayref("SELECT id FROM language WHERE name=$language_q");
	my $id = @{$ary_ref}[0];

	my $tag_q = $dbh->quote($tag);
	$ary_ref = $dbh->selectcol_arrayref("SELECT value FROM message WHERE language_id=$id AND tag=$tag_q");
	my $message = @{$ary_ref}[0];
	return $message;
}

1;
