package Squidalyser::ListManager;
$VERSION = 0.1;
use strict;
use Carp;
use CGI;

#
#   ListManager.pm, module to handle squidalyser lists (http://ababa.org/)
#   Copyright (C) 2001-2002  Simon J Burns.
#
#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#


#
# This module handles all list-related functions for squidalyser, eg creating
# and deleting lists, adding and removing elements.
#

sub new {
	my ($class, %args) = @_;

	# _dbh			Database handle.
	# _listname		Name of the current list.
	# _listmembers		The HTML control returned by get_list_members.
	# _listnonmembers	The HTML control returned by get_list_non_members.
	# _scope		Set to 'all' or 'some' to determine if we 'add all'/'remove all'
	# 				or just remove the selected items.
	# _listtype		Set to 'w' or 'u' to determine if we're handling users or words.
	# _lists		The HTML control returned by get_lists below.

	bless {
		_dbh			=> $args{dbhandle},
		_listname		=> undef,
		_listmembers		=> undef,
		_listnonmembers		=> undef,
		_scope			=> undef,
		_listtype		=> undef,
		_lists			=> undef,
		_msg			=> $args{msg},
	}, $class;
}

sub check_new_list_name {

#
# Check that the user entered a valid list name, and that it isn't already in
# use.
#
# Known wart: all lists must be uniquely named, rather than being unique within
# lists of a similar type. So you can't have a user-list called 'teapot' and a
# words-list called 'teapot' (if you should ever want such a thing anyway...)
#

	# Allowed chars = A-Z, a-z, 0-9 and _ only (ie match with \w)
	my ($self, $name) = @_;
	unless (length($name)) { return $self->{_msg}->tran('noname_list') };
	unless ($name =~ /^\w+$/) { return $name . $self->{_msg}->tran('only_val_char') };

	# Name already exists in DB?
	my $dbh = $self->{_dbh};
	my $name_q = $dbh->quote($name);
	my $query = qq|SELECT id FROM list WHERE name=$name_q|;
	my $sth = $dbh->prepare($query);
	$sth->execute or die $dbh->errstr;
	my $rows = $sth->rows;
	$sth->finish;
	if ($rows) { return $name . $self->{_msg}->tran('al_exists') };

	return;
}

sub new_list {

#
# Create a shiny new list.
#

	my ($self, $name) = @_;
	my $dbh = $self->{_dbh};
	my $name_q = $dbh->quote($name);
	my $query = qq|INSERT INTO list VALUES (NULL, $name_q, '$self->{_listtype}')|;
	my $sth = $dbh->prepare($query);
	$sth->execute or die $dbh->errstr;
	$sth->finish;
	return;
}

sub delete_list {

#
# Delete a list and all its members from the database.
#

	my ($self, $name) = @_;
	my $dbh = $self->{_dbh};
	my $name_q = $dbh->quote($name);

	# Seek ... (get the list's id number).
	my $query = qq|SELECT id FROM list WHERE name=$name_q|;

	my $sth = $dbh->prepare($query);
	$sth->execute or die $dbh->errstr;
	$sth->rows or return;
	my $id = $sth->fetchrow;
	$sth->finish;

	# ... and destroy (remove the list and then its members).
	$dbh->do(qq|DELETE FROM list WHERE name=$name_q|);
	$dbh->do(qq|DELETE FROM list_member WHERE list_id=$id|);

	return;
}

sub get_list_members {

#
# Find out which elements are members of a list.
#

	my ($self, $name) = @_;
	my $dbh = $self->{_dbh};
	my $name_q = $dbh->quote($name);

	# This will provide a list of list-members.
	my $query = qq|
		SELECT value
		FROM list_member,list
		WHERE list_member.list_id=list.id
		AND list.name=$name_q
		ORDER BY value
	|;
	my $ary_ref = $dbh->selectcol_arrayref($query);

	# Store HTML control in a string and put that into _listmembers.
	my $lists = CGI::scrolling_list (
		-name		=> 'list_members',
		-values		=> \@{$ary_ref},
		-multiple	=> 'true',
		-size		=> 8,
	);
	$self->{_listmembers} = $lists;
	return;
}

sub show_list_members {
	my $self = shift;
	return $self->{_listmembers};
}

sub get_list_non_members {

#
# Create a simple text-entry field to allow the user to enter words (if we're
# dealing with lists of words); or get the list of users who are not members of
# the list and place their usernames in a scrolling list box.
#

	my $self = shift;
	my $non_members_box;

	# If we're dealing with words, it's easy.
	if ($self->{_listtype} eq 'w') {
		$non_members_box =
			'<textarea name="list_non_members" cols=40 rows=5></textarea><p><small>' . 
			$self->{_msg}->tran('ent_sep_list') . '</small>';
	} else {
	# If it's users we're interested in, we first get the members of the list,
	# then the complete list of users from the database, and then find the list
	# of non-members by comparing those two lists.
		my $dbh = $self->{_dbh};
		my $non_members;
		my $listname_q = $dbh->quote($self->{_listname});
		my $listtype_q = $dbh->quote($self->{_listtype});
		my $query = qq|
			SELECT value
			FROM list_member, list
			WHERE list_id=list.id
			AND name=$listname_q
			AND type=$listtype_q
		|;
		my $list_members = $dbh->selectcol_arrayref($query);
		my %members;
		foreach my $member (@{$list_members}) { $members{$member}++ };

		$query = qq|SELECT DISTINCT(rfc931) FROM logfile WHERE rfc931 != '-'|;
		my $everyone = $dbh->selectcol_arrayref($query);
		foreach my $rfc931 (@{$everyone}) {
			# Get the next item in the list if the username is a member of the list.
			$members{$rfc931} and next;
			push @{$non_members}, $rfc931;
		}
		$non_members_box = CGI::scrolling_list (
			-name		=> 'list_non_members',
			-values		=> \@{$non_members},
			-multiple	=> 'true',
			-size		=> 8,
		);
	}
	$self->{_listnonmembers} = $non_members_box;
}

sub show_list_non_members {
	my $self = shift;
	return $self->{_listnonmembers};
}

sub get_lists {

#
# Get a list of lists from the database. We specify either word- or user-lists
# by selecting against the '$self->{_listtype}' attribute.
#

	my $self = shift;
	my $dbh = $self->{_dbh};
	my $ary_ref;
	my $query = qq|SELECT DISTINCT(name) FROM list WHERE type='$self->{_listtype}' ORDER BY name|;
	my $sth = $dbh->prepare($query);
	$sth->execute or die $dbh->errstr;
	if ($sth->rows) {
		$ary_ref = $dbh->selectcol_arrayref($query);
	} else {
		$ary_ref = ['~' . $self->{_msg}->tran('none_def') . '~'];
	}

	my $lists;

	if ($self->{_listtype} eq 'u') {
		$lists = CGI::scrolling_list (
			-name           => 'groups_list',
			-values         => \@{$ary_ref},
			-multiple       => 'true',
			-size           => 8,
		);
	} else {
		$lists = CGI::scrolling_list (
			-name           => 'words_list',
			-values         => \@{$ary_ref},
			-multiple       => 'true',
			-size           => 8,
		);
	}

	$self->{_lists} = $lists;
}

sub show_lists {
	my $self = shift;
	$self->get_lists;
	return $self->{_lists};
}

sub add_items_to_list {

#
# Add some or all of the items in the list-box/text-entry field to the list. In
# the case of word-lists, 'Add' and 'Add all' amount to the same thing: all
# words will be added to the list.
#

	my ($self, @list) = @_;
	my $listtype = $self->{_listtype};
	if ($listtype eq 'w') {
		my $list = $list[0];
		$list =~ s/,/ /g;
		$list =~ s/\r\n/ /g;
		$list =~ s/\n/ /g;
		@list = split(/\s+/, $list);
	}

	my $dbh = $self->{_dbh};

	my $listname = $self->get_list_name;
	my $listname_q = $dbh->quote($listname);
	my $listtype_q = $dbh->quote($listtype);
	my $sth = $dbh->prepare(qq|SELECT id FROM list WHERE name=$listname_q AND type=$listtype_q|);
	$sth->execute or die $dbh->errstr;
	my $list_id = $sth->fetchrow;
	$sth->finish;

	# This is the 'Add all' case for users.
	if (($self->{_listtype} eq 'u') and ($self->{_scope} eq 'all')) {
		$dbh->do("DELETE FROM list_member WHERE list_id=$list_id");

		my $query = qq|SELECT DISTINCT(rfc931) FROM logfile WHERE rfc931 != '-'|;

		my $everyone = $dbh->selectcol_arrayref($query);
		$sth = $dbh->prepare("INSERT INTO list_member(id, list_id, value) VALUES (?,?,?)");
		foreach my $rfc931 (@{$everyone}) {
			$sth->execute('NULL', $list_id, $rfc931) or die $dbh->errstr;
		}
	} else {
	# This takes care of everything else - selected users or all words will be added to the list.
		my $ary_ref = $dbh->selectcol_arrayref(qq|SELECT value FROM list_member WHERE list_id=$list_id|);
		my %seen;

		foreach my $word (@{$ary_ref}) { $seen{$word} = 1 };

		$sth = $dbh->prepare("INSERT INTO list_member(id, list_id, value) VALUES (?,?,?)");
		foreach my $item (@list) {
			# FIXME we should probably tell them if the word is too long.
			length($item) > 64 and next;
			$seen{$item}++ and next;
			$sth->execute('NULL', $list_id, $item) or die $dbh->errstr;
		}
		$sth->finish;
	}
	return;
}

sub set_list_name {
	my ($self, $listname) = @_;
	$self->{_listname} = $listname;
	return;
}

sub set_list_type {
	my ($self, $listtype) = @_;
	$self->{_listtype} = $listtype;
	return;
}

sub set_scope {
	my ($self, $scope) = @_;
	$self->{_scope} = $scope;
	return;
}

sub get_list_name {
	my $self = shift;
	return $self->{_listname};
}

sub get_list_type {
	my $self = shift;
	return $self->{_listtype};
}

sub remove_items_from_list {

#
# Clear all or some items from a list.
#

	my ($self, @items) = @_;

	my $dbh = $self->{_dbh};

	my $listname = $self->get_list_name;
	my $listname_q = $dbh->quote($listname);
	my $sth = $dbh->prepare(qq|SELECT id FROM list WHERE name=$listname_q|);
	$sth->execute or die $dbh->errstr;
	my $id = $sth->fetchrow;
	$sth->finish;

	my $query = qq|DELETE FROM list_member WHERE list_id=$id|;

	if ($self->{_scope} eq 'some') {
		foreach my $item (@items) {
			my $item_q = $dbh->quote($item);
			$query .= qq| OR value=$item_q|;
		}
		$query .= ')';
		$query =~ s/OR /AND \(/;
	}

	$dbh->do($query);
	return;
}

1;
