package Squidalyser::HTMLControls;
$VERSION = 0.1;
use strict;
use Carp;
use CGI;

#
#   HTMLControls.pm, module to provide squidalyser HTML "widgets" (http://ababa.org/)
#   Copyright (C) 2001-2002  Simon J Burns.
#
#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#


# Module to create HTML controls for squidalyser. This is being/has been
# superseded by ListManager.pm, but is still used.

sub new {
	my ($class, %args) = @_;

	my $msg = $args{msg};

	my %labels = (
		listpages	=> $msg->tran('list_pages'),
		listsites	=> $msg->tran('list_sites'),
		pictures	=> $msg->tran('pics_viewed'),
		blocked		=> $msg->tran('blocked_acc'),
		graphbytes	=> $msg->tran('graph_act_byte'),
		graphitems	=> $msg->tran('graph_act_item'),
	);

	my $type_of_results = CGI::radio_group (
		-name		=>	'type_of_result',
		-values		=>	[qw|listpages listsites pictures blocked graphbytes graphitems|],
		-default	=>	$Q::type_of_result,
		-linebreak	=>	'true',
		-labels		=>	\%labels,
	);

	# _type_of_results	Format of results (according to list in %labels above).
	# _groups		A list of groups (ie user lists) contained in the DB.
	# _groups_default	The selected group(s) after the form has been submitted.
	# _users		A list of users.
	# _user_default		The selected user(s) after the form has been submitted.
	# _words_lists		A list of lists of words.
	# _words_default	The selected word(s) after the form has been submitted.
	# _dbh			The database handle to use for queries.

	bless {
		_type_of_results	=> $type_of_results,
		_groups			=> undef,
		_groups_default		=> $args{groups_default},
		_users			=> undef,
		_user_default		=> $args{user_default},
		_words_lists		=> undef,
		_words_default		=> $args{words_default},
		_dbh			=> $args{dbhandle},
		_msg			=> $args{msg},
	}, $class;
}

sub get_users {

#
# Show a list of users from the DB.
#

	my $self = shift;
	my $dbh = $self->{_dbh};
	my $ary_ref;
	my $query = q|SELECT DISTINCT(rfc931) FROM logfile WHERE rfc931 != '-' ORDER BY rfc931|;
	my $sth = $dbh->prepare($query);
	$sth->execute or die $dbh->errstr;
	if ($sth->rows) {
		$ary_ref = $dbh->selectcol_arrayref($query);
	} else {
		$ary_ref = ['~' . $self->{_msg}->tran('none_def') . '~'];
	}
	$sth->finish;

	my $users = CGI::scrolling_list (
		-name		=> 'rfc931',
		-values		=> \@{$ary_ref},
		-multiple	=> 'true',
		-size		=> 8,
		-default	=> \$self->{_user_default},
	);

	$self->{_users} = $users;
}

sub get_lists {

#
# Show a list of lists of users. Note this is specific to 'users', not words
# and has been superseded in part by the ListManager module.
#

	my $self = shift;
	my $dbh = $self->{_dbh};
	my $ary_ref;
	my $query = q|SELECT DISTINCT(name) FROM list WHERE type='u' ORDER BY name|;
	my $sth = $dbh->prepare($query);
	$sth->execute or die $dbh->errstr;
	if ($sth->rows) {
		$ary_ref = $dbh->selectcol_arrayref($query);
	} else {
		$ary_ref = ['~' . $self->{_msg}->tran('none_def') . '~'];
	}

	my $groups = CGI::scrolling_list (
		-name		=> 'groups',
		-values		=> \@{$ary_ref},
		-multiple	=> 'true',
		-size		=> 8,
	);

	$self->{_groups} = $groups;
}

sub show_type_of_results {
	my $self = shift;
	return $self->{_type_of_results};
}

sub show_users {
	my $self = shift;
	$self->get_users;
	return $self->{_users};
}

sub show_lists {
	my $self = shift;
	$self->get_lists;
	return $self->{_groups};
}

sub show_words_lists {
	my $self = shift;
	$self->get_words_lists;
	return $self->{_words_lists};
}

sub show {
	my ($self, $control) = @_;
	print $self->{$$control};
	return;
}

1;
