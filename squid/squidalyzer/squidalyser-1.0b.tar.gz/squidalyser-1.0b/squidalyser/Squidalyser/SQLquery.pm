package Squidalyser::SQLquery;
$VERSION = 0.1;
use strict;
use Carp;
use URI::Escape;

#
#   SQLQuery.pm, module to handle squidalyser SQL queries (http://ababa.org/)
#   Copyright (C) 2001-2002  Simon J Burns.
#
#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#


#
# Module to compose and execute MySQL queries for squidalyser.
#

sub new {
	my ($class, %args) = @_;
	bless {

	# _db_handle		Database handle to use for queries.
	# _type_of_result	The type of result (graph, list of sites, etc) required.
	# _substring		User-specified substring to be matched against URLs.
	# _user_system		User-specified computer from which the web-user has been using the squid proxy.
	# _limit		A limit on the number of results (usually rows, or users if returning a graph).
	# _url_limit		Max length of URL - for neatness it may be truncated to this length.
	# _hilo			Whether to return most active users' results first or last.
	# _query		The finished query.
	# _results		The results.
	# _graph_results	The graph results.
	# _form_params		The form parameters as entered by the user.

		_db_handle	=> $args{dbhandle},
		_type_of_result	=> $args{type_of_result},
		_substring	=> $args{substring},
		_user_system	=> $args{user_system},
		_limit		=> $args{limit},
		_url_limit	=> $args{url_limit},
		_hilo		=> $args{hilo},
		_query		=> undef,
		_results	=> undef,
		_graph_results	=> undef,
		_form_params	=> $args{form_params},
		_msg		=> $args{msg},
	}, $class;
}

sub compose {

#
# Compose a MySQL query by calling other routines within this module.
#

	my $self = shift;

	$self->select_clause;

	my @rfc931 = $self->{_form_params}->param('rfc931');
	my @groups = $self->{_form_params}->param('groups_list');
	if (($#rfc931 > -1) or ($#groups > -1)) { $self->rfc931_clause };
	my @words_lists = $self->{_form_params}->param('words_list');
	if (($self->{_substring}) or ($#words_lists > -1)) { $self->substring_clause };

	$self->{_user_system} and $self->user_system_clause;
	$self->group_by_clause;
	$self->order_by_clause;
	$self->{_limit} and $self->limit_clause;

#	debug($self->{_query});

	return;
}

sub show_results {

#
# Show the reults of the query, either by returning them or calling squidimg.pl
# to make a graph.
#

	my $self = shift;
	unless (($self->{_type_of_result} eq 'graphbytes') or ($self->{_type_of_result} eq 'graphitems'))  {
		return $self->{_results};
	}

	# Create the URL required to call squidimg.pl ...
	if ($self->{_type_of_result} eq 'graphbytes') {
		$self->{_results} .=
			'<p align="center"><img src="/cgi-bin/squidimg.pl?title=' .
			$self->{_msg}->tran('bytes') . '%20' .
			$self->{_msg}->tran('downloaded') . '&ylabel=Bytes&';
	} elsif ($self->{_type_of_result} eq 'graphitems') {
		$self->{_results} .= '<p align="center"><img src="/cgi-bin/squidimg.pl?title=' .
			$self->{_msg}->tran('items') . '%20' .
			$self->{_msg}->tran('downloaded') . '&ylabel=Items&';
	}

	# ... then add each user in turn.
	foreach my $user (keys %{$self->{_graph_results}}) {
		$user eq '-' and next;
		my $user_q = uri_escape($user);
		my $total = $self->{_graph_results}->{$user};
		$self->{_results} .= qq|$user_q=$total&|;
	}
	chop($self->{_results}); # remove trailing ampersand
	$self->{_results} .= qq|"></p>|;
	return $self->{_results};
}

sub quote_like {

#
# Rearranges a quoted string so it can be used in a << LIKE '%string%' >>
# clause
#

	my $string = shift;
	$string = qq|\%$string\%|;
	$string =~ s/\'\%/\%\'/;
	$string =~ s/\%\'/\'\%/;
	return $string;
}

sub select_clause {

#
# Create the initial part of the SQL query.
#
	my $self = shift;
	if ($self->{_type_of_result} eq 'graphbytes') {
		# A column of usernames matched with total bytes for each user.
		$self->{_query} = 'SELECT rfc931,sum(bytes) AS req_total FROM logfile ';
	} elsif ($self->{_type_of_result} eq 'graphitems') {
		# Column of usernames matched with total requests made by each user.
		$self->{_query} = 'SELECT rfc931,count(*) AS req_total FROM logfile ';
	} else {
		$self->{_query} = 'SELECT * FROM logfile ';
	}
	# The '-' user occurs when squid is initially asking for username/password. We're
	# not interested in it.
	$self->{_query} .= q|WHERE rfc931 != '-' |;
	return;
}

sub rfc931_clause {
	my $self = shift;
	my @rfc931 = $self->{_form_params}->param('rfc931');
	my @groups = $self->{_form_params}->param('groups_list');
	my %seen;
	foreach my $rfc931 (@rfc931) { $seen{$rfc931}++ };
	if ($#groups > -1) {
		my $dbh = $self->{_db_handle};
		my $query = qq|SELECT DISTINCT(value) FROM list_member,list WHERE (|;
		foreach my $group (@groups) {
			next if $group eq '~ ' . $self->{_msg}->tran('none_def') . ' ~';
			my $group_q = $dbh->quote($group);
			$query .= qq|OR list.name=$group_q |;
		}
		$query .= ') AND list_id=list.id ORDER BY value';
		$query =~ s/OR //;
		my $sth = $dbh->prepare($query);
		$sth->execute or $dbh->errstr;
		my $ary_ref = $dbh->selectcol_arrayref($query);
		$sth->finish;
		foreach my $rfc931 (@{$ary_ref}) {
			$seen{$rfc931}++ and next;
			push @rfc931, $rfc931;
		}
	}
	my $query = 'AND (';
	foreach my $rfc931 (@rfc931) {
		my $rfc931_q = $self->{_db_handle}->quote($rfc931);
		$query .= qq|OR rfc931=$rfc931_q |;
	}
	$query .= ') ';
	$query =~ s/OR //;
	$self->{_query} .= $query;
}

sub substring_clause {
	my $self = shift;
	my $dbh = $self->{_db_handle};

	my @words;
	if ($self->{_substring}) {
		my $substring = $self->{_substring};
		$substring =~ s/,\s+/,/g;
		my @substring = split(/,/, $substring);
		foreach my $word (@substring) {
			if ($word =~ /\?/) {
				my @alt_words = alt_words($word);
				foreach my $alt_word(@alt_words) { push @words, uri_escape($alt_word) };
			} else {
				push @words, uri_escape($word);
			}
		}
	}

	my @words_lists = $self->{_form_params}->param('words_list');
	foreach my $words_list (@words_lists) {
		# get the IDs of each list in the list of lists selected by user
		my $words_list_q = $dbh->quote($words_list);
		my $query = qq|SELECT id FROM list WHERE name=$words_list_q|;
		my $sth = $dbh->prepare($query);
		$sth->execute or die $dbh->errstr;
		my $words_list_id = $sth->fetchrow;
		$sth->finish;

		$query = qq|
			SELECT DISTINCT(value)
			FROM list_member,list
			WHERE list_id=list.id
			AND list.id=$words_list_id
		|;
		my $ary_ref = $dbh->selectcol_arrayref($query);
		$sth->finish;
		my %seen;
		foreach my $word (@{$ary_ref}) {
			$seen{$word}++ and next;
			if ($word =~ /\?/) {
				my @alt_words = alt_words($word);
				foreach my $alt_word(@alt_words) { push @words, uri_escape($alt_word) };
			} else {
				push @words, uri_escape($word);
			}
		}
	}

	my $query = 'AND (';
	foreach my $word (@words) {
		my $word_q = $dbh->quote($word);
		$word_q = quote_like($word_q);
		$query .= qq|OR request LIKE $word_q |;
	}
	$query .= ') ';
	$query =~ s/OR //;
	$self->{_query} .= $query;
}

sub alt_words {
	# word can be 'sex?teen' (for example ;-) to get 'sex-teen', 'sex_teen', 'sex teen', 'sexteen'
	my $word = shift;
	my @alt_words;
	foreach my $char ('_', '-', ' ', '') {
		my $alt_word = $word;
		$alt_word =~ s/\?/$char/g;
		push @alt_words, $alt_word;
	}
	return @alt_words;
}

sub user_system_clause {
	my $self = shift;
	my $user_system_q = $self->{_db_handle}->quote($self->{_user_system});
	$self->{_query} .= qq|AND remotehost=$user_system_q |;
	return;
}

sub group_by_clause {
	my $self = shift;
	if (($self->{_type_of_result} eq 'graphbytes') or ($self->{_type_of_result} eq 'graphitems'))  {
		$self->{_query} .= 'GROUP BY rfc931 ';
	} else {
		$self->{_query} .= 'GROUP BY id,rfc931 ';
	}
	return;
}

sub order_by_clause {
	my $self = shift;
	if (($self->{_type_of_result} eq 'graphbytes') or ($self->{_type_of_result} eq 'graphitems'))  {
		$self->{_query} .= 'ORDER BY req_total ';
		$self->{_hilo} eq 'high' and $self->{_query} .= 'DESC ';
	} else {
		$self->{_query} .= 'ORDER BY rfc931,id ';
	}
	return;
}

sub limit_clause {
	my $self = shift;
	$self->{_query} .= qq|LIMIT $self->{_limit} |;
	return;
}

sub execute {
	my $self = shift;
	my $query = $self->{_query};
	my $dbh = $self->{_db_handle};
	my $url_limit = $self->{_url_limit};
	my $sth = $dbh->prepare($query);
	my %site_names;
	$sth->execute or die $!;
	if (($self->{_type_of_result} eq 'graphbytes') or ($self->{_type_of_result} eq 'graphitems'))  {
		while (my ($rfc931, $total) = $sth->fetchrow) {
			$self->{_graph_results}->{$rfc931} = $total;
		}
	} else {
		$self->{_results} = '<p><b>' . $self->{_msg}->tran('results') . '</b></p><table border=1 cellpadding=5>';
		while (my ($id, $remhost, $rfc931, $auth, $req, $sta, $bytes, $time) = $sth->fetchrow) {
			my $short_url = $self->short_url($req);
			if ($self->{_type_of_result} eq 'listsites') {
				$req = site_name($req);
				$site_names{$rfc931}->{$req}++;
			} else {
				$req = urlify($req, $short_url);
				$time = readable_date($time);
				$time =~ s/\s+/\&nbsp\;/g;
				my $submit_but = $self->{_msg}->tran('submit_but');
				$self->{_results} .= qq|<tr>
					<td>
					<a href="./squidalyser.pl?rfc931=$rfc931&submit=$submit_but&url_limit=$url_limit">
						$rfc931
					</a></td>
					<td>$req</td>
					<td>$remhost</td>
					<td>$sta</td>
					<td>$bytes</td>
					<td>$time</td>
				</tr>|;
			}
		}
		if ($self->{_type_of_result} eq 'listsites') {
			$self->{_results} .=
				'<tr><th>' .
				$self->{_msg}->tran('user') .
				'</th><th>' .
				$self->{_msg}->tran('site') .
				'</th><th>' .
				$self->{_msg}->tran('num_req') .
				'</th></tr>';
			# This does my 'ead in :-} Mostly ripped from ch 4.7.1 "Programming Perl".
			foreach my $rfc931 (sort keys %site_names) {
				foreach my $req (keys %{ $site_names{$rfc931} } ) {
					my $num = $site_names{$rfc931}{$req};
					my $short_url = $self->short_url($req);
					$req = urlify($req, $short_url);
					$self->{_results} .= qq|<tr>
						<td>$rfc931</td>
						<td>$req</td>
						<td>$num</td>
					</tr>|;
				}
			}
		}
		$self->{_results} .= '</table>';
	}
	return;
}

sub site_name {
	my $request = shift;
	if ($request =~ /(http:\/\/.*?\/)/) { $request = $1 };
	return $request;
}

sub urlify {
	my ($req, $short_url) = @_;
	$short_url ||= $req;
	my $clickable = qq|<a href="$req">$short_url</a>|;
	return $clickable;
}

sub short_url {
	my ($self, $url) = @_;
	$self->{_url_limit} or return $url;

	my $length = $self->{_url_limit};
	$length > length($url) and return $url;

	my $half_length = ($length -3) / 2;
	my $string_start = substr $url, 0, $half_length;
	my $string_end = substr $url, -$half_length, $half_length;
	my $short_url = qq|$string_start ~ $string_end|;
	return $short_url;
}

sub readable_date {
	my $ctime = shift;
	my $date_string = localtime($ctime);
	my @date_elements = split(/\s+/, $date_string);
	my $short_date = qq|$date_elements[1] $date_elements[2] $date_elements[3]|;
	return $short_date;
}

sub debug {
	my $param = shift;
	print "Content-type: text/html\n\n" . $param;
	exit;
}

1;
