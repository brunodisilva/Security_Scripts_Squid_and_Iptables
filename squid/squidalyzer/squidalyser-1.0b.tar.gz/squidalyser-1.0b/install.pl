#!/usr/bin/perl

#
#   install.pl, script to install squidalyser program (http://ababa.org/)
#   Copyright (C) 2001-2002  Simon J Burns.
#
#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#

print qq|

This script will attempt to install the files required to run squidalyser. It
will create a /usr/local/squidalyser directory, archiving any previous
installation at /usr/local/squidalyser or /usr/local/squidparse.

A number of default locations for the web scripts and graphics will be
suggested before the installation begins. You can press <return> to accept the
default -- this script will have checked for its existence and that you have
write permissions to it. Or you can enter an alternative location and press
<return>. The alternative directory, if specified, must exist and be writable.

#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

|;

$accept = question(qq|Press "A" <return> to continue or any other key to abort...  |);
$accept = lc($accept);
$accept eq 'a' or do {
	print "Exiting without install.\n";
	exit;
};

print "\n";
my ($d_basedir, $d_cgidir, $d_icondir, $d_htmldir) = get_defaults();

$basedir = question("Enter your base web directory [$d_basedir]: ");
length($basedir) or $basedir = $d_basedir;
$basedir =~ s/\/$//;
direxists($basedir);

$cgidir  = question("Enter your CGI directory [$d_cgidir]: ");
length($cgidir) or $cgidir = $d_cgidir;
$cgidir =~ s/$basedir//g;
$cgidir =~ s/\///g;
direxists("$basedir/$cgidir");

$icondir  = question("Enter your icons/graphics directory [$d_icondir]: ");
length($icondir) or $icondir = $d_icondir;
$icondir =~ s/$basedir//g;
$icondir =~ s/\///g;
direxists("$basedir/$icondir");

$htmldir  = question("Enter your html documents directory [$d_htmldir]: ");
length($htmldir) or $htmldir = $d_htmldir;
$htmldir =~ s/$basedir//g;
$htmldir =~ s/\///g;
direxists("$basedir/$icondir");

my $overw_message;
my $existing_dir;
if (-w "/usr/local/squidparse") {
	$existing_dir = "/usr/local/squidparse"
} elsif (-w "/usr/local/squidalyser") {
	$existing_dir = "/usr/local/squidalyser"
}

if ((-w $existing_dir) and (-w "/tmp")) {
	$overw_message = "(existing $existing_dir will be archived to /tmp)";
}

print qq|
Proceeding with the following defaults:

Base web directory:\t$basedir
CGI scripts directory:\t$basedir/$cgidir
Icons/graphics dir:\t$basedir/$icondir
HTML docs dir:\t$basedir/$htmldir
Squidalyser home dir:\t/usr/local/squidalyser $overw_message

Enter "C" <return> to continue, any other key to abort...

|;

my $response = <STDIN>;
chomp $response;
$response = lc($response);
$response eq 'c' or do {
	print "\nAborted installation. Nothing has been changed.\n\n";
	exit;
};

$existing_dir and system("tar -zcvf /tmp/squidalyser.tar.gz $existing_dir/*");
system("rm -rf /usr/local/squidalyser");
system("mkdir /usr/local/squidalyser");
system("cp -v cgi-bin/* $basedir/$cgidir");
system("cp -v icons/* $basedir/$icondir");
system("cp -rv squidalyser/* /usr/local/squidalyser");

$existing_dir and print("tar -zcvf /tmp/squidalyser.tar.gz $existing_dir/*\n");
print("rm -rf /usr/local/squidalyser\n");
print("mkdir /usr/local/squidalyser\n");
print("cp -v cgi-bin/* $basedir/$cgidir\n");
print("cp -v icons/* $basedir/$icondir\n");
print("cp -v html/* $basedir/$htmldir\n");
print("cp -rv squidalyser/* /usr/local/squidalyser\n");

print "\nDone.\n";
exit;

sub question {
	my $question = shift;
	print $question;
	my $reply = <STDIN>;
	chomp $reply;
	return $reply;
}

sub direxists {
	my $dir = shift;
	return if (-w $dir);
	print "$dir is not writable, or does not exist. Please check and try again.\n\n";
	exit;
}

sub get_defaults {
	my @base_guesses = qw(/usr/local/apache /usr/local/httpd /var/www /home/httpd /httpd );
	my ($d_basedir, $d_cgidir, $d_icondir, $d_htmldir);
	foreach my $dir (@base_guesses) {
		if (-w $dir) { $d_basedir = $dir };
	}
	my @cgi_guesses = qw(cgi cgi-bin cgibin);
	foreach my $dir (@cgi_guesses) {
		if (-w "$d_basedir/$dir") { $d_cgidir = $dir };
	}
	my @icon_guesses = qw(icons pics images graphics);
	foreach my $dir (@icon_guesses) {
		if (-w "$d_basedir/$dir") { $d_icondir = $dir };
	}
	my @html_guesses = qw(html htdocs);
	foreach my $dir (@html_guesses) {
		if (-w "$d_basedir/$dir") { $d_htmldir = $dir };
	}
	return ($d_basedir, $d_cgidir, $d_icondir, $d_htmldir);
}












