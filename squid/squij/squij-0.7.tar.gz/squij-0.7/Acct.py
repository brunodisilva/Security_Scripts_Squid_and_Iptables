
# This class is messy and undocumented; will revisit later. 


class Accountant:
	''' keep statistics in a easy-to-use format '''

	def __init__(self):
		self._func = {}		# stores functions that determine stats
		self._count = {}	# stores the stats
	
	def __setattr__(self, name, attr):
		if name[0] != '_': 
			self._func[name] = attr
		else:
			self.__dict__[name] = attr
	
	def __getattr__(self, attr):
		if self._count.has_key(attr):
			if self._count[attr] != 0:
				return self._count[attr]
		return 0
		
	def enter(self, item, ref):
		''' enter data and process according to set rules '''
	
		for name, func in self._func.items(): 
			fullname = ref + '_' + name
			self._count[fullname] = self._count.get(fullname, 0L) + func(item) 
			
