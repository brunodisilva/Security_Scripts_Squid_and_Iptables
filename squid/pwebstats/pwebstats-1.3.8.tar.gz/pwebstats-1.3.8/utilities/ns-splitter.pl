#!/usr/local/bin/perl
#
# split the netscape extended proxy log into cache and proxy logs
#
# Martin Gleeson, September 1995
# (c) Copyright, The University of Melbourne, 1995
#
#### ___________________________________________________________________ ####
# enter your site-specific information below

$ns_proxy_log = ""; #  path to netscape proxy log  
$out          = ""; #  path to output directory  
$proxy_log    = "$out/proxy-log";
$cache_log    = "$out/proxy-cache-log";

# end of user-configuration section
#### ___________________________________________________________________ ####


$address_type = 2;

if( $ns_proxy_log eq "" || $out eq "")
{
	print "\nError:\nNetscape proxy log and output directory not specified.\n" .
          "Please edit ns-splitter.pl and add the paths to them.\n\n";
	exit(0);
}

open(PROXY_LOG,"> $proxy_log");
open(CACHE_LOG,"> $cache_log");
open(NS,"$ns_proxy_log");

local(%hosts);

$date_now=`date +"%I:%M %p, %A %B %e %Y"`; chop($date_now);
print STDERR "===================================================================\n";
print STDERR "ns-splitter.pl started at $date_now.\n";
print STDERR "===================================================================\n";

open(COUNT,"wc -l $ns_proxy_log |");
while( <COUNT> ){ chop; ($line_count) = /^\s+(\d+)\s+\S+$/;  }
close(COUNT);
$inc = sprintf "%d", ( $line_count / 50 );
print STDERR "The logfile has $line_count entries.\n";
print STDERR "Each \"#\" is $inc requests\n";
print STDERR "Processing...\n";
print STDERR "0%                     50%                      100%\n";
print STDERR "|-----------------------|------------------------|\n";
$counter=0;

while( <NS> )
{
	($host,$user,$time,$req,$st1,$cnt1,$st2,$cnt2,$body1,$body2,$h1,$h2,$h3,$h4,$xfer) =
	/^(\S+) - (\S+) \[(.+)\] \"(.+)\" (\S+) (\S+) (\S+) (\S+) (\S+) (\S+) (\S+) (\S+) (\S+) (\S+) (\S+)$/;
	$name = "";

	$counter += 1;
	if( $counter >= $inc )
	{
		$counter = 0;
		print STDERR "#";
	}

	if( $hosts{$host} ) { $name = $hosts{$host};}
	else
    {
        if($host =~ /\d\d\.\d\d/)
        {
                @address = split(/\./,$host);
                $addpacked = pack('C4',@address);
                ($name,$aliases,$addrtype,$length,@addrs) = gethostbyaddr($addpacked,$address_type);
        }
        if ( $name eq "") { $name = $host };
        $name = "\L$name";
        $hosts{$host} = $name;
	}

	if( $st2 ne "304" )
	{
		if( $user ne "http" )
		{
			print PROXY_LOG "$name - - [$time] \"$req\" $st1 $cnt1\n";
		}
	}
	else
	{
		print CACHE_LOG "$name - - [$time] \"$req\" $st1 $cnt1\n";
	}
}

close(NS);
close(PROXY_LOG);
close(CACHE_LOG);

print STDERR "\n";
$date_now=`date +"%I:%M %p, %A %B %e %Y"`; chop($date_now);
print STDERR "===================================================================\n";
print STDERR "ns-splitter.pl finished at $date_now.\n";
print STDERR "===================================================================\n";

