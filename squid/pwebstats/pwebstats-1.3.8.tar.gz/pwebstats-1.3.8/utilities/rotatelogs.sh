#!/bin/sh
#
# Turn over the server log files
# Run once a week from http's crontab at 00:00 sunday
#
# Stops all the servers, moved the logfiles, and then restarts the servers
#
# Original by Danny O'Callaghan
# Rewritten by Martin Gleeson
#
# (c) Copyright the University of Melbourne, 1995
#
# This program is provided free of charge provided the Copyright
# notice remains intact. No warranty is made, either expressed or
# implied. USE AT YOUR OWN RISK.
#

PATH=:/bin:/usr/bin:/etc:/usr/local/bin

# Start by killing the server(s)

kill `cat /home/servers/http/teldem/logs/httpd.pid`       # The http server

# Generate a suffix for this rotation of files.

DATE=`date +"%Y-%m-%d"`

# files to be rolled over

IN="/home/servers/http/teldem/logs"
HTTP="${IN}/access_log"
HTTP_AGENT="${IN}/agent_log"
HTTP_REFERER="${IN}/referer_log"
HTTP_ERROR="${IN}/error_log"

# filenames to be rolled into

OUT="/home/servers/http/teldem/old-logs"
OHTTP="${OUT}/access/http-access_log.${DATE}"
OHTTP_AGENT="${OUT}/agent/http-agent_log.${DATE}"
OHTTP_REFERER="${OUT}/referer/http-referer_log.${DATE}"
OHTTP_ERROR="${OUT}/error/http-error_log.${DATE}"

#
# Move the current file, create the new one
#

mv ${HTTP} ${OHTTP}
touch ${HTTP}
chmod 777 ${HTTP}

mv ${HTTP_ERROR} ${OHTTP_ERROR}
touch ${HTTP_ERROR}
chmod 777 ${HTTP_ERROR}

mv ${HTTP_AGENT} ${OHTTP_AGENT}
touch ${HTTP_AGENT}
chmod 777 ${HTTP_AGENT}

mv ${HTTP_REFERER} ${OHTTP_REFERER}
touch ${HTTP_REFERER}
chmod 777 ${HTTP_REFERER}

# restart the http server(s)

/home/servers/http/teldem/httpd.start

# set up links to current logs for processing by pwebstats

rm ${OUT}/access-log.current
ln -s ${OHTTP} ${OUT}/access-log.current
chmod 666 ${OUT}/access-log.current
chmod 666 ${OHTTP}

#####

# compress logs older than 2 weeks

cd ${OUT}
find ${OUT} -mtime +14 -exec nice gzip -9 {} \;
