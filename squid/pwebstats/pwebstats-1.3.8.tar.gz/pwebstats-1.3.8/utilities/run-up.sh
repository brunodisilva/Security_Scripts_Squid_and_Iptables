#!/bin/sh

# Simple shell script to feed all your old weekly/monthly logs
# into pwebstats. If you just have one big logfile, run it through
# log-splitter.pl first.
# 
# usage:
#
# run-up.sh logfile1 logfile2 ... logfileN
#
# make sure they are in chronological order!
# the output from log-splitter.pl makes this so, and you can
# use wildcards and still get them in chronological order
# (i.e. httpd-log.* will produce the correct chronological order)

# !!!  Edit the following line to be the path to your current logfile

CURRENT_LOGFILE=/path/to/current_logfile


# For each logfile on the command line, feed it into pwebstats.

for file in $*
do
	ln -s $file ${CURRENT_LOGFILE}
	./pwebstats -c ./conf/pwebstats.conf
	echo -n "pwebstats done on "
	echo -n $file
	echo "."
	rm -f ${CURRENT_LOGFILE}
done
