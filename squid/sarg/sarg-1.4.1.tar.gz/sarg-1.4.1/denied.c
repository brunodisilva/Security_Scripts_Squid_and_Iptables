/*
 * sarg - Squid user management log
 * Mar/98 - Pedro L Orso - orso@brturbo.com
 */

#include "include/conf.h"

void gen_denied_report(const char *dirname, int debug, const char *outdir, char *BgColor, char *TxColor, char *TxBgColor, char *TiColor, char *LogoImage, char *LogoText, char *LogoTextColor, char *Width, char *Height, char *Title, char *BgImage, char *FontFace, char *HeaderColor, char *HeaderBgColor, char *FontSize, char *TempDir, char *DateFormat)
{

   FILE *fp_in = NULL, *fp_ou = NULL;
      
   char url[MAXLEN];
   char html[MAXLEN];
   char html2[MAXLEN];
   char denied_in[MAXLEN];
   char denied_ou[MAXLEN];
   char per[MAXLEN];
   char report[MAXLEN];
   char periodo[100];
   char ip[MAXLEN];
   char oip[MAXLEN];
   char user[MAXLEN];
   char ouser[MAXLEN];
   char data[15];
   char hora[15];
   char ftime[128];
   char *str;
   int  z=0;

   ouser[0]='\0';

   sprintf(denied_in,"%s/denied.log",TempDir);
   if(!denied_count) {
      unlink(denied_in);
      return;
   }

   sprintf(per,"%s/periodo",dirname);
   sprintf(report,"%s/denied.html",dirname);

   if ((fp_in = fopen(per, "r")) == 0) {
      fprintf(stderr, "SARG: (denied) %s: %s\n",text[45],per);
      exit(1);
   }

   fgets(periodo,sizeof(periodo),fp_in);
   fclose(fp_in);

   if((fp_in=fopen(denied_in,"r"))==NULL) {
     fprintf(stderr, "SARG: (denied) %s: %s\n",text[8],denied_in);
     exit(1);
   }

   if((fp_ou=fopen(report,"w"))==NULL) {
     fprintf(stderr, "SARG: (denied) %s: %s\n",text[8],report);
     exit(1);
   }

   fputs("<html>\n",fp_ou);
   fputs("<head>\n",fp_ou);
   sprintf(html,"  <meta http-equiv=\"Content-Type\" content=\"text/html; charset=%s\">\n",CharSet);
   fputs(html,fp_ou);
   fputs("</head>\n",fp_ou);

   if(strlen(FontFace) > 0) {
      sprintf(url,"<font face=%s>\n",FontFace);
      fputs(url,fp_ou);
   }

   sprintf(url,"<body bgcolor=%s text=%s background='%s'>\n",BgColor,TxColor,BgImage);
   fputs(url,fp_ou);

   fputs("<center><table cellpadding=0 cellspacing=0>\n",fp_ou);

   if(strlen(LogoImage) > 0) {
      sprintf(url,"<tr><th><img src='%s' border=0 align=absmiddle width=%s height=%s>		\
		   <font color=%s>%s</font>\n",LogoImage,Width,Height,LogoTextColor,LogoText);
      fputs(url,fp_ou);
   }

   sprintf(url,"<tr><th align=center><b><font color=%s size=+1>%s</font></b></th></tr>\n",TiColor,Title);
   fputs(url,fp_ou);

   sprintf(url,"<tr><td align=center bgcolor=%s><font size=%s color=%s>%s: %s</font></td></tr>\n", HeaderBgColor,FontSize,HeaderColor,text[89],periodo);
   fputs(url,fp_ou);
   sprintf(url,"<tr><th bgcolor=%s align=center><font size=%s color=red>%s</font>		\
		 <font size=%s>%s</font></th></tr>\n",	\
		HeaderBgColor,FontSize,text[46],FontSize,text[55]);
   fputs(url,fp_ou);
   fputs("</table></center>\n",fp_ou);

   fputs("<center><table cellpadding=0 cellspacing=2>\n",fp_ou);
   fputs("<tr><td></td></tr>\n",fp_ou);
   fputs("<tr><td></td></tr>\n",fp_ou);
   fputs("<tr><td></td></tr>\n",fp_ou);
   sprintf(url,"<tr><th bgcolor=%s><font size=%s color=%s>%s</font></th>		\
		<th bgcolor=%s><font size=%s color=%s>%s</font></th>			\
		<th bgcolor=%s><font size=%s color=%s>%s</font></th>			\
		<th bgcolor=%s><font size=%s color=%s>%s</font></th></tr>\n",		\
		HeaderBgColor,FontSize,HeaderColor,text[98],						\
		HeaderBgColor,FontSize,HeaderColor,text[111],						\
		HeaderBgColor,FontSize,HeaderColor,text[110],						\
		HeaderBgColor,FontSize,HeaderColor,text[91]);
   fputs(url,fp_ou);

   while(fgets(buf,sizeof(buf),fp_in)!=NULL) {
      getword(data,buf,' ');
      getword(hora,buf,' ');
      getword(user,buf,' ');
      getword(ip,buf,' ');
      getword(url,buf,' ');

      if((str=(char *) strstr(user, "_")) != (char *) NULL ) {
         if((str=(char *) strstr(str+1, "_")) != (char *) NULL )
            fixip(user);
      }

      if(strcmp(Ip2Name,"yes") == 0) 
         ip2name(ip);

      if(!z) {
         strcpy(ouser,user);
         strcpy(oip,ip);
         z++;
      } else {
         if(strcmp(ouser,user) == 0)
            user[0]='\0';
         if(user[0] != '\0')
            strcpy(ouser,user);
         if(strcmp(oip,ip) == 0) 
            ip[0]='\0';
         if(ip[0] != '\0')
            strcpy(oip,ip);
      }

      if(UserTabFile[0] != '\0') {
         sprintf(warea,":%s:",user);
         if((str=(char *) strstr(userfile,warea)) != (char *) NULL ) {
            z1=0;
            str2=(char *) strstr(str+1,":");
            str2++;
            bzero(name, MAXLEN);
            while(str2[z1] != ':') {
               name[z1]=str2[z1];
               z1++;
            }
         } else strcpy(name,user);
      } else strcpy(name,user);

      sprintf(html2,"<tr><td bgcolor=%s><font size=%s>%s</font></td> \
			<td bgcolor=%s><font size=%s>%s</font></td> \
			<td bgcolor=%s><font size=%s>%s-%s</font></td> \
			<td bgcolor=%s><font size=%s><a href=\"%s\">%s</a></font></td></th>\n",
			TxBgColor,FontSize,name,
			TxBgColor,FontSize,ip,
			TxBgColor,FontSize,data,hora,
			TxBgColor,FontSize,url,url);
      fputs(html2,fp_ou);
   }

   fputs("</table>\n",fp_ou);

   if(strcmp(ShowSargInfo,"yes") == 0) {
      zdate(ftime, DateFormat);
      sprintf(html,"<br><br><center><font size=-2>%s <a href='%s'>%s-%s</a> %s %s</font></center>\n", text[108],URL,PGM,VERSION,text[109],ftime);
      fputs(html,fp_ou);
   }
   fputs("</html>\n",fp_ou);

   fclose(fp_in);
   fclose(fp_ou);

   unlink(denied_in);

   return;
}
