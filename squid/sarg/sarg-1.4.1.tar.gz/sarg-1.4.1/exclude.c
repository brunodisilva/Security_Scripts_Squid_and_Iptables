/*
 * sarg - Squid user management log
 * Mar/98 - Pedro L Orso - orso@brturbo.com
 */

#include "include/conf.h"

int vhexclude(char *excludefile, char *ip)
{

   char whost[1024];
   char wip1[1024], wip2[1024];
   char sn1[4], sn2[4], sn3[4];
   char str[strlen(excludefile)];

   whost[0]='\0';
   strcpy(str,excludefile);
   getword(whost,str,' ');
   
   while(strcmp(whost,"*FIM*") != 0) {

      if(strstr(ip,whost) !=0)
         return(0);

      strcpy(wip1,ip);
      getword(sn1,wip1,'.');
      getword(sn2,wip1,'.');
      getword(sn3,wip1,'.');

      sprintf(wip1,"%s.%s.%s.0",sn1,sn2,sn3);
      sprintf(wip2,"%s.%s.0.0",sn1,sn2);

      if(strstr(whost,wip1) !=0)
         return(0);

      if(strstr(whost,wip2) !=0)
         return(0);

      getword(whost,str,' ');
   }

   return(1);
}


int vuexclude(char *excludeuser, char *user)
{

   char wuser[MAXLEN];

   strcpy(wuser,user);
   strcat(wuser," ");

   if(strstr(excludeuser,wuser) != 0 )
      return(0);

   return(1);
}
