/*
 * sarg - Squid user management log
 * Mar/98 - Pedro L Orso - orso@brturbo.com
 */

#include "include/conf.h"

int totalger(const char *dirname, int debug, const char *outdir)

{


   FILE *fp_in, *fp_ou;
   long long int tnacc=0;
   long long int tnbytes=0;
   long long int telap=0;
   long long int tincache=0, toucache=0;
   char wger[MAXLEN], user[MAXLEN], nacc[10], nbytes[10], url[1024];
   char ip[MAXLEN], hora[9], data[11], elap[15];
   char incac[15], oucac[15];

   strcpy(wger,dirname);
   strcat(wger,"/geral");

   if((fp_in=fopen(wger,"r"))==NULL) {
      fprintf(stderr, "SARG: (totger) %s: %s\n",text[45],wger);
      exit(1);
   }

   fscanf(fp_in,"%s",user);
   fscanf(fp_in,"%s",nacc);
   fscanf(fp_in,"%s",nbytes);
   fscanf(fp_in,"%s",url);
   fscanf(fp_in,"%s",ip);
   fscanf(fp_in,"%s",hora);
   fscanf(fp_in,"%s",data);
   fscanf(fp_in,"%s",elap);
   fscanf(fp_in,"%s",incac);
   fscanf(fp_in,"%s",oucac);

   while(!feof(fp_in))
   {

      tnacc+=my_atoll(nacc);
      tnbytes+=my_atoll(nbytes);
      telap+=my_atoll(elap);
      tincache+=my_atoll(incac);
      toucache+=my_atoll(oucac);

      fscanf(fp_in,"%s",user);
      fscanf(fp_in,"%s",nacc);
      fscanf(fp_in,"%s",nbytes);
      fscanf(fp_in,"%s",url);
      fscanf(fp_in,"%s",ip);
      fscanf(fp_in,"%s",hora);
      fscanf(fp_in,"%s",data);
      fscanf(fp_in,"%s",elap);
      fscanf(fp_in,"%s",incac);
      fscanf(fp_in,"%s",oucac);
   }

   fclose(fp_in);

   strcpy(wger,dirname);
   strcat(wger,"/geral");

   if((fp_ou=fopen(wger,"a"))==NULL) {
    fprintf(stderr, "SARG: (totger) %s: %s\n",text[45],wger);
    exit(1);
   }

   url[0]='\0';

   my_lltoa(tnacc,val1,15);
   my_lltoa(tnbytes,val2,15);
   my_lltoa(telap,val3,15);
   my_lltoa(tincache,val4,15);
   my_lltoa(toucache,val5,15);
   sprintf(url,"TOTAL %s %s %s %s %s\n",val1,val2,val3,val4,val5);
   fputs(url,fp_ou);
   fclose(fp_ou);

   return (0);
}
