/*
 * sarg - Squid user management log
 * Mar/98 - Pedro L Orso - orso@brturbo.com
 */

#include "include/conf.h"

void ccharset()
{

   if(strcmp(CharSet,"Latin2") == 0)
      strcpy(CharSet,"ISO-8859-2");

   if(strcmp(CharSet,"Latin3") == 0)
      strcpy(CharSet,"ISO-8859-3");

   if(strcmp(CharSet,"Latin4") == 0)
      strcpy(CharSet,"ISO-8859-4");

   if(strcmp(CharSet,"Cyrillic") == 0)
      strcpy(CharSet,"ISO-8859-5");

   if(strcmp(CharSet,"Arabic") == 0)
      strcpy(CharSet,"ISO-8859-6");

   if(strcmp(CharSet,"Greek") == 0)
      strcpy(CharSet,"ISO-8859-7");

   if(strcmp(CharSet,"Hebrew") == 0)
      strcpy(CharSet,"ISO-8859-8");

   if(strcmp(CharSet,"Latin5") == 0)
      strcpy(CharSet,"ISO-8859-9");

   if(strcmp(CharSet,"Latin6") == 0)
      strcpy(CharSet,"ISO-8859-10");

   if(strcmp(CharSet,"Windows-1251") == 0)
      strcpy(CharSet,"Windows-1251");

   if(strcmp(CharSet,"Koi8-r") == 0)
      strcpy(CharSet,"KOI8-R");

   return;

}
