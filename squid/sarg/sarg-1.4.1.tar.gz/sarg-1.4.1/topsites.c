/*
 * sarg - Squid user management log
 * Mar/98 - Pedro L Orso - orso@brturbo.com
 */

#include "include/conf.h"

void topsites(const char *dirname, int debug, const char *outdir, int userip, char *BgColor, char *TxColor, char *TxBgColor, char *TiColor, char *LogoImage, char *LogoText, char *LogoTextColor, char *Width, char *Height, char *Title, char *BgImage, char *FontFace, char *HeaderColor, char *HeaderBgColor, char *FontSize, char *TempDir, char *Ip2Name, char *TopuserSortField, char *TopuserSortOrder, char *UserAgentLog, char *DateFormat)
{

   FILE *fp_in, *fp_ou;
      
   char url[MAXLEN];
   char ourl[MAXLEN];
   char nacc[20];
   char nbytes[20];
   char ttnacc[20];
   char ttnbytes[20];
   char csort[255];
   char geral[MAXLEN];
   char geral2[MAXLEN];
   char geral3[MAXLEN];
   char per[MAXLEN];
   char sites[MAXLEN];
   char report[MAXLEN];
   char periodo[100];
   char ftime[128];
   char sortf[10];
   char sortt[10];
   long long int tnacc=0;
   long long int tnbytes=0;
   long long int twork1=0, twork2=0;
   int regs=0;

   sprintf(geral,"%s/geral",dirname);
   sprintf(sites,"%s/sites",dirname);
   sprintf(geral2,"%s/geral2",dirname);
   sprintf(geral3,"%s/geral3",dirname);
   sprintf(per,"%s/periodo",dirname);
   sprintf(report,"%s/topsites.html",dirname);

   if ((fp_in = fopen(per, "r")) == 0) {
      fprintf(stderr, "SARG: (topuser) %s: %s\n",text[45],per);
      exit(1);
   }

   fgets(periodo,sizeof(periodo),fp_in);
   fclose(fp_in);

   sprintf(csort,"sort -k 4,4 -o %s %s",geral2,geral);
   system(csort);

   if((fp_in=fopen(geral2,"r"))==NULL) {
     fprintf(stderr, "SARG: (topsite) %s: %s\n",text[8],geral2);
     exit(1);
   }

   if((fp_ou=fopen(geral3,"w"))==NULL) {
     fprintf(stderr, "SARG: (topsite) %s: %s\n",text[8],geral3);
     exit(1);
   }

   while(fgets(buf,sizeof(buf),fp_in)!=NULL) {
      getword(url,buf,' ');
      if(strcmp(url,"TOTAL") == 0) {
         getword(ttnacc,buf,' ');
         getword(ttnbytes,buf,' ');
         continue;
      }
      getword(nacc,buf,' ');
      getword(nbytes,buf,' ');
      getword(url,buf,' ');

      if(!regs) {
         strcpy(ourl,url);
         regs++;
      }

      if(strcmp(url,ourl) != 0) {
         my_lltoa(tnacc,val1,15);
         my_lltoa(tnbytes,val2,15);
         sprintf(buf,"%s %s %s\n",val1,val2,ourl);
         fputs(buf, fp_ou);
         strcpy(ourl,url);
         tnacc=0;
         tnbytes=0;
      }

      tnacc+=my_atoll(nacc);
      tnbytes+=my_atoll(nbytes);
   }

   my_lltoa(tnacc,val1,15);
   my_lltoa(tnbytes,val2,15);
   sprintf(buf,"%s %s %s\n",val1,val2,ourl);
   fputs(buf, fp_ou);

   fclose(fp_in);
   fclose(fp_ou);
   unlink(geral2);

   strlow(TopsitesSortField);
   strlow(TopsitesSortType);

   if(strcmp(TopsitesSortField,"connect") == 0)
      strcpy(sortf,"1,1");
   if(strcmp(TopsitesSortField,"bytes") == 0)
      strcpy(sortf,"2,2");
   if(strcmp(TopsitesSortType,"a") == 0)
      strcpy(sortt," ");
   if(strcmp(TopsitesSortType,"d") == 0)
      strcpy(sortt,"-r");

   sprintf(csort,"sort %s -k %s -o %s %s",sortt,sortf,sites,geral3);
   system(csort);

   unlink(geral2);
   unlink(geral3);

   if((fp_in=fopen(sites,"r"))==NULL) {
     fprintf(stderr, "SARG: (topsite) %s: %s\n",text[8],sites);
     exit(1);
   }

   if((fp_ou=fopen(report,"w"))==NULL) {
     fprintf(stderr, "SARG: (topsite) %s: %s\n",text[8],report);
     exit(1);
   }

   regs=0;

   fputs("<html>\n",fp_ou);
   fputs("<head>\n",fp_ou);
   sprintf(html,"  <meta http-equiv=\"Content-Type\" content=\"text/html; charset=%s\">\n",CharSet);
   fputs(html,fp_ou);
   fputs("</head>\n",fp_ou);

   if(strlen(FontFace) > 0) {
      sprintf(url,"<font face=%s>\n",FontFace);
      fputs(url,fp_ou);
   }

   sprintf(url,"<body bgcolor=%s text=%s background='%s'>\n",BgColor,TxColor,BgImage);
   fputs(url,fp_ou);

   fputs("<center><table cellpadding=0 cellspacing=0>\n",fp_ou);

   if(strlen(LogoImage) > 0) {
      sprintf(url,"<tr><th align=left><img src='%s' border=0 align=absmiddle width=%s height=%s><font color=%s>%s</font>\n",LogoImage,Width,Height,LogoTextColor,LogoText);
      fputs(url,fp_ou);
   }

   sprintf(url,"<tr><th align=center><b><font color=%s size=+1>%s</font></b></th></tr>\n",TiColor,Title);
   fputs(url,fp_ou);

   sprintf(url,"<tr><td align=center bgcolor=%s><font size=%s>%s: %s</font></td></tr>\n",HeaderBgColor,FontSize,text[89],periodo);
   fputs(url,fp_ou);
   sprintf(url,"<tr><td align=center bgcolor=%s><font size=%s>%s %s %s</font></td></tr>\n",HeaderBgColor,FontSize,text[83],TopSitesNum,text[84]);
   fputs(url,fp_ou);
   fputs("</table></center>\n",fp_ou);

   fputs("<center><table cellpadding=0 cellspacing=1>\n",fp_ou);
   fputs("<tr><td></td></tr>\n",fp_ou);
   fputs("<tr><td></td></tr>\n",fp_ou);
   fputs("<tr><td></td></tr>\n",fp_ou);
   sprintf(url,"<tr><th></th><td>&nbsp;</td>								\
		<th bgcolor=%s><font size=%s color=%s>%s</font></th>					\
		<td>&nbsp;</td>										\
		<th bgcolor=%s><font size=%s color=%s>%s</font></th>					\
		<td>&nbsp;</td>										\
		<th bgcolor=%s><font size=%s color=%s>%s</font></th></tr>\n",				\
		HeaderBgColor,FontSize,HeaderColor,text[91],						\
		HeaderBgColor,FontSize,HeaderColor,text[92],						\
		HeaderBgColor,FontSize,HeaderColor,text[93]);
   fputs(url,fp_ou);

   regs=1;

   while(fgets(buf,sizeof(buf),fp_in)!=NULL) {
      if(regs>atoi(TopSitesNum))
         break;
      getword(nacc,buf,' ');
      getword(nbytes,buf,' ');
      getword(url,buf,' ');

      twork1=my_atoll(nacc);
      twork2=my_atoll(nbytes);

      sprintf(wwork1,"%s",fixnum(twork1));
      sprintf(wwork2,"%s",fixnum(twork2));

      sprintf(ourl,"<tr><td bgcolor=%s align=right><font size=%s>%d</font></td><td>&nbsp;</td><td align=right border=0 bgcolor=%s><font size=%s><a href=\"http://%s\">%s</font></td><td>&nbsp;</td><td bgcolor=%s align=right><font size=%s>%s</font></td><td>&nbsp;</td><td bgcolor=%s align=right><font size=%s>%s</font></td></tr>\n",TxBgColor,FontSize,regs,TxBgColor,FontSize,url,url,TxBgColor,FontSize,wwork1,TxBgColor,FontSize,wwork2);
      fputs(ourl,fp_ou);
      regs++;
   }

   fputs("</table></center>\n",fp_ou);

   if(strcmp(ShowSargInfo,"yes") == 0) {
      zdate(ftime, DateFormat);
      sprintf(ourl,"<br><br><center><font size=-2>%s <a href='%s'>%s-%s</a> %s %s</font></center>\n",text[108],URL,PGM,VERSION,text[109],ftime);
      fputs(ourl,fp_ou);
   }

   fputs("</html>\n",fp_ou);
   
   fclose(fp_in);
   fclose(fp_ou);

   return;

}
