/*
 * sarg - Squid user management log
 * Mar/98 - Pedro L Orso - orso@brturbo.com
 */

#include "include/conf.h"


void index_only(const char *dirname, int debug)
{

   DIR *dirp;
   struct dirent *direntp;
   char remove[MAXLEN];
  

   dirp = opendir(dirname);
   while ( (direntp = readdir( dirp )) != NULL ){
      if(strcmp(direntp->d_name,".") == 0 || strcmp(direntp->d_name,"..") == 0 || strcmp(direntp->d_name, "index.html") == 0)
         continue;
       
      sprintf(remove,"%s/%s",dirname,direntp->d_name);
      unlink(remove);
   }

   (void)closedir( dirp );
   (void)rewinddir( dirp );

   return;
}
