/*
 * sarg - Squid user management log
 * Mar/98 - Pedro L Orso - orso@brturbo.com
 */

#include "include/conf.h"


void language_load(char *language)
{

   FILE *fp_text;
   int record=0;

   sprintf(warea,"%s/languages/%s",SYSCONFDIR,language);

   if((fp_text=fopen(warea,"r"))==NULL) {
     fprintf(stderr, "SARG: (language) Cannot open language file: %s\n",warea);
     exit(1);
   }

   while(fgets(buf,MAXLEN,fp_text)!=NULL) {
//      if(strncmp(buf,"#",1) == 0)
//         continue;
      getword(warea,buf,'"');
      getword(warea,buf,'"');
      strcpy(text[record],warea);

      if(langcode)
      printf("%d %s\n",record,warea);

      record++;
   }

   fclose(fp_text);

   return;
}
