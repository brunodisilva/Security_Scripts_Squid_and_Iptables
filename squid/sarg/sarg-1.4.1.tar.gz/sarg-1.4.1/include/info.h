#define VERSION "1.4.1 25Apr2003"
#define PGM "sarg"
#define URL "http://web.onda.com.br/orso/index.html"
