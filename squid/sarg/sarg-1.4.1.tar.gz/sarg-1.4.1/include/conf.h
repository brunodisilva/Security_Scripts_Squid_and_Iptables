
#include "info.h"

#if HAVE_STDIO_H
#include <stdio.h>
#endif
#if HAVE_STDLIB_H
#include <stdlib.h>
#endif
#if HAVE_STRING_H
#include <string.h>
#endif
#if HAVE_STRINGS_H
#include <strings.h>
#endif
#if HAVE_SYS_TIME_H
#include <sys/time.h>
#endif
#if HAVE_TIME_H
#include <time.h>
#endif
#if HAVE_UNISTD_H
#include <unistd.h>
#endif
#if HAVE_SYS_DIRENT_H && !HAVE_DIRENT_H
#include <sys/dirent.h>
#endif
#if HAVE_DIRENT_H
#include <dirent.h>
#endif
#if HAVE_SYS_SOCKET_H
#include <sys/socket.h>
#endif
#if HAVE_NETDB_H
#include <netdb.h>
#endif
#if HAVE_TYPES_H
#include <types.h>
#endif
#if HAVE_NETINET_IN_H
#include <netinet/in.h>
#endif
#if HAVE_ARPA_INET_H
#include <arpa/inet.h>
#endif
#if HAVE_SYS_STAT_H
#include <sys/stat.h>
#endif
#if HAVE_CTYPE_H
#include <ctype.h>
#endif

#define MAXLEN 8192
long long int my_atoll (const char *nptr);

FILE *fp_tt; 

char buf[8192];
char url[8192];
char urly[8192];
char user[MAXLEN];
char msg[1024];
char per_hour[128];
char tmp3[MAXLEN];
char tmp4[MAXLEN];
char tmp5[MAXLEN];
char tmp6[MAXLEN];
char parse_out[MAXLEN];
char arqtt[MAXLEN];
char html[MAXLEN];
char datestimes[MAXLEN];
char ConfigFile[MAXLEN];
char href[MAXLEN];
char href2[MAXLEN];
char df[20];
char ltext110[50];
char LastLog[5];
char RemoveTempFiles[4];
char ReplaceIndex[256];
char Index[5];
char OverwriteReport[4];
char RecordsWithoutUser[20];
char UseComma[4];
char MailUtility[6];
char TopSitesNum[5];
char TopUsersNum[5];
char ExcludeCodes[256];
char TopsitesSortField[15];
char TopsitesSortType[5];
char ReportType[255];
char UserTabFile[255];
char warea[MAXLEN];
char name[MAXLEN];
char LongUrl[4];
char Ip2Name[5];
char language[255];
char AccessLog[MAXLEN];
char Title[MAXLEN];
char BgColor[MAXLEN];
char BgImage[MAXLEN];
char TxColor[MAXLEN];
char TxBgColor[MAXLEN];
char TiColor[MAXLEN];
char LogoImage[MAXLEN];
char LogoText[MAXLEN];
char LogoTextColor[MAXLEN];
char Width[MAXLEN];
char Height[MAXLEN];
char FontFace[MAXLEN];
char HeaderColor[MAXLEN];
char HeaderBgColor[MAXLEN];
char FontSize[MAXLEN];
char PasswdFile[MAXLEN];
char TempDir[MAXLEN];
char OutputDir[MAXLEN];
char OutputEmail[MAXLEN];
char TopuserSortField[30];
char UserSortField[30];
char TopuserSortOrder[10];
char UserSortOrder[10];
char UserAgentLog[255];
char ExcludeHosts[255];
char ExcludeUsers[255];
char DateFormat[2];
char PerUserLimitFile[255];
char PerUserLimit[20];
char UserIp[5];
char MaxElapsed[255];
char datetimeby[10];
char csort[255];
char CharSet[255];
char UserInvalidChar[255];
char Privacy[10];
char PrivacyString[255];
char PrivacyStringColor[30];
char IncludeUsers[MAXLEN];
char ExcludeString[MAXLEN];
char SuccessfulMsg[5];
char TopUserFields[255];
char UserReportFields[255];
char DataFile[MAXLEN];
char DataFileDelimiter[3];
char DataFileFields[MAXLEN];
char SiteUserTimeDateType[10];
char ShowReadStatistics[5];
char IndexSortOrder[5];
char SquidGuardLogPath[MAXLEN];
char ShowSargInfo[5];
char ParsedOutputLog[MAXLEN];
char ParsedOutputLogCompress[255];
char DisplayedValues[20];
char hbc1[30];
char hbc2[30];
char hbc3[30];
char hbc4[30];
char hbc5[30];
char hbc6[30];
char hbc7[30];
char hbc8[30];
char hbc9[30];
char hbc10[30];

char *excludecode;
char *userfile;
char *str;
char *str2;
char text[200][255];
char val1[255];
char val2[255];
char val3[255];
char val4[255];
char val5[255];
char val6[255];
char val7[255];
char val8[255];
char val9[255];
char val10[255];
char val11[255];
char wwork1[255];
char wwork2[255];
char wwork3[255];
char mask[MAXLEN];
char httplink[MAXLEN];
char html_old[MAXLEN];
char siteind[MAXLEN];
char test[1];
char user2[MAXLEN];
int  excode;
int  denied_count;
int  authfail_count;
int  squidguard_count;
int  limit_flag;
int  z1, z2;
int  ttopen;
int  ind2;
int  dataonly;
int  langcode;

long long int twork;
long long int twork2;

typedef struct
{ int list[ 24 ];
  int len;
} numlist;

int getnumlist( char *, numlist *, const int, const int );
