/*
 * sarg - Squid user management log
 * Mar/98 - Pedro L Orso - orso@brturbo.com
 */

#include "include/conf.h"

void usage(char *prog)
{
  fprintf(stderr, "%s: %s [%s...]\n", prog,text[39],text[40]);
  fprintf(stderr, "%5s-a %s\n"," ",text[23]);
  fprintf(stderr, "%5s-b %s\n"," ",text[71]);
  fprintf(stderr, "%5s-c %s\n"," ",text[69]);
  fprintf(stderr, "%5s-d %s dd/mm/yyyy-dd/mm/yyyy\n"," ",text[24]);
  fprintf(stderr, "%5s-e %s (%s)\n"," ",text[41],text[42]);
  fprintf(stderr, "%5s-f %s (%s/sarg.conf)\n"," ",text[70],SYSCONFDIR);
  fprintf(stderr, "%5s-g %s [e=%s -> dd/mm/yy, u=%s -> mm/dd/yy]\n"," ",text[25],text[26],text[27]);
  fprintf(stderr, "%5s-h Help (this...)\n"," ");
  fprintf(stderr, "%5s-i %s\n"," ",text[43]);
  fprintf(stderr, "%5s-l %s\n"," ",text[37]);
  fprintf(stderr, "%5s-n %s\n"," ",text[65]);
  fprintf(stderr, "%5s-o %s\n"," ",text[38]);
  fprintf(stderr, "%5s-p %s (%s)\n"," ",text[29],text[44]);
  fprintf(stderr, "%5s-s %s [Eg. www.microsoft.com, www.netscape.com]\n"," ",text[30]);
  fprintf(stderr, "%5s-t %s [HH, HH:MM, HH:MM:SS]\n"," ",text[31]);
  fprintf(stderr, "%5s-u %s\n"," ",text[32]);
  fprintf(stderr, "%5s-w %s\n"," ",text[34]);
  fprintf(stderr, "%5s-x %s\n"," ",text[36]);
  fprintf(stderr, "%5s-z %s\n"," ",text[35]);
  fprintf(stderr, "%5s-convert %s\n"," ",text[76]);
  fprintf(stderr, "%5s-split %s\n"," ",text[77]);
  fprintf(stderr, "\n\t%s-%s %s Pedro Lineu Orso - orso@brturbo.com\n",PGM,VERSION,text[78]);
  fprintf(stderr, "\thttp://web.onda.com.br/orso/index.html\n\n");

  return;
}
